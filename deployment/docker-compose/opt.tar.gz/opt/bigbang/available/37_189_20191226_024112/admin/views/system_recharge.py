# -*- coding: utf-8 -*-

import json
import re

from django.views.decorators.http import require_POST, require_GET
from common.system_recharge.db import create_system_trans, list_all_detail
from common.system_recharge.model import TYPE
from common.transaction.model import TRANSACTION_TYPE
from common.utils.api import get_client_ip, get_client_ua, get_operating_system
from common.admin.db import get_nickname_by_id
from common.utils.tz import utc_to_local_str
from common.utils.decorator import response_wrapper
from common.utils.api import token_required, mask_string
from common.utils.currency import convert_fen_to_yuan
from common.utils import exceptions as err
from common.utils.export import gen_filename, redirect_to_file


@require_GET
@response_wrapper
@token_required
def sys_recharge(req):
    query_dct = req.GET.dict()
    for_user = query_dct.get('for')
    user_id = query_dct.get('user_id')
    re_type = int(query_dct.get('type', 0))
    export = query_dct.pop('$export', None)
    if export:
        # 导出运营上分记录
        filename = gen_filename('operate_add_coin')
        header = ['id', 'user_name', 'user_id', 'amount', 'created_at', 'operator', 'note']
        cn_header = [u'上分单号', u'用户昵称', u'用户ID', u'上分金额', u'上分时间', u'操作人', u'备注']
    if for_user == 'kefu' and not user_id:
        query_dct['user_id'] = '0'
    if not re_type:
        query_dct['type'] = '{"$neq": %s}' % TYPE.SYSTEM_CHASE
    items, total_count = list_all_detail(query_dct)

    resp_items = []
    for item in items:
        data = item.as_dict()
        if data.get('user_name'):
            if re.match(r'\d{13}', data['user_name']) and data['user_name'].startswith('86'):
                data['user_name'] = mask_string(data['user_name'])
        data.pop('batch_id')
        data['created_at'] = utc_to_local_str(data['created_at'])
        data['updated_at'] = utc_to_local_str(data['updated_at'])
        data['amount'] = convert_fen_to_yuan(data['amount'])
        if data.get('device'):
            data['device'] = get_operating_system(data['device'])
        if export:
            resp_items.append([data.get(x, '-') for x in header])
        else:
            resp_items.append(data)

    if export:
        return redirect_to_file(resp_items, cn_header, filename)

    return {'list': resp_items, 'page': query_dct.get('$page', 1),
            'size': len(resp_items), 'total_count': total_count}


@require_POST
@response_wrapper
@token_required
def create_sys_recharge(req, trans_id):
    ip = get_client_ip(req)
    device = get_client_ua(req)
    admin_id = req.user_id
    operator = get_nickname_by_id(admin_id)
    if not req.body:
        raise err.ParamError(u'参数错误')
    data = json.loads(req.body)
    params = data.get('detail_info', 0)
    note = data.get('note', 0)
    black_type = data.get('black_type', None)
    enable_withdraw = int(data.get('enable_withdraw', False))
    trans_type = int(data.get('type', True))
    if enable_withdraw not in [0, 1]:
        raise err.ParamError(u'参数错误')
    create_system_trans(trans_id, params, operator, note, admin_id, ip, device,
                        trans_type, black_type, enable_withdraw)

    return {}