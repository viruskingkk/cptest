# -*- coding: utf-8 -*-

from django.views.decorators.http import require_GET
from common.utils.api import token_required
from common.utils.decorator import response_wrapper
from common.coupon.db import filter_coupon


@require_GET
@response_wrapper
@token_required
def get_coupons(req):
    query_dct = req.GET.dict()
    user_id = query_dct.get('user_id')
    coupon_type = query_dct.get('coupon_type')
    status = query_dct.get('status')
    source = query_dct.get('source')
    effect_time = query_dct.get('effect_time')
    use_time = query_dct.get('use_time')
    page = int(query_dct.get('$page', 1))
    size = int(query_dct.get('$size', 15))

    return filter_coupon(user_id, coupon_type, status, source, effect_time, use_time, page, size)