# -*- coding: utf-8 -*-
import json
import logging
import time
from datetime import datetime
from django.views.generic import TemplateView
from django.utils.encoding import smart_unicode
from django.utils.decorators import method_decorator
from django.views.decorators.http import require_POST
from common.coupon.model import AccountCoupon
from common.coupon import db
from common.utils.decorator import response_wrapper
from common.utils.api import token_required, check_params
from common.utils.tz import utc_to_local_str
from common.utils import tracker, maestro_tracker

_LOGGER = logging.getLogger(__name__)


class CouponTemplateView(TemplateView):
    def get(self, req):
        query_dct = req.GET.dict()
        items, total_count = db.list_coupon_template(query_dct)

        resp_items = []
        for item in items:
            item.updated_at = utc_to_local_str(item.updated_at)
            item.created_at = utc_to_local_str(item.created_at)
            resp_items.append(item.as_dict())

        return {'list': resp_items, 'page': query_dct.get('$page', 1),
                'size': len(resp_items), 'total_count': total_count}

    def post(self, req):
        query_dct = json.loads(req.body)
        db.upsert_coupon_template(query_dct)
        return {}

    @method_decorator(response_wrapper)
    @method_decorator(token_required)
    def dispatch(self, *args, **kwargs):
        return super(CouponTemplateView, self).dispatch(*args, **kwargs)


class SingleCouponTemplateView(TemplateView):
    def get(self, req, coupon_template_id):
        t = db.get_coupon_template(id=int(coupon_template_id))
        t.updated_at = utc_to_local_str(t.updated_at)
        t.created_at = utc_to_local_str(t.created_at)
        return t.as_dict()

    def post(self, req, coupon_template_id):
        return self.put(req, coupon_template_id)

    def put(self, req, coupon_template_id):
        query_dct = json.loads(smart_unicode(req.body))
        query_dct['id'] = int(coupon_template_id)
        db.upsert_coupon_template(query_dct)
        return {}

    @method_decorator(response_wrapper)
    @method_decorator(token_required)
    def dispatch(self, *args, **kwargs):
        return super(SingleCouponTemplateView, self).dispatch(*args, **kwargs)


@require_POST
@response_wrapper
@token_required
def manual_create_coupon(req):
    query_dct = json.loads(req.body)
    if 'user_id' in query_dct:
        # for single user
        check_params(query_dct, ('user_id', 'template_id'), {"count": 1})
        template = db.get_coupon_template(query_dct['template_id'])
        for _ in range(query_dct['count']):
            coupon = AccountCoupon.create_from_template(
                template, query_dct['user_id'], by=req.user_id)
            coupon.save()
            log_data = coupon.as_dict()
            log_data.update({
                'from': u'客服添加',
                'by': req.user_id
            })
            tracker.track_coupon(log_data, action='create')
            try:
                coupon_type = template.title or '' + template.desc or ''
                maestro_tracker.track_coupon_birth(coupon.id, query_dct['user_id'], coupon_type, template.price,
                                                   int(time.mktime(datetime.now().timetuple())))
            except:
                _LOGGER.exception('fail to track coupon birth fail')
            AccountCoupon.start_expire_timer(coupon.id, coupon.expire_ts)

        return coupon.as_dict()
    elif 'uids' in query_dct:
        check_params(query_dct, ('uids', 'coupons'))
        resp_items = []
        for template_id, count in query_dct['coupons'].iteritems():
            template = db.get_coupon_template(template_id)
            for uid in query_dct['uids']:
                for _ in range(count):
                    coupon = AccountCoupon.create_from_template(
                        template, uid, by=req.user_id)
                    coupon.save()
                    resp_items.append(coupon.as_dict())
                    AccountCoupon.start_expire_timer(
                        coupon.id, coupon.expire_ts)
                    log_data = coupon.as_dict()
                    log_data.update({
                        'from': u'客服添加',
                        'by': req.user_id
                    })
                    tracker.track_coupon(log_data, action='create')
                    try:
                        coupon_type = template.title or '' + template.desc or ''
                        maestro_tracker.track_coupon_birth(coupon.id, query_dct['user_id'], coupon_type, template.price,
                                                           int(time.mktime(datetime.now().timetuple())))
                    except:
                        _LOGGER.exception('fail to track coupon birth fail')
        return resp_items

    return {}
