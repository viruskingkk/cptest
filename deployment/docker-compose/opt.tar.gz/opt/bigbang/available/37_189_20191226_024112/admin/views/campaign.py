# -*- coding: utf-8 -*-

import json
import logging

from django.views.decorators.http import require_GET

from common.utils.decorator import response_wrapper
from common.utils.api import token_required
from common.campaign.db.trans_detail import get_data_detail
from common.utils.tz import utc_to_local_str

_LOGGER = logging.getLogger(__name__)


@require_GET
@response_wrapper
@token_required
def get_campaign_detail(req):
    query_dct = req.GET.dict()
    campaign = query_dct.get('campaign_name', 'register')
    page = int(query_dct.get('$page', 1))
    size = int(query_dct.get('$size', 15))
    user_id = query_dct.get('user_id')
    create_time = query_dct.get('create_time')
    datas = get_data_detail(campaign, user_id, create_time, page, size)
    if campaign in ['recharge', 'red_envelope', 'spring_festival', 'recharge_iphone', 'ranking']:
        datas = handler_campaign(campaign, datas)
    return datas


CAMPAIGN_NAME= {
    'recharge': u'充值送',
    'red_envelope': u'双旦活动',
    'spring_festival': u'春节福利',
    'recharge_iphone': u'充值送iPhone',
    'ranking': u'财富风云榜'
}


def handler_campaign(campaign, datas):
    data_list = []
    if datas['data']:
        for item in datas['data']:
            user_id = item.user_id
            if not user_id:
                continue
            if campaign == 'recharge_iphone':
                amount = None
            elif campaign in ['red_envelope', 'spring_festival', 'ranking']:
                amount = item.amount
            else:
                amount = round(item.price, 2)
            created_at = utc_to_local_str(item.created_at)
            data_list.append({'campaign_name': CAMPAIGN_NAME.get(campaign), 'user_id': user_id,
                              'award_price': amount, 'created_at': created_at})
    datas['data'] = data_list
    return datas