# -*- coding: utf-8 -*-
from django.conf.urls import patterns, url

from admin.report.daily import ShippingReportView, get_daily_report, get_activity_report, get_profit_report, \
    get_recharge_report, get_resource_report, get_tactics_report, get_top100_list, get_lottery_report, \
    get_interval_recharge, get_ks_report, get_fruit_report, get_bull_report, get_kfc_report, get_game_list_report, \
    get_metis_report
from admin.report.overview import get_user_overview, get_cost_overview, get_channels
from admin.stats.account import get_account_info, get_recharge_list, get_coupon_list, get_transaction_list, \
    search_black_account, update_blcak_account, get_account_chn_ip
from admin.stats.pay import get_pay_list, get_pay_list_by_user_id
from admin.stats.vips import MissedVipsView, BackVipsView, ActiveVipsView
from admin.views.abtest import ABTestView, SingleABTestView
from admin.views.coupon import CouponTemplateView, SingleCouponTemplateView, manual_create_coupon
from admin.views.feedback import FeedBackView, reply_feedback
from admin.views.game import get_bull_list, BullPartView, fresh_bull_part, get_lottery_wheel_list, GameLotteryPartView, \
    fresh_lottery_part, get_casino_records, get_fruit_list, get_fruit_part, get_game_list
from admin.views.lottery import ActivityView, ActivityOrderView, refund_orders
from admin.views.notify import (
    NotificationView, SingleNotificationView, XingeNotificationView, SingleXingeNotificationView,
    SingleInAppAnnouncementView, InAppAnnouncementView)
from admin.views.order import OrderView, approve_order
from admin.views.preset import (PresetView, SinglePresetView,
                                SingleBannerView, BannerView,
                                SingleShortcutView, ShortcutView,
                                SingleDiscoveryView, DiscoveryView,
                                SingleLoadingView, LoadingView,
                                PayView, SinglePayView,
                                RewardView, SingleRewardView,
                                RecommendView, SingleRecommendView,
                                FloatIconView, SingleFloatIconView,
                                LotteryView, SingleLotteryView,
                                TabView, SingleTabView, set_chn_links, get_chn_links, switch_lottery, ProfitRateView,
                                SingleProfitRateView)
from admin.views.recharge import RechargeView, SingleRechargeView, revert_apply, get_self_recharge, set_self_recharge, \
    RechargeWechatView
from admin.views.show import ShowView, SingleShowView
from admin.views.uptoken import get_uptoken, delete_image
from admin.views.user import (UserView, SingleUserView, PermissionView,
                              SinglePermissionView, login, logout, list_records, black_user, get_user_id,
                              reset_user_phone, unbind_financial_account)
from admin.views.withdraw import (WithdrawView, SingleWithdrawView, WithdrawAccountView,
                                  batch_check_withdraw, check_withdraw, get_black_uids,
                                  set_black_uids, get_limit, set_limit, query_withdraw_duplicate,
                                  get_withdraw_channels, set_withdraw_channels, get_black_modification,
                                  get_user_black_modification, get_black_info)
from admin.views.system_recharge import sys_recharge, create_sys_recharge
from admin.views.third_game import (MetisOrderView, MetisGameView, MetisGamePartView, get_third_game_trans,
                                    get_ares_game_by_user)
from admin.views.metis_risk import MetisConsoleView, MetisPumpingView,  metis_order_manage
from admin.views.transaction import create_pay_submit
from admin.views.metis_risk import (MetisDailyBetView, MetisForbiddenView,
                                    MetisPassView)
from admin.views.campaign import get_campaign_detail

urlpatterns = patterns(
    '',
    # user
    url(r'^user/login/?$', login),
    url(r'^user/logout/?$', logout),
    url(r'^user/?$', UserView.as_view()),
    url(r'^user/(?P<user_id>\d+)/?$', SingleUserView.as_view()),
    url(r'^permission/?$', PermissionView.as_view()),
    url(r'^permission/(?P<perm_id>\d+)/?$', SinglePermissionView.as_view()),
    url(r'^record/?$', list_records),
    url(r'^user/black/?$', black_user),
    url(r'^user/reset_user_phone/?$', reset_user_phone),
    url(r'^user/financial_account/unbind/?$', unbind_financial_account),
    # 根据user_name或phone 查询user_id
    url(r'^get_user_id/?$', get_user_id),
    # template
    # order
    url(r'^order/charge_card/(?P<order_id>\d+)/?$', 'admin.views.card.get_charge_card'),
    # shipping
    url(r'^order/status/(?P<ship_id>\d+)/?$', 'admin.views.order.refresh_ship_status'),
    # up token
    url(r'^uptoken/?$', get_uptoken),
    url(r'^image/delete/?$', delete_image),
    # show
    url(r'^show/?$', ShowView.as_view()),
    url(r'^show/(?P<show_id>\d+)/?$', SingleShowView.as_view()),
    # preset data
    url(r'^preset/?$', PresetView.as_view()),
    url(r'^preset/(?P<preset_id>\d+)/?$', SinglePresetView.as_view()),
    url(r'^preset/shortcut/?$', ShortcutView.as_view()),
    url(r'^preset/shortcut/(?P<shortcut_id>\d+)/?$', SingleShortcutView.as_view()),
    url(r'^preset/banner/?$', BannerView.as_view()),
    url(r'^preset/banner/(?P<banner_id>\d+)/?$', SingleBannerView.as_view()),
    url(r'^preset/discovery/?$', DiscoveryView.as_view()),
    url(r'^preset/discovery/(?P<discovery_id>\d+)/?$', SingleDiscoveryView.as_view()),
    url(r'^preset/loading/?$', LoadingView.as_view()),
    url(r'^preset/loading/(?P<loading_id>\d+)/?$', SingleLoadingView.as_view()),
    url(r'^preset/pay/?$', PayView.as_view()),
    url(r'^preset/pay/(?P<pay_id>\d+)/?$', SinglePayView.as_view()),
    url(r'^preset/reward/?$', RewardView.as_view()),
    url(r'^preset/reward/(?P<reward_id>\d+)/?$', SingleRewardView.as_view()),
    url(r'^preset/recommend/?$', RecommendView.as_view()),
    url(r'^preset/recommend/(?P<recommend_id>\d+)/?$', SingleRecommendView.as_view()),
    url(r'^preset/float_icon/?$', FloatIconView.as_view()),
    url(r'^preset/float_icon/(?P<float_icon_id>\d+)/?$', SingleFloatIconView.as_view()),
    url(r'^preset/lottery/?$', LotteryView.as_view()),
    url(r'^preset/lottery/(?P<lottery_id>\d+)/?$', SingleLotteryView.as_view()),
    url(r'^preset/lottery/(?P<lottery_type>\d+)/switch/(?P<off>\d+)/?$', switch_lottery),
    url(r'^preset/tab/?$', TabView.as_view()),
    url(r'^preset/tab/(?P<tab_id>\d+)/?$', SingleTabView.as_view()),
    url(r'^preset/profit_rate/?$', ProfitRateView.as_view()),
    url(r'^preset/profit_rate/(?P<profit_rate_id>\d+)/?$', SingleProfitRateView.as_view()),
    # abtest
    url(r'^abtest/?$', ABTestView.as_view()),
    url(r'^abtest/(?P<abtest_id>\d+)/?$', SingleABTestView.as_view()),
    # feedback
    url(r'^feedback/uninstall/report/?$',
        'admin.stats.report.get_uninstall_report'),
    url(r'^notification/?$', NotificationView.as_view()),
    url(r'^notification/(?P<notify_id>\d+)/?$', SingleNotificationView.as_view()),
    url(r'^in_app_announcement/?$', InAppAnnouncementView.as_view()),
    url(r'^in_app_announcement/(?P<in_app_announcement_id>\d+)/?$', SingleInAppAnnouncementView.as_view()),
    # 信鸽推送
    url(r'^xinge_notification/?$', XingeNotificationView.as_view()),
    url(r'^xinge_notification/(?P<notify_id>\d+)/?$', SingleXingeNotificationView.as_view()),
    # for mobile console
    url(r'^stats/?$', "admin.stats.total.get_stats"),
    url(r'^stats/recharge/?$', "admin.stats.total.get_recharge_list"),
    url(r'^stats/limit/?$', "admin.stats.total.set_limit"),
    url(r'^account/(?P<account_id>\d+)/?$', get_account_info),
    url(r'^account/(?P<account_id>\d+)/recharge/?$', get_recharge_list),
    url(r'^account/(?P<account_id>\d+)/win/?$', "admin.stats.account.get_win_list"),
    url(r'^account/(?P<account_id>\d+)/coupon/?$', get_coupon_list),
    url(r'^account/(?P<account_id>\d+)/transaction/?$', get_transaction_list),
    url(r'^coupon/?$', "admin.stats.coupon.get_coupons"),
    url(r'^coupon/add/?$', manual_create_coupon),
    url(r'^account/chn_ip/?$', get_account_chn_ip),
    #  black user
    url(r'^account/get_black_account/?$', search_black_account),
    url(r'^account/set_black_account/?$', update_blcak_account),
    # for web console
    url(r'^stats/coupon/?$', get_coupon_list),
    url(r'^stats/coupon/?$', "admin.stats.coupon.get_coupon_list"),
    url(r'^stats/pay/?$', get_pay_list),
    url(r'^stats/pay_by_user_id/?$', get_pay_list_by_user_id),
    url(r'^stats/vips/missed/?$', MissedVipsView.as_view()),
    url(r'^stats/vips/back/?$', BackVipsView.as_view()),
    url(r'^stats/vips/active/?$', ActiveVipsView.as_view()),
    # for report
    url(r'^report/activity/?$', get_activity_report),
    url(r'^report/overview/user/?$', get_user_overview),
    url(r"^report/overview/cost/?$", get_cost_overview),
    url(r"^report/channels/?$", get_channels),
    url(r'^report/daily/?$', get_daily_report),
    url(r'^report/ks/?$', "admin.report.daily.get_ks_report"),
    url(r'^report/daily/profit/?$', get_profit_report),
    url(r'^report/daily/recharge/?$', get_recharge_report),
    url(r'^report/interval/recharge/?$', get_interval_recharge),
    url(r'^report/daily/resource/(?P<resource>[^/]+)/?$', get_resource_report),
    url(r'^report/daily/tactics/?$', get_tactics_report),
    url(r'^report/daily/shipping/?$', ShippingReportView.as_view()),
    url(r'^report/top100/?$', get_top100_list),
    url(r'^report/top100/bigbang/?$', 'admin.report.daily.get_top_bigbang'),
    url(r'^report/lottery/?$', get_lottery_report),
    url(r'^report/ks/?$', get_ks_report),
    url(r'^report/fruit/?$', get_fruit_report),
    url(r'^report/bull/?$', get_bull_report),
    url(r'^report/kfc/?$', get_kfc_report),
    url(r'^report/fresh/?$', 'admin.report.daily.fresh'),
    url(r'^report/fresh_bull/?$', 'admin.report.daily.fresh_bull'),
    url(r'^report/fresh_fruit/?$', 'admin.report.daily.fresh_fruit'),
    url(r'^report/fresh_lottery/?$', 'admin.report.daily.fresh_lottery'),
    url(r'^report/fresh_kfc/?$', 'admin.report.daily.fresh_kfc'),
    # withdraw
    url(r'^withdraw/?$', WithdrawView.as_view()),
    url(r'^withdraw/(?P<withdraw_id>\d+)/?$', SingleWithdrawView.as_view()),
    url(r'^withdraw/check/?$', batch_check_withdraw),
    url(r'^withdraw/check/(?P<withdraw_id>\d+)/(?P<check_status>\d+)/?$', check_withdraw),
    url(r'^withdraw/get_limit/?$', get_limit),
    url(r'^withdraw/set_limit/?$', set_limit),
    url(r'^withdraw/get_available_channels/?$', get_withdraw_channels),
    url(r'^withdraw/set_available_channels/?$', set_withdraw_channels),
    url(r'^withdraw/(?P<withdraw_type>\d+)/(?P<withdraw_no>[^/]+)/duplicate/?$', query_withdraw_duplicate),
    url(r'^withdraw/account/?$', WithdrawAccountView.as_view()),
    # 订单
    url(r'^order/?$', OrderView.as_view()),
    url(r'^order/(?P<order_id>\d+)/(?P<status>\d+)/?$', approve_order),
    # 菜种/订单 
    url(r'^activity/(?P<activity_type>\d+)/?$', ActivityView.as_view()),
    url(r'^activity/(?P<activity_type>\d+)/order/?$', ActivityOrderView.as_view()),
    url(r'^activity/(?P<activity_type>\d+)/order/refund/?$', refund_orders),
    url(r'^activity/(?P<activity_type>\d+)/order/(?P<order_id>\d+)/fresh/?$', 'admin.views.lottery.fresh_order'),
    # 红包模版
    url(r'^coupon/template/?$', CouponTemplateView.as_view()),
    url(r'^coupon/template/(?P<coupon_template_id>\d+)/?$', SingleCouponTemplateView.as_view()),
    # 用户反馈
    url(r'^feedback/?$', FeedBackView.as_view()),
    url(r'^feedback/reply/?$', reply_feedback),
    # for market links
    url(r'^market/set/(?P<platform>[^/]+)/?$', set_chn_links),
    url(r'^market/get/(?P<platform>[^/]+)/?$', get_chn_links),
    # game开奖查询统一入口
    url(r'^game_list/?$', get_game_list),
    # for game bull
    url(r'^bull/?$', get_bull_list),
    url(r'^bull_part/?$', BullPartView.as_view()),
    url(r'^bull_part/(?P<part_id>\d+)/fresh/?$', fresh_bull_part),
    # for game fruit
    url(r'^fruit/?$', get_fruit_list),
    url(r'^fruit_part/?$', get_fruit_part),
    # for game lottery
    url(r'^lottery/?$', get_lottery_wheel_list),
    url(r'^lottery_part/?$', GameLotteryPartView.as_view()),
    url(r'^lottery_part/(?P<part_id>\d+)/fresh/?$', fresh_lottery_part),
    # for recharge
    url(r'^recharge/apply/?$', RechargeView.as_view()),
    url(r'^recharge/apply/(?P<apply_id>\d+)/(?P<pay_amount>\d+)/?$', SingleRechargeView.as_view()),
    url(r'^recharge/revert/(?P<apply_id>\d+)/?$', revert_apply),
    url(r'^recharge/checkstatus/?$', get_self_recharge),
    url(r'^recharge/set/(?P<status>\d+)/?$', set_self_recharge),
    url(r'^recharge/wechat/?$', RechargeWechatView.as_view()),
    # for withdraw black
    url(r'^withdraw/black/get/?$', get_black_uids),
    url(r'^withdraw/black/set/?$', set_black_uids),
    url(r'^withdraw/black_modification/get/?$', get_black_modification),
    url(r'^withdraw/user_black_modification/get/?$', get_user_black_modification),
    url(r'^withdraw/black_info/get/?$', get_black_info),
    # for game strategy
    url(r'^strategy/game/set/?$', 'admin.views.strategy.set_game_strategy'),
    url(r'^strategy/game/get/?$', 'admin.views.strategy.get_game_strategy'),
    # for super strategy
    url(r'^super/strategy/black/(?P<game>[^/]+)/get/?$', 'admin.views.strategy.get_super_black_uids'),
    url(r'^super/strategy/white/(?P<game>[^/]+)/get/?$', 'admin.views.strategy.get_super_white_uids'),
    url(r'^super/strategy/black/(?P<game>[^/]+)/set/?$', 'admin.views.strategy.set_super_black_uid'),
    url(r'^super/strategy/white/(?P<game>[^/]+)/set/?$', 'admin.views.strategy.set_super_white_uid'),
    url(r'^super/strategy/black/(?P<game>[^/]+)/remove/(?P<uid>\d+)/?$', 'admin.views.strategy.remove_super_black_uid'),
    url(r'^super/strategy/white/(?P<game>[^/]+)/remove/(?P<uid>\d+)/?$', 'admin.views.strategy.remove_super_white_uid'),
    #  for game all
    url(r'^casino_records/?$', get_casino_records),
    url(r'^game_list_report/?$', get_game_list_report),
    # for system recharge
    url(r'^system_recharge/?$', sys_recharge),
    url(r'^system_recharge/create/(?P<trans_id>[^/]+)/?$', create_sys_recharge),

    # 第三方游戏相关
    url(r'^metis_order/?$', MetisOrderView.as_view()),
    url(r'^metis_game/?$', MetisGameView.as_view()),
    url(r'^metis_game_part/?$', MetisGamePartView.as_view()),
    url(r'^metis_report/?$', get_metis_report),
    url(r'^metis_console/?$', MetisConsoleView.as_view()),
    url(r'^metis_pumping/?$', MetisPumpingView.as_view()),
    url(r'^metis_order_manage/?$', metis_order_manage),
    url(r'^metis_daily_bet/?$', MetisDailyBetView.as_view()),
    url(r'^metis_forbidden/?$', MetisForbiddenView.as_view()),
    url(r'^metis_pass/?$', MetisPassView.as_view()),

    url(r'^third_game_transaction/?$', get_third_game_trans),
    url(r'^ares_game_report/?$', get_ares_game_by_user),

    url(r'^pay/submit/?$', create_pay_submit),
    # 活动相关
    url(r'^campaign_detail/?$', get_campaign_detail),
)
