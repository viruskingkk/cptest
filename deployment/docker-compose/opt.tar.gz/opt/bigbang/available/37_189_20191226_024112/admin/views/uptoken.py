# -*- coding: utf-8 -*-

from django.conf import settings

from django.views.decorators.http import require_GET, require_POST
from common.third.image import get_token, delete_data_by_url
from common.utils import JsonResponse
from common.utils.api import token_required, check_auth
from common.utils.decorator import response_wrapper


@require_GET
def get_uptoken(req):
    check_auth(req)
    bucket = req.GET.get('bucket', settings.ADMIN_BUCKET_NAME)
    if bucket == 'avatar':
        bucket = settings.USER_BUCKET_NAME
    token = get_token(bucket)

    return JsonResponse({'uptoken': token})


@require_POST
@response_wrapper
@token_required
def delete_image(req):
    urls = req.POST.get('urls')
    urls = urls.split(',')
    delete_data_by_url(urls)

    return {}
