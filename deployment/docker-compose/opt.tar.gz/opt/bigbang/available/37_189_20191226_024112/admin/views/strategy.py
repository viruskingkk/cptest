# -*- coding: utf-8 -*-

import re
import json
import logging

from django.views.generic import TemplateView
from django.utils.encoding import smart_unicode
from django.utils.decorators import method_decorator
from django.views.decorators.http import require_POST, require_GET

from common.cache import bull_cache, redis_cache
from common.utils import exceptions as err
from common.utils.decorator import response_wrapper
from common.utils.api import token_required, check_params


_LOGGER = logging.getLogger(__name__)

_SUPPORT_GAME = ('bull', )


@require_POST
@response_wrapper
@token_required
def set_super_black_uid(req, game):
    if game not in _SUPPORT_GAME:
        raise err.ParamError('game not support')
    param_dct = json.loads(smart_unicode(req.body))
    check_params(param_dct, ('uid', 'times', 'ratio', 'ttl'))
    bull_cache.set_super_black_uid(int(param_dct['uid']),
        int(param_dct['times']), float(param_dct['ratio']), int(param_dct['ttl']))
    _LOGGER.info('set_super_black_uid, admin_id:%s, game:%s, param_dct:%s',
        req.user_id, game, param_dct)
    return {'id': param_dct['uid']}


@require_POST
@response_wrapper
@token_required
def set_super_white_uid(req, game):
    if game not in _SUPPORT_GAME:
        raise err.ParamError('game not support')
    param_dct = json.loads(smart_unicode(req.body))
    check_params(param_dct, ('uid', 'times', 'ratio', 'ttl'))
    bull_cache.set_super_white_uid(int(param_dct['uid']),
        int(param_dct['times']), float(param_dct['ratio']), int(param_dct['ttl']))
    _LOGGER.info('set_super_white_uid, admin_id:%s, game:%s, param_dct:%s',
        req.user_id, game, param_dct)
    return {'id': param_dct['uid']}


@require_GET
@response_wrapper
@token_required
def get_super_black_uids(req, game):
    if game not in _SUPPORT_GAME:
        raise err.ParamError('game not support')
    l = bull_cache.get_super_black_uids()
    return {'list': l, 'page': 1, 'size': len(l),
            'stock': [], 'total_count': len(l)}


@require_GET
@response_wrapper
@token_required
def get_super_white_uids(req, game):
    if game not in _SUPPORT_GAME:
        raise err.ParamError('game not support')
    l = bull_cache.get_super_white_uids()
    return {'list': l, 'page': 1, 'size': len(l),
            'stock': [], 'total_count': len(l)}


@require_POST
@response_wrapper
@token_required
def remove_super_white_uid(req, game, uid):
    if game not in _SUPPORT_GAME:
        raise err.ParamError('game not support')
    bull_cache.remove_super_white_uid(int(uid))
    _LOGGER.info('remove_super_white_uid, admin_id:%s, game:%s, uid:%s',
        req.user_id, game, uid)
    return {'id': uid}


@require_POST
@response_wrapper
@token_required
def remove_super_black_uid(req, game, uid):
    if game not in _SUPPORT_GAME:
        raise err.ParamError('game not support')
    bull_cache.remove_super_black_uid(int(uid))
    _LOGGER.info('remove_super_black_uid, admin_id:%s, game:%s, uid:%s',
        req.user_id, game, uid)
    return {'id': uid}


STRATEGY_KEY = {
    'lucky:bull:pool_limit': 'bull',
    'lucky:bull:cheat_probability': 'bull',
    'lucky:bull:pool_up_limit': 'bull',
    'lucky:bull:cheat_up_probability': 'bull',
}


@require_POST
@response_wrapper
@token_required
def set_game_strategy(req):
    param_dct = json.loads(smart_unicode(req.body))
    check_params(param_dct, ('game_key', 'value', 'ttl'))
    game_key = param_dct['game_key']
    if game_key in STRATEGY_KEY:
        game = STRATEGY_KEY[game_key]
        redis_cache.set_game_strategy(game,
            game_key, param_dct['value'], param_dct['ttl'])
        return {}
    if game_key == 'lucky:bull:pool_award':
        redis_cache.set_pool_award(param_dct['value'])
    if game_key == 'lucky:bull:dailysum':
        redis_cache.set_daily_sum(param_dct['value'])
    raise err.PermissionError()


@require_GET
@response_wrapper
@token_required
def get_game_strategy(req):
    l = {}
    for game_key in STRATEGY_KEY:
        game = STRATEGY_KEY[game_key]
        value, ttl = redis_cache.get_game_strategy(game, game_key)
        l[game_key] = {'value': value, 'ttl': ttl}
    # add pool
    pool_award, pool_ttl = redis_cache.get_pool_award()
    dailysum, dailysum_ttl = redis_cache.get_daily_sum()
    ratio = pool_award / dailysum
    l['lucky:bull:pool_award'] = {'value': pool_award, 'ttl': pool_ttl, 'ratio': ratio}
    l['lucky:bull:dailysum'] = {'value': dailysum, 'ttl': dailysum_ttl}
    return {'dict': l, 'page': 1, 'size': len(l),
            'stock': [], 'total_count': len(l)}
