# -*- coding: utf-8 -*-
import json
import logging

from django.views.decorators.http import require_GET

from common.utils.decorator import response_wrapper, mongo_wrapper
from common.utils.api import token_required
from common.utils.tz import utc_to_local_str
from common.stats import MG_BIGBANG_COLL as mg
from common.utils.tz import local_now
from common.utils.export import redirect_to_file, gen_filename

_LOGGER = logging.getLogger(__name__)


@mongo_wrapper
def get_order_overview():
    today = local_now().strftime('%Y-%m-%d')
    info = mg.daily_report.find_one({'_id': today}) or {
        'pay_user': 0,
        'pay_price': 0,
        'announced_price': 0,
        'real_profit': 0
    }
    coin = mg.coin_report.find_one({'_id': today}) or {}
    info['balance'] = coin.get('balance', 0)
    return info
