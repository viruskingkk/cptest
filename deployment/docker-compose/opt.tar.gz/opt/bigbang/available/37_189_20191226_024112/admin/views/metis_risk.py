# -*- coding: utf-8 -*-

import json
import logging
from datetime import timedelta

from django.utils.decorators import method_decorator
from django.views.decorators.http import require_GET
from django.utils.encoding import smart_unicode
from django.views.generic import TemplateView

from common.account.db import account as account_db
from common.cache import redis_cache
from common.platform.metis import handler as metis_handler
from common.platform.metis import metis_api
from common.utils.api import check_params, token_required
from common.utils.decorator import response_wrapper
from common.utils.export import gen_filename, redirect_to_file
from common.utils.tz import utc_to_local_str, get_utc_date, to_ts, today_str
from common.lottery import METIS_GAME_TYPE
from common.utils.exceptions import ParamError
from common.platform.metis import db as metis_db

_LOGGER = logging.getLogger(__name__)

PLATFORM = 'metis'


class MetisConsoleView(TemplateView):

    def get(self, req):
        """获取Metis水池/抽水率
        """
        query_dct = req.GET.dict()
        game_id = query_dct['game_id']
        status, data = metis_api.get_pool(game_id)
        now_rate, now_pool = data['pool_refund'], data['pool_money']
        return {'now_rate': now_rate, 'now_pool': now_pool}

    def post(self, req):
        """设定Metis游戏每日分析配置：人工增减抽水金额/预期抽水率
        """
        query_dct = json.loads(req.body)
        game_id = query_dct.get('game_id')
        control_rate = query_dct.get('control_rate', 0)
        control_rate = float(control_rate) / 100
        control_pool = query_dct.get('control_pool', 0)
        dct = metis_handler.set_pool(game_id, control_rate, control_pool)
        return dct

    @method_decorator(response_wrapper)
    @method_decorator(token_required)
    def dispatch(self, *args, **kwargs):
        return super(MetisConsoleView, self).dispatch(*args, **kwargs)


class MetisDailyBetView(TemplateView):

    def get(self, req):
        """获取Metis单日投注上限金额
        """
        amount = redis_cache.get_daily_bet(PLATFORM)
        return {'amount': amount}

    def post(self, req):
        """设定Metis单日累计投注上限金额
        """
        query_dct = json.loads(req.body)
        check_params(query_dct,
                     required_params=['amount'])
        amount = int(query_dct['amount'])

        redis_cache.set_daily_bet(PLATFORM, amount)
        return {}

    @method_decorator(response_wrapper)
    @method_decorator(token_required)
    def dispatch(self, *args, **kwargs):
        return super(MetisDailyBetView, self).dispatch(*args, **kwargs)


class MetisForbiddenView(TemplateView):

    def get(self, req):
        """获取Metis禁止登入名单
        """
        query_dct = req.GET.dict()
        export = query_dct.pop('$export', None)
        uids = redis_cache.get_platform_risk_uids(PLATFORM, 'forbidden')

        if export:  # 导出记录信息
            resp_items = []
            filename = gen_filename('{}_forbidden'.format(PLATFORM))
            cn_header = [u'用户ID', u'手机号', u'注册时间']
            for i in uids:
                uid = int(i)
                account = account_db.get_account(uid)
                resp_items.append([uid, account.phone, utc_to_local_str(account.created_at)])
                return redirect_to_file(resp_items, cn_header, filename)
        return {'list': list(uids), 'page': 1, 'size': len(uids),
                'stock': [], 'total_count': len(uids)}

    def post(self, req):
        """设定Metis禁止登入名单
        """
        uids = json.loads(smart_unicode(req.body))
        try:
            redis_cache.add_metis_risk_uids(PLATFORM, 'forbidden', *uids)
        except:
            pass
        return {}

    @method_decorator(response_wrapper)
    @method_decorator(token_required)
    def dispatch(self, *args, **kwargs):
        return super(MetisForbiddenView, self).dispatch(*args, **kwargs)


class MetisPassView(TemplateView):

    def get(self, req):
        """获取Metis测试登入名单
        """
        query_dct = req.GET.dict()
        export = query_dct.pop('$export', None)
        uids = redis_cache.get_platform_risk_uids(PLATFORM, 'pass')

        if export:  # 导出记录信息
            resp_items = []
            filename = gen_filename('{}_pass'.format(PLATFORM))
            cn_header = [u'用户ID', u'手机号', u'注册时间']
            for i in uids:
                uid = int(i)
                account = account_db.get_account(uid)
                resp_items.append([uid, account.phone, utc_to_local_str(account.created_at)])
                return redirect_to_file(resp_items, cn_header, filename)
        return {'list': list(uids), 'page': 1, 'size': len(uids),
                'stock': [], 'total_count': len(uids)}

    def post(self, req):
        """设定Metis测试登入名单
        """
        uids = json.loads(smart_unicode(req.body))
        try:
            redis_cache.add_metis_risk_uids(PLATFORM, 'pass', *uids)
        except:
            pass
        return {}

    @method_decorator(response_wrapper)
    @method_decorator(token_required)
    def dispatch(self, *args, **kwargs):
        return super(MetisPassView, self).dispatch(*args, **kwargs)


class MetisPumpingView(TemplateView):
    def get(self, req):
        """ 获取Metis抽水策略 """
        query_dct = req.GET.dict()
        game_id = query_dct.get('game_id')
        game_list = [METIS_GAME_TYPE.SUPER_SIX, METIS_GAME_TYPE.DRAGON_TIGER,
                     METIS_GAME_TYPE.GOLD_SHARK, METIS_GAME_TYPE.SUPER_BULL]
        if game_id:
            status, data = metis_api.get_pump_tactics(game_id)
            up_value = round((1 - float(data['lower_value'])) * 100, 2) if data['lower_value'] else 0
            low_value = round((1 - float(data['upper_value'])) * 100, 2) if data['upper_value'] else 0
            data['upper_value'] = up_value
            data['lower_value'] = low_value
            pool_lower_limit = metis_api.get_pool(game_id)[1].get('pool_lower_limit', 0)
            data['pool_lower_limit'] = pool_lower_limit
            total_bet = metis_db.get_total_bet(game_id)
            data['total_bet'] = total_bet
            return {'data': data}

        data_list = []
        for game in game_list:
            bet = redis_cache.get_daily_metis_value(game, 'bet', today_str())
            result = redis_cache.get_daily_metis_value(game, 'result', today_str())
            profit = round(result / bet * 100, 2) if bet else 0
            status, data = metis_api.get_pump_tactics(game)
            up_value = round((1 - float(data['lower_value'])) * 100, 2) if data['lower_value'] else 0
            low_value = round((1 - float(data['upper_value'])) * 100, 2) if data['upper_value'] else 0
            data['upper_value'] = up_value
            data['lower_value'] = low_value
            data['upper_rate'] = data['upper_rate'] if data['upper_rate'] else 0
            data['lower_rate'] = data['lower_rate'] if data['lower_rate'] else 0
            data.update({'profit': profit, 'game_id': game})
            pool_lower_limit = metis_api.get_pool(game)[1].get('pool_lower_limit', 0)
            data['pool_lower_limit'] = pool_lower_limit
            total_bet = metis_db.get_total_bet(game)
            data['total_bet'] = total_bet
            data_list.append(data)
        return {'data': data_list}

    def post(self, req):
        """ 设定Metis抽水策略 """
        query_dct = json.loads(req.body)
        game_id = query_dct.get('game_id')
        control_value = query_dct.get('control_value', 0)
        up_value = float(query_dct.get('upper_value', 0.0))
        low_value = float(query_dct.get('lower_value', 0.0))
        upper_value = round(1 - (low_value / 100), 2)  # 抽水率上限（百分比）
        lower_value = round(1 - (up_value / 100), 2)  # 抽水率下限（百分比）
        upper_rate = query_dct.get('upper_rate', 0)
        lower_rate = query_dct.get('lower_rate', 0)
        status, data = metis_api.set_pump_tactics(game_id, control_value, upper_value,
                                                  upper_rate, lower_value, lower_rate)
        pool_lower_limit = float(query_dct.get('pool_lower_limit', 0.0))
        metis_api.set_pool(game_id, pool_lower_limit)
        if not status:
            raise ParamError(u'设置失败')
        _LOGGER.info('metis_pumping_console success %s', data)
        metis_db.add_metis_pool(game_id, control_value, upper_value, upper_rate,
                                lower_value, lower_rate, pool_lower_limit)
        return {}

    @method_decorator(response_wrapper)
    @method_decorator(token_required)
    def dispatch(self, *args, **kwargs):
        return super(MetisPumpingView, self).dispatch(*args, **kwargs)


@require_GET
@response_wrapper
@token_required
def metis_order_manage(req):
    query_dct = req.GET.dict()
    items = metis_db.get_order_manage(query_dct)

    return items