# -*- coding: utf-8 -*-

import json
import datetime
import logging
from django.views.decorators.http import require_GET

from django.utils.decorators import method_decorator
from django.views.generic import TemplateView

from common.lottery import METIS_GAME_TYPE
from common.platform.common import db as common_db
from common.platform.metis import db as metis_db
from common.platform.ametis import db as ametis_db
from common.utils.api import token_required
from common.utils.currency import convert_fen_to_yuan
from common.utils.decorator import response_wrapper
from common.utils.export import redirect_to_file, gen_filename
from common.utils.tz import utc_to_local_str
from common.utils import tz

_LOGGER = logging.getLogger(__name__)


class MetisOrderView(TemplateView):

    @method_decorator(response_wrapper)
    @method_decorator(token_required)
    def get(self, req):
        query_dct = req.GET.dict()
        export = query_dct.pop('$export', None)
        # for_user = query_dct.get('for')
        # # 为客服查询订单通过user_id
        # if for_user == 'kefu':
        #     if 'user_id' not in query_dct:
        #         query_dct['user_id'] = '0'
        # # 为数据运营查询订单通过game_id
        # if for_user == 'data':
        #     if 'game_id' not in query_dct:
        #         query_dct['game_id'] = '0'
        if 'create_time' not in query_dct:
            today = tz.local_now().strftime('%Y-%m-%d')
            # yesterday = tz.date_str_before(days=1)
            # query_dct['create_time'] = '{"$gte":"' + yesterday + ' 16:00:00","$lt":"' + today + ' 16:00:00"}'
            query_dct['create_time'] = '{"$gte":"' + today + \
                                       ' 00:00:00","$lt":"' + today + ' 23:59:59"}'
        # elif 'create_time' in query_dct:
        #      create_time = eval(query_dct['create_time'])
        #      start_date = datetime.datetime.strptime(create_time.get('$gte'), "%Y-%m-%d %H:%M:%S")
        #      end_date = datetime.datetime.strptime(create_time.get('$lte'), "%Y-%m-%d %H:%M:%S")
        #      if 7 < (end_date - start_date).days:
        #          raise ParamError(u'时间区间大于7天')

        if export:
            filename = gen_filename('pay')
            header = ['id', 'user_id', 'game_id', 'play_type', 'round_id', 'bet_amount', 'bet_result',
                      'create_time']
            cn_header = [u'订单ID', u'用户ID', u'游戏类别', u'玩法', u'局号', u'押注金额', u'返还金额', u'购买时间']
        items, total_count, total_bet, total_result, total_win = metis_db.list_all_orders(query_dct)
        resp = []
        for item in items:
            data = item.as_dict()
            data.pop('extend')
            data.pop('created_at')
            data['bet_amount'] = convert_fen_to_yuan(item.bet_amount)
            data['bet_result'] = convert_fen_to_yuan(item.bet_result)
            # 返回金额(bet_win) = 下注金额(bet_amount) + 盈亏金额(bet_result)
            data['bet_win'] = data['bet_amount'] + data['bet_result']
            data['create_time'] = utc_to_local_str(item.create_time)
            data['updated_at'] = utc_to_local_str(item.updated_at)
            row = []
            if export:
                for x in header:
                    if x == 'game_id' and data.get(x):
                        row.append(METIS_GAME_TYPE.to_dict()[data.get(x)])
                    else:
                        row.append(data.get(x, '-'))
                resp.append(row)
            else:
                resp.append(data)

        if export:
            return redirect_to_file(resp, cn_header, filename)

        return {'list': resp, 'page': query_dct.get('$page', 1),
                'total_count': total_count, 'size': len(resp),
                'total_bet': convert_fen_to_yuan(total_bet),
                'total_result': convert_fen_to_yuan(total_result),
                'total_win': convert_fen_to_yuan(total_win)}


class MetisGameView(TemplateView):

    @method_decorator(response_wrapper)
    @method_decorator(token_required)
    def get(self, req):
        query_dct = req.GET.dict()
        game_id = query_dct['game_id']
        if 'create_time' not in query_dct:
            today = tz.local_now().strftime('%Y-%m-%d')
            yesterday = tz.date_str_before(days=1)
            query_dct['create_time'] = '{"$gte":"' + today + \
                                       ' 00:00:00","$lt":"' + today + ' 23:59:59"}'
        items, total_count = metis_db.list_metis_game(query_dct, game_id)
        resp_items = []
        for item in items:
            data = item.as_dict()
            extend = json.loads(item.extend)
            data.pop('created_at')
            data.pop('updated_at')
            data['win_list'] = extend.get('section_bet_rate')
            data['create_time'] = utc_to_local_str(item.create_time)
            data['rate'] = round((1 - float(item.rate)) * 100, 2)
            resp_items.append(data)

        return {'list': resp_items, 'page': query_dct.get('$page', 1),
                'total_count': total_count, 'size': len(resp_items)}


class MetisGamePartView(TemplateView):

    @method_decorator(response_wrapper)
    @method_decorator(token_required)
    def get(self, req):
        query_dct = req.GET.dict()
        game_id = query_dct['game_id']
        items, total_count, total_bet, total_win = metis_db.list_metis_game_part(query_dct, game_id)
        resp_items = []
        for item in items:
            data = item.as_dict()
            data.pop('created_at')
            data.pop('updated_at')
            extend = json.loads(item.extend)
            data['win_area'] = extend.get('total_bet_result')
            data['bet_amount'] = convert_fen_to_yuan(item.bet_amount)
            data['bet_result'] = convert_fen_to_yuan(item.bet_result)
            data['create_time'] = utc_to_local_str(item.create_time)
            resp_items.append(data)

        return {'list': resp_items, 'page': query_dct.get('$page', 1),
                'total_count': total_count, 'size': len(resp_items),
                'total_bet': convert_fen_to_yuan(total_bet),
                'total_win': convert_fen_to_yuan(total_win)}


@require_GET
@response_wrapper
@token_required
def get_third_game_trans(req):
    query_dct = req.GET.dict()
    if 'created_at' not in query_dct:
        today = tz.local_now().strftime('%Y-%m-%d')
        query_dct['created_at'] = '{"$gte":"' + today + ' 00:00:00","$lt":"' + today + ' 23:59:59"}'
    items, total_count, total_login, total_logout = common_db.query_game_trans(query_dct)
    resp_items = []
    for item in items:
        data = item.as_dict()
        data.pop('accu_balance')
        data.pop('accu_withdraw')
        data['balance'] = convert_fen_to_yuan(data['balance'])
        data['withdraw'] = convert_fen_to_yuan(data['withdraw'])
        data['curr_balance'] = convert_fen_to_yuan(data['curr_balance'])
        data['curr_withdraw'] = convert_fen_to_yuan(data['curr_withdraw'])
        data['created_at'] = utc_to_local_str(data['created_at'])
        data['updated_at'] = utc_to_local_str(data['updated_at'])
        resp_items.append(data)

    return {'list': resp_items, 'page': query_dct.get('$page', 1), 'size': len(resp_items),
            'total_count': total_count, 'total_login': abs(convert_fen_to_yuan(total_login)),
            'total_logout': convert_fen_to_yuan(total_logout)}


@require_GET
@response_wrapper
@token_required
def get_ares_game_by_user(req):
    query_dct = req.GET.dict()
    data = ametis_db.query_data_by_user(query_dct)
    return data
