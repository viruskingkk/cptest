import os
import sys
import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")
