# -*- coding: utf-8 -*-
from __future__ import absolute_import

import os
import sys
from copy import deepcopy
from datetime import timedelta

from sqlalchemy import func

# add up one level dir into sys path

sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
os.environ['DJANGO_SETTINGS_MODULE'] = 'base.settings'

from common.stats import MG_BIGBANG_COLL as mg
from common.utils.tz import get_utc_date, local_now, utc_to_local
from tools.create_daily_report import fix_daily_recharge


def create_daily_report(day):
    end = day + timedelta(days=1)
    value = {}
    # 每日上分數據
    items = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {"system_recharge.total": {"$exists": True}}
        ]}},
        {"$group": {"_id": None, "total": {"$sum": 1},
                    "price": {"$sum": "$system_recharge.total"},
                    "count": {"$sum": "$system_recharge.count"}}}
    ])
    item = items.next() if items.alive else {}
    value['system_recharge_user'] = item.get('total', 0)
    value['system_recharge_price'] = item.get('price', 0)
    value['system_recharge_count'] = item.get('count', 0)
    # 每日metis數據
    items = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {"metis.total_bet": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "total": {"$sum": 1},
                    "bet": {"$sum": "$metis.total_bet"},
                    "profit": {"$sum": "$metis.total_profit"}}}
    ])
    item = items.next() if items.alive else {}
    value['metis_count'] = item.get('total', 0)
    value['metis_price'] = item.get('bet', 0)
    value['metis_profit'] = item.get('profit', 0)

    # 新增设备
    t = mg.device_stats.aggregate([
        {"$match": {"created_at": {"$gte": day, "$lt": end}}},
        {"$group": {"_id": None, "count": {"$sum": 1}}}
    ])
    t = t.next() if t.alive else {}
    value['new_device'] = t.get('count', 0)
    # 活跃设备
    t = mg.device_stats.aggregate([
        {"$match": {"updated_at": {"$gte": day}}},
        {"$group": {"_id": None, "count": {"$sum": 1}}}
    ])
    t = t.next() if t.alive else {}
    value['active_device'] = t.get('count', 0)
    # 新用户
    t = mg.user_stats.aggregate([
        {"$match": {"created_at": {"$gte": day, "$lt": end}}},
        {"$group": {"_id": None, "count": {"$sum": 1}}}
    ])
    t = t.next() if t.alive else {}
    value['new_user'] = t.get('count', 0)
    # 新注册设备
    cond = [
        {'$match': {'$and': [
            {'created_at': {'$gte': day, "$lt": end}},
            {'register_at': {'$exists': 1}}
        ]}},
        {'$group': {'_id': None, 'count': {'$sum': 1}}}
    ]
    t = mg.device_stats.aggregate(cond)
    t = t.next() if t.alive else {}
    value["new_register_device"] = t.get('count', 0)
    # 活跃用户
    t = mg.user_stats.aggregate([
        {"$match": {"updated_at": {"$gte": day}}},
        {"$group": {"_id": None, "count": {"$sum": 1}}}
    ])
    t = t.next() if t.alive else {}
    value['active_user'] = t.get('count', 0)
    # 活跃用户中已注册用户
    t = mg.user_stats.aggregate([
        {"$match": {
            "updated_at": {"$gte": day, "$lt": end},
            "register_at": {"$exists": 1}
        }},
        {"$group": {"_id": None, "count": {"$sum": 1}}}
    ])
    t = t.next() if t.alive else {}
    value['active_register_user'] = t.get('count', 0)
    # 玩过游戏的用户
    t = mg.user_stats.aggregate([
        {"$match": {
            "updated_at": {"$gte": day, "$lt": end},
            "$or": [{"pay": {"$exists": 1}},
                    {"lottery": {"$exists": 1}},
                    {"kfc": {"$exists": 1}},
                    {"fruit": {"$exists": 1}},
                    {"bull": {"$exists": 1}}]
        }},
        {"$group": {"_id": None, "count": {"$sum": 1}}}
    ])
    t = t.next() if t.alive else {}
    value['play_user'] = t.get('count', 0)
    # 总付费（充值）人数/金额
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {"recharge.total": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "total": {"$sum": 1},
                    "price": {"$sum": "$recharge.total"},
                    "count": {"$sum": "$recharge.count"}}}
    ])
    t = t.next() if t.alive else {}
    value['recharge_user'] = t.get('total', 0)
    value['recharge_price'] = t.get('price', 0)
    value['recharge_count'] = t.get('count', 0)
    # 代理付费（充值）人数/金额
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {u"recharge.agent_wechat": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "wechat_total": {"$sum": 1},
                    "wechat_price": {"$sum": u"$recharge.agent_wechat"}}}
    ])
    t = t.next() if t.alive else {}
    value['agent_wechat_recharge_user'] = t.get('wechat_total', 0)
    value['agent_wechat_recharge_price'] = t.get('wechat_price', 0)
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {u"recharge.agent_alipay": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "alipay_total": {"$sum": 1},
                    "alipay_price": {"$sum": u"$recharge.agent_alipay"}}}
    ])
    t = t.next() if t.alive else {}
    value['agent_alipay_recharge_user'] = t.get('alipay_total', 0)
    value['agent_alipay_recharge_price'] = t.get('alipay_price', 0)
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {u"recharge.agent_union": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "union_total": {"$sum": 1},
                    "union_price": {"$sum": u"$recharge.agent_union"}}}
    ])
    t = t.next() if t.alive else {}
    value['agent_union_recharge_user'] = t.get('union_total', 0)
    value['agent_union_recharge_price'] = t.get('union_price', 0)
    value['agent_recharge_user'] = value['agent_union_recharge_user'] + value['agent_alipay_recharge_user'] + value[
        'agent_wechat_recharge_user']
    value['agent_recharge_price'] = value['agent_union_recharge_price'] + value['agent_alipay_recharge_price'] + value[
        'agent_wechat_recharge_price']

    # 修正秒付充值，计算到代理充值
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {u"recharge.unionagency": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "unionagency_total": {"$sum": 1},
                    "unionagency_price": {"$sum": u"$recharge.unionagency"},
                    "count": {"$sum": "$recharge.count"}}}
    ])
    t = t.next() if t.alive else {}
    value['agent_recharge_user'] = t.get('unionagency_total', 0)
    value['agent_recharge_price'] = t.get('unionagency_price', 0)

    # 总付费设备数
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {"recharge.total": {"$gt": 0}}
        ]}},
        {"$group": {"_id": "$aid"}},
        {"$group": {"_id": None, "total": {"$sum": 1}}}
    ])
    t = t.next() if t.alive else {}
    value["recharge_device"] = t.get('total', 0)
    # 渠道用户参与夺宝人数/金额
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {"pay.total": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "total": {"$sum": 1},
                    "price": {"$sum": "$pay.total"}}}
    ])
    t = t.next() if t.alive else {}
    value['pay_user'] = t.get('total', 0)
    value['pay_price'] = t.get('price', 0)
    # 新用户付费人数／金额
    t = mg.user_stats.aggregate([
        {"$match": {"$and": [
            {"created_at": {"$gte": day, "$lt": end}},
            {"recharge.total": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "total": {"$sum": 1},
                    "price": {"$sum": "$recharge.total"},
                    "count": {"$sum": "$recharge.count"},
                    }}
    ])
    t = t.next() if t.alive else {}
    value['new_recharge_user'] = t.get('total', 0)
    value['new_recharge_price'] = t.get('price', 0)
    value['new_recharge_count'] = t.get('count', 0)
    # 新用户代理付费人数/金额
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {'is_fresh': 1},
            {"updated_at": {"$gte": day, "$lt": end}},
            {u"recharge.agent_wechat": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "wechat_total": {"$sum": 1},
                    "wechat_price": {"$sum": u"$recharge.agent_wechat"}}}
    ])
    t = t.next() if t.alive else {}
    value['new_agent_wechat_recharge_user'] = t.get('wechat_total', 0)
    value['new_agent_wechat_recharge_price'] = t.get('wechat_price', 0)
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {'is_fresh': 1},
            {"updated_at": {"$gte": day, "$lt": end}},
            {u"recharge.agent_alipay": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "alipay_total": {"$sum": 1},
                    "alipay_price": {"$sum": u"$recharge.agent_alipay"}}}
    ])
    t = t.next() if t.alive else {}
    value['new_agent_alipay_recharge_user'] = t.get('alipay_total', 0)
    value['new_agent_alipay_recharge_price'] = t.get('alipay_price', 0)
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {'is_fresh': 1},
            {"updated_at": {"$gte": day, "$lt": end}},
            {u"recharge.agent_union": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "union_total": {"$sum": 1},
                    "union_price": {"$sum": u"$recharge.agent_union"}}}
    ])
    t = t.next() if t.alive else {}
    value['new_agent_union_recharge_user'] = t.get('union_total', 0)
    value['new_agent_union_recharge_price'] = t.get('union_price', 0)
    value['new_agent_recharge_user'] = value['new_agent_union_recharge_user'] + value[
        'new_agent_alipay_recharge_user'] + value['new_agent_wechat_recharge_user']
    value['new_agent_recharge_price'] = value['new_agent_union_recharge_price'] + value[
        'new_agent_alipay_recharge_price'] + value['new_agent_wechat_recharge_price']

    # 覆盖代理充值数据
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {'is_fresh': 1},
            {"updated_at": {"$gte": day, "$lt": end}},
            {u"recharge.unionagency": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "unionagency_total": {"$sum": 1},
                    "unionagency_price": {"$sum": u"$recharge.unionagency"}}}
    ])
    t = t.next() if t.alive else {}
    value['new_agent_recharge_user'] = t.get('unionagency_total', 0)
    value['new_agent_recharge_price'] = t.get('unionagency_price', 0)

    # 真实用户夺宝中奖人数/金额
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {"win.total": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "total": {"$sum": 1},
                    "price": {"$sum": "$win.total"}}}
    ])
    t = t.next() if t.alive else {}
    value['win_count'] = t.get('total', 0)
    value['win_price'] = t.get('price', 0)
    # 用户加奖人数／金额
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {"bonus.total": {"$gt": 0}}
        ]}},
        {
            "$group": {"_id": None, "total": {"$sum": 1},
                       "price": {"$sum": "$bonus.total"}}}
    ])
    t = t.next() if t.alive else {}
    value['bonus_count'] = t.get('total', 0)
    value['bonus_price'] = t.get('price', 0)
    # 红包消耗
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {"coupon.use": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "total": {"$sum": "$coupon.use"}}}
    ])
    t = t.next() if t.alive else {}
    value['coupon_use'] = t.get('total', 0)
    # 退款人数／金额
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {"refund.total": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "total": {"$sum": 1},
                    "price": {"$sum": "$refund.total"}}}
    ])
    t = t.next() if t.alive else {}
    value['refund_count'] = t.get('total', 0)
    value['refund_price'] = t.get('price', 0)
    # 用户提现人数/金额
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {"withdraw.total": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "total": {"$sum": 1},
                    "price": {"$sum": "$withdraw.total"}}}
    ])
    t = t.next() if t.alive else {}
    value['withdraw_count'] = t.get('total', 0)
    value['withdraw_price'] = t.get('price', 0)
    # 新增付费设备
    t = mg.user_stats.aggregate([
        {"$match": {"$and": [
            {"register_at": {"$gte": day, "$lt": end}},
            {"recharge.total": {"$gt": 0}}
        ]}},
        {"$group": {"_id": "$aid"}},
        {"$group": {"_id": None, "total": {"$sum": 1}}}
    ])
    t = t.next() if t.alive else {}

    value['new_recharge_device'] = t.get('total', 0)
    # 实际利润: 真实用户充值 - 真实用户中奖成本
    value['profit'] = value['recharge_price'] - value['withdraw_price']
    value['profit_rate'] = value['profit'] / value['recharge_price'] if value['recharge_price'] else 0
    today = utc_to_local(day).strftime('%Y-%m-%d')

    # mg.daily_report.update_one({'_id': today},
    #                            {'$set': value}, upsert=True)
    print(today, value)


def update_daily_report(day):
    end = day + timedelta(days=1)
    value = {}

    # 修正秒付充值，计算到代理充值
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {"updated_at": {"$gte": day, "$lt": end}},
            {u"recharge.unionagency": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "unionagency_total": {"$sum": 1},
                    "unionagency_price": {"$sum": u"$recharge.unionagency"}}}
    ])
    t = t.next() if t.alive else {}
    value['agent_recharge_user'] = t.get('unionagency_total', 0)
    value['agent_recharge_price'] = t.get('unionagency_price', 0)

    # 覆盖代理充值数据
    t = mg.daily_stats.aggregate([
        {"$match": {"$and": [
            {'is_fresh': 1},
            {"updated_at": {"$gte": day, "$lt": end}},
            {u"recharge.unionagency": {"$gt": 0}}
        ]}},
        {"$group": {"_id": None, "unionagency_total": {"$sum": 1},
                    "unionagency_price": {"$sum": u"$recharge.unionagency"}}}
    ])
    t = t.next() if t.alive else {}
    value['new_agent_recharge_user'] = t.get('unionagency_total', 0)
    value['new_agent_recharge_price'] = t.get('unionagency_price', 0)

    if value:
        today = utc_to_local(day).strftime('%Y-%m-%d')
        mg.daily_report.update_one({'_id': today}, {'$set': value}, upsert=True)
        print(today, value)


def create_days_ltv(day, delta=7):
    start = day - timedelta(days=delta)
    end = day - timedelta(days=delta - 1)
    cond = {'created_at': {'$gte': start, '$lte': end}}
    t = mg.user_stats.aggregate([
        {"$match": {"created_at": {"$gte": start, "$lt": end}}},
        {"$group": {"_id": None, "count": {"$sum": 1},
                    "price": {"$sum": "$recharge.total"}}}
    ])
    t = t.next() if t.alive else {}
    user_count = t.get('count', 0)
    total_recharge = t.get('price', 0)
    print 'start:{}, end:{}, user count:{}, recharge:{}'.format(start, end, user_count, total_recharge)
    return total_recharge / user_count if user_count else 0


def update_ks_report(day):
    date_str = utc_to_local(day).strftime('%Y-%m-%d')
    print(date_str)
    index = 23
    print 'creating date:%s, index:%s' % (date_str, index)
    key = {
        '_id': '%s-%s' % (date_str, index),
        'day': date_str,
        'index': index,
        'time_start': '%s %d:00' % (date_str, index),
        'time_end': '%s %d:00' % (date_str, index + 1),
    }

    set_data = {}
    # 用户数据
    item = mg.daily_report.find_one({'_id': date_str}) or {}
    new_device = item.get('new_device', 0)  # 新注册
    active_register_user = item.get('active_register_user', 0)  # 绑定总数
    new_user = item.get('new_user', 0)  # 注册绑定
    new_recharge_user = item.get('new_recharge_user', 0)
    active_user = item.get('active_user', 0)
    active_user_ios = item.get('active_user_ios', 0)
    active_user_android = active_user - active_user_ios
    play_user = item.get('play_user', 0)
    day_2_ago = (day - timedelta(1)).strftime('%Y-%m-%d')
    item_2_ago = mg.daily_report.find_one({'_id': day_2_ago}) or {}
    user_stay_2 = float(item_2_ago.get('stay_2', 0)) / item_2_ago.get('new_device')
    day_3_ago = (day - timedelta(3)).strftime('%Y-%m-%d')
    item_3_ago = mg.daily_report.find_one({'_id': day_3_ago}) or {}
    user_stay_3 = float(item_3_ago.get('stay_3', 0)) / item_3_ago.get('new_device')
    day_7_ago = (day - timedelta(7)).strftime('%Y-%m-%d')
    item_7_ago = mg.daily_report.find_one({'_id': day_7_ago}) or {}
    user_stay_7 = float(item_7_ago.get('stay_7', 0)) / item_7_ago.get('new_device')
    recharge_price = item.get('recharge_price', 0)
    recharge_user = item.get('recharge_user', 0)
    recharge_count = item.get('recharge_count', 0)
    agent_recharge_price = item.get('agent_recharge_price', 0)
    agent_recharge_user = item.get('agent_recharge_user', 0)
    new_recharge_price = item.get('new_recharge_price', 0)
    new_recharge_user = item.get('new_recharge_user', 0)
    new_agent_recharge_price = item.get('new_agent_recharge_price', 0)
    new_agent_recharge_user = item.get('new_agent_recharge_user', 0)
    total_tax = item.get('total_tax', 0)
    withdraw_price = item.get('withdraw_price', 0)
    withdraw_user = item.get('withdraw_count', 0)
    real_profit = item.get('profit', 0)
    real_profit_rate = item.get('profit_rate', 0)

    set_data['new_device'] = new_device  # 新注册
    set_data['new_user'] = new_user  # 注册绑定
    set_data['active_register_user'] = active_register_user  # 绑定总数
    set_data['new_recharge_user'] = new_recharge_user
    set_data['new_recharge_device_ratio'] = float(new_recharge_user) / new_device if new_device else 0  # 注充率
    set_data['new_register_device_ratio'] = float(new_user) / new_device if new_device else 0  # 注绑率
    set_data['new_recharge_ratio'] = float(new_recharge_user) / new_user if new_user else 0 # 绑充率
    set_data['active_user'] = active_user
    set_data['active_user_ios'] = active_user_ios
    set_data['active_user_android'] = active_user_android
    set_data['recharge_price'] = recharge_price
    set_data['new_recharge_price'] = new_recharge_price
    set_data['old_recharge_price'] = recharge_price - new_recharge_price
    set_data['online_recharge_price'] = recharge_price - agent_recharge_price
    set_data['new_online_recharge_price'] = new_recharge_price - new_agent_recharge_price
    set_data['old_online_recharge_price'] = set_data['online_recharge_price'] - set_data['new_online_recharge_price']
    set_data['agent_recharge_price'] = agent_recharge_price
    set_data['new_agent_recharge_price'] = new_agent_recharge_price
    set_data['old_agent_recharge_price'] = agent_recharge_price - new_agent_recharge_price
    set_data['recharge_user'] = recharge_user
    set_data['new_recharge_user'] = new_recharge_user
    set_data['old_recharge_user'] = recharge_user - new_recharge_user
    set_data['online_recharge_user'] = recharge_user - agent_recharge_user
    set_data['new_online_recharge_user'] = new_recharge_user - new_agent_recharge_user
    set_data['old_online_recharge_user'] = (recharge_user - agent_recharge_user) - (
    new_recharge_user - new_agent_recharge_user)
    set_data['agent_recharge_user'] = agent_recharge_user
    set_data['new_agent_recharge_user'] = new_agent_recharge_user
    set_data['old_agent_recharge_user'] = agent_recharge_user - new_agent_recharge_user
    set_data['recharge_count'] = recharge_count
    set_data['online_recharge_count'] = recharge_count
    set_data['agent_recharge_count'] = 0
    set_data['agent_import'] = 0
    set_data['agent_cost'] = 0
    set_data['agent_balance'] = 0
    set_data['average_recharge'] = float(recharge_price) / recharge_user
    set_data['recharge_rate'] = float(recharge_user) / active_user
    set_data['average_contribute'] = float(total_tax) / recharge_user  # FIXME
    set_data['withdraw_price'] = withdraw_price
    set_data['withdraw_count'] = withdraw_user
    set_data['play_user'] = play_user
    set_data['real_profit'] = real_profit
    set_data['real_profit_rate'] = real_profit_rate
    set_data['user_stay_2'] = user_stay_2
    set_data['user_stay_3'] = user_stay_3
    set_data['user_stay_7'] = user_stay_7
    set_data['arpu'] = float(recharge_price) / active_user
    set_data['arppu'] = float(recharge_price) / recharge_user
    # ltv
    set_data['ltv7'] = create_days_ltv(day, 7)
    set_data['ltv14'] = create_days_ltv(day, 14)
    set_data['ltv30'] = create_days_ltv(day, 30)
    set_data['ltv60'] = create_days_ltv(day, 60)

    print(key)
    mg.interval_report.update_one(
        key, {'$set': set_data}, upsert=True
    )

if __name__ == '__main__':
    today = get_utc_date()
    print(today)
    yesterday = today - timedelta(days=1)
    # day = today - timedelta(days=delta)
    # update_daily_report(yesterday)
    # fix_daily_recharge(today)
    print(yesterday)
    update_ks_report(yesterday)

