import os
import sys
import logging.config
from argparse import ArgumentParser

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.withdraw.db import get_withdraw
from common.withdraw.unionagency_withdraw import create_withdraw
from django.conf import settings
from common.transaction import calc_withdraw_amount

logging.config.dictConfig(settings.LOGGING)


def test_new_ua_withdraw(withdraw_id):
    item = get_withdraw(withdraw_id)
    amount = calc_withdraw_amount(item.user_id, int(item.price))
    item.real_price = amount
    item.save()
    create_withdraw(item.user_id, item)


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument("withdraw_id", type=int)

    args = parser.parse_args()
    if args.withdraw_id:
        test_new_ua_withdraw(args.withdraw_id)
    else:
        print('no withdraw id')

