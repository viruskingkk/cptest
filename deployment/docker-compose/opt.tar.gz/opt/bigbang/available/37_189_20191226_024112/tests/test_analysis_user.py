# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os
import sys
import requests
import json
from datetime import datetime, timedelta
import argparse

# add up one level dir into sys path
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
os.environ['DJANGO_SETTINGS_MODULE'] = 'base.settings'

from common.lottery import LOTTERY_TYPE
from common.lottery.cyclical.model import ACTIVITY_MODEL, ORDER_LOGIC, ORDER_MODEL
from common.lottery.cyclical import ORDER_STATUS, TRACK_STATUS
from common import orm
from common.utils.decorator import sql_wrapper
from common.utils.tz import get_utc_date


class AnalysisTool(object):
    def __init__(self, user_ids, start_day=None, end_day=None):
        self.user_ids = user_ids
        self.start_day = start_day
        self.end_day = end_day

    @sql_wrapper
    def analysis_lottery_stats(self, user_id, lottery_type):
        # select * from cq_ssc_order where id < 3192700 and win_price > 0  order by id desc limit 20;

        start_date = get_utc_date()
        end_date = start_date + timedelta(days=1)
        order_model = ORDER_MODEL.get(lottery_type)
        items = orm.session.query(orm.func.sum(order_model.price), orm.func.sum(order_model.win_price),
                                  orm.func.sum(order_model.bonus), order_model.status).\
            filter(order_model.user_id == user_id). \
            filter(order_model.updated_at >= start_date).\
            filter(order_model.updated_at < end_date).group_by(
            order_model.status).all()
        for item in items:
            print(item)

    def analysis(self):
        for user_id in self.user_ids:
            self.analysis_lottery_stats(user_id, LOTTERY_TYPE.JX_11X5)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Process some argument.')
    parser.add_argument('user_ids', type=int, nargs='+')
    parser.add_argument('-s', '--start_day', dest='start_day')
    parser.add_argument('-e', '--end_day', dest='end_day')
    args = parser.parse_args()
    print(args)

    AnalysisTool(args.user_ids, args.start_day, args.end_day).analysis()
