# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os
import sys
from datetime import datetime

# add up one level dir into sys path
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
os.environ['DJANGO_SETTINGS_MODULE'] = 'base.settings'


from common.platform.ares.db import add_imone_user_info, add_bet_logs, get_imone_user_info_by_player_id
from analysis.games.es import emit_game_order
from common.platform.common.model import PLATFORM_TYPE
from common.platform.ares.handler import add_bet_log_to_db


if __name__ == '__main__':
    # add_imone_user_info(111111, 'IM22222222')
    # add_bet_log(2, 111111, 'IM22222222', 12003, 13345345345, 100, 100, '2019-05-30 15:00:00', '2019-05-30 15:00:00')

    # user_info = get_imone_user_info_by_player_id('IM22222222')
    # print(user_info)
    #
    # emit_game_order(111111, PLATFORM_TYPE.IMONE, 12003, 13345345345,
    #                 100,
    #                 100,
    #                 datetime.strptime('2019-05-30 15:00:00', "%Y-%m-%d %H:%M:%S"))

    # start_datetime = datetime(2019, 06, 02, 11, 22, 00)
    # end_datetime = datetime(2019, 06, 02, 11, 35, 00)

    add_imone_user_info(1953370, 'M00000572')
    data = {
        "code": 0,
        "data": {
            "Result": [
                {
                    "Provider": "ASIAGAMING_LD",
                    "GameId": "IMAG1005",
                    "GameName": "Dragon tiget of AGIN",
                    "BetType": "Dragon",
                    "BetId": "190529002400201",
                    "ExternalBetId": "N/A",
                    "PlayerId": "M00000572",
                    "Currency": "CNY",
                    "BetAmount": 20,
                    "ValidBet": 20,
                    "WinLoss": 20,
                    "Tips": 0,
                    "ProviderBonus": 0,
                    "Status": "Settled",
                    "Platform": "Mobile",
                    "DateCreated": "2019-05-29 12:36:23 +08:00",
                    "LastUpdatedDate": "2019-05-29 12:36:37 +08:00",
                    "RoundId": "GC007195281IQ"
                },
                {
                    "Provider": "ASIAGAMING_LD",
                    "GameId": "IMAG1005",
                    "GameName": "Dragon tiget of AGIN",
                    "BetType": "Tiger",
                    "BetId": "190529002417036",
                    "ExternalBetId": "N/A",
                    "PlayerId": "M00000572",
                    "Currency": "CNY",
                    "BetAmount": 20,
                    "ValidBet": 20,
                    "WinLoss": 20,
                    "Tips": 0,
                    "ProviderBonus": 0,
                    "Status": "Settled",
                    "Platform": "Mobile",
                    "DateCreated": "2019-05-29 12:36:49 +08:00",
                    "LastUpdatedDate": "2019-05-29 12:37:16 +08:00",
                    "RoundId": "GC007195281IR"
                }
            ],
            "Pagination": {
                "CurrentPage": 1,
                "TotalPage": 1,
                "ItemPerPage": 2,
                "TotalCount": 2
            },
            "Code": "0",
            "Message": "Successful."
        }
    }

    items = data['data']['Result'] if data else {}
    for item in items:
        add_bet_log_to_db(item)


