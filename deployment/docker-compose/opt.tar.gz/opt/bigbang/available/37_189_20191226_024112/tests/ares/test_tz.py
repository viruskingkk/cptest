# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os
import sys
from datetime import datetime

# add up one level dir into sys path
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
os.environ['DJANGO_SETTINGS_MODULE'] = 'base.settings'


from common.utils import tz


if __name__ == '__main__':
    a = tz.local_now()
    print(a)
    utc_a = tz.local_to_utc(a)

    print(utc_a)

    time1 = tz.to_ts(a)
    time2 = tz.to_ts(utc_a)

    print(time1, time2)  # 结论， time1不等于time2

    # 可以相减， 为0；结论， datetime带有时区信息，但是转化为一定格式string的时候，没有时区信息，
    # 转换为 timestamp的时候也没有时区信息
    print(a - utc_a)
