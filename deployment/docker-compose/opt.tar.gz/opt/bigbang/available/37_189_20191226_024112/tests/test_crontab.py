import datetime

time_stamp = datetime.datetime.now()
print(time_stamp)
