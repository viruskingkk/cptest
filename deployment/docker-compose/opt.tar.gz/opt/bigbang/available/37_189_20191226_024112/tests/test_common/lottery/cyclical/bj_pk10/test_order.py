import unittest
from common.lottery.cyclical.bj_pk10.logic.order import generate_win_func, BET_TYPE


class GenerateWinFuncTest(unittest.TestCase):

    def test_generate_win_func(self):
        funcs = generate_win_func("10,1,7,5,8,2,4,6,3,9")

        self.assertEqual(funcs[BET_TYPE.PLATE_DRAGON_TIGER_1v10]('t'), 0)
        self.assertEqual(funcs[BET_TYPE.PLATE_DRAGON_TIGER_5v6]('d'), 1)

        self.assertEqual(funcs[BET_TYPE.PLATE_BSOE_1]('b,e'), 2)
        self.assertEqual(funcs[BET_TYPE.PLATE_BSOE_5]('s,o'), 0)
        self.assertEqual(funcs[BET_TYPE.PLATE_BSOE_10]('b,e'), 1)
