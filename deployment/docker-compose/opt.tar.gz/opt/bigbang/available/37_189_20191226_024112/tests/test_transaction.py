#! -*- coding:utf-8 -*-
"""
最近运营提出bug，用户在追号的同时，系统也派奖，导致派奖金额没有添加到余额中，查看数据库的transaction表，发现类似如下记录（测试用）：
id	             user_id type activity_type	title price	   balance	  pay_id	order_id	status	extend	created_at	updated_at	out_trans_id	trans_type
5435027177357403151	181884	8193	0	系统加钱	2.000000000	9.502000000	NULL	NULL	1	NULL	2019-07-08 02:17:48	2019-07-08 02:17:48	94568db6-a126-11e9-aed5-005056ac1d4e	50002
5435027177357403152	181884	8193	0	系统减钱	-1.000000000	8.502000000	NULL	NULL	1	NULL	2019-07-08 02:17:48	2019-07-08 02:17:48	9465eae0-a126-11e9-aed5-005056ac1d4e	50002
5435027177357403153	181884	8193	0	系统减钱	-1.000000000	7.502000000	NULL	NULL	1	NULL	2019-07-08 02:17:48	2019-07-08 02:17:48	9465eae1-a126-11e9-aed5-005056ac1d4e	50002
5435027177357403154	181884	8193	0	系统加钱	2.000000000	9.502000000	NULL	NULL	1	NULL	2019-07-08 02:17:48	2019-07-08 02:17:48	94568db7-a126-11e9-aed5-005056ac1d4e	50002
5435027177357403155	181884	8193	0	系统减钱	-1.000000000	6.502000000	NULL	NULL	1	NULL	2019-07-08 02:17:48	2019-07-08 02:17:48	9465eae2-a126-11e9-aed5-005056ac1d4e	50002
5435027177357403156	181884	8193	0	系统加钱	2.000000000	11.502000000	NULL	NULL	1	NULL	2019-07-08 02:17:48	2019-07-08 02:17:48	94568db8-a126-11e9-aed5-005056ac1d4e	50002
5435027177357403157	181884	8193	0	系统减钱	-1.000000000	5.502000000	NULL	NULL	1	NULL	2019-07-08 02:17:48	2019-07-08 02:17:48	9465eae3-a126-11e9-aed5-005056ac1d4e	50002
5435027177357403158	181884	8193	0	系统加钱	2.000000000	13.502000000	NULL	NULL	1	NULL	2019-07-08 02:17:48	2019-07-08 02:17:48	94568db9-a126-11e9-aed5-005056ac1d4e	50002
5435027177357403159	181884	8193	0	系统减钱	-1.000000000	4.502000000	NULL	NULL	1	NULL	2019-07-08 02:17:48	2019-07-08 02:17:48	9465eae4-a126-11e9-aed5-005056ac1d4e	50002
5435027177357403160	181884	8193	0	系统加钱	2.000000000	15.502000000	NULL	NULL	1	NULL	2019-07-08 02:17:48	2019-07-08 02:17:48	94568dba-a126-11e9-aed5-005056ac1d4e	50002
5435027177357403161	181884	8193	0	系统加钱	2.000000000	17.502000000	NULL	NULL	1	NULL	2019-07-08 02:17:48	2019-07-08 02:17:48	94568dbb-a126-11e9-aed5-005056ac1d4e	50002

查看记录，可以发现
系统减钱和加钱，并不是使用的最新的余额数据，在错误的余额数据上进行的加减钱

经过测试，发现要把 common/transaction/db.py 文件中的 orm.session.expire(account)替换成orm.session.refresh(account)
也就是把expire方法替换成refresh方法
"""
import os
import sys
import uuid
import time
from threading import Thread
import copy

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.transaction.model import TRANSACTION_TYPE, TRANSACTION_STATUS
from common.utils.currency import convert_yuan_to_fen, convert_fen_to_hao, convert_fen_to_yuan
from common.transaction.db import create_transaction
from common import orm
from common.account.model.account import BALANCE_TYPE, Account
from common.utils.api import check_params
from common.transaction.db import get_out_trans_id, _increase_balance, _decrease_balance
from common.utils import exceptions as err
from common.utils.currency import convert_yuan_to_hao, convert_hao_to_yuan
from common.transaction.model import (Transaction, TRANSACTION_TYPE, TITLE_MAPPER,)

USER_ID = 9348011


# def create_transaction(transaction_data):
#     data = copy.deepcopy(transaction_data)
#     check_params(data, ['user_id', 'type', 'title', 'price', 'balance_type', 'trans_type'])
#     assert data['balance_type'] in BALANCE_TYPE.to_dict()
#     if data['balance_type'] == BALANCE_TYPE.SPECIFIED:
#         check_params(data, ['balance_dct'])
#         for key in data.get('balance_dct', {}):
#             assert data['balance_dct'][key] >= 0
#     else:
#         assert data['price'] != 0
#
#     if data.get('out_trans_id'):
#         query = get_out_trans_id(data.get('out_trans_id'))
#         if not query:
#             raise err.ParamError(u'交易重复')
#
#     # start transaction
#     amount = data['price']
#     if amount > 0 or data['balance_type'] == BALANCE_TYPE.SPECIFIED:
#         account = _increase_balance(data['user_id'], amount, data['balance_type'], data.get('balance_dct', {}))
#     elif amount < 0:
#         account = _decrease_balance(data['user_id'], -amount, data['balance_type'])
#     data['price'], data['balance'] = convert_hao_to_yuan(amount), account.balance
#     # insert transaction
#     trans = Transaction()
#     trans = create_transaction_record(trans, data)
#     data['id'] = trans.id
#     return 1, account


def test_increase():
    # account = Account.query.with_for_update().filter(Account.id == USER_ID).first()
    # print('current balance:%s' % account.balance)
    # print(u'加2')
    # account.balance = account.balance + 2
    # account.save(auto_commit=False)
    # orm.session.flush()
    #
    # amount = 200
    # data = {'user_id': USER_ID, 'type': TRANSACTION_TYPE.SYSTEM_RECHARGE, 'trans_type': TRANS_TYPE.SYSTEM_RECHARGE,
    #         'title': u'系统加钱', 'price': convert_hao_to_yuan(amount), 'status': TRANSACTION_STATUS.DONE,
    #         'out_trans_id': uuid.uuid1(), 'balance_type': BALANCE_TYPE.BALANCE, 'balance': account.balance}
    # trans = Transaction()
    # trans = create_transaction_record(trans, data)
    # orm.session.commit()
    # print(account.balance)
    # orm.session.commit()

    amount = 200
    data = {
        'user_id': USER_ID,
        'type': TRANSACTION_TYPE.SYSTEM_RECHARGE,
        'title': u'系统加钱',
        'price': convert_fen_to_hao(amount),
        'status': TRANSACTION_STATUS.DONE,
        # 'out_trans_id': uuid.uuid1(),
        'balance_type': BALANCE_TYPE.BALANCE,
    }
    trans_id = create_transaction(data)
    # account = _increase_balance(USER_ID, convert_fen_to_hao(amount), BALANCE_TYPE.BALANCE)
    print(u'加2')
    # orm.session.commit()


def test_decrease():
    # account = Account.query.with_for_update().filter(Account.id == USER_ID).first()
    # print('current balance:%s' % account.balance)
    # print(u'减1')
    # account.balance = account.balance - 1
    # account.save(auto_commit=False)
    # orm.session.flush()
    # amount = -100
    # data = {
    #     'user_id': USER_ID,
    #     'type': TRANSACTION_TYPE.SYSTEM_RECHARGE,
    #     'trans_type': TRANS_TYPE.SYSTEM_RECHARGE,
    #     'title': u'系统减钱',
    #     'price': convert_fen_to_hao(amount),
    #     'status': TRANSACTION_STATUS.DONE,
    #     'out_trans_id': uuid.uuid1(),
    #     'balance_type': BALANCE_TYPE.BALANCE,
    # }
    # trans = Transaction()
    # trans = create_transaction_record(trans, data)
    # orm.session.commit()
    # print(account.balance)
    # account.save()
    # orm.session.commit()

    amount = -100
    data = {
        'user_id': USER_ID,
        'type': TRANSACTION_TYPE.SYSTEM_RECHARGE,
        'title': u'系统减钱',
        'price': convert_fen_to_hao(amount),
        'status': TRANSACTION_STATUS.DONE,
        # 'out_trans_id': uuid.uuid1(),
        'balance_type': BALANCE_TYPE.BALANCE,
    }
    trans_id = create_transaction(data)
    # # account = _decrease_balance(USER_ID, convert_fen_to_hao(100), BALANCE_TYPE.BALANCE)
    print(u'减1')
    # orm.session.commit()



def test_multi_increase(s):
    print(s)
    test_increase()
    test_increase()
    test_increase()
    orm.session.commit()
    Account.query.filter(Account.id == USER_ID).first()
    test_increase()
    test_increase()
    orm.session.commit()
    test_increase()
    test_increase()
    orm.session.commit()
    test_increase()
    test_increase()
    orm.session.commit()


def test_multi_decrease(s):
    print(s)
    test_decrease()
    test_decrease()
    # orm.session.refresh(account)
    test_decrease()
    orm.session.commit()
    test_decrease()
    test_decrease()
    orm.session.commit()
    test_decrease()
    test_decrease()
    test_decrease()
    orm.session.commit()
    orm.session.commit()


Thread(target=test_multi_increase, args=('Hello1',)).start()
# Thread(target=test_multi_increase, args=('Hello2',)).start()
# time.sleep(0.1)

Thread(target=test_multi_decrease, args=('Hello3',)).start()
#
# Thread(target=test_multi_decrease, args=('Hello4',)).start()
