# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os
import sys
import requests
import json
from datetime import datetime

# add up one level dir into sys path
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
os.environ['DJANGO_SETTINGS_MODULE'] = 'base.settings'

from api.preset.handler import view_pay_type
from django.conf import settings
from common.withdraw.just_withdraw import generate_sign
from common.cache import redis_cache
from common.pay.model import PAY_STATUS, PAY_TYPE, PAY_SERVICE_NAMES


def check_payservice_available(user_id, pay_types):
    # 根据userid query_paytypes
    # available_pays = redis_cache.get_available_pays()
    try:
        parameter_dict = {
            'mch_id': settings.JUSTPAY_MCH_ID,
            'user_id': user_id
        }
        parameter_dict['sign'] = generate_sign(parameter_dict, settings.JUSTPAY_API_KEY)
        query_url = settings.QUERY_URL
        res = requests.post(settings.QUERY_URL, data=parameter_dict, timeout=3).text
        res = json.loads(res)
        print('requests,url:%s, params:%s, response:%s' % (settings.QUERY_URL, parameter_dict,res))
        available_pays = res['data']['list']
    except Exception as e:
        print('query_pay_type by user_id error, %s', user_id)
        available_pays = redis_cache.get_available_pays()

    available_sources = [PAY_SERVICE_NAMES.get(ap) for ap in available_pays]

    print available_sources
    pay_list = []
    for pay_type in pay_types:
        pt = str(pay_type.get('pay_type'))
        if pt and pt in PAY_SERVICE_NAMES.values():
            if pt in available_sources:
                pay_list.append(pay_type)
        else:
            pay_list.append(pay_type)
    return pay_list

tracks = {'cvc': 33, 'chn': 'google'}
filtered_available_pay_types = view_pay_type(tracks.get('cvc'), tracks.get('chn'))

print(filtered_available_pay_types)

pay_type_list = check_payservice_available(150508, filtered_available_pay_types)

print(pay_type_list)