#! -*- coding:utf-8 -*-

import unittest
from common.lottery.cyclical.ssc.order import generate_win_func, BET_TYPE


class GenerateWinFuncTest(unittest.TestCase):

    def test_generate_win_func(self):
        funcs = generate_win_func("01345")

        # test PLATE_SUM_BSOE
        self.assertEqual(funcs[BET_TYPE.PLATE_SUM_BSOE]('b'), 0)
        self.assertEqual(funcs[BET_TYPE.PLATE_SUM_BSOE]('s'), 1)
        self.assertEqual(funcs[BET_TYPE.PLATE_SUM_BSOE]('e'), 0)
        self.assertEqual(funcs[BET_TYPE.PLATE_SUM_BSOE]('o'), 1)
        self.assertEqual(funcs[BET_TYPE.PLATE_SUM_BSOE]('b,s'), 1)
        self.assertEqual(funcs[BET_TYPE.PLATE_SUM_BSOE]('b,e'), 0)
        self.assertEqual(funcs[BET_TYPE.PLATE_SUM_BSOE]('s,o'), 2)

        # test PLATE_BOSE_1
        self.assertEqual(funcs[BET_TYPE.PLATE_BOSE_1]('b'), 0)
        self.assertEqual(funcs[BET_TYPE.PLATE_BOSE_1]('e'), 1)
        self.assertEqual(funcs[BET_TYPE.PLATE_BOSE_1]('s'), 1)
        self.assertEqual(funcs[BET_TYPE.PLATE_BOSE_1]('o'), 0)

        # test PLATE_BOSE_5
        self.assertEqual(funcs[BET_TYPE.PLATE_BOSE_5]('b'), 1)
        self.assertEqual(funcs[BET_TYPE.PLATE_BOSE_5]('e'), 0)
        self.assertEqual(funcs[BET_TYPE.PLATE_BOSE_5]('s'), 0)
        self.assertEqual(funcs[BET_TYPE.PLATE_BOSE_5]('o'), 1)

        # test PLATE_DRAGON_TIGER_1_5
        self.assertEqual(funcs[BET_TYPE.PLATE_DRAGON_TIGER_1_5]('d'), -1)
        self.assertEqual(funcs[BET_TYPE.PLATE_DRAGON_TIGER_1_5]('t'), 0)


if __name__ == "__main__":
    unittest.main()
