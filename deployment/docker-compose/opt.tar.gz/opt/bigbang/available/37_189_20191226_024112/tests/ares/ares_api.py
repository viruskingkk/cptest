#! -*- coding:utf-8 -*-
import hashlib
import time
import json
import requests
import uuid
from datetime import datetime

MERCHANT = 'WITCH'
ARES_URL = 'http://103.71.50.214:11898/imone'
ARES_KEY = 'fYZr4DeT6aeaeIxMSOXP'


def post(*args, **kwargs):
    return _request('post', *args, **kwargs)


def _request(method, *args, **kwargs):
    if 'disable_proxy' in kwargs:
        del kwargs['disable_proxy']

    result = getattr(requests, method)(*args, **kwargs)
    return result


def generate_sign(data, website, _time, key):
    s = ''
    s += '%s%s%s&%s%s' % (website, _time, key, data, MERCHANT)
    m = hashlib.md5()
    m.update(s.encode('utf8'))
    sign = m.hexdigest()
    return sign


def _base_request(method, data, success_code=[0], website="witch", timeout=10):
    url = ARES_URL + method
    key = ARES_KEY
    timestamp = int(time.time())
    headers = {'content-type': 'application/json'}
    data = json.dumps(data, separators=(',', ':'))
    sign = generate_sign(data, website, timestamp, key)
    payload = {"M": MERCHANT, "L": website, "time": timestamp, "sign": sign}
    print('begin request imone_api {}, data: {}'.format(method, data))
    resp = post(url, params=payload, headers=headers, data=data, timeout=timeout)
    print(resp.url)

    print('finish request imone_api {}-{}, resp.content : {}'.format(method, data, resp.content))
    print(resp.status_code)
    if resp.status_code != 200:
        return False, None
    else:
        resp_data = json.loads(resp.text)
        if resp_data['code'] in success_code and int(resp_data['data']['Code']) in success_code:
            return True, resp_data.get('data')
        else:
            return False, None


def launch(user_id, ref_id, amount, wallet):
    method = '/trade_bank'
    data = {"user": user_id, "gold": amount, "refs": ref_id, "wallet": wallet}
    return _base_request(method, data)


def check_transfer_status(user_id, ref_id, wallet):
    method = '/check_transfer_status'
    data = {"user": user_id, "refs": ref_id, "wallet": wallet}
    return _base_request(method, data)

REF_ID = uuid.uuid1().hex


def withdraw(user_id, ref_id, wallet):
    method = '/trade_draw'
    data = {"user": user_id, "refs": ref_id, "wallet": wallet}
    return _base_request(method, data)


def query_balance(user_id, wallet):
    """查询当前在游戏内的余额"""
    method = '/get_balance'
    data = {"user": user_id, "wallet": wallet}
    return _base_request(method, data)


if __name__ == '__main__':
    user = '2310543'
    ref_id = '474f9df740544598907017b9deea01b7'
    # ref_id = uuid.uuid1().hex
    amount = 10
    wallet = 1
    # wallet = 201
    # status, data = launch(user, ref_id, amount, wallet)
    # status, data = check_transfer_status(user, ref_id, wallet)

    # status, data = withdraw(user, ref_id, wallet)
    status, data = query_balance(user, wallet)
    # start = datetime.strptime('2019-05-25 09:05:00', '%Y-%m-%d %H:%M:%S')
    # end = datetime.strptime('2019-05-25 09:15:00', '%Y-%m-%d %H:%M:%S')
    # status, data = query_bet_logs(wallet, start, end, 1, 1000)

    print(status)
    print(data)
