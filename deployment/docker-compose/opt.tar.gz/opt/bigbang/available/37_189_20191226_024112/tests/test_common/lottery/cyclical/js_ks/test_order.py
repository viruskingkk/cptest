import unittest
from common.lottery.cyclical.ff_ks.logic.order import generate_win_func, BET_TYPE


class GenerateWinFuncTest(unittest.TestCase):

    def test_generate_win_func(self):
        funcs = generate_win_func("455")

        # test PLATE_SUM_BSOE
        self.assertEqual(funcs[BET_TYPE.PLATE_SUM_BSOE]('b,e'), 2)
        self.assertEqual(funcs[BET_TYPE.PLATE_SUM_BSOE]('s'), 0)
        self.assertEqual(funcs[BET_TYPE.PLATE_SUM_BSOE]('b,o'), 1)

