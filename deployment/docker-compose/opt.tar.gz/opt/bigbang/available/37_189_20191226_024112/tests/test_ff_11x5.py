# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os
import sys
import requests
import json
from datetime import datetime

# add up one level dir into sys path
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
os.environ['DJANGO_SETTINGS_MODULE'] = 'base.settings'


from common.lottery.cyclical.ff_11x5.logic.order import *


def test_ff_11x5():
    win_funs = generate_win_func('3,5,8,7,11')
    win_price = calc_win_price(win_funs, '3,5', BET_TYPE.TWO_FRONT_GROUP)
    print(win_price)

if __name__ == '__main__':
    test_ff_11x5()
