DEBUG = True

IS_PRODUCTION_ENV = False

CORS_ORIGIN_ALLOW_ALL = True

MYSQL_CONF = {
    'db': 'mysql://root:123456@127.0.0.1:3306/bigbang?charset=utf8',
    'DEBUG': False
}

SLAVE_CONF = MYSQL_CONF

ADMIN_CONF = {
    'db': 'mysql://root:123456@127.0.0.1:3306/bigbang_admin?charset=utf8',
    'DEBUG': False
}

MONGO_ADDR = '127.0.0.1:27017'

CELERY_BROKER = 'redis://127.0.0.1:6379//'

REDIS_HOST = '127.0.0.1'
REDIS_PORT = 6379

JUSTPAY_NOTIFY_URL = 'http://13.250.105.3/api/v1/third/justpay/notify'

JUSTPAY_MCH_ID = '7'
JUSTPAY_HOST = 'http://219.135.56.195:9003'
JUSTPAY_API_KEY = '10b7ca9b90f44d879f179084b02f3940'
JUSTPAY_CHARGE_URL = JUSTPAY_HOST + '/pay/api/charge/create'
JUSTPAY_TRANS_URL = JUSTPAY_HOST + '/pay/api/trans/create/'
JUSTPAY_TRANS_QUERY_CHANNELS = 'http://219.135.56.195:9003/pay/api/trans/query_channels/'
QUERY_URL = 'http://219.135.56.195:9003/pay/api/channel/get_vaild_pay_type/'

EXCHANGE_CALLBACK_URL = 'http://219.135.56.195:9001/exchange/'

UNIONAGENCY_NOTIFY_URL = 'http://13.250.105.3/api/v1/third/unionagency/notify'
UNIONAGENCY_MCH_ID = '2'
UNIONAGENCY_HOST = 'http://test.maiunion.net:8084'
UNIONAGENCY_API_KEY = 'b12f2adf9aca408983f6a5c5efdf30e7'
UNIONAGENCY_CHARGE_URL = UNIONAGENCY_HOST + '/fin/api/charge/create'
UNIONAGENCY_GATEWAY_URL = UNIONAGENCY_HOST + '/fin/api/gateway/'
UNIONAGENCY_FILL_URL = UNIONAGENCY_HOST + '/fin/api/charge/fill'
UNIONAGENCY_CHARGE_URL_V2 = UNIONAGENCY_HOST + '/api/v2/recharge/create/'
UNIONAGENCY_GATEWAY_URL_V2 = 'http://13.250.105.3/info/ChargeUnionAgent'
UNIONAGENCY_WITHDRAW_CHARGE_URL = UNIONAGENCY_HOST + '/api/v2/withdraw/create/'
UNIONAGENCY_WITHDRAW_QUERY_URL = UNIONAGENCY_HOST + '/api/v2/withdraw/query/'
UNIONAGENCY_WITHDRAW_NOTIFY_URL = 'http://13.250.105.3/api/v1/third/unionagency/withdraw/notify/'
UNIONAGENCY_PAY_INFO_QUERY_URL = UNIONAGENCY_HOST + "/api/v2/recharge/query/"

UNIONAGENCY_CHARGE_URL_NEW = 'http://13.250.105.3:9001/recharge/OfficialRecharge'

UNION_REDIS_HOST = '127.0.0.1'
UNION_REDIS_PORT = 6379

NEW_UNIONAGENCY_MCH_ID = '10002'
NEW_UNIONAGENCY_API_KEY = '6a78afa1-ccf5-4e6b-ad64-c6fc919fbae9'
NEW_UNIONAGENCY_HOST = 'http://3.1.171.240:50001'
NEW_UNIONAGENCY_WITHDRAW_URL = NEW_UNIONAGENCY_HOST + '/api/withdraw/'
NEW_UNIONAGENCY_WITHDRAW_QUERY_URL = UNIONAGENCY_HOST + '/api/withdraw/query/'

WEB_APP_ROOT_URL = 'http://13.250.105.3'

METIS_URL = 'http://stage.labsgl.com:8801/api'
METIS_CONTROL_URL = 'http://stage.labsgl.com:8003/backend'
METIS_KEY = '378d6694-9c41-11e8-9d0b-42010a8c0002'

AMETIS_URL = 'http://103.230.243.68:12000/1'
AMETIS_KEY = 'fYZr4DeT6aeaeIxMSOXP'
AMETIS_DATA_URL = 'http://103.230.243.68:12000'

ARES_URL = 'http://103.230.243.68:11898/imone'
ARES_KEY = 'fYZr4DeT6aeaeIxMSOXP'

MF_MERCHANT_ID = 19
MF_MERCHANT_KEY = 'f67d35a8-2aee-4d4f-bab8-9cb297de2b48'
MF_API_HOST = 'http://miaopay.testxyz115.com:20002/api/'

# miaofu and justpay use the same url
APPEAL_NOTIFY_URL = 'http://13.250.105.3/api/v1/appeal/notify/'

# customer service parameters
CS_MERCHANT_ID = 20
CS_MERCHANT_KEY = '95de6f0c-6e3a-86e1-c7e8-982e3dd415af'
CS_TOKEN_API = 'http://18.136.192.121:9292/rpc/get_token/'
CS_H5_API = 'http://18.136.192.121:9295/customerServicePage/'
