DEBUG = False

CORS_ORIGIN_ALLOW_ALL = True

MYSQL_CONF = {
    'db': 'mysql://bigbang:n0ra@wang@Witch-Mysql-1.dns236.com:3306/bigbang?charset=utf8',
    'DEBUG': DEBUG
}

SLAVE_CONF = {
    # 'db': 'mysql://bigbang:n0ra@wang@103.230.243.141:3306/bigbang?charset=utf8',
    'db': 'mysql://bigbang:n0ra@wang@Witch-Mysql-1.dns236.com:3306/bigbang?charset=utf8',
    'DEBUG': DEBUG
}

ADMIN_CONF = {
    'db': 'mysql://bigbang:n0ra@wang@Witch-Mysql-1.dns236.com:3306/bigbang_admin?charset=utf8',
    'DEBUG': DEBUG
}

METIS_MYSQL_CONF = {
    'db': 'mysql://admin:ST83wSNx398W97HP@103.71.50.18:3307/platform?charset=utf8',
    'DEBUG': DEBUG
}

MONGO_ADDR = 'Witch-Nosql-1.dns236.com:27017'

CELERY_BROKER = 'redis://Witch-Nosql-1.dns236.com:6379//'

REDIS_HOST = 'Witch-Nosql-1.dns236.com'
REDIS_PORT = 6379

# if move the console machine, should change the direction of pay.umk12.com, this is very important
CONSOLE_HOST = 'http://pay.umk12.com:9001'

JUSTPAY_NOTIFY_URL = CONSOLE_HOST + '/api/v1/third/justpay/notify/'

JUSTPAY_MCH_ID = '6001000'
JUSTPAY_HOST = 'http://api.o2ojob.net:9009'
JUSTPAY_API_KEY = 'c1750f82442a4b65ba4fa55a8ee78848'
JUSTPAY_CHARGE_URL = JUSTPAY_HOST + '/pay/api/charge/create/'
JUSTPAY_TRANS_URL = JUSTPAY_HOST + '/pay/api/trans/create/'
JUSTPAY_TRANS_QUERY_CHANNELS = JUSTPAY_HOST + '/pay/api/trans/query_channels/'
QUERY_URL = JUSTPAY_HOST + '/pay/api/channel/get_vaild_pay_type/'

EXCHANGE_CALLBACK_URL = CONSOLE_HOST + '/exchange/'

UNIONAGENCY_NOTIFY_URL = CONSOLE_HOST + '/api/v1/third/unionagency/notify'
UNIONAGENCY_MCH_ID = '2'
UNIONAGENCY_HOST = 'http://api.o2ojob.net:9002'
UNIONAGENCY_API_KEY = 'b12f2adf9aca408983f6a5c5efdf30e7'
UNIONAGENCY_CHARGE_URL = UNIONAGENCY_HOST + '/fin/api/charge/create'
UNIONAGENCY_GATEWAY_URL = UNIONAGENCY_HOST + '/fin/api/gateway/'
UNIONAGENCY_FILL_URL = UNIONAGENCY_HOST + '/fin/api/charge/fill'
UNIONAGENCY_CHARGE_URL_V2 = UNIONAGENCY_HOST + '/api/v2/recharge/create/'
UNIONAGENCY_GATEWAY_URL_V2 = 'http://183.60.211.151:9001/info/ChargeUnionAgent'
UNIONAGENCY_WITHDRAW_CHARGE_URL = UNIONAGENCY_HOST + '/api/v2/withdraw/create/'
UNIONAGENCY_WITHDRAW_QUERY_URL = UNIONAGENCY_HOST + '/api/v2/withdraw/query/'
UNIONAGENCY_WITHDRAW_NOTIFY_URL = CONSOLE_HOST + '/api/v1/third/unionagency/withdraw/notify/'
UNIONAGENCY_PAY_INFO_QUERY_URL = UNIONAGENCY_HOST + "/api/v2/recharge/query/"

UNIONAGENCY_CHARGE_URL_NEW = 'http://h5.zv567.com:9001/recharge/OfficialRecharge'

UNION_REDIS_HOST = '103.230.243.233'
UNION_REDIS_PORT = 6379

NEW_UNIONAGENCY_MCH_ID = '10001'
NEW_UNIONAGENCY_API_KEY = 'adca1c68-066b-49d6-9f2b-1cd54033f727'
NEW_UNIONAGENCY_HOST = 'http://ua_open_api.798907.com:22001'
NEW_UNIONAGENCY_WITHDRAW_URL = NEW_UNIONAGENCY_HOST + '/api/withdraw/'
NEW_UNIONAGENCY_WITHDRAW_QUERY_URL = UNIONAGENCY_HOST + '/api/withdraw/query/'

WEB_APP_ROOT_URL = 'http://183.60.211.151:9001'

ES_HOST = "http://103.230.243.40:9200"
MQ_HOST = '61.146.72.33'
MQ_USERNAME = 'admin'
MQ_PASSWORD = 'WCBQf4Bb4YFoNbgUtXaC'

QINIU_DOMAIN = 'http://{}.rqzahb.com/'
ADMIN_BUCKET_NAME = 'bigbang'

QINIU_BUCKETS = {
    'default': QINIU_DOMAIN.format('bigbang'),
    'avatar': QINIU_DOMAIN.format('avatar'),
    'show': QINIU_DOMAIN.format('show'),
}

METIS_URL = 'http://gs.kcvh79w.com:8001/api'
METIS_CONTROL_URL = 'http://gs.kcvh79w.com:8003/backend'
METIS_KEY = '378d6694-9c41-11e8-9d0b-42010a8c0002'

ARES_URL = 'http://103.71.50.214:11898/imone'
ARES_KEY = 'fYZr4DeT6aeaeIxMSOXP'

AMETIS_URL = 'http://103.71.50.214:12000/1'
AMETIS_DATA_URL = 'http://103.71.50.214:12000'
AMETIS_KEY = 'fYZr4DeT6aeaeIxMSOXP'

MF_MERCHANT_ID = 88802
MF_MERCHANT_KEY = '7fa52ffb-701d-4ca4-8a52-a73cb27e67e9'
MF_API_HOST = 'http://proxy.maosaijf.com:11006/api/'

# miaofu and justpay use the same url
APPEAL_NOTIFY_URL = CONSOLE_HOST + '/api/v1/appeal/notify/'


# customer service parameters
CS_MERCHANT_ID = 20
CS_MERCHANT_KEY = '85a54e1c-52a1-974c-16e2-467da167a3c63'
CS_TOKEN_API = 'http://pyy89.com:9292/rpc/get_token/'
CS_H5_API = 'http://cqqz99.com:9295/customerServicePage/'