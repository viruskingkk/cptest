# -*- coding: utf-8 -*-
"""
Django settings for base project.

For more information on this file, see
https://docs.djangoproject.com/en/1.6/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/1.6/ref/settings/
"""

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
import os
from base.jsonlogger import JsonFormatter

# 生成ID时使用，不同的机器应当使用不同的ID
SERVICE_ID = 1

# 标识当前是生产环境
IS_PRODUCTION_ENV = True

# 当前启动入口标识
BIGBANG_ENV = os.getenv('BIGBANG_ENV', 'bigbang_api')

BASE_DIR = os.path.dirname(os.path.dirname(__file__))

FONT_PATH = os.path.join(BASE_DIR, 'base/font/')

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.6/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'mzm2ojrfc54x#9%dptxc4c-!pa3ppj!h(5=@^h*346p-fs88vi'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

UNIONAGENCY_PAY_INFO_QUERY_URL = "http://test.maiunion.net:8084/api/v2/recharge/query/"

TEMPLATE_DEBUG = True

ALLOWED_HOSTS = ['*']

COUNTRY = 'cn'

CELERY_BROKER = 'redis://127.0.0.1:6379//'

GEOLITE_CITY_DB = '/opt/bigbang/GeoLite2-City.mmdb'

WEB_APP_ROOT_URL = ''

# 七牛相关依赖，用于图片存储
QINIU_KEY_PAIR = ('NPQQw0Ybar-3koZu2JhVGQ8Ezo0PXuVn6EwuinZ4',
                  'pzuW4eqmHa42fW_89n-3kDCe4pCRou3JdCLCp_Od')

# 此bucket用于存储控制台上传图片

QINIU_DOMAIN = 'http://{}.rqzahb.com/'
ADMIN_BUCKET_NAME = 'bigbang'

QINIU_BUCKETS = {
    'default': QINIU_DOMAIN.format('bigbang'),
    'avatar': QINIU_DOMAIN.format('avatar'),
    'show': QINIU_DOMAIN.format('show'),
}

# 用户默认头像
DEFAULT_AVATAR = QINIU_BUCKETS['avatar'] + 'avatar_default.png'

# 微信相关依赖
WX_APP_ID = ""
WX_SECRET_KEY = ""
WX_CLIENT_TOKEN = ""
WX_ENCODING_AES_KEY = ""

# xinge相关依赖，用于推送
XINGE_ACCESS_ID = ''
XINGE_SECRET = ''
XINGE_IOS_ACCESS_ID = '2200256757'
XINGE_IOS_SECRET = 'f40de2e85ce2af0badd4583739bc6ece'
XINGE_IPAD_ACCESS_ID = ''
XINGE_IPAD_SECRET = ''
APNS_ENV = 1  # 1-生产环境，2-开发环境
XINGE_ANDROID_ACCESS_ID = '2100256756'
XINGE_ANDROID_SECRET = 'ef9bdef45120d5c6ab1f2b6ce0fdf758'

XINGE_IOS_CONF = {
    'ios': {
        'access_id': '2200256757',
        'secret_key': 'f40de2e85ce2af0badd4583739bc6ece'
    }
}

UNION_REDIS_HOST = '192.168.20.65'
UNION_REDIS_PORT = 6379

SUBMAIL_APPID = '14029'
SUBMAIL_APP_KEY = '1597866f5ee0faec66071151f692ff07'

JUSTPAY_MCH_ID = '6001000'
JUSTPAY_API_KEY = 'c1750f82442a4b65ba4fa55a8ee78848'
JUSTPAY_CHARGE_URL = 'http://183.60.211.195:9003/pay/api/charge/create/'
JUSTPAY_TRANS_URL = 'http://183.60.211.195:9003/pay/api/trans/create/'
JUSTPAY_TRANS_QUERY_CHANNELS = 'http://183.60.211.195:9003/pay/api/trans/query_channels/'

# 控制台文件导出路径
EXPORT_PATH = '/tmp/export_data/'
if not os.path.isdir(EXPORT_PATH):
    os.mkdir(EXPORT_PATH)

# Application definition

INSTALLED_APPS = (
    'api',
    'admin',
    'corsheaders',
    'tests',
)

# List of callables that know how to import templates from various sources.
TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.Loader',
    'django.template.loaders.app_directories.Loader',
    # 'django.template.loaders.eggs.Loader',
)

MIDDLEWARE_CLASSES = (
    'corsheaders.middleware.CorsMiddleware',
    'base.middleware.ApiGateMiddleware',
    'base.middleware.UserMiddleware',
)

ROOT_URLCONF = 'base.urls'

WSGI_APPLICATION = 'base.wsgi.application'

SITE_ROOT = os.path.dirname(os.path.realpath(__file__))

TEMPLATE_DIRS = (
    # Put strings here, like "/home/html/django_templates"
    # "C:/www/django/templates".
    # Always use forward slashes, even on Windows.
    # Don't forget to use absolute paths, not relative paths.
    os.path.join(SITE_ROOT, 'templates'),
)

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    }
}

CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'unique-snowflake',
    }
}

# Internationalization
# https://docs.djangoproject.com/en/1.6/topics/i18n/

LANGUAGE_CODE = 'zh-cn'

LOCALE_PATHS = ['/home/ubuntu/af-env/bigbang/locale']

TIME_ZONE = 'UTC'

USE_I18N = False

USE_L10N = True

USE_TZ = True

APPEND_SLASH = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.6/howto/static-files/

STATIC_URL = '/static/'

MYSQL_CONF = {
    'db': 'mysql://root:123456@127.0.0.1:3306/bigbang?charset=utf8',
    'DEBUG': False
}

SLAVE_CONF = MYSQL_CONF

ADMIN_CONF = {
    'db': 'mysql://root:123456@127.0.0.1:3306/bigbang_admin?charset=utf8',
    'DEBUG': False
}

METIS_MYSQL_CONF = {
    'db': 'mysql://root:123456@127.0.0.1:3306/bigbang?charset=utf8',
    'DEBUG': False
}

MONGO_ADDR = '127.0.0.1:27017'

REDIS_HOST = 'localhost'
REDIS_PORT = 6379
STRATEGY_REDIS_DB = 8  # for strategy

# ES
ES_HOST = 'http://127.0.0.1:9200'

# PingPlusPlus config
# Pingpp App key
PINGXX_API_KEY = ''
PINGXX_APP_ID = ''

# LOG CONFIG
LOG_DIR = "/var/log/bigbang/"
LOG_FILE = os.path.join(LOG_DIR, "bigbang.log")
LOG_ERR_FILE = os.path.join(LOG_DIR, "bigbang.err.log")
TRACK_LOG = os.path.join(LOG_DIR, 'track.json')
MAESTRO_LOG = os.path.join(LOG_DIR, 'maestro.json')
SPECIAL_USER_LOG = os.path.join(LOG_DIR, 'special_user.log')

MQ_HOST = '127.0.0.1'
MQ_USERNAME = ''
MQ_PASSWORD = ''

METIS_URL = ''
METIS_CONTROL_URL = ''
METIS_KEY = ''

try:
    from base.env_settings import *
except ImportError:
    import logging

    logging.warn('no env specified settings loaded, use default.')
    pass

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'json_stat': {
            '()': JsonFormatter,
            'format': '%(message)s'
        },
        'simple': {
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        }
    },
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'formatter': 'simple'
        },
        'file': {
            'level': 'INFO',
            'formatter': 'simple',
            'class': 'logging.handlers.WatchedFileHandler',
            'filename': LOG_FILE,
        },
        'err_file': {
            'level': 'WARN',
            'formatter': 'simple',
            'class': 'logging.handlers.WatchedFileHandler',
            'filename': LOG_ERR_FILE,
        },
        'track_file': {
            'level': 'INFO',
            'formatter': 'json_stat',
            'class': 'logging.handlers.WatchedFileHandler',
            'filename': TRACK_LOG
        },
        'maestro_file': {
            'level': 'INFO',
            'formatter': 'json_stat',
            'class': 'logging.handlers.WatchedFileHandler',
            'filename': MAESTRO_LOG
        },
        'special_user_file': {
            'level': 'INFO',
            'formatter': 'simple',
            'class': 'logging.handlers.WatchedFileHandler',
            'filename': SPECIAL_USER_LOG
        },
        'tg_handler': {
            'level': 'ERROR',
            'class': 'common.utils.loger_handlers.TGHandler',
            'formatter': 'simple'
        }
    },
    'loggers': {
        'tracker': {
            'handlers': ['track_file'],
            'level': 'INFO',
            'propagate': False
        },
        'maestro': {
            'handlers': ['maestro_file'],
            'level': 'INFO',
            'propagate': False
        },
        'special_user': {
            'handlers': ['special_user_file'],
            'level': 'INFO',
            'propagate': False
        }
    },
    'root': {
        'level': 'DEBUG',
        'handlers': ['console', 'file', 'err_file'] if DEBUG else ['file', 'err_file', 'tg_handler'],
        'propagate': True
    }
}

# if IS_PRODUCTION_ENV:
#     LOGGING['handlers']['mq_handler'] = {
#         'level': 'INFO',
#         'formatter': 'simple',
#         'class': 'common.utils.loger_handlers.MQHandler',
#         'host': MQ_HOST,
#         'username': MQ_USERNAME,
#         'password': MQ_PASSWORD,
#         'exchange': 'e_' + BIGBANG_ENV
#     }
#
#     LOGGING['root']['handlers'].append('mq_handler')
