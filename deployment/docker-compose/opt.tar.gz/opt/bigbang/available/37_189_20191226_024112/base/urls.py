from django.conf.urls import patterns, include, url


urlpatterns = patterns(
    '',
    url(r'^api/v1/', include('api.urls')),
    url(r'^admin/', include('admin.urls')),
    url(r'^exchange/', include('api.urls_exchange')),
    url(r'^api/v2/', include('api.urls_v2')),
    url(r'^api/v3/', include('api.urls_v3')),
    url(r'^api/v4/', include('api.urls_v4')),
)
