#! /bin/bash
curl 'http://console.91whcp.com:9001/admin/user/5/?_=1505560860088' -H 'User-Agent: HeartBeating by python' -H 'Cookie: bigbang_user_id=5; bigbang_user_token=c55852c6-bf54-4547-8d02-a7bc6b9e348c'
curl 'http://console.91whcp.com:9001/admin/user/5/?_=1505560860088' -H 'User-Agent: HeartBeating by python' -H 'Cookie: bigbang_user_id=5; bigbang_user_token=c55852c6-bf54-4547-8d02-a7bc6b9e348c'
curl 'http://console.91whcp.com:9001/admin/user/5/?_=1505560860088' -H 'User-Agent: HeartBeating by python' -H 'Cookie: bigbang_user_id=5; bigbang_user_token=c55852c6-bf54-4547-8d02-a7bc6b9e348c'
curl 'http://console.91whcp.com:9001/admin/user/5/?_=1505560860088' -H 'User-Agent: HeartBeating by python' -H 'Cookie: bigbang_user_id=5; bigbang_user_token=c55852c6-bf54-4547-8d02-a7bc6b9e348c'
