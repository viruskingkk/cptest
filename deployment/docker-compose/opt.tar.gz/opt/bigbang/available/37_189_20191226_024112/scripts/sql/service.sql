-- MySQL dump 10.13  Distrib 5.7.17, for osx10.12 (x86_64)
--
-- Host: 192.168.20.65    Database: bigbang
-- ------------------------------------------------------
-- Server version	5.7.18-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `abtest`
--

DROP TABLE IF EXISTS `abtest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abtest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` text COLLATE utf8mb4_unicode_ci,
  `user_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trade_pwd` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `channel` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `citizen_id` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sign` text COLLATE utf8mb4_unicode_ci,
  `balance` decimal(20,3) DEFAULT NULL,
  `withdraw` decimal(20,3) DEFAULT NULL,
  `status` int(4) DEFAULT '0',
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_virtual` tinyint(4) DEFAULT '0',
  `settings` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_idx` (`user_name`),
  UNIQUE KEY `phone_idx` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=5069 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_bankcard`
--

DROP TABLE IF EXISTS `account_bankcard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_bankcard` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `bank_id` smallint(6) NOT NULL,
  `card_no` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_bankcard` (`user_id`,`card_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_coupon`
--

DROP TABLE IF EXISTS `account_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `template_id` int(11) NOT NULL,
  `coupon_type` tinyint(4) NOT NULL,
  `title` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` smallint(6) NOT NULL,
  `condition_price` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `expire_ts` int(11) NOT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `start_ts` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_token`
--

DROP TABLE IF EXISTS `account_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_token` (
  `user_id` bigint(20) NOT NULL DEFAULT '0',
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chn` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `cvc` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `extend` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` smallint(6) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announce_show`
--

DROP TABLE IF EXISTS `announce_show`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announce_show` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_index_id` bigint(20) DEFAULT NULL,
  `order_id` bigint(20) NOT NULL,
  `activity_type` smallint(6) NOT NULL,
  `term_number` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `status` smallint(6) NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `images` text COLLATE utf8mb4_unicode_ci,
  `verified_at` int(11) DEFAULT NULL,
  `verify_comment` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `highlight` smallint(6) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `detail` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bj_pk10`
--

DROP TABLE IF EXISTS `bj_pk10`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bj_pk10` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=3518 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bj_pk10_order`
--

DROP TABLE IF EXISTS `bj_pk10_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bj_pk10_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bj_pk10_trend`
--

DROP TABLE IF EXISTS `bj_pk10_trend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bj_pk10_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_7` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_8` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_9` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_7` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_8` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_9` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `coupon_template`
--

DROP TABLE IF EXISTS `coupon_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupon_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_type` tinyint(4) NOT NULL,
  `title` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` smallint(6) NOT NULL,
  `condition_price` int(11) DEFAULT NULL,
  `valid_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activity_type` int(11) DEFAULT NULL,
  `cmd` text COLLATE utf8mb4_unicode_ci,
  `remark` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cq_ssc`
--

DROP TABLE IF EXISTS `cq_ssc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cq_ssc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=14698 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cq_ssc_order`
--

DROP TABLE IF EXISTS `cq_ssc_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cq_ssc_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1233 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cq_ssc_trend`
--

DROP TABLE IF EXISTS `cq_ssc_trend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cq_ssc_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_11` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_232` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_235` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_313` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_316` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_323` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_326` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_333` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_336` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_200` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_209` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_309` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_409` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=151130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_recharge_campaign`
--

DROP TABLE IF EXISTS `daily_recharge_campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_recharge_campaign` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `date` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `price` int(11) DEFAULT NULL,
  `status` smallint(6) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`date`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `nick_name` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qq` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `chn` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cvc` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1569 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fortune_wheel`
--

DROP TABLE IF EXISTS `fortune_wheel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fortune_wheel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `left_normal_times` int(11) NOT NULL,
  `left_double_times` int(11) NOT NULL,
  `apply_normal_times` int(11) NOT NULL,
  `apply_double_times` int(11) NOT NULL,
  `task_status` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`date`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fortune_wheel_award`
--

DROP TABLE IF EXISTS `fortune_wheel_award`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fortune_wheel_award` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_double` int(11) NOT NULL,
  `award_index` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gd_11x5`
--

DROP TABLE IF EXISTS `gd_11x5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gd_11x5` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=10941 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gd_11x5_order`
--

DROP TABLE IF EXISTS `gd_11x5_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gd_11x5_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gd_11x5_trend`
--

DROP TABLE IF EXISTS `gd_11x5_trend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gd_11x5_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_12` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=28986 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gx_ks`
--

DROP TABLE IF EXISTS `gx_ks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gx_ks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=10758 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gx_ks_order`
--

DROP TABLE IF EXISTS `gx_ks_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gx_ks_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `track_status` tinyint(4) NOT NULL DEFAULT '1',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=446 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gx_ks_trend`
--

DROP TABLE IF EXISTS `gx_ks_trend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gx_ks_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_8` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_9` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=15569 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hn_wfc`
--

DROP TABLE IF EXISTS `hn_wfc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hn_wfc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=6308 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hn_wfc_order`
--

DROP TABLE IF EXISTS `hn_wfc_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hn_wfc_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hn_wfc_trend`
--

DROP TABLE IF EXISTS `hn_wfc_trend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hn_wfc_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_11` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hn_yfc`
--

DROP TABLE IF EXISTS `hn_yfc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hn_yfc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=30344 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hn_yfc_order`
--

DROP TABLE IF EXISTS `hn_yfc_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hn_yfc_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hn_yfc_trend`
--

DROP TABLE IF EXISTS `hn_yfc_trend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hn_yfc_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_11` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jd_area`
--

DROP TABLE IF EXISTS `jd_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jd_area` (
  `id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `parent` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `js_ks`
--

DROP TABLE IF EXISTS `js_ks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `js_ks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=11473 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `js_ks_order`
--

DROP TABLE IF EXISTS `js_ks_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `js_ks_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `track_status` tinyint(4) NOT NULL DEFAULT '1',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=253 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `js_ks_trend`
--

DROP TABLE IF EXISTS `js_ks_trend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `js_ks_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_8` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_9` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=11139 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jx_11x5`
--

DROP TABLE IF EXISTS `jx_11x5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jx_11x5` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=11041 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jx_11x5_order`
--

DROP TABLE IF EXISTS `jx_11x5_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jx_11x5_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jx_11x5_trend`
--

DROP TABLE IF EXISTS `jx_11x5_trend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jx_11x5_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_12` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=27775 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `moist_campaign`
--

DROP TABLE IF EXISTS `moist_campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moist_campaign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `recharge_price` int(11) NOT NULL,
  `award_price` int(11) NOT NULL,
  `coupons` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `notify_type` smallint(6) DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `command` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expire_ts` int(11) DEFAULT NULL,
  `status` smallint(6) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `read` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notification_sys`
--

DROP TABLE IF EXISTS `notification_sys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_sys` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sync_id` bigint(20) DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `expire_ts` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `syncid` (`sync_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notification_user`
--

DROP TABLE IF EXISTS `notification_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `sync_id` bigint(20) DEFAULT NULL,
  `notify_type` int(11) DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usersync` (`user_id`,`sync_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_index`
--

DROP TABLE IF EXISTS `order_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_index` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `activity_type` smallint(6) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `detail` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_idx` (`activity_type`,`order_id`),
  KEY `time_idx` (`user_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2995 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pay`
--

DROP TABLE IF EXISTS `pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `pay_type` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `price` decimal(20,2) DEFAULT NULL,
  `third_id` text COLLATE utf8mb4_unicode_ci,
  `target_id` text COLLATE utf8mb4_unicode_ci,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preset`
--

DROP TABLE IF EXISTS `preset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preset` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `device_type` int(8) DEFAULT '0',
  `min_version` int(8) NOT NULL DEFAULT '1',
  `max_version` int(8) DEFAULT NULL,
  `last_modified` bigint(20) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `content` text COLLATE utf8mb4_unicode_ci,
  `title` text COLLATE utf8mb4_unicode_ci,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `chn` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preset_banner`
--

DROP TABLE IF EXISTS `preset_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preset_banner` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_ts` bigint(20) unsigned DEFAULT NULL,
  `end_ts` bigint(20) unsigned DEFAULT NULL,
  `cmd` text COLLATE utf8mb4_unicode_ci,
  `abtest` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `title` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preset_discovery`
--

DROP TABLE IF EXISTS `preset_discovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preset_discovery` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8mb4_unicode_ci,
  `icon` text COLLATE utf8mb4_unicode_ci,
  `start_ts` bigint(20) unsigned DEFAULT NULL,
  `end_ts` bigint(20) unsigned DEFAULT NULL,
  `desc` text COLLATE utf8mb4_unicode_ci,
  `tag` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cmd` text COLLATE utf8mb4_unicode_ci,
  `abtest` int(10) unsigned DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preset_float_icon`
--

DROP TABLE IF EXISTS `preset_float_icon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preset_float_icon` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8mb4_unicode_ci,
  `icon` text COLLATE utf8mb4_unicode_ci,
  `start_ts` bigint(20) DEFAULT NULL,
  `end_ts` bigint(20) DEFAULT NULL,
  `cmd` text COLLATE utf8mb4_unicode_ci,
  `abtest` int(10) DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preset_loading`
--

DROP TABLE IF EXISTS `preset_loading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preset_loading` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8mb4_unicode_ci,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `stay` int(8) NOT NULL,
  `start_ts` bigint(20) unsigned DEFAULT NULL,
  `end_ts` bigint(20) unsigned DEFAULT NULL,
  `cmd` text COLLATE utf8mb4_unicode_ci,
  `skip` tinyint(2) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `abtest` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preset_pay`
--

DROP TABLE IF EXISTS `preset_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preset_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `least_pay` smallint(6) DEFAULT NULL,
  `pay_type` smallint(6) DEFAULT NULL,
  `desc_short` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc_long` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `highlight` tinyint(4) DEFAULT '0',
  `abtest` smallint(6) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preset_recommend`
--

DROP TABLE IF EXISTS `preset_recommend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preset_recommend` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8mb4_unicode_ci,
  `activity_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_ts` bigint(20) unsigned DEFAULT NULL,
  `end_ts` bigint(20) unsigned DEFAULT NULL,
  `cmd` text COLLATE utf8mb4_unicode_ci,
  `abtest` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `preset_reward`
--

DROP TABLE IF EXISTS `preset_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preset_reward` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activity_type` int(11) DEFAULT '0',
  `enable` tinyint(1) NOT NULL DEFAULT '1',
  `bet_type` int(11) DEFAULT '0',
  `rate` int(11) DEFAULT '0',
  `amount` int(11) DEFAULT '0',
  `withdraw` tinyint(1) DEFAULT '1',
  `condition` text COLLATE utf8mb4_unicode_ci,
  `limit` int(11) DEFAULT '-1',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `push_config`
--

DROP TABLE IF EXISTS `push_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `win` smallint(6) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reward_limit`
--

DROP TABLE IF EXISTS `reward_limit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reward_limit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` decimal(20,2) DEFAULT '0.00',
  `left` decimal(20,2) DEFAULT '0.00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sd_11x5`
--

DROP TABLE IF EXISTS `sd_11x5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sd_11x5` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=11217 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sd_11x5_order`
--

DROP TABLE IF EXISTS `sd_11x5_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sd_11x5_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` int(11) NOT NULL DEFAULT '2',
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,2) NOT NULL,
  `win_price` decimal(20,2) NOT NULL DEFAULT '0.00',
  `bonus` decimal(20,2) NOT NULL DEFAULT '0.00',
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3940 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sd_11x5_trend`
--

DROP TABLE IF EXISTS `sd_11x5_trend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sd_11x5_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_12` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=19134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sh_11x5`
--

DROP TABLE IF EXISTS `sh_11x5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sh_11x5` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=11585 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sh_11x5_order`
--

DROP TABLE IF EXISTS `sh_11x5_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sh_11x5_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=233 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sh_11x5_trend`
--

DROP TABLE IF EXISTS `sh_11x5_trend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sh_11x5_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_12` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=30924 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tj_ssc`
--

DROP TABLE IF EXISTS `tj_ssc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tj_ssc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=10982 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tj_ssc_order`
--

DROP TABLE IF EXISTS `tj_ssc_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tj_ssc_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tj_ssc_trend`
--

DROP TABLE IF EXISTS `tj_ssc_trend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tj_ssc_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_11` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_232` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_235` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_313` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_316` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_323` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_326` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_333` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_336` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_200` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_209` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_309` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_409` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=39373 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `track_index`
--

DROP TABLE IF EXISTS `track_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `track_index` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `activity_type` smallint(6) NOT NULL,
  `track_id` bigint(20) NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `track_idx` (`activity_type`,`track_id`),
  KEY `time_idx` (`user_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '0',
  `activity_type` smallint(6) NOT NULL DEFAULT '0',
  `title` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `price` decimal(20,3) DEFAULT NULL,
  `balance` decimal(20,3) DEFAULT NULL,
  `pay_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=5873 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `withdraw`
--

DROP TABLE IF EXISTS `withdraw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `withdraw` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `trans_id` bigint(20) NOT NULL,
  `target_type` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `after_cash` decimal(20,3) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `balance` decimal(20,3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`target_type`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xinge_notification`
--

DROP TABLE IF EXISTS `xinge_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xinge_notification` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `push_device` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `send_time` text,
  `extend` text,
  `cmd` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_ssc`
--

DROP TABLE IF EXISTS `xj_ssc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xj_ssc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=13751 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_ssc_order`
--

DROP TABLE IF EXISTS `xj_ssc_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xj_ssc_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_ssc_trend`
--

DROP TABLE IF EXISTS `xj_ssc_trend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xj_ssc_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_11` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_232` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_235` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_313` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_316` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_323` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_326` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_333` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_336` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_200` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_209` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_309` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_409` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB AUTO_INCREMENT=41843 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `preset_lottery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `sort_id` int(11) NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_ts` int(11) NOT NULL,
  `end_ts` int(11) NOT NULL,
  `desc` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `priority` int(11) DEFAULT '0',
  `device_type` int(11) NOT NULL,
  `exclude_chn` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `min_cvc` int(11) DEFAULT '0',
  `max_cvc` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `remark` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

create table preset_tab (
    id int(11) not null auto_increment,
    name varchar(100) not null,
    column_type int default 1,
    sort_id int default 1,
    created_at timestamp not null default current_timestamp,
    updated_at timestamp not null default current_timestamp,
    primary key (`id`)
)engine=InnoDB default charset=utf8mb4 collate=utf8mb4_unicode_ci;

/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-01 11:20:28
