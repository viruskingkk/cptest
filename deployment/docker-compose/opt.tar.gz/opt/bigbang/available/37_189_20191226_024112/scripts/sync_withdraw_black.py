# -*- coding: utf-8 -*-
import os
import sys
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")
from common import orm
from common.cache import redis_cache
from common.black_account.model import WITHDRAW_BLACK_TYPE, WITHDRAW_BLACK_STATUS, WithdrawBlack


def sync_withdraw_black():
    sync_data = {
        WITHDRAW_BLACK_TYPE.TEST_UID: redis_cache.get_withdraw_test_uids(),
        WITHDRAW_BLACK_TYPE.BLACK_UID: redis_cache.get_withdraw_black_uids(),
        WITHDRAW_BLACK_TYPE.BLACK_ALIPAYNO: redis_cache.get_withdraw_black_alipayno(),
        WITHDRAW_BLACK_TYPE.BLACK_NAME: redis_cache.get_withdraw_black_name(),
    }
    for key, withdraw_black_lists in sync_data.iteritems():
        for type_account in withdraw_black_lists:
            withdraw_black = WithdrawBlack()
            withdraw_black.type_account = type_account
            withdraw_black.type = key
            withdraw_black.status = WITHDRAW_BLACK_STATUS.ENABLE
            withdraw_black.money = 0
            withdraw_black.note = None
            withdraw_black.save(auto_commit=False)
            print 'create {} instance, type_account: {}'.format(key, type_account)
        orm.session.commit()
        print '{} sync complete.'.format(key)


if __name__ == '__main__':
    sync_withdraw_black()
