INSERT INTO `coupon_template` (`id`, `coupon_type`, `title`, `desc`, `price`, `condition_price`, `valid_ts`, `created_at`, `updated_at`, `activity_type`, `cmd`, `remark`)
VALUES
	(19, 2, '晒单赠送彩金', '满20减2', 2, 20, 259200, '2017-11-28 07:58:52', '2017-11-28 07:58:52', 0, NULL, NULL),
	(20, 2, '晒单赠送彩金', '满30减4', 4, 30, 259200, '2017-11-28 07:59:10', '2017-11-28 07:59:10', 0, NULL, NULL);
