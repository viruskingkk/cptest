# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.21-0ubuntu0.16.04.1)
# Database: bigbang
# Generation Time: 2018-04-03 03:14:20 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table abtest
# ------------------------------------------------------------

CREATE TABLE `abtest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table account
# ------------------------------------------------------------

CREATE TABLE `account` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` text COLLATE utf8mb4_unicode_ci,
  `user_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trade_pwd` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `channel` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `citizen_id` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sign` text COLLATE utf8mb4_unicode_ci,
  `balance` decimal(20,3) DEFAULT NULL,
  `withdraw` decimal(20,3) DEFAULT NULL,
  `status` int(4) DEFAULT '0',
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_virtual` tinyint(4) DEFAULT '0',
  `settings` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_idx` (`user_name`),
  UNIQUE KEY `phone_idx` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table account_coupon
# ------------------------------------------------------------

CREATE TABLE `account_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `template_id` int(11) NOT NULL,
  `coupon_type` tinyint(4) NOT NULL,
  `title` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` smallint(6) NOT NULL,
  `condition_price` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `expire_ts` int(11) NOT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `start_ts` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table account_token
# ------------------------------------------------------------

CREATE TABLE `account_token` (
  `user_id` bigint(20) NOT NULL DEFAULT '0',
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chn` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `cvc` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `extend` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` smallint(6) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table alipay_trans
# ------------------------------------------------------------

CREATE TABLE `alipay_trans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `third_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remark_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trans_amount` float NOT NULL,
  `status` tinyint(4) DEFAULT '0',
  `pay_time` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `third_id` (`third_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table announce_show
# ------------------------------------------------------------

CREATE TABLE `announce_show` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_index_id` bigint(20) DEFAULT NULL,
  `order_id` bigint(20) NOT NULL,
  `activity_type` smallint(6) NOT NULL,
  `term_number` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `status` smallint(6) NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `images` text COLLATE utf8mb4_unicode_ci,
  `verified_at` int(11) DEFAULT NULL,
  `verify_comment` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `highlight` smallint(6) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `detail` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table bj_pk10
# ------------------------------------------------------------

CREATE TABLE `bj_pk10` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table bj_pk10_order
# ------------------------------------------------------------

CREATE TABLE `bj_pk10_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`),
  KEY `track` (`track_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table bj_pk10_trend
# ------------------------------------------------------------

CREATE TABLE `bj_pk10_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_7` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_8` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_9` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_7` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_8` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_9` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table broadcast
# ------------------------------------------------------------

CREATE TABLE `broadcast` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `nick_name` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `game_name` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(11,2) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table bull_participate
# ------------------------------------------------------------

CREATE TABLE `bull_participate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `term_number` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bet_index` smallint(6) NOT NULL,
  `bet_amount` decimal(11,2) NOT NULL,
  `award_amount` decimal(11,2) DEFAULT '0.00',
  `extend` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_term_bet` (`user_id`,`term_number`,`bet_index`),
  KEY `term` (`term_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table bull_term
# ------------------------------------------------------------

CREATE TABLE `bull_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `term_number` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `win_index` smallint(6) DEFAULT NULL,
  `cards` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_ts` int(11) NOT NULL,
  `announce_ts` int(11) NOT NULL,
  `end_ts` int(11) NOT NULL,
  `extend` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_number` (`term_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table coupon_template
# ------------------------------------------------------------

CREATE TABLE `coupon_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_type` tinyint(4) NOT NULL,
  `title` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` smallint(6) NOT NULL,
  `condition_price` int(11) DEFAULT NULL,
  `valid_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activity_type` int(11) DEFAULT NULL,
  `cmd` text COLLATE utf8mb4_unicode_ci,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `bet_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table cq_lf
# ------------------------------------------------------------

CREATE TABLE `cq_lf` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(23) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table cq_lf_order
# ------------------------------------------------------------

CREATE TABLE `cq_lf_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table cq_lf_trend
# ------------------------------------------------------------

CREATE TABLE `cq_lf_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(23) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_5` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_6` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_7` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table cq_ssc
# ------------------------------------------------------------

CREATE TABLE `cq_ssc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table cq_ssc_order
# ------------------------------------------------------------

CREATE TABLE `cq_ssc_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`),
  KEY `term` (`term`),
  KEY `track` (`track_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table cq_ssc_trend
# ------------------------------------------------------------

CREATE TABLE `cq_ssc_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_11` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_232` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_235` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_313` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_316` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_323` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_326` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_333` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_336` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_200` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_209` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_309` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_409` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table daily_bet_return
# ------------------------------------------------------------

CREATE TABLE `daily_bet_return` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `date` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `game_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `is_awarded` tinyint(4) NOT NULL DEFAULT '0',
  `transaction_id` bigint(20) DEFAULT NULL,
  `is_notified` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_date_type` (`user_id`,`date`,`game_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table daily_recharge_campaign
# ------------------------------------------------------------

CREATE TABLE `daily_recharge_campaign` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `date` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `price` int(11) DEFAULT NULL,
  `status` smallint(6) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table daily_recharge_return
# ------------------------------------------------------------

CREATE TABLE `daily_recharge_return` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `date` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `is_awarded` tinyint(4) NOT NULL DEFAULT '0',
  `transaction_id` bigint(20) DEFAULT NULL,
  `is_notified` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_date_type` (`user_id`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table fc3d
# ------------------------------------------------------------

CREATE TABLE `fc3d` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table fc3d_order
# ------------------------------------------------------------

CREATE TABLE `fc3d_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table fc3d_trend
# ------------------------------------------------------------

CREATE TABLE `fc3d_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table feedback
# ------------------------------------------------------------

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `nick_name` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qq` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `chn` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cvc` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table ff_11x5
# ------------------------------------------------------------

CREATE TABLE `ff_11x5` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `repeat_numbers` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table ff_11x5_order
# ------------------------------------------------------------

CREATE TABLE `ff_11x5_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,2) NOT NULL,
  `win_price` decimal(20,2) NOT NULL DEFAULT '0.00',
  `bonus` decimal(20,2) NOT NULL DEFAULT '0.00',
  `extend` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table ff_11x5_trend
# ------------------------------------------------------------

CREATE TABLE `ff_11x5_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_12` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `repeat_numbers` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table ff_ks
# ------------------------------------------------------------

CREATE TABLE `ff_ks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table ff_ks_order
# ------------------------------------------------------------

CREATE TABLE `ff_ks_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `track_status` tinyint(4) NOT NULL DEFAULT '1',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table ff_ks_trend
# ------------------------------------------------------------

CREATE TABLE `ff_ks_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_4` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_8` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_9` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table ff_pk10
# ------------------------------------------------------------

CREATE TABLE `ff_pk10` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `reference` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table ff_pk10_order
# ------------------------------------------------------------

CREATE TABLE `ff_pk10_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table ff_pk10_trend
# ------------------------------------------------------------

CREATE TABLE `ff_pk10_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_5` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_6` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_7` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_8` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_9` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_7` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_8` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_9` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table ff_ssc
# ------------------------------------------------------------

CREATE TABLE `ff_ssc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table ff_ssc_order
# ------------------------------------------------------------

CREATE TABLE `ff_ssc_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table ff_ssc_trend
# ------------------------------------------------------------

CREATE TABLE `ff_ssc_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_11` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_232` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_235` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_313` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_316` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_323` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_326` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_333` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_336` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_200` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_209` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_309` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_409` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table fortune_wheel
# ------------------------------------------------------------

CREATE TABLE `fortune_wheel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `left_normal_times` int(11) NOT NULL,
  `left_double_times` int(11) NOT NULL,
  `apply_normal_times` int(11) NOT NULL,
  `apply_double_times` int(11) NOT NULL,
  `task_status` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table fortune_wheel_award
# ------------------------------------------------------------

CREATE TABLE `fortune_wheel_award` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_double` int(11) NOT NULL,
  `award_index` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table game_billboard
# ------------------------------------------------------------

CREATE TABLE `game_billboard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `champion_info` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `top_info` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table gd_11x5
# ------------------------------------------------------------

CREATE TABLE `gd_11x5` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `repeat_numbers` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table gd_11x5_order
# ------------------------------------------------------------

CREATE TABLE `gd_11x5_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`),
  KEY `track` (`track_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table gd_11x5_trend
# ------------------------------------------------------------

CREATE TABLE `gd_11x5_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_12` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `repeat_numbers` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table guess_fruit_participate
# ------------------------------------------------------------

CREATE TABLE `guess_fruit_participate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `term_number` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bet_index` smallint(6) NOT NULL,
  `bet_amount` decimal(11,2) NOT NULL,
  `award_amount` decimal(11,2) DEFAULT '0.00',
  `extend` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_term_bet` (`user_id`,`term_number`,`bet_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table guess_fruit_term
# ------------------------------------------------------------

CREATE TABLE `guess_fruit_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `term_number` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `is_lucky` tinyint(1) NOT NULL DEFAULT '0',
  `win_index` smallint(6) DEFAULT NULL,
  `start_ts` int(11) NOT NULL,
  `announce_ts` int(11) NOT NULL,
  `end_ts` int(11) NOT NULL,
  `extend` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_number` (`term_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table gx_ks
# ------------------------------------------------------------

CREATE TABLE `gx_ks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table gx_ks_order
# ------------------------------------------------------------

CREATE TABLE `gx_ks_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `track_status` tinyint(4) NOT NULL DEFAULT '1',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table gx_ks_trend
# ------------------------------------------------------------

CREATE TABLE `gx_ks_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_8` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_9` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table hn_wfc
# ------------------------------------------------------------

CREATE TABLE `hn_wfc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table hn_wfc_order
# ------------------------------------------------------------

CREATE TABLE `hn_wfc_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table hn_wfc_trend
# ------------------------------------------------------------

CREATE TABLE `hn_wfc_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_11` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table hn_yfc
# ------------------------------------------------------------

CREATE TABLE `hn_yfc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table hn_yfc_order
# ------------------------------------------------------------

CREATE TABLE `hn_yfc_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table hn_yfc_trend
# ------------------------------------------------------------

CREATE TABLE `hn_yfc_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_11` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table js_ks
# ------------------------------------------------------------

CREATE TABLE `js_ks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table js_ks_order
# ------------------------------------------------------------

CREATE TABLE `js_ks_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `track_status` tinyint(4) NOT NULL DEFAULT '1',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table js_ks_trend
# ------------------------------------------------------------

CREATE TABLE `js_ks_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_8` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_9` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table jx_11x5
# ------------------------------------------------------------

CREATE TABLE `jx_11x5` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `repeat_numbers` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table jx_11x5_order
# ------------------------------------------------------------

CREATE TABLE `jx_11x5_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table jx_11x5_trend
# ------------------------------------------------------------

CREATE TABLE `jx_11x5_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_12` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `repeat_numbers` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table kfc_record
# ------------------------------------------------------------

CREATE TABLE `kfc_record` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `bet_amount` decimal(11,2) NOT NULL,
  `award_amount` decimal(11,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `extend` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table lottery_participate
# ------------------------------------------------------------

CREATE TABLE `lottery_participate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `term_number` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bet_index` smallint(6) NOT NULL,
  `bet_amount` decimal(11,2) NOT NULL,
  `award_amount` decimal(11,2) DEFAULT '0.00',
  `extend` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_term_bet` (`user_id`,`term_number`,`bet_index`),
  KEY `term` (`term_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table lottery_term
# ------------------------------------------------------------

CREATE TABLE `lottery_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `term_number` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `win_index` smallint(6) DEFAULT NULL,
  `start_ts` int(11) NOT NULL,
  `announce_ts` int(11) NOT NULL,
  `end_ts` int(11) NOT NULL,
  `extend` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_number` (`term_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table moist_campaign
# ------------------------------------------------------------

CREATE TABLE `moist_campaign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `recharge_price` int(11) NOT NULL,
  `award_price` int(11) NOT NULL,
  `coupons` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table notification
# ------------------------------------------------------------

CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `notify_type` smallint(6) DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `command` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expire_ts` int(11) DEFAULT NULL,
  `status` smallint(6) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `read` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table order_index
# ------------------------------------------------------------

CREATE TABLE `order_index` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `activity_type` smallint(6) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `detail` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_idx` (`activity_type`,`order_id`),
  KEY `time_idx` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table pay
# ------------------------------------------------------------

CREATE TABLE `pay` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `pay_type` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `price` decimal(20,2) DEFAULT NULL,
  `third_id` text COLLATE utf8mb4_unicode_ci,
  `target_id` text COLLATE utf8mb4_unicode_ci,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table preset
# ------------------------------------------------------------

CREATE TABLE `preset` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `device_type` int(8) DEFAULT '0',
  `min_version` int(8) NOT NULL DEFAULT '1',
  `max_version` int(8) DEFAULT NULL,
  `last_modified` bigint(20) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `content` text COLLATE utf8mb4_unicode_ci,
  `title` text COLLATE utf8mb4_unicode_ci,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `chn` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table preset_banner
# ------------------------------------------------------------

CREATE TABLE `preset_banner` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_ts` bigint(20) unsigned DEFAULT NULL,
  `end_ts` bigint(20) unsigned DEFAULT NULL,
  `cmd` text COLLATE utf8mb4_unicode_ci,
  `abtest` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `title` text COLLATE utf8mb4_unicode_ci,
  `campaign_start` int(20) DEFAULT NULL,
  `campaign_end` int(20) DEFAULT NULL,
  `type` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table preset_discovery
# ------------------------------------------------------------

CREATE TABLE `preset_discovery` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8mb4_unicode_ci,
  `icon` text COLLATE utf8mb4_unicode_ci,
  `start_ts` bigint(20) unsigned DEFAULT NULL,
  `end_ts` bigint(20) unsigned DEFAULT NULL,
  `desc` text COLLATE utf8mb4_unicode_ci,
  `tag` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cmd` text COLLATE utf8mb4_unicode_ci,
  `abtest` int(10) unsigned DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table preset_float_icon
# ------------------------------------------------------------

CREATE TABLE `preset_float_icon` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8mb4_unicode_ci,
  `icon` text COLLATE utf8mb4_unicode_ci,
  `start_ts` bigint(20) DEFAULT NULL,
  `end_ts` bigint(20) DEFAULT NULL,
  `cmd` text COLLATE utf8mb4_unicode_ci,
  `abtest` int(10) DEFAULT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table preset_loading
# ------------------------------------------------------------

CREATE TABLE `preset_loading` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8mb4_unicode_ci,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `stay` int(8) NOT NULL,
  `start_ts` bigint(20) unsigned DEFAULT NULL,
  `end_ts` bigint(20) unsigned DEFAULT NULL,
  `cmd` text COLLATE utf8mb4_unicode_ci,
  `skip` tinyint(2) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `abtest` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table preset_lottery
# ------------------------------------------------------------

CREATE TABLE `preset_lottery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `sort_id` int(11) NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_ts` int(11) NOT NULL,
  `end_ts` int(11) NOT NULL,
  `desc` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `priority` int(11) DEFAULT '0',
  `device_type` int(11) NOT NULL,
  `exclude_chn` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `min_cvc` int(11) DEFAULT '0',
  `max_cvc` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `remark` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `cmd` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `tab` int(11) DEFAULT '1',
  `bet_type` int(11) DEFAULT NULL,
  `start_stop_lottery` timestamp NULL DEFAULT NULL,
  `end_stop_lottery` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table preset_pay
# ------------------------------------------------------------

CREATE TABLE `preset_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `least_pay` smallint(6) DEFAULT NULL,
  `pay_type` smallint(6) DEFAULT NULL,
  `desc_short` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc_long` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `highlight` tinyint(4) DEFAULT '0',
  `abtest` smallint(6) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bonus_rate` decimal(10,5) DEFAULT '0.00000',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table preset_recommend
# ------------------------------------------------------------

CREATE TABLE `preset_recommend` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8mb4_unicode_ci,
  `activity_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_ts` bigint(20) unsigned DEFAULT NULL,
  `end_ts` bigint(20) unsigned DEFAULT NULL,
  `cmd` text COLLATE utf8mb4_unicode_ci,
  `abtest` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table preset_reward
# ------------------------------------------------------------

CREATE TABLE `preset_reward` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activity_type` int(11) DEFAULT '0',
  `enable` tinyint(1) NOT NULL DEFAULT '1',
  `bet_type` int(11) DEFAULT '0',
  `rate` int(11) DEFAULT '0',
  `amount` int(11) DEFAULT '0',
  `withdraw` tinyint(1) DEFAULT '1',
  `condition` text COLLATE utf8mb4_unicode_ci,
  `limit` int(11) DEFAULT '-1',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table preset_shortcut
# ------------------------------------------------------------

CREATE TABLE `preset_shortcut` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `cmd` text,
  `image` text NOT NULL,
  `abtest` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table preset_tab
# ------------------------------------------------------------

CREATE TABLE `preset_tab` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `column_type` int(11) DEFAULT '1',
  `sort_id` int(11) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table push_config
# ------------------------------------------------------------

CREATE TABLE `push_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `win` smallint(6) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table recharge_apply
# ------------------------------------------------------------

CREATE TABLE `recharge_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `recharge_type` tinyint(4) NOT NULL,
  `recharger_info` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rechargee_info` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) DEFAULT '1',
  `pay_id` bigint(20) DEFAULT NULL,
  `pay_amount` float DEFAULT NULL,
  `third_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `third_id` (`third_id`),
  KEY `user_id` (`user_id`),
  KEY `recharge_type` (`recharge_type`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table reward_limit
# ------------------------------------------------------------

CREATE TABLE `reward_limit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` decimal(20,2) DEFAULT '0.00',
  `left` decimal(20,2) DEFAULT '0.00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table sd_11x5
# ------------------------------------------------------------

CREATE TABLE `sd_11x5` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `repeat_numbers` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table sd_11x5_order
# ------------------------------------------------------------

CREATE TABLE `sd_11x5_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table sd_11x5_trend
# ------------------------------------------------------------

CREATE TABLE `sd_11x5_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_12` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `repeat_numbers` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table sh_11x5
# ------------------------------------------------------------

CREATE TABLE `sh_11x5` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `repeat_numbers` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table sh_11x5_order
# ------------------------------------------------------------

CREATE TABLE `sh_11x5_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`),
  KEY `track` (`track_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table sh_11x5_trend
# ------------------------------------------------------------

CREATE TABLE `sh_11x5_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_12` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `repeat_numbers` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table tc_pls
# ------------------------------------------------------------

CREATE TABLE `tc_pls` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `number` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table tc_pls_order
# ------------------------------------------------------------

CREATE TABLE `tc_pls_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table tc_pls_trend
# ------------------------------------------------------------

CREATE TABLE `tc_pls_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table tj_ssc
# ------------------------------------------------------------

CREATE TABLE `tj_ssc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table tj_ssc_order
# ------------------------------------------------------------

CREATE TABLE `tj_ssc_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table tj_ssc_trend
# ------------------------------------------------------------

CREATE TABLE `tj_ssc_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_11` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_232` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_235` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_313` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_316` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_323` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_326` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_333` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_336` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_200` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_209` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_309` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_409` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table track_index
# ------------------------------------------------------------

CREATE TABLE `track_index` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `activity_type` smallint(6) NOT NULL,
  `track_id` bigint(20) NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `detail` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `track_idx` (`activity_type`,`track_id`),
  KEY `time_idx` (`user_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table transaction
# ------------------------------------------------------------

CREATE TABLE `transaction` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '0',
  `activity_type` smallint(6) NOT NULL DEFAULT '0',
  `title` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `price` decimal(20,3) DEFAULT NULL,
  `balance` decimal(20,3) DEFAULT NULL,
  `pay_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table transaction_bk
# ------------------------------------------------------------

CREATE TABLE `transaction_bk` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '0',
  `activity_type` smallint(6) NOT NULL DEFAULT '0',
  `title` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `price` decimal(20,3) DEFAULT NULL,
  `balance` decimal(20,3) DEFAULT NULL,
  `pay_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table treasure
# ------------------------------------------------------------

CREATE TABLE `treasure` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `amount` float NOT NULL,
  `treasure_type` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `transaction_id` bigint(20) DEFAULT NULL,
  `date` varchar(30) NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table winner_award_record
# ------------------------------------------------------------

CREATE TABLE `winner_award_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `start` timestamp NULL DEFAULT NULL,
  `end` timestamp NULL DEFAULT NULL,
  `type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rank` int(11) NOT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `transaction_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table withdraw
# ------------------------------------------------------------

CREATE TABLE `withdraw` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `trans_id` bigint(20) NOT NULL,
  `target_type` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `after_cash` decimal(20,3) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `balance` decimal(20,3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`target_type`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table xinge_notification
# ------------------------------------------------------------

CREATE TABLE `xinge_notification` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `push_device` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `send_time` text,
  `extend` text,
  `cmd` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table xj_ssc
# ------------------------------------------------------------

CREATE TABLE `xj_ssc` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text COLLATE utf8mb4_unicode_ci,
  `status` smallint(6) DEFAULT '0',
  `start_ts` int(11) DEFAULT NULL,
  `end_ts` int(11) DEFAULT NULL,
  `announce_ts` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table xj_ssc_order
# ------------------------------------------------------------

CREATE TABLE `xj_ssc_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `user_id` bigint(20) NOT NULL,
  `track_id` bigint(20) DEFAULT NULL,
  `bet_type` smallint(6) NOT NULL,
  `number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` decimal(10,2) DEFAULT NULL,
  `times` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `track_status` tinyint(4) NOT NULL DEFAULT '0',
  `price` decimal(20,3) DEFAULT NULL,
  `win_price` decimal(20,3) DEFAULT NULL,
  `bonus` decimal(20,3) DEFAULT NULL,
  `extend` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_idx` (`user_id`,`track_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table xj_ssc_trend
# ------------------------------------------------------------

CREATE TABLE `xj_ssc_trend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `term` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_0` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `idx_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_6` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_10` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_11` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_232` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_235` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_313` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_316` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_323` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_326` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_333` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_336` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_200` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_209` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_309` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `miss_409` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `term_idx` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
