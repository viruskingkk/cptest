#!/bin/bash

PROJECT_HOME=/home/ubuntu/af-env/bigbang
VIRENV_BIN_DIR=/home/ubuntu/af-env/bin

#pkill -f "processor.py"
#pkill -f "celery -A async"

cd $PROJECT_HOME
#nohup sudo -u ubuntu $VIRENV_BIN_DIR/python $PROJECT_HOME/common/timer/processor.py >/dev/null 2>&1 &
#nohup sudo -u ubuntu $VIRENV_BIN_DIR/celery -A async worker -c 2 -l info --autoreload >/dev/null 2>&1 &

#supervisorctl restart bigbangservice
