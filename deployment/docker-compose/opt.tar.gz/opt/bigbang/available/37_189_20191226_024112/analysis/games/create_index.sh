#!/usr/bin/env bash

ES_HOST='http://127.0.0.1:9200'

curl -XPUT ${ES_HOST}/gameorders -H 'Content-Type: application/json' --data '
{
    "settings" : {
        "number_of_shards" : 1
    },
    "mappings" : {
        "_doc" : {
            "properties" : {
                "platform_type" : { "type" : "integer"},
                "game_id" : { "type" : "integer"},
                "order_id" : { "type" : "integer"},
                "user_id": {"type": "integer"},
                "bet_amount": {"type": "long"},
                "bet_result": {"type": "long"},
                "created_at": {"type": "long"}
            }
        }
    }
}
'

curl -XGET 'localhost:9200/gameorders/_search/'

curl -XPOST "localhost:9200/gameorders/_delete_by_query" -H 'Content-Type: application/json' -d '
{
  "query": {
    "match": {
      "platform_type": 3
    }
  }
}
'