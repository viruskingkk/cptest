# -*- coding: utf-8 -*-

from api import BaseModel


class TrendData(BaseModel):
    structure = {
        'term': str,   # 期数
        'number': str,  # 开奖结果
        'idx_0': list,
        'idx_1': list,
        'idx_2': list,
        'idx_3': list,
        'idx_4': list,
    }


class StatData(BaseModel):
    structure = {
        'max_seq': list,    # 最大连出
        'max_miss': list,   # 最大遗漏
        'avg_miss': list,   # 平均遗漏
        'hit': list         # 命中次数
    }
