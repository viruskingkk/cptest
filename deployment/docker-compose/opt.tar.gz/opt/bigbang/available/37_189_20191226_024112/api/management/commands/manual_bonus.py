#! -*- coding:utf-8 -*-
import os
import json
import logging
from datetime import datetime

from common.lottery import LOTTERY_TYPE
from common.lottery.cyclical.model import ACTIVITY_MODEL, ORDER_MODEL
from common.lottery.cyclical.abstract.order import manual_bonus_orders
from django.core.management.base import BaseCommand


_LOGGER = logging.getLogger('alipay')


class Command(BaseCommand):

    def handle(self, activity_type, term, **kwargs):
        activity_type = int(activity_type)
        order_table = ORDER_MODEL[activity_type]
        orders = order_table.query.with_for_update().filter(
            order_table.term == term).filter(
            order_table.status == 3).filter(
            order_table.bonus==0).all()
        order_ids = []
        for order in orders:
            order_ids.append(order.id)
        print order_ids
        succ_list, fail_list, total_price = manual_bonus_orders(activity_type, order_ids)
        print succ_list, fail_list, total_price
