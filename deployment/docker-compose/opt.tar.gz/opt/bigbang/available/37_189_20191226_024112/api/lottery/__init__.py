from common.lottery import LOTTERY_TYPE
from api.lottery.cq_ssc.order import handler as cq_ssc_handler
from api.lottery.cq_lf.order import handler as cq_lf_handler
from api.lottery.gd_11x5.order import handler as gd_11x5_handler
from api.lottery.js_ks.order import handler as js_ks_handler
from api.lottery.sd_11x5.order import handler as sd_11x5_handler
from api.lottery.tj_ssc.order import handler as tj_ssc_handler
from api.lottery.xj_ssc.order import handler as xj_ssc_handler
from api.lottery.jx_11x5.order import handler as jx_11x5_handler
from api.lottery.sh_11x5.order import handler as sh_11x5_handler
from api.lottery.gx_ks.order import handler as gx_ks_handler
from api.lottery.bj_pk10.order import handler as bj_pk10_handler
from api.lottery.tc_pls.order import handler as tc_pls_handler
from api.lottery.fc3d.order import handler as fc3d_handler
from api.lottery.ff_ssc.order import handler as ff_ssc_handler
from api.lottery.ff_11x5.order import handler as ff_11x5_handler
from api.lottery.ff_ks.order import handler as ff_ks_handler
from common.lottery.cyclical.abstract.order import BatchOrderPayer
from api.lottery.ff_pk10.order import handler as ff_pk10_handler

from common.lottery.cyclical.cq_ssc.logic import order as cq_ssc_logic
from common.lottery.cyclical.cq_lf.logic import order as cq_lf_logic
from common.lottery.cyclical.gd_11x5.logic import order as gd_11x5_logic
from common.lottery.cyclical.js_ks.logic import order as js_ks_logic
from common.lottery.cyclical.sd_11x5.logic import order as sd_11x5_logic
from common.lottery.cyclical.tj_ssc.logic import order as tj_ssc_logic
from common.lottery.cyclical.xj_ssc.logic import order as xj_ssc_logic
from common.lottery.cyclical.gx_ks.logic import order as gx_ks_logic
from common.lottery.cyclical.jx_11x5.logic import order as jx_11x5_logic
from common.lottery.cyclical.sh_11x5.logic import order as sh_11x5_logic
from common.lottery.cyclical.bj_pk10.logic import order as bj_pk10_logic
from common.lottery.cyclical.tc_pls.logic import order as tc_pls_logic
from common.lottery.cyclical.fc3d.logic import order as fc3d_logic
from common.lottery.cyclical.ff_ssc.logic import order as ff_ssc_logic
from common.lottery.cyclical.ff_11x5.logic import order as ff_11x5_logic
from common.lottery.cyclical.ff_ks.logic import order as ff_ks_logic
from common.lottery.cyclical.ff_pk10.logic import order as ff_pk10_logic

ORDER_HANDLER = {
    LOTTERY_TYPE.CQ_SSC: cq_ssc_handler,
    LOTTERY_TYPE.CQ_LF: cq_lf_handler,
    LOTTERY_TYPE.JS_KS: js_ks_handler,
    LOTTERY_TYPE.SD_11X5: sd_11x5_handler,
    LOTTERY_TYPE.TJ_SSC: tj_ssc_handler,
    LOTTERY_TYPE.XJ_SSC: xj_ssc_handler,
    LOTTERY_TYPE.JX_11X5: jx_11x5_handler,
    LOTTERY_TYPE.GD_11X5: gd_11x5_handler,
    LOTTERY_TYPE.SH_11X5: sh_11x5_handler,
    LOTTERY_TYPE.GX_KS: gx_ks_handler,
    LOTTERY_TYPE.BJ_PK10: bj_pk10_handler,
    LOTTERY_TYPE.TC_PLS: tc_pls_handler,
    LOTTERY_TYPE.FC3D: fc3d_handler,
    LOTTERY_TYPE.FF_SSC: ff_ssc_handler,
    LOTTERY_TYPE.FF_11X5: ff_11x5_handler,
    LOTTERY_TYPE.FF_KS: ff_ks_handler,
    LOTTERY_TYPE.FF_PK10: ff_pk10_handler,
}

ORDER_LOGIC = {
    LOTTERY_TYPE.CQ_SSC: cq_ssc_logic,
    LOTTERY_TYPE.CQ_LF: cq_lf_logic,
    LOTTERY_TYPE.JS_KS: js_ks_logic,
    LOTTERY_TYPE.SD_11X5: sd_11x5_logic,
    LOTTERY_TYPE.TJ_SSC: tj_ssc_logic,
    LOTTERY_TYPE.XJ_SSC: xj_ssc_logic,
    LOTTERY_TYPE.JX_11X5: jx_11x5_logic,
    LOTTERY_TYPE.GD_11X5: gd_11x5_logic,
    LOTTERY_TYPE.SH_11X5: sh_11x5_logic,
    LOTTERY_TYPE.GX_KS: gx_ks_logic,
    LOTTERY_TYPE.BJ_PK10: bj_pk10_logic,
    LOTTERY_TYPE.TC_PLS: tc_pls_logic,
    LOTTERY_TYPE.FC3D: fc3d_logic,
    LOTTERY_TYPE.FF_SSC: ff_ssc_logic,
    LOTTERY_TYPE.FF_11X5: ff_11x5_logic,
    LOTTERY_TYPE.FF_KS: ff_ks_logic,
    LOTTERY_TYPE.FF_PK10: ff_pk10_logic,
}
