# coding=utf-8
import json

from django.views.decorators.http import require_POST
from future.utils import raise_with_traceback

from common.utils.exceptions import ParamError
from common.utils.decorator import response_wrapper
from common.utils.api import parse_p
from api.feedback import db as feedback_db
from common.account.db.account import get_account


@require_POST
@response_wrapper
def feedback(request):
    """
    提交反馈
    """
    try:
        data = json.loads(request.body)
        qq = data['qq']
        content = data['content']
    except Exception as e:
        raise_with_traceback(ParamError(e))
    user_id = request.user_id
    tracks = parse_p(request.GET.get('p'))
    chn = tracks.get('chn', None)
    cvc = int(tracks.get('cvc', 0))
    content = content[:300]
    user_name = request.user.user_name if request.user else ''
    feedback_db.submit(qq, content, chn=chn, cvc=cvc, user_id=user_id, user_name=user_name)
    return {}
