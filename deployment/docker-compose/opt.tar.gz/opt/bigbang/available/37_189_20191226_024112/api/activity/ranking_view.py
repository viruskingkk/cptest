# -*- coding: utf-8 -*-
import json
import datetime

from django.views.decorators.http import require_GET

from common.activity.ranking_db import get_today_my_join, get_today_ranks, get_total_ranks, get_history_ranks
from common.activity.ranking_model import RANK_ACTIVITY_STATUS
from common.activity.utils import get_activity_time, ts_to_date_str_list
from common.preset.model.preset import BANNER_TYPE
from common.utils.decorator import response_wrapper
from common.utils.tz import now_ts, date_str_before, get_day_and_start_ts


@require_GET
@response_wrapper
def get_home_info(request):
    start_time, end_time = get_activity_time(BANNER_TYPE.get_key('ranking'))
    activity_date = ts_to_date_str_list(start_time, end_time)
    my_join = get_today_my_join(request.user_id)
    return dict(time=dict(start_time=start_time, end_time=end_time), activity_date=activity_date, my_join=my_join)


@require_GET
@response_wrapper
def get_ranking_info(request):
    params = request.GET
    try:
        _type = int(params.get('t') or 0)  # -1(历史）, 0（当天）, 1（累积）
    except:
        _type = 0
    start_time, end_time = get_activity_time(BANNER_TYPE.get_key('ranking'))
    start_str, _ = get_day_and_start_ts(start_time, f="%Y-%m-%d")
    end_str, _ = get_day_and_start_ts(end_time, f="%Y-%m-%d")
    now_t = now_ts()
    if now_t < start_time:
        activity_status = RANK_ACTIVITY_STATUS.NOT_START
    elif start_time <= now_t <= end_time:
        activity_status = RANK_ACTIVITY_STATUS.ON_GOING
    else:
        activity_status = RANK_ACTIVITY_STATUS.END
    data = {
        'start_time': start_time,
        'end_time': end_time,
        'activity_status': activity_status
    }
    if _type == -1:
        activity_days = ts_to_date_str_list(start_time, end_time)
        print activity_days
        data['history'] = get_history_ranks(activity_days)
    if _type == 0:
        today = date_str_before(0) \
            if activity_status < RANK_ACTIVITY_STATUS.END else end_str
        data['today'] = get_today_ranks(today)
    if _type == 1:
        data['total'] = get_total_ranks()
    return data