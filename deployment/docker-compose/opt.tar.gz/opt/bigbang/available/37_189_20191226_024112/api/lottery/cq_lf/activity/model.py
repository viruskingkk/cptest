# -*- coding: utf-8 -*-

from api import BaseModel


class TrendData(BaseModel):
    structure = {
        'term': str,   # 期数
        'number': str,  # 开奖结果
        'idx_0': list,  # 万位遗漏数据，表示0~9的遗漏数，如果命中当期，使用0
        'idx_1': list,  # 千位
        'idx_2': list,  # 百位
        'idx_3': list,  # 十位
        'idx_4': list,  # 个位
    }


class StatData(BaseModel):
    structure = {
        'max_seq': list,    # 最大连出
        'max_miss': list,   # 最大遗漏
        'avg_miss': list,   # 平均遗漏
        'hit': list         # 命中次数
    }
