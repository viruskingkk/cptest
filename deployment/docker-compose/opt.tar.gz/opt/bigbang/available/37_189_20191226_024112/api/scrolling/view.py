# coding=utf-8

import logging

from django.views.decorators.http import require_GET

from api.scrolling.logic import view_scrolling

from common.utils.api import parse_p, get_client_ip
from common.utils.decorator import response_wrapper
from common.utils.ua import shorten_ua

_LOGGER = logging.getLogger('bigbang')


@require_GET
@response_wrapper
def fetch_scrolling(req):
    """
    获取跑马灯
    eg:
    {
        'size': 10,
        'list': [
            {
                'text': u'恭喜【x***】中奖55元',
            }
        ]
    }
    """
    scrolling_list = view_scrolling()
    data = {
        'size': len(scrolling_list),
        'list': scrolling_list
    }
    return data
