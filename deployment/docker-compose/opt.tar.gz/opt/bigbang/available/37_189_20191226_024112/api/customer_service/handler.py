# -*- coding: utf-8 -*-
import copy
import hashlib
import json
import logging
import time

import requests
from django.conf import settings

from async.async_job import submit_appeal_to_third
from common.pay.db import get_pay_orders_for_cs, get_pay
from common.pay.model import PAY_TYPE
from common.preset.db import pay as preset_db
from common.recharge_appeal import db as appeal_db
from common.recharge_appeal.model import CS_ORDER_TYPE, PAY_TYPE_TO_CS_MAP, APPEAL_STATUS
from common.utils import exceptions as err
from common.utils.tz import utc_to_local_str
from common.withdraw.db import get_withdraw_list_for_cs
from common.transaction.model import WITHDRAW_TYPE
from common.cache import redis_cache
from common.recharge_appeal.db import get_appeal_pay_ids
from api.recharge_appeal import handler as recharge_appeal_handler

_LOGGER = logging.getLogger('bigbang')


def generate_sign(parameter, key):
    if 'timestamp' not in parameter:
        parameter['timestamp'] = int(time.time())
    s = ''
    for k in sorted(parameter.keys()):
        if parameter[k] is None:
            continue
        s += '%s=%s&' % (k, parameter[k])
    s += 'key=%s' % key
    m = hashlib.md5()
    m.update(s.encode('utf8'))
    sign = m.hexdigest().upper()
    return sign


def check_sign(parameters):
    params = copy.deepcopy(parameters)
    if 'sign' not in params:
        raise err.ParamError('missing sign')
    sign = params.pop('sign')
    resign = generate_sign(params, settings.CS_MERCHANT_KEY)
    if sign != resign:
        raise err.ParamError(u'customer service sign error, parameter:{}, resign:{}'.
                             format(parameters, resign))


def get_token(user_id):
    params = {'user_id': int(user_id),
              'pro_id': settings.CS_MERCHANT_ID}
    sign = generate_sign(params, settings.CS_MERCHANT_KEY)
    params.update({'sign': sign})
    response = requests.get(settings.CS_TOKEN_API, params, timeout=5)
    try:
        resp_json = json.loads(response.text)
    except ValueError:
        raise Exception('cs token api error, url: %s, response:%s' % (response.url, response.text))
    return resp_json.get('data').get('token')


def get_h5_url(user_id, p):
    assert 'pkg' in p
    token = redis_cache.get_cs_user_token(user_id)
    if not token:
        token = get_token(user_id)
        redis_cache.set_cs_user_token(user_id, token)
    p_params = ','.join(['[{}:{}]'.format(item, p[item]) for item in p])

    data = {'pro_id': settings.CS_MERCHANT_ID,
            'api_host': settings.CS_H5_API,
            'v': '1.1',
            'userid': user_id,
            'token': token,
            'gv': p.get('cvn'),
            'level': 0,
            'p': p_params,
            't': int(time.time()),
            }
    cs_h5_url = '{api_host}?v={v}&pro_id={pro_id}&userid={userid}&token={token}&gv={gv}&level={level}&p={p}&t={t}'.\
        format(**data)
    # 对于android版本小于23的用户，使用系统浏览器打开客服系统
    if 'svc' in p and int(p.get('svc')) <= 23:
        cs_h5_url = cs_h5_url + '&webview_type=3'
    return cs_h5_url


def get_recharge_appeal_url(user_id, p):
    h5_main_url = get_h5_url(user_id, p)
    assert 'customerServicePage' in h5_main_url
    appeal_url = h5_main_url.replace('customerServicePage', 'rechargeStatement', 1)
    return appeal_url


def get_recharge_appeal_record_url(user_id, p):
    h5_main_url = get_h5_url(user_id, p)
    assert 'customerServicePage' in h5_main_url
    appeal_url = h5_main_url.replace('customerServicePage', 'rechargerecord', 1)
    return appeal_url


def get_order(user_id, question_type):
    assert isinstance(user_id, int)
    assert question_type in CS_ORDER_TYPE.to_dict()
    ret_list = []
    if question_type == CS_ORDER_TYPE.RECHARGE:
        preset_pay_type_title_map = preset_db.get_pay_type_to_title_map()
        # 获取正在申诉以及申诉成功的订单
        appealed_list = get_appeal_pay_ids(user_id,
                                           [APPEAL_STATUS.WAIT, APPEAL_STATUS.SUBMIT, APPEAL_STATUS.SUCCESS], 1,
                                           60)
        items = get_pay_orders_for_cs(user_id)
        for item in items:
            if item['id'] in appealed_list:
                continue
            if item['pay_type'] in [PAY_TYPE.UNIONAGENCY_V2_ALI, PAY_TYPE.UNIONAGENCY_V2_BANKCARD,
                                    PAY_TYPE.UNIONAGENCY_V2_WX]:
                item.update({'name': preset_pay_type_title_map.get(PAY_TYPE.UNIONAGENCY)})
            else:
                item.update({'name': preset_pay_type_title_map.get(item['pay_type'])})
            item.update({'type': PAY_TYPE_TO_CS_MAP.get(item.pop('pay_type'))})
            item.update({'created_at': utc_to_local_str(item['created_at'])})
            item.update({'id': str(item['id'])})  # ID太长，发送到前端的时候，如果使用int会自动修改
            ret_list.append(item)
    else:
        items = get_withdraw_list_for_cs(user_id)
        for item in items:
            item.update({'type': WITHDRAW_TYPE.get_label(item.pop('target_type'))})
            item.update({'created_at': utc_to_local_str(item['created_at'])})
            item.update()
            ret_list.append(item)

    return ret_list


def get_appeal_orders(user_id, page, size):
    items, total = appeal_db.get_appeal_orders_by_user_id(user_id, page, size)
    preset_pay_type_title_map = preset_db.get_pay_type_to_title_map()
    for item in items:
        item.update({'price': item.pop('pay_amount')})
        if item['pay_type'] in [PAY_TYPE.UNIONAGENCY_V2_ALI, PAY_TYPE.UNIONAGENCY_V2_BANKCARD,
                                PAY_TYPE.UNIONAGENCY_V2_WX]:
            item.update({'pay_type': preset_pay_type_title_map.get(PAY_TYPE.UNIONAGENCY)})
        else:
            item.update({'pay_type': preset_pay_type_title_map.get(item['pay_type'])})
        item.update({'created_at': utc_to_local_str(item['created_at'])})
        item.update({'pay_id': str(item['pay_id'])})
        item.update({'id': str(item['id'])})
    return items, total


def submit_appeal_order(params):
    """
    :param params: at least contain {'pay_id':23344, 'pay_at':'2019-08-20 12:00:00', 'pay_amount':'20.00', name:u'你好',
                                     'desc':u'请解决问题', receipt:'["www.google.com", "www.123.com"]'}
    :return:
    """
    assert 'pay_id' in params
    pay_id = int(params.get('pay_id'))
    if params.get('desc') is None:
        params.update(desc='')
    if 'user_id' not in params:
        pay = get_pay(pay_id)
        if not pay:
            raise err.ParamError(u'订单不存在')
        params.update({'user_id': pay.user_id})
        params.update({'pay_type': pay.pay_type})
    params.update({'status': APPEAL_STATUS.WAIT})

    _LOGGER.info('customer service create appeal for params:%s' % params)
    appeal_orders = appeal_db.get_appeal_orders(pay_id=pay_id, status=[APPEAL_STATUS.WAIT, APPEAL_STATUS.SUBMIT,
                                                                       APPEAL_STATUS.SUCCESS])
    if appeal_orders:
        # 获取最近一笔的申诉订单
        appeal_order = appeal_orders[0]
        if appeal_order['status'] in [APPEAL_STATUS.WAIT, APPEAL_STATUS.SUBMIT]:
            raise err.ParamError(u'该订单正在审核中，请耐心等待')
        elif appeal_order['status'] in [APPEAL_STATUS.SUCCESS]:
            raise err.ParamError(u'该订单已经审核通过')

    appeal = appeal_db.add_appeal_order(params)

    recharge_appeal_handler.submit_appeal_order_to_third(appeal['id'])
