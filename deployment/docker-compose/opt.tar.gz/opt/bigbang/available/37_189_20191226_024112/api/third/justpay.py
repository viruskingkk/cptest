# -*- coding: utf-8 -*-
import logging

from django.views.decorators.http import require_POST
from django.http import HttpResponse

from common.third.pay import justpay
from common.utils import exceptions as err

_LOGGER = logging.getLogger('pay')


@require_POST
def charge_callback(request):
    try:
        justpay.check_notify_sign(request)
        # we must return 'success' after processing
        return HttpResponse('success', status=200)
    except err.ParamError as e:
        _LOGGER.warn('justpay notify param error, %s', e)
        return HttpResponse('success', status=200)
    except Exception as e:
        _LOGGER.exception('justpay notify exception.(%s)' % e)
        return HttpResponse('failure', status=500)
