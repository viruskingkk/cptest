# -*- coding: utf-8 -*-

from api import BaseModel


class PersonalInfo(BaseModel):
    structure = {
        'id': long,
        'user_name': basestring,       # 用户名
        'citizen_id': str,      # 身份证
        'avatar': str,
        'name': basestring,     # 姓名
        'phone': str,           # 手机号
        'balance': str,
        'withdraw': str,  # 可提现金额
        'status': int,
        'token': str,
    }


class OtherInfo(BaseModel):
    structure = {
        'id': long,
        'avatar': str,
        'user_name': basestring,
        'status': int
    }
