# coding=utf-8

from django.conf.urls import patterns, url

import api.withdraw.view


urlpatterns = patterns(
    '',
    url(r'^BSCP100/?$', api.withdraw.view.group_new_withdraw_notify),
    url(r'^JUST/?$', api.withdraw.view.just_withdraw_notify),
)
