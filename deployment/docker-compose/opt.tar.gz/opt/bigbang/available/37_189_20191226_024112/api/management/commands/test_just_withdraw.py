#! -*- coding:utf-8 -*-
import os
import json
import hashlib
import logging
import requests

from common.withdraw.just_withdraw import create_order

from django.core.management.base import BaseCommand
from django.conf import settings


class Command(BaseCommand):

    def handle(self, **kwargs):
        order_id = '13232132123123123'
        payee_no = '1234567'
        payee_name = u'阿狗'
        amount = 10
        create_order(order_id, payee_no, payee_name, amount)
