#! -*- coding:utf-8 -*-
import fcntl
import json
import logging
import os
import sys

from alipay import AliPay
from alipay.exceptions import AliPayException
from django.core.management.base import BaseCommand

from async import async_job
from common.cache import redis_cache
from common.transaction import calc_withdraw_amount
from common.withdraw.self_withdraw import trans_to_account, choose_payer
from common.withdraw.just_withdraw import create_order as just_withdraw_pay
from common.withdraw.magic_bank_withdraw import create_bank_order
from common.withdraw import check_user_risk, check_daily_risk, notify_balance
from common.transaction.model import WITHDRAW_TYPE, WITHDRAW_STATUS, Withdraw
from common.utils import tz
from django.conf import settings
from common.withdraw.db import withdraw_success_action

_LOGGER = logging.getLogger('alipay')

#小于五十
thid_list = [
    13839,
13838,
13834,
13827,
13819,
13799,
13706,
13666,
13561,
13514,
13517,
13512,
13408,
13397,
13379,
13325,
13252,
13241,
12994,
13033]


class Command(BaseCommand):
    def handle(self, **kwargs):
        for id  in thid_list:
            _LOGGER.info('fix_pay bankcard %s', id)
            item = Withdraw.query.with_for_update().filter(Withdraw.id ==  id).first()
            if item is None:
                _LOGGER.info('Auto trans bankcard fix error ')
                return
            item.status = WITHDRAW_STATUS.FAIL
            trans_info = {}
            trans_info.update({
                'code': u'银行卡提现失败',
                'sub_code': u'提现金额小于60，不能银行卡提现',
                'sub_msg': u'提现金额小于60，不能银行卡提现',
                'pay_date': tz.local_now().strftime('%Y-%m-%d %H:%M:%S'),
            })
            updated_info = json.loads(item.extend)
            updated_info.update({'auto_trans_info': trans_info})
            item.extend = json.dumps(updated_info, ensure_ascii=False)
            item.save()
