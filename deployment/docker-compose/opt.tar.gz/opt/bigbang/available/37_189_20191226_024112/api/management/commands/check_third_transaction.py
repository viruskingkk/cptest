#! -*- coding:utf-8 -*-
"""
用于自动核对和第三方游戏的资金流水。
"""
from django.core.management.base import BaseCommand

from common.platform.common.check_transaction import ThirdTransactionCheck
from common.utils.thread import GracefulExitedExecutor


class Command(BaseCommand):

    def handle(self, *args, **options):
        GracefulExitedExecutor('Auto Check Third Transaction Processor', [ThirdTransactionCheck()]).start()
