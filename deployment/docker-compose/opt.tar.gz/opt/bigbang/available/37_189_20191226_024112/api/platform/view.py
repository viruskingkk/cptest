# -*- coding: utf-8 -*-

import json
import logging

from django.views.decorators.http import require_GET, require_POST

from common.platform.metis.handler import get_history
from common.platform.metis.handler import handler as metis_handler
from common.platform.ametis.handler import handler as ametis_handler
from common.platform.ares.handler import handler as ares_handler
from common.platform.common import base as base_handler
from common.utils import exceptions as err
from common.utils.api import token_required, get_client_ip, parse_p
from common.utils.decorator import response_wrapper

_LOGGER = logging.getLogger(__name__)

HANDLERS = {
    'metis': metis_handler,
    'ametis': ametis_handler,
    'ares': ares_handler,
}


@require_POST
@response_wrapper
@token_required
def platform_login(req, platform):
    if platform not in HANDLERS:
        raise err.ParamError('platform name invalid')

    params = json.loads(req.body)
    game_id = params.get('game_id')
    p = parse_p(req.GET.get('p'))
    if p and p.get('cvc'):
        cvc = int(p.get('cvc'))
        if cvc <= 33:
            # 对于老版本的用户，直接用 ametis 代替 metis
            if platform == 'metis':
                platform = 'ametis'
                game_id = '88%s' % game_id

    user_id = req.user_id
    handler = HANDLERS.get(platform)
    if platform == 'ametis':
        game_id = int(str(game_id)[2:])
    user_name = req.user.user_name
    token = req.user.token
    ip = get_client_ip(req)
    res = handler.login(user_id, user_name=user_name, game_id=game_id, token=token, ip=ip)
    return {'data': res}


@require_GET
@response_wrapper
@token_required
def platform_logout(req, platform):
    user_id = req.user_id
    if platform == 'smart':
        # 智能判断，根据第三方游戏的transaction表，判断用户在哪一个游戏中
        # 此处并非严谨的判断，因为transaction表的内容是可变的;如果需要严格限制，需要新建用户状态表，同步用户状态
        # 但是可以减少和metis以及ares等第三方游戏的api交互
        need_logout, platform_str = base_handler.need_logout(user_id)
        if need_logout and platform_str != 'metis':
            handler = HANDLERS.get(platform_str)
        else:
            return {'data': u'不在游戏中'}
    else:
        p = parse_p(req.GET.get('p'))
        if p and p.get('cvc'):
            cvc = int(p.get('cvc'))
            if cvc <= 33:
                # 对于老版本的用户，使用 ametis 代替 metis
                # 对于高版本的用户，已经没有 metis了
                if platform == 'metis':
                    platform = 'ametis'
            else:
                if platform == 'metis':
                    raise err.ParamError('platform name invalid')
        handler = HANDLERS.get(platform)

    if not handler:
        raise err.ParamError('platform name invalid')

    res = handler.logout(user_id)
    if not res:
        raise err.ServerError('logout platform error')
    return {'data': res}


@require_GET
@response_wrapper
@token_required
def get_game_history(req):
    params = req.GET.dict()
    page = int(req.GET.get('page', 1))
    size = int(req.GET.get('size', 30))
    user_id = req.user_id
    resp_items = get_history(
        user_id, params.get('start_date'), params.get('end_date'), page, size)
    ret = dict({'list': resp_items, 'page': page, 'size': len(resp_items)})
    return ret
