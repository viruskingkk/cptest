# coding=utf-8
from api import BaseModel


class LastMsg(BaseModel):
    structure = {
        'title': basestring,
        'created_at': basestring,
        'tag': basestring,
        'body': basestring
    }


class ShortMsg(BaseModel):
    """
    消息列表页的消息简要描述
    """
    structure = {
        'id': long,
        'created_at': basestring,
        'content': dict,  # keys: tag, title
        'read': bool,
        'command': basestring,  # 非必须
    }


class MsgDetail(BaseModel):
    structure = {
        'id': long,
        'created_at': basestring,
        'content': dict,  # keys: tag, title, body
        'read': bool,
    }
