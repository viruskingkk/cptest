# -*- coding: utf-8 -*-
import logging
import json

from django.views.decorators.http import require_GET, require_POST

from common.utils.decorator import response_wrapper
from common.utils import exceptions as err
from common.utils.api import parse_p, check_params, token_required
from common.push import db


@require_POST
@response_wrapper
@token_required
def switch_push(req):
    params = json.loads(req.body)
    db.update_push_config(req.user_id, params)