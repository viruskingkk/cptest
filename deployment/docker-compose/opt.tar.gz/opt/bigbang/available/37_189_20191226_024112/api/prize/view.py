# coding: utf-8

from django.views.decorators.http import require_GET, require_POST
from common.utils.decorator import response_wrapper
from common.utils.api import token_required
from common.prize.db import get_fresh_award, get_first_award
from common.account.db.account import get_user_bankcard


@require_GET
@response_wrapper
@token_required
def get_reg_status(req):
    # register & bind bankcard & check award
    phone = req.user.phone
    user_id = req.user_id
    user_created_at = req.user.created_at
    data = {'phone': 0, 'card': 0, 'fresh': 0, 'old_fresh': 0}
    if phone and len(phone) == 13:
        data.update({'phone': 1})
    bankcard = get_user_bankcard(user_id)
    if bankcard:
        data.update({'card': 1})
    if get_fresh_award(user_id, fresh_type='old_fresh_award') or user_created_at.strftime(
                "%Y-%m-%d") < '2018-12-20':
        data.update({'old_fresh': 1})
    if get_fresh_award(user_id, fresh_type='fresh_award'):
        data.update({'fresh': 1})
    return data


@require_GET
@response_wrapper
@token_required
def get_first_prize(req):
    # 188充值
    status = get_first_award(req.user_id)
    return {'status': status}
