# -*- coding: utf-8 -*-
'''手动开奖，运行方式为 python tools/manual_announce_lottery.py 7 20170301022
    后面是期号
'''

import time
from django.core.management.base import BaseCommand
from common.lottery import LOTTERY_TYPE
from common.lottery.handler import crawl_from_opencai_with_date
from common.lottery.cyclical.abstract.activity import get_unannounced_terms, get_term_start_date
from common.utils.tz import local_date_to_ts, now_ts

STANDARD_LOTTERIES = [LOTTERY_TYPE.CQ_SSC, LOTTERY_TYPE.JS_KS, LOTTERY_TYPE.SD_11X5, LOTTERY_TYPE.TJ_SSC,
                      LOTTERY_TYPE.XJ_SSC, LOTTERY_TYPE.JX_11X5, LOTTERY_TYPE.GD_11X5, LOTTERY_TYPE.SH_11X5,
                      LOTTERY_TYPE.GX_KS, LOTTERY_TYPE.BJ_PK10, LOTTERY_TYPE.CQ_LF, LOTTERY_TYPE.TC_PLS]

DIY_LOTTERIES = [LOTTERY_TYPE.FF_SSC, LOTTERY_TYPE.FF_11X5, LOTTERY_TYPE.FF_KS, LOTTERY_TYPE.FF_PK10,]


class Command(BaseCommand):
    invalid_lottery = []
    begin_ts = local_date_to_ts('2019-10-10')
    end_ts = now_ts() - 24 * 3600

    # 存 彩种 以及对应没有开奖的 日期；因为开彩网需要指定对应日期
    lottery_announce_dict = {}

    def add_arguments(self, parser):
        # parser.add_argument('user_ids', nargs='?', type=int)
        pass

    @staticmethod
    def manual_announce_lottery(lottery_type, date):
        # 不能请求过快，防止第三方封号
        crawl_from_opencai_with_date(lottery_type, date)
        time.sleep(5)

    def announce_all(self):
        for lottery, dates in self.lottery_announce_dict.items():
            for date in dates:
                self.manual_announce_lottery(lottery, date)

    def search_unannounced_lottery(self):
        lotteries = [LOTTERY_TYPE.CQ_SSC, LOTTERY_TYPE.JS_KS, LOTTERY_TYPE.SD_11X5, LOTTERY_TYPE.XJ_SSC,
                     LOTTERY_TYPE.JX_11X5, LOTTERY_TYPE.GD_11X5, LOTTERY_TYPE.SH_11X5, LOTTERY_TYPE.GX_KS,
                     LOTTERY_TYPE.BJ_PK10, ]

        for lottery in lotteries:
            terms = get_unannounced_terms(lottery)
            print('begin lottery:%s' % LOTTERY_TYPE.get_label(lottery))
            date_set = set()
            for term in terms:
                if self.begin_ts <= term.end_ts <= self.end_ts:
                    date_set.add(get_term_start_date(term))
            print('lottery: %s, date set: %s' % (LOTTERY_TYPE.get_label(lottery), date_set))

            self.lottery_announce_dict.update({lottery: date_set})
            print('end lottery:%s' % LOTTERY_TYPE.get_label(lottery))

    def handle(self, **kwargs):
        # lottery_type = 12
        # terms = ['740043']
        # for term in terms:
        #     self.manaual_announce_lottery(lottery_type, term)
        self.search_unannounced_lottery()
        self.announce_all()



