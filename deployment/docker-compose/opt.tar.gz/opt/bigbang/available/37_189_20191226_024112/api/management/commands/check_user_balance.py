#! -*- coding:utf-8 -*-

import logging
from datetime import datetime, timedelta
from django.core.management.base import BaseCommand

from common.transaction import db as transaction_db
from common.account.db import account
from common.utils.decorator import sql_wrapper, mongo_wrapper
from common.utils.export import gen_filename, redirect_to_file
from common.stats import MG_BIGBANG_COLL as mg
from common.utils.tz import get_utc_date, utc_to_local_str

_LOGGER = logging.getLogger('worker')


@sql_wrapper
def get_account(user_id):
    return account.get_account(user_id)


@mongo_wrapper
def get_active_users():
    date_range = [get_utc_date('2019-10-20'), get_utc_date('2019-10-30')]
    filters = [{
        '$match': {'updated_at': {
            '$gte': date_range[0],
            '$lt': date_range[1]
        }, '$or': [
            {'pay': {'$exists': 1}},
            {'kfc': {'$exists': 1}},
            {'lottery': {'$exists': 1}},
            {'bull': {'$exists': 1}},
            {'fruit': {'$exists': 1}},
            {'metis': {'$exists': 1}}
        ]}},
        {'$group': {'_id': '$user_id'}},
    ]
    items = mg.daily_stats.aggregate(filters)
    return [item['_id'] for item in items]


class Command(BaseCommand):
    out_infos = []

    added = [2733862, 966721, 646346, 2521988, 2707614, 1044955, 1349282, 75050, 978587, 2736099, 2448975, 575819,
             2689499, 2727954, 2041481, 471556, 2736471,

             2647815, 2702669, 449535, 2706094, 2651898, 2654024, 764289, 2192370, 1349282, 2563388, 2729925,
             2683764, 931106, 1426943, 2568326, 2649891, 2654185, 536539, 2601868, 2498272, 2736355, 2619842,
             986675, 485988, 2565923, 2728333, 1199462]

    exclude = added
    not_exist_users = []

    def check_user_balance(self, user_id):
        print('check balance for user_id: %s' % user_id)

        start_day = datetime.utcnow() - timedelta(days=3)
        trans = transaction_db.get_transactions_for_check(int(user_id), start_day)
        print('check trans length: %s' % len(trans))
        pre_item = None
        total = 0
        out_info = [user_id]
        trans_info = ''
        for item in trans:
            if pre_item:
                dis = pre_item.balance + item.price - item.balance
                if abs(dis) > 0.001:
                    print('item id: %s has issue, value is:%s' % (item.id, dis))
                    total = total + dis
                    trans_info = '%s%s,%s,%s\n' % (trans_info, utc_to_local_str(item.created_at), item.id, dis)
            pre_item = item

        out_info.append(trans_info)

        print('user_id: %s , total trans issue is: %s' % (user_id, total))

        out_info.append(total)

        user_info = get_account(user_id)
        if user_info is None or pre_item is None:
            self.not_exist_users.append(user_id)
            return

        diff = pre_item.balance - user_info.balance
        if abs(diff) > 0.001:
            print('user_id balance %s is not equal last trans %s , diff %s ' %
                  (user_info.balance, pre_item.balance, diff))
            out_info.append(diff)
            total = total + diff
            print('user_id: %s , total issue is: %s' % (user_id, total))
        else:
            out_info.append(0)

        out_info.append(total)
        out_info.append(',%s,%s' % (user_id, total))
        self.out_infos.append(out_info)

    def export(self):
        header = [u'用户id', u'异常交易ID', u'异常交易数额', u'当前余额与最近交易差额', u'总差额', u'执行代码']
        filename = gen_filename('issue_balance')
        print('http://c.69whqi.com:9002' + redirect_to_file(self.out_infos, header, filename).get('url'))
        print('not exist users: %s' % self.not_exist_users)

    def add_arguments(self, parser):
        parser.add_argument('user_ids', nargs='*', type=int)

    def handle(self, *args, **kwargs):
        if 'user_ids' in kwargs and kwargs['user_ids']:
            user_ids = kwargs['user_ids']
        else:
            user_ids = [2682646]
            # user_ids = get_active_users()
        for user_id in user_ids:
            if user_id in self.exclude:
                continue
            self.check_user_balance(user_id)

        # self.export()


