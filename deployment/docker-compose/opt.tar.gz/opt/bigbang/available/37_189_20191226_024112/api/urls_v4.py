# coding=utf-8

from django.conf.urls import patterns, url

import api.preset.view
from activity.recharge_red_envelope_view import get_winners, RedEnvelopeView, get_time
import api.prize.view
from api.activity import spring_festival_view
from api.activity import recharge_iphone_view
from api.activity import ranking_view
from api.activity import lantern_view


urlpatterns = patterns(
    '',
    url(r'^preset/lottery/?$', api.preset.view.get_available_lottery_v4),

    # 活动相关
    # 双旦活动
    url(r'^activity/recharge_red_envelope/winners/?$', get_winners),
    url(r'^activity/recharge_red_envelope/prize/?$', RedEnvelopeView.as_view()),
    url(r'^activity/recharge_red_envelope/time/?$', get_time),
    # 新注册送活动
    url(r'^prize/register/status?$', api.prize.view.get_reg_status),
    # 充值送1888活动
    url(r'^prize/first/get?$', api.prize.view.get_first_prize),
    # 春节福利活动
    url(r'^activity/spring_festival/home_info/?$', spring_festival_view.get_home_info),
    url(r'^activity/spring_festival/prize/?$', spring_festival_view.open_prize),
    # 充值送iPhone活动
    url(r'^activity/recharge_iphone/home_info/?$', recharge_iphone_view.get_home_info),
    url(r'^activity/recharge_iphone/winners/?$', recharge_iphone_view.get_winners),
    # 春节财富风云榜活动
    url(r'^activity/ranking/ranking_info/?$', ranking_view.get_ranking_info),
    url(r'^activity/ranking/home_info/?$', ranking_view.get_home_info),
    # 元宵活动
    url(r'^activity/lantern/home_info/?$', lantern_view.get_home_info),
    url(r'^activity/lantern/winners/?$', lantern_view.get_winners),
)
