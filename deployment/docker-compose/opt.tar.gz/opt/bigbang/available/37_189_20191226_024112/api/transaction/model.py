# -*- coding: utf-8 -*-

from api import BaseModel
from common.pay.model import PAY_TYPE

from django.conf import settings


class TransactionLite(BaseModel):
    structure = {
        'status': int,  # 0: 等待中, 1: 已完成, 2: 交易失败
        'title': basestring,  # 交易梗概
        'price': str,  # 具体金额
        'type': int,     # 交易类型
        'activity_type': int,
        'balance': str,  # 交易结束后用户余额
        'time': basestring  # 具体交易时间
    }


class PayType(BaseModel):
    structure = {
        'name': basestring,
        'pay_type': int,
        'child': list
    }


class WithdrawLite(BaseModel):
    structure = {
        'status': int,  # 0: 等待中, 1: 已完成, 2: 提现失败
        'target_type': int,
        'info': dict,
        'price': str,  # 提现金额
        'time': basestring  # 提现申请时间
    }


available_pay_types = {
    PAY_TYPE.JUSTPAY_ALI: {
        'name': u'支付宝',
        'pay_type': PAY_TYPE.JUSTPAY_ALI,
        'comment': u'',
        'highlight': 1,
        'icon': settings.QINIU_BUCKETS['default'] + 'alipay.png'
    },
    PAY_TYPE.JUSTPAY_WX: {
        'name': u'微信',
        'pay_type': PAY_TYPE.JUSTPAY_WX,
        'comment': u'',
        'highlight': 0,
        'icon': settings.QINIU_BUCKETS['default'] + 'wechat.png'
    },
    PAY_TYPE.JUSTPAY_QQ: {
        'name': u'QQ支付',
        'pay_type': PAY_TYPE.JUSTPAY_QQ,
        'comment': u'',
        'highlight': 0,
        'icon': settings.QINIU_BUCKETS['default'] + 'qq_pay.png'
    },
    PAY_TYPE.JUSTPAY_UNION: {
        'name': u'银行卡',
        'pay_type': PAY_TYPE.JUSTPAY_UNION,
        'comment': u'',
        'highlight': 0,
        'icon': settings.QINIU_BUCKETS['default'] + 'ic_buycard_recharge.png'
    },
    PAY_TYPE.JUSTPAY_TEST: {
        'name': u'测试支付',
        'pay_type': PAY_TYPE.JUSTPAY_TEST,
        'comment': u'',
        'highlight': 0,
        'icon': settings.QINIU_BUCKETS['default'] + 'ic_buycard_recharge.png'
    },
    'self_recharge': {
        'name': u'官方代理充值',
        'pay_type': PAY_TYPE.SELF_WECHAT,
        'open_url': settings.WEB_APP_ROOT_URL+'/info/agent_charge/',
        'icon': settings.QINIU_BUCKETS['default'] + 'o_1bs58mjmm172aqch1gjh1ct91uj651.png',
        'category': u'VIP支付',
        'comment': u'加官方微信充值，有额外返利！',
        'highlight': 1,
    },
}
