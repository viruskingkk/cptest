# -*- coding: utf-8 -*-

from api import BaseModel


class ShowLite(BaseModel):
    structure = {
        'id': int,
        'user_name': basestring,
        'order_id': int,
        'avatar': basestring,
        'highlight': bool,
        'term': basestring,
        'activity_type': int,
        'bet_type': int,
        'title': basestring,
        'content': basestring,
        'images': list,
        'small_images': list,
        'status': int,
        'verify_at': basestring,
        'verify_comment': basestring,
        'price': basestring,
        'win_price': basestring,
    }
