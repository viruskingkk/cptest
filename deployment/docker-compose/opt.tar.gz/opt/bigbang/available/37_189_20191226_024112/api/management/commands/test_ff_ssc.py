#! -*- coding:utf-8 -*-
import os
import json
import hashlib
import logging
import requests

from common import orm, slave
from common.lottery import KEYWORD_TYPE_DCT
from common.lottery.cyclical.model import ORDER_MODEL
from common.lottery.cyclical.handler import (normal_random, calc_win,
                                             choose_user_win_number,
                                             choose_user_lose_number,
                                             user_lose_digits_weight,
                                             probability_random_wrap)
from common.lottery.cyclical.model import ACTIVITY_MODEL

from django.core.management.base import BaseCommand
from django.conf import settings

_LOGGER = logging.getLogger('test')


MAX_ADJUST_COUNT = 50
MIN_ADJUST_BET = 10000
MIN_PROFIT_RATE = 0.02
MAX_PROFIT_RATE = 0.1


class Command(BaseCommand):

    def get_all_orders(self, activity_type, term):
        order_table = ORDER_MODEL[activity_type]
        order_query = order_table.query.filter(order_table.term == term).all()
        orders = []
        for order in order_query:
            order_dict = {
                'id': order.id,
                'user_id': order.user_id,
                'term': order.term,
                'number': order.number,
                'price': float(order.price),
                'bet_type': order.bet_type,
                'times': order.times,
                'unit': order.unit
            }
            orders.append(order_dict)
        return orders

    def process(self, term):
        tag = '#%s%s#' % (self.key, term)
        orders = self.get_all_orders(self.activity_type, term)
        bet_this_term = sum(x['price'] for x in orders)
        current_profit_rate = 100 * self.system_win / float(self.total_bet) if self.total_bet else 0
        _LOGGER.info('%s before current system_win: %s, bet: %s, profit_rate: %s%%' %
                     (tag, self.system_win, self.total_bet, round(current_profit_rate, 3)))
        final_number = None

        if bet_this_term > 0:# and self.total_bet > MIN_ADJUST_BET:
            number = normal_random(self.activity_type)
            result = calc_win(self.activity_type, number, orders)
            win_this_term = sum(x['win_amount'] for x in result)
            new_profit_rate = (self.system_win + bet_this_term - win_this_term) / (self.total_bet + bet_this_term)
            _LOGGER.info(u'%s %s -> term_bet: %s, term_win: %s, rate: %s%%' %
                         (tag, number, bet_this_term, win_this_term, round(new_profit_rate * 100, 3)))
            if new_profit_rate > MAX_PROFIT_RATE:
                _LOGGER.info(u'%s profit_rate > %s, need to make user win' % (tag, MAX_PROFIT_RATE))
                try_count = 0
                candidate_dict = {}
                while try_count < MAX_ADJUST_COUNT:
                    number = normal_random(self.activity_type)
                    result = calc_win(self.activity_type, number, orders)
                    win_this_term = sum(x['win_amount'] for x in result)
                    new_profit_rate = (self.system_win + bet_this_term - win_this_term) / (self.total_bet + bet_this_term)
                    candidate_dict.update({
                        number: new_profit_rate
                    })
                    try_count += 1
                    _LOGGER.info(u'%s %s -> term_bet: %s, term_win: %s, rate: %s%%, try count: %s' %
                                 (tag, number, bet_this_term, win_this_term, round(new_profit_rate * 100, 3), try_count))
                    if MIN_PROFIT_RATE <= new_profit_rate <= MAX_PROFIT_RATE:
                        final_number = number
                        _LOGGER.info(u'%s adjust succ, update number %s' % (tag, final_number))
                        break
                if not final_number:
                    final_number = choose_user_win_number(candidate_dict)
                    _LOGGER.info(u'%s adjust fail, choose_user_win_number %s' % (tag, final_number))
            elif new_profit_rate < MIN_PROFIT_RATE:
                _LOGGER.info(u'%s profit_rate < %s, need to make user lose' % (tag, MIN_PROFIT_RATE))
                try_count = 0
                digits_weight = user_lose_digits_weight(orders, self.activity_type)
                candidate_dict = {}
                _LOGGER.info(u'%s digits_weight: %s' % (tag, digits_weight))
                while try_count < MAX_ADJUST_COUNT:
                    number = probability_random_wrap(digits_weight, self.activity_type)
                    result = calc_win(self.activity_type, number, orders)
                    win_this_term = sum(x['win_amount'] for x in result)
                    new_profit_rate = (self.system_win + bet_this_term - win_this_term) / (self.total_bet + bet_this_term)
                    candidate_dict.update({
                        number: new_profit_rate
                    })
                    try_count += 1
                    _LOGGER.info(u'%s %s -> term_bet: %s, term_win: %s, rate: %s%%, try count: %s' %
                                 (tag, number, bet_this_term, win_this_term, round(new_profit_rate * 100, 3), try_count))
                    if MIN_PROFIT_RATE <= new_profit_rate <= MAX_PROFIT_RATE:
                        final_number = number
                        _LOGGER.info(u'%s adjust succ, update number %s' % (tag, final_number))
                        break
                if not final_number:
                    final_number = choose_user_lose_number(candidate_dict)
                    _LOGGER.info(u'%s adjust fail, choose_user_lose_number %s' % (tag, final_number))
            else:
                final_number = number
        else:
            _LOGGER.info('%s no user bet, skip adjust' % tag)
            final_number = normal_random(self.activity_type)

        result = calc_win(self.activity_type, final_number, orders)
        win_this_term = sum(x['win_amount'] for x in result)
        self.system_win += (bet_this_term - win_this_term)
        self.total_bet += bet_this_term
        current_profit_rate = 100 * self.system_win / float(self.total_bet) if self.total_bet else 0
        _LOGGER.info('%s final number <%s>, bet: %s, win: %s, rate: %s%%' %
                     (tag, final_number, bet_this_term, win_this_term, round(current_profit_rate , 3)))
        _LOGGER.info('%s after current system_win: %s, bet: %s, profit_rate: %s%%' %
                     (tag, self.system_win, self.total_bet, round(current_profit_rate, 3)))
        if current_profit_rate < 0:
            _LOGGER.warn('!!!!!!!!!!!!!%s current profit rate %s lt 0 !!!!!!!', tag, round(current_profit_rate, 3))

    def handle(self, key, start_term, end_term, **kwargs):
        self.key = key
        self.total_bet = 0
        self.system_win = 0
        activity_type = KEYWORD_TYPE_DCT[key]
        self.activity_type = activity_type
        table = ACTIVITY_MODEL[activity_type]
        terms = orm.session.query(table).filter(table.term>=start_term).filter(
            table.term<=end_term).order_by(table.term).all()
        for term in terms:
            self.process(term.term)
