#! -*- coding:utf-8 -*-
import logging

from django.core.management.base import BaseCommand
from common.utils.tz import today_str
from common.activity.ranking_db import get_history_ranking_by_mongo
from common.cache import redis_cache


_LOGGER = logging.getLogger('worker')


class Command(BaseCommand):

    def handle(self, **kwargs):
        # 定时刷新
        today = today_str()
        today_rank = get_history_ranking_by_mongo(today, total=0)
        if today_rank:
            redis_cache.set_today_ranks(today, today_rank)
        total_rank = get_history_ranking_by_mongo(activity_date=None, total=1)
        if total_rank:
            redis_cache.set_total_ranks(total_rank)
