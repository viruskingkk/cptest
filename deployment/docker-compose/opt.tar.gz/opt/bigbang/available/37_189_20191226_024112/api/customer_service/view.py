# -*- coding: utf-8 -*-
import json
import logging

from django.views.decorators.http import require_GET, require_POST

from common.utils.api import token_required
from common.utils.decorator import response_wrapper
from common.utils.api import parse_p
from common.utils import exceptions as err
from common.utils.api import check_params

import handler as cs_handler


_LOGGER = logging.getLogger('bigbang')


@require_GET
@response_wrapper
@token_required
def get_h5_url(request):
    """
    获取客服h5页面入口
    """
    try:
        user_id = request.user_id
        p = parse_p(request.GET.get('p'))
    except:
        raise err.ParamError('p param not right, params:%s' % request.GET)
    token = cs_handler.get_h5_url(user_id, p)
    return {'url': token}


@require_GET
@response_wrapper
@token_required
def get_recharge_appeal_url(request):
    """
    获取客服h5充值申诉页面入口
    """
    try:
        user_id = request.user_id
        p = parse_p(request.GET.get('p'))
    except:
        raise err.ParamError('p param not right, params:%s' % request.GET)
    appeal_url = cs_handler.get_recharge_appeal_url(user_id, p)
    appeal_record_url = appeal_url.replace('rechargeStatement', 'rechargerecord', 1)
    return {'url': appeal_url, 'record_url': appeal_record_url}


@require_GET
@response_wrapper
@token_required
def get_recharge_appeal_record_url(request):
    """
    获取客服h5充值申诉历史记录页面入口
    """
    try:
        user_id = request.user_id
        p = parse_p(request.GET.get('p'))
    except:
        raise err.ParamError('p param not right, params:%s' % request.GET)
    token = cs_handler.get_recharge_appeal_record_url(user_id, p)
    return {'url': token}


@require_POST
@response_wrapper
def get_order(request):
    """
    获取充值或提现订单， 充值要7天内订单，提现要15天内订单， 状态要去掉成功的
    """
    params = json.loads(request.body)
    check_params(params, ['user_id', 'question_type', 'timestamp', 'sign'])
    cs_handler.check_sign(params)

    user_id = int(params.get('user_id'))
    question_type = int(params.get('question_type'))

    items = cs_handler.get_order(user_id, question_type)
    return {'list': items}


@require_POST
@response_wrapper
def get_appeal_order(request):
    """
    获取已提交的充值申诉订单
    """
    params = json.loads(request.body)
    check_params(params, ['user_id', 'timestamp', 'sign'])
    cs_handler.check_sign(params)

    user_id = int(params.get('user_id'))
    page = int(params.get('page', 1))
    size = int(params.get('size', 30))
    items, total = cs_handler.get_appeal_orders(user_id, page, size)
    return {'list': items, 'page': page, 'size': size, 'total': total}


@require_POST
@response_wrapper
def submit_appeal_order(request):
    """
    提交充值申诉
    """
    params = json.loads(request.body)
    check_params(params, ['pay_id', 'pay_at', 'pay_amount', 'name', 'desc', 'receipt', 'timestamp', 'sign'])
    cs_handler.check_sign(params)

    cs_handler.submit_appeal_order(params)
    return {}
