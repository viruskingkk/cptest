# -*- coding: utf-8 -*-
from common.feedback.model import Feedback

from common.utils.decorator import sql_wrapper


@sql_wrapper
def submit(qq, content, chn, cvc, user_id=None, user_name=None):
    feedback = Feedback()
    feedback.chn = chn
    feedback.cvc = cvc
    feedback.qq = qq
    feedback.content = content
    if user_id:
        feedback.user_id = user_id
    if user_name:
        feedback.nick_name = user_name
    feedback.save()
