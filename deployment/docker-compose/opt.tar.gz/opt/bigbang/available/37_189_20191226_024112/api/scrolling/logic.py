# coding=utf-8
import datetime
import json
import logging
import random

from common.cache import redis_cache
from common.scrolling.handler import _fill_text
from common.utils.tz import now_ts

_LOGGER = logging.getLogger('bigbang')

_MAX_COUNT = 10

_LIMIT_TS = 600


def view_scrolling(key='scrolling'):
    """
    跑马灯
    """
    scrolling_list = []
    scrolling_set = redis_cache.range_scrolling(key=key)
    now = now_ts()
    count = 0
    for scrolling, ts in scrolling_set:
        if now - ts > _LIMIT_TS and count >= _MAX_COUNT:
            break
        scrolling_value = json.loads(scrolling)
        text = scrolling_value.get('text')
        params = scrolling_value.get('params')
        if params:
            text = _fill_text(text, params)
        scrolling_list.append({
            'text': text,
        })
        count += 1

    now = datetime.datetime.now()
    if 16 < now.hour < 24:
        scrolling_list += _gen_fake_scrolling(10)
    else:
        scrolling_list += _gen_fake_scrolling(30)
    return scrolling_list


_PRICE_LIST = [20.000, 30.000, 19.000, 50.000, 18.000, 100.000, 16.000, 80.000, 200.000, 462.000, 66.000, 2000.000,
               10.286, 156.000, 110.000, 400.000, 940.000, 540.000, 33.333, 1000.000, 3000.000, 1386.000, 1920.000,
               3960.000, 3520]

_username_list = [
    u'17681770877', u'mmdkd', u'15230698009as', u'xuzh9805', u'nfdx', u'jylyl123', u'王穿', u'ruyiqian', u'w1472583690',
    u'gzf654321', u'1099626524', u'a73k5e7', u'yeruihao', u'天知道', u'ekjsj', u'57588665885', u'qy512135034',
    u'15599323656zh', u'中大奖走起', u'fy198737', u'时间长斯诺', u'13278523620', u'wuyouhua', u'红军', u'fg54921079', u'我可以昨天',
    u'13563096017', u'骗子', u'15155940041', u'qweasdzxc147', u'jijia00', u'ymsh2233', u'iioveyou', u'11111abc', u'wwksk',
    u'dhe1', u'15169199122', u'518888', u'17774859179', u'5201314txy', u'17303247246', u'52csj', u'15733558800',
    u'13223656038', u'中q华一刀斩', u'羊羊羊', u'qvcz4290', u'15978024520', u'觉得你都不', u'在不在不想', u'ymt123456789', u'bnb963',
    u'啊啊啊kkk', u'枫树未央', u'lkl666lkl', u'SJL18085412009', u'm2d2', u'e799', u'yyll', u'18201315313', u'cxl5569', u'a2f9',
    u'li4n1lpfu77', u'13646339141', u'mmb987', u'快速的注册', u'd02n1y3', u'huangqi', u'jSze779', u'zu22229780', u'刘光头强',
    u'xuanlvmeihao', u'qq5426458', u'铭宝1970', u'15840682305', u'LJM198611', u'13815874525', u'bz380', u'18367326933',
    u'李洋ll', u'13275127007', u'如果你在', u'hefeiyan', u'15046606168', u'bk51', u'diao83812', u'18108879247', u'A1b2c3',
    u'18776839951', u'luoluao', u'zjs东天', u'xx8371xx', u'程文军2', u'玲珑', u'13239799171', u'high路途有', u'13734237372',
    u'DFC鸿', u'18672799660h',
]


def _gen_fake_scrolling(count=10):
    fake_list = []
    for username in get_random_username(count):
        price = random.choice(_PRICE_LIST)
        fake_list.append({
            'text': u'恭喜【%s***】中奖<font color="red">%s</font>元' % (username[0], str(price))
        })
    return fake_list


def get_random_username(count):
    return random.sample(_username_list, count)
