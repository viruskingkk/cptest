# -*- coding: utf-8 -*-

from api import BaseModel


class TreasureLite(BaseModel):
    structure = {
        'id': int,
        'user_name': basestring,
        'amount': int,
        'treasure_type': int,
        'status': int,
        'date': str,
    }
