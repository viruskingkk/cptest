#! -*- coding:utf-8 -*-
import fcntl
import json
import logging
import os
import sys

from django.core.management.base import BaseCommand

from common import orm
from common.cache import redis_cache
from common.admin.db import get_nickname_by_id
from common.notification.model import NOTIFY_TYPE
from common.notification.db import create_user_notification
from common.black_account.db import create_withdraw_black
from common.system_recharge.db import create_system_trans
from common.utils import tz
from django.conf import settings

_LOGGER = logging.getLogger('worker')


TMP_DCT = {
    'a-1000': {
        'award_amount': 1000,
        'title': u'万豪2周年真情大回馈',
        'body': u'尊敬的万豪彩票用户：\n       恭喜！您被选中为“万豪2周年VIP大回馈”活动的幸运用户！感谢您对万豪彩票平台的信任与支持，平台特奖励您 1000元 专属彩金。彩金已打入您的账户余额中，达到该金额10倍流水后即可提现。\n祝您财源广进，天天开心！\n\n万豪彩票运营部'
    },
    'a-500': {
        'award_amount': 500,
        'title': u'万豪2周年真情大回馈',
        'body': u'尊敬的万豪彩票用户：\n       恭喜！您被选中为“万豪2周年VIP大回馈”活动的幸运用户！感谢您对万豪彩票平台的信任与支持，平台特奖励您 500元 专属彩金。彩金已打入您的账户余额中，达到该金额10倍流水后即可提现。\n祝您财源广进，天天开心！\n\n万豪彩票运营部'
    },
    'a-200': {
        'award_amount': 200,
        'title': u'万豪2周年真情大回馈',
        'body': u'尊敬的万豪彩票用户：\n       恭喜！您被选中为“万豪2周年VIP大回馈”活动的幸运用户！感谢您对万豪彩票平台的信任与支持，平台特奖励您 200元 专属彩金。彩金已打入您的账户余额中，达到该金额10倍流水后即可提现。\n祝您财源广进，天天开心！\n\n万豪彩票运营部'
    },
    'b-1000': {
        'award_amount': 1000,
        'title': u'万豪2周年真情大回馈',
        'body': u'尊敬的万豪彩票用户：\n       恭喜！您被选中为“万豪2周年VIP大回馈”活动的幸运用户！感谢您对万豪彩票平台的信任与支持，平台特奖励您 1000元 专属彩金。彩金已打入您的账户余额中，达到该金额10倍流水后即可提现。\n祝您财源广进，天天开心！\n\n万豪彩票运营部'
    },
    'b-500': {
        'award_amount': 500,
        'title': u'万豪2周年真情大回馈',
        'body': u'尊敬的万豪彩票用户：\n       恭喜！您被选中为“万豪2周年VIP大回馈”活动的幸运用户！感谢您对万豪彩票平台的信任与支持，平台特奖励您 500元 专属彩金。彩金已打入您的账户余额中，达到该金额10倍流水后即可提现。\n祝您财源广进，天天开心！\n\n万豪彩票运营部'
    },
    'b-200': {
        'award_amount': 200,
        'title': u'万豪2周年真情大回馈',
        'body': u'尊敬的万豪彩票用户：\n       恭喜！您被选中为“万豪2周年VIP大回馈”活动的幸运用户！感谢您对万豪彩票平台的信任与支持，平台特奖励您 200元 专属彩金。彩金已打入您的账户余额中，达到该金额10倍流水后即可提现。\n祝您财源广进，天天开心！\n\n万豪彩票运营部'
    },
}


class Command(BaseCommand):

    def withdraw_black(self, user_id):
        """
        加入电销黑名单
        """
        note = u'电销批量召回'
        withdraw_black_dct = create_withdraw_black(user_id,
            'black_sales', user_id, note=note)

    def add_coin(self, user_id, amount):
        """
        系统上分奖励
        """
        pass

    def notify(self, user_id, tmp_id):
        TMP_INFO = TMP_DCT[tmp_id]
        content = {
            "body": TMP_INFO['body'],
            "tag": u"平台彩金奖励",
            "title": TMP_INFO['title']
        }
        content = json.dumps(content, ensure_ascii=False)
        create_user_notification(user_id, NOTIFY_TYPE.INSIDE, content)
        print 'notify {} to user {} succ'.format(tmp_id, user_id)

    def handle(self, **kwargs):
        admin_id = 5
        tmp_id = 'a-1000'
        TMP_INFO = TMP_DCT[tmp_id]
        award_amount = TMP_INFO['award_amount']
        trans_id = '20180726-{}'.format(tmp_id)
        operator = get_nickname_by_id(admin_id)
        params = []
        with open('./{}'.format(tmp_id), 'r') as fp:
            for line in fp:
                user_id = line.strip()
                params.append({
                    'user_name': '',
                    'user_id': user_id,
                    'amount': award_amount
                })
                print 'add ', user_id
        note = u'批量电销召回'
        black_type = 'black_sales'
        create_system_trans(trans_id, params, operator, note, admin_id, ip=None,
                            device=None, trans_type=None, black_type=black_type)
        for param in params:
            self.notify(param['user_id'], tmp_id)
