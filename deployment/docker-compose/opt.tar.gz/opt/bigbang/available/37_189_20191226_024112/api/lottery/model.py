# -*- coding: utf-8 -*-
from datetime import datetime

from api import BaseModel
from common.utils import tz


class SummaryModel(BaseModel):
    structure = {
        'term': str,  # 期号
        'number': str,  # 开奖结果,
        'time': str     # 开奖时间
    }

    def __init__(self, dct):
        super(SummaryModel, self).__init__(dct)
        if 'announce_ts' in dct:
            self['time'] = tz.utc_to_local_str(
                datetime.fromtimestamp(dct['announce_ts']))
        if ',' not in dct['number']:
            self['number'] = ','.join(dct['number'])


class OrderRecord(BaseModel):
    structure = {
        "id": int,
        'activity_type': int,
        'term': str,    # 期号
        'order_id': long,
        'bet_type': int,  # 押注方式
        'number': str,   # 押注内容
        'status': int,
        'track_status': int,
        'price': str,
        'win_price': str,  # 用户中奖
        "bonus": str,   # 系统奖励
        'created_at': str,
    }


class TrackRecord(BaseModel):
    structure = {
        'activity_type': int,
        'track_id': str,
        'bet_type': int,
        'term': str,
        'number': str,
        'total_amount': int,  # 总计金额
        'total_count': int,  # 共多少期
        'bet_amount': int,    # 已投注金额
        'bet_count': int,      # 已投注期数
        'win_price': str,    # 中奖金额
        'bonus': str,
        'type': int,          # 订单类型
        'status': int,
        'created_at': str,
    }

class TrackRecordV2(BaseModel):
    structure = {
        'activity_type': int,
        'track_id': str,
        'bet_type': int,
        'term': str,
        'number': str,
        'total_amount': basestring,  # 总计金额
        'total_count': int,  # 共多少期
        'bet_amount': basestring,    # 已投注金额
        'bet_count': int,      # 已投注期数
        'win_price': str,    # 中奖金额
        'bonus': str,
        'type': int,          # 订单类型
        'status': int,
        'created_at': str,
        'group_count': int  # 投了几注
    }

class WaitShowOrder(BaseModel):
    structure = {
        'term': basestring,  # 期数
        'price': basestring,  # 投注金额
        'win_price': basestring,  # 中奖金额
        'activity_type': int,  # 彩种
        'order_id': int,  # 订单号
    }

class OrderStats(BaseModel):
    structure = {
        'win': int,        # 未读的中奖订单数
        'tracking': int,   # 进行中的追号订单数
    }


class CyclicalActivity(BaseModel):
    structure = {
        'id': int,
        'type': int,
        'term': str,        # 期号
        'status': int,      # 1: 进行中， 2：等待爬取结果，3：已开奖
        'left_ts': int,     # 距离结束还剩多少秒
        'number': str,      # 如果已开奖，这里是开奖结果
        'announce_at': str,  # 开奖时间
        'repeat_numbers': int  # 重号个数
    }
    required_fields = ['id', 'term', 'status']
    default_fields = {
        'left_ts': 0,
        'number': None
    }


class CyclicalOrderRecord(BaseModel):
    structure = {
        'id': int,
        'activity_type': int,
        'type': int,    # 订单类型，0：普通，1：追注
        'term': str,    # 期号
        'status': int,   # 订单状态
        'track_status': int,  # 追号状态
        'bet_type': int,  # 押注方式
        'number': str,   # 押注内容
        'price': str,  # 订单总价
        'times': int,    # 倍率
        'track_id': str,    # 追号ID，普通投注为null
        'win_price': str,  # 订单金额
        "bonus": str,     # 系统奖励
        'unit': int,   # 用户自选每注单价
        'created_at': str,
        'updated_at': str
    }


class CyclicalOrderRecordV2(BaseModel):
    structure = {
        'id': int,
        'activity_type': int,
        'type': int,    # 订单类型，0：普通，1：追注
        'term': str,    # 期号
        'status': int,   # 订单状态
        'track_status': int,  # 追号状态
        'bet_type': int,  # 押注方式
        'number': str,   # 押注内容
        'price': str,  # 订单总价
        'times': int,    # 倍率
        'track_id': str,    # 追号ID，普通投注为null
        'win_price': str,  # 订单金额
        "bonus": str,     # 系统奖励
        'unit': basestring,   # 用户自选每注单价
        'created_at': str,
        'updated_at': str
    }


class CyclicalOrderDetail(BaseModel):
    structure = {
        'id': int,
        'activity_type': int,    # 活动类型，时时彩固定为1
        'type': int,    # 订单类型，0：普通，1：追注
        'term': str,    # 期号
        'status': int,   # 订单状态
        'track_status': int,  # 追号状态
        'bet_type': int,  # 押注方式
        'number': str,   # 押注内容
        'price': str,  # 订单总价
        'track_id': str,  # 追号ID
        'times': int,    # 倍率
        'win_price': str,  # 订单金额
        "bonus": str,      # 系统奖励
        'unit': int,   # 用户自选每注单价
        'left_ts': int,  # 该期距离开奖的时间
        'win_number': str,  # 该期中奖号码
        'created_at': str,
        'updated_at': str,
    }


class CyclicalOrderDetailV2(BaseModel):
    structure = {
        'id': int,
        'activity_type': int,    # 活动类型，时时彩固定为1
        'type': int,    # 订单类型，0：普通，1：追注
        'term': str,    # 期号
        'status': int,   # 订单状态
        'track_status': int,  # 追号状态
        'bet_type': int,  # 押注方式
        'number': str,   # 押注内容
        'price': str,  # 订单总价
        'track_id': str,  # 追号ID
        'times': int,    # 倍率
        'win_price': str,  # 订单金额
        "bonus": str,      # 系统奖励
        'unit': basestring,   # 用户自选每注单价
        'left_ts': int,  # 该期距离开奖的时间
        'win_number': str,  # 该期中奖号码
        'created_at': str,
        'updated_at': str,
        'group_count': int  # 下了几注
    }