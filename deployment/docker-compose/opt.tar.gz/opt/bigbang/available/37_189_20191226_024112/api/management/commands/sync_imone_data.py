#! -*- coding:utf-8 -*-

import time
from datetime import datetime, timedelta
from django.core.management.base import BaseCommand

from common import orm
from common.platform.ares import ares_api
from common.platform.ares.handler import add_bet_log_to_db
from common.platform.ares.db import get_lastest_time_betlogs
from common.utils import track_logging, tracker
from common.utils.tz import local_now, utc_to_local

_LOGGER = track_logging.getLogger(__name__)


def sync_ares_bet_logs(start, end):
    status, data = ares_api.query_bet_logs_v2(start, end, 1, 500)
    if status:
        # if not data['total_count']:
        #     return
        for item in data['items']:
            if not item:
                return
            try:
                add_bet_log_to_db(item)
            except:
                orm.session.rollback()
                continue
            finally:
                orm.session.close()

    return status


class Command(BaseCommand):
    def handle(self, *args, **options):
        start_time = local_now() - timedelta(minutes=60)
        latest_time = get_lastest_time_betlogs()
        if latest_time:
            start_time = max(start_time, utc_to_local(latest_time))
        while True:
            success = True
            try:
                end_time = start_time + timedelta(minutes=2)
                if end_time <= local_now() - timedelta(minutes=10):
                    sync_ares_bet_logs(start_time, end_time)
                else:
                    success = False
                start_time = end_time
                time.sleep(2)
            except:
                success = False
                _LOGGER.exception('sync_imone_data error')
            finally:
                orm.session.close()
                if not success:
                    time.sleep(60)

