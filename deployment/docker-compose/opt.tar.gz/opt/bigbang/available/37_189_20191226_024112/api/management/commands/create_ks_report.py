#! -*- coding:utf-8 -*-
import os
import json
import logging
from datetime import datetime, timedelta

from common.utils.tz import get_utc_date, local_now, utc_to_local

from common.stats import ks_report

from django.core.management.base import BaseCommand


_LOGGER = logging.getLogger('worker')


class Command(BaseCommand):

    def handle(self, **kwargs):
        today = get_utc_date()
        yesterday = today - timedelta(days=1)
        day = today - timedelta(days=0)
        now = local_now()

        if now.hour == 0:
            day = yesterday
        
        # 记录不同时段的数据 for ks
        print local_now(), 'updating ks report...'
        ks_report.create_ks_report(day)
        print local_now(), 'calc complete.'
