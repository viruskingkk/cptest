# -*- coding: utf-8 -*-
import json
import logging

from django.views.decorators.http import require_GET, require_POST
from django.conf import settings

from common.third.image import get_token, delete_data_by_key
from common.utils.api import token_required
from common.utils.decorator import response_wrapper

_LOGGER = logging.getLogger(__name__)


@require_GET
@response_wrapper
@token_required
def get_qiniu_token(req):
    use = req.GET.get('use')
    if use:
        bucket_name = use
        host = settings.QINIU_BUCKETS[use]
    else:
        bucket_name = settings.ADMIN_BUCKET_NAME
        host = settings.QINIU_DOMAIN
    token = get_token(bucket_name, expires=3600)
    return {"token": token, "host": host,
            "bucket": bucket_name}


@require_POST
@response_wrapper
@token_required
def delete_data(req):
    query_dct = json.loads(req.body)
    bucket_name = settings.USER_BUCKET_NAME
    keys = query_dct.get('keys', [])
    assert isinstance(keys, list)
    if keys:
        delete_data_by_key(keys, bucket_name)

    return {}
