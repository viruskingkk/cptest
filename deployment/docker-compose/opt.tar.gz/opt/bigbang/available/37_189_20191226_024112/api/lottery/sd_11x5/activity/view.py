# -*- coding: utf-8 -*-
from django.views.decorators.http import require_GET

from api.lottery.sd_11x5.activity import handler
from common.utils.decorator import response_wrapper
from common.utils.api import check_params


MAX_COUNT = 200


@require_GET
@response_wrapper
def get_trend(req):
    query_dct = req.GET.dict()
    check_params(query_dct, [], {'last_n': 20},
                 param_type_dct={
        'index': int,
        'last_n': int
    },
        param_validfunc_dct={
            'index': lambda x: 0 <= x <= 4,
            'last_n': lambda x: 0 <= x <= 500
    })

    return handler.get_trend(query_dct['last_n'], query_dct.get('index'))
