# coding=utf-8

from django.conf.urls import patterns, url

import api.transaction.view
from api.lottery import view as common
from api.lottery.view import order_pay
from api.platform.view import get_game_history
from api.transaction import view as transaction_view
from api.recharge import view as recharge_view


urlpatterns = patterns(
    '',
    # 所有的购买都用此接口
    url(r'^order/pay/?$', order_pay),
    # unit升级接口
    url(r'^record/order/?$', common.get_order_history_v2),
    url(r'^record/track/?$', common.get_track_history_v2),
    url(r'^record/game/?$', get_game_history),
    url(r'^record/pay/?$', common.get_pay_history),
    url(r'^record/pay/(?P<pay_id>[\d]+)/?$',  recharge_view.get_pay_info),
    url(r'^record/order/(?P<activity_type>[\w]+)/?$', common.get_order_history_by_type_v2),
    url(r'^order/(?P<activity_type>[\w]+)/(?P<order_id>[\d]+)/?$', common.get_order_detail_by_type_v2),
    url(r'^track/(?P<activity_type>[\w]+)/(?P<track_id>[\d]+)/?$', common.get_track_detail_by_type_v2),
    url(r'^preset/lottery/?$', api.preset.view.get_avaliable_lottery_v2),
    url(r'^record/withdraw/?$', api.transaction.view.get_withdraw_record_v2),
    url(r'^pay_submit_unionagency/?$', transaction_view.pay_submit_unionagency),
    url(r'^pay_submit_mf/?$', transaction_view.pay_submit_mf),
)
