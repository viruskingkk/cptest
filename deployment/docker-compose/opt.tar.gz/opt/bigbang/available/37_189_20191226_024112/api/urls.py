# coding=utf-8
# TODO: 将高频彩种再次抽象为时时彩/pk10/11选5等若干种

from django.conf.urls import patterns, url

import api.coupon.view
import api.feedback.view
import api.scrolling.view
import api.show.view
import api.third.justpay
import api.third.qiniu
import api.third.unionagency
import api.platform.view
from api.customer_service import view as cs_view
from api.recharge_appeal import view as appeal_view
from api.account.view import login, logout, AuthCodeView, ImageCodeView, reset_passwd, \
    reset_trade_pwd, check_trade_pwd, UserSettingsView, UserView, get_banks, bind_financial_account, login_by_username, \
    login_by_phone, get_sms_auth_code
from api.campaign import view as campaign
from api.lottery import view as common
from api.lottery.bj_pk10.activity import view as bj_pk10_activity
from api.lottery.bj_pk10.order import view as bj_pk10_order
from api.lottery.cq_lf.activity import view as cq_lf_activity
from api.lottery.cq_lf.order import view as cq_lf_order
from api.lottery.cq_ssc.activity import view as cq_ssc_activity
from api.lottery.cq_ssc.order import view as cq_ssc_order
from api.lottery.fc3d.activity import view as fc3d_activity
from api.lottery.fc3d.order import view as fc3d_order
from api.lottery.ff_11x5.activity import view as ff_11x5_activity
from api.lottery.ff_11x5.order import view as ff_11x5_order
from api.lottery.ff_ks.activity import view as ff_ks_activity
from api.lottery.ff_ks.order import view as ff_ks_order
from api.lottery.ff_pk10.activity import view as ff_pk10_activity
from api.lottery.ff_pk10.order import view as ff_pk10_order
from api.lottery.ff_ssc.activity import view as ff_ssc_activity
from api.lottery.ff_ssc.order import view as ff_ssc_order
from api.lottery.gd_11x5.activity import view as gd_11x5_activity
from api.lottery.gd_11x5.order import view as gd_11x5_order
from api.lottery.gx_ks.activity import view as gx_ks_activity
from api.lottery.gx_ks.order import view as gx_ks_order
from api.lottery.js_ks.activity import view as js_ks_activity
from api.lottery.js_ks.order import view as js_ks_order
from api.lottery.jx_11x5.activity import view as jx_11x5_activity
from api.lottery.jx_11x5.order import view as jx_11x5_order
from api.lottery.sd_11x5.activity import view as sd_11x5_activity
from api.lottery.sd_11x5.order import view as sd_11x5_order
from api.lottery.sh_11x5.activity import view as sh_11x5_activity
from api.lottery.sh_11x5.order import view as sh_11x5_order
from api.lottery.tc_pls.activity import view as tc_pls_activity
from api.lottery.tc_pls.order import view as tc_pls_order
from api.lottery.tj_ssc.activity import view as tj_ssc_activity
from api.lottery.tj_ssc.order import view as tj_ssc_order
from api.lottery.xj_ssc.activity import view as xj_ssc_activity
from api.lottery.xj_ssc.order import view as xj_ssc_order
from api.notification import view as notify
from api.notification.view import get_in_app_announcement
from api.preset import view as preset
from api.recharge import view as recharge
from api.transaction import view as transaction
from api.transaction.view import pay_submit_unionagency_v2
from api.update import update
from api.withdraw import view as withdraw_view

urlpatterns = patterns(
    '',
    # 用户相关
    url(r'^auth/login/?$', login),
    url(r'^auth/login_by_username/?$', login_by_username),
    url(r'^auth/login_by_phone/?$', login_by_phone),
    url(r'^auth/logout/?$', logout),
    url(r'^auth/sms/?$', AuthCodeView.as_view()),
    url(r'^auth/image/?$', ImageCodeView.as_view()),
    url(r'^user/password/reset/?$', reset_passwd),
    url(r'^user/trade_pwd/reset/?$', reset_trade_pwd),
    url(r'^user/trade_pwd/check/?$', check_trade_pwd),
    url(r'^user/settings/?$', UserSettingsView.as_view()),
    url(r'^user/?$', UserView.as_view()),
    url(r'^user/financial_account/bind?$', bind_financial_account),
    url(r'^get_sms_auth_code', get_sms_auth_code),

    # 银行卡相关
    url(r'^bank/?$', get_banks),

    # 交易相关
    url(r'^record/transaction/?$', transaction.get_transactions),

    # 支付相关
    url(r'^pay/types/?$', transaction.get_pay_types),
    url(r'^pay/ready/?$', transaction.pay_ready),
    url(r'^pay/(?P<pay_id>[^/]+)/submit/?$',
        transaction.pay_submit),
    url(r'^pay/last_unionagent_unsuccess_record/?$', transaction.last_unionagent_unsuccess_record),
    url(r'^pay/get_type_min_amount/?$', transaction.get_type_min_amount),
    url(r'^pay/unionagency/get_pay_information/?$', transaction.get_pay_information),

    url(r'^get_unionagent_page/(?P<pay_id>[^/]+)/?$', transaction.get_unionagent_page),
    url(r'^fill_unionagent_charge/?$', transaction.fill_unionagent_charge),
    url(r'^pay_submit_unionagency_v2/(?P<pay_id>[^/]+)/?$', pay_submit_unionagency_v2),
    url(r'^pay/(?P<pay_id>[^/]+)/status/?$', transaction.get_pay_status),
    url(r'^pay/chase_unionagency/?$', transaction.chase_unionagency),
    url(r'^pay/mf/get_last_waiting_pay/?$', transaction.get_last_waiting_pay),
    url(r'^pay/mf/orders/?$', transaction.create_mf_order),   # 秒付下单
    url(r'^pay/mf/orders/trans/?$', transaction.trans_mf_order),    # 秒付上分
    url(r'^pay/mf/orders/chase/?$', transaction.chase_mf_order),    # 秒付追分
    url(r'^pay/mf/get_recharge_info/?$', transaction.mf_get_recharge_info),  # 秒付查询用户信息


    # 提现相关
    url(r'^withdraw/last_info/?$', transaction.get_last_info),
    url(r'^withdraw/get_limit/?$', transaction.get_limit),
    url(r'^withdraw/submit/?$', transaction.submit_withdraw),
    url(r'^record/withdraw/?$', transaction.get_withdraw_record),
    # recharge 
    url(r'^recharge/records/?$', recharge.get_apply_records),
    url(r'^recharge/wechat/?$', recharge.RechargeWechatView.as_view()),
    url(r'^recharge/apply/?$', recharge.RechargeView.as_view()),
    url(r'^recharge/apply/finish_apply/?$', recharge.SingleRechargeView.as_view()),
    # 支付部门替用户追加订单
    url(r'^recharge/chase_order/?$', recharge.chase_order),

    url(r'^rechargees/?$', recharge.get_rechargees),
    url(r'^recharge/submit/?$', recharge.submit),
    url(r'^recharge/callback/?$', recharge.callback),

    # 通知相关
    url(r'^notifications/category/?$', notify.get_notifications_category),
    url(r'^notifications/(?P<notify_type>\d+)/list/?$', notify.get_notifications),
    url(r'^notifications/(?P<notify_id>\d+)/?$', notify.get_notification_detail),
    url(r'^notifications/read/mark/?$', notify.read),
    url(r'^notifications/unread/count/?$', notify.unread_count),
    url(r'^get_in_app_announcement/?$', get_in_app_announcement),
    # 活动相关
    url(r'^activity/summary/?$', common.summarize),
    url(r'^campaign/(?P<campaign_name>[^/]+)/status/?$', campaign.view_campaign_status),
    url(r'^campaign/winner_ranking_award/pool/?$', campaign.view_winner_pool),
    url(r'^campaign/(?P<campaign_name>[^/]+)/award/?$', campaign.award),
    url(r'^campaign/(?P<campaign_name>[^/]+)/scrolling/?$', campaign.scrolling),
    # fortune wheel
    url(r'^fortunewheel/timeline/?$', campaign.get_wheel_timeline),
    url(r'^fortunewheel/awardlist/?$', campaign.get_wheel_award_list),
    url(r'^fortunewheel/status/?$', campaign.get_wheel_status),
    url(r'^fortunewheel/play/?$', campaign.play_wheel),
    # 通用API
    url(r'^activity/(?P<activity_type>[\w]+)/latest/?$',
        common.get_latest_term_by_type),
    url(r'^activity/(?P<activity_type>[\w]+)/history/?$',
        common.get_activity_history_by_type),
    url(r'^activity/(?P<activity_type>[\w]+)/stats/(?P<bet_type>[\w]+)/?$', common.get_activity_stats_by_bet_type),
    # 重庆幸運農場
    url(r'^activity/cq_lf/trend/?$', cq_lf_activity.get_trend),
    # 重庆时时彩
    url(r'^activity/cq_ssc/trend/?$', cq_ssc_activity.get_trend),
    # 天津时时彩
    url(r'^activity/tj_ssc/trend/?$', tj_ssc_activity.get_trend),
    # 新疆时时彩
    url(r'^activity/xj_ssc/trend/?$', xj_ssc_activity.get_trend),
    # 江苏快三
    url(r'^activity/js_ks/trend/?$', js_ks_activity.get_trend),
    # 广西快三
    url(r'^activity/gx_ks/trend/?$', gx_ks_activity.get_trend),
    # 山东11选5
    url(r'^activity/sd_11x5/trend/?$', sd_11x5_activity.get_trend),
    # 上海11选5
    url(r'^activity/sh_11x5/trend/?$', sh_11x5_activity.get_trend),
    # 江西11选5
    url(r'^activity/jx_11x5/trend/?$', jx_11x5_activity.get_trend),
    # 广东11选5
    url(r'^activity/gd_11x5/trend/?$', gd_11x5_activity.get_trend),
    # 北京PK10
    url(r'^activity/bj_pk10/trend/?$', bj_pk10_activity.get_trend),
    # 体彩排列3
    url(r'^activity/tc_pls/trend/?$', tc_pls_activity.get_trend),
    # 福彩3D
    url(r'^activity/fc3d/trend/?$', fc3d_activity.get_trend),
    # 分分时时彩
    url(r'^activity/ff_ssc/trend/?$', ff_ssc_activity.get_trend),
    # 分分11选5
    url(r'^activity/ff_11x5/trend/?$', ff_11x5_activity.get_trend),
    # 分分快3
    url(r'^activity/ff_ks/trend/?$', ff_ks_activity.get_trend),
    url(r'^activity/ff_pk10/trend/?$', ff_pk10_activity.get_trend),
    # 重庆时时彩
    url(r'^order/cq_ssc/cancel/?$', cq_ssc_order.cancel_order),
    # 重庆幸運農場
    url(r'^order/cq_lf/cancel/?$', cq_lf_order.cancel_order),
    # 天津时时彩
    url(r'^order/tj_ssc/cancel/?$', tj_ssc_order.cancel_order),
    # 新疆时时彩
    url(r'^order/xj_ssc/cancel/?$', xj_ssc_order.cancel_order),
    # 江苏快三
    url(r'^order/js_ks/cancel/?$', js_ks_order.cancel_order),
    # 广西快三
    url(r'^order/gx_ks/cancel/?$', gx_ks_order.cancel_order),
    # 山东11选5
    url(r'^order/sd_11x5/cancel/?$', sd_11x5_order.cancel_order),
    # 上海11选5
    url(r'^order/sh_11x5/cancel/?$', sh_11x5_order.cancel_order),
    # 广东11选5
    url(r'^order/gd_11x5/cancel/?$', gd_11x5_order.cancel_order),
    # 江西11选5
    url(r'^order/jx_11x5/cancel/?$', jx_11x5_order.cancel_order),
    # # 北京PK10
    # url(r'^order/bj_pk10/pay/?$', bj_pk10_order.create_order),
    url(r'^order/bj_pk10/cancel/?$', bj_pk10_order.cancel_order),
    # 体彩排列3
    url(r'^order/tc_pls/cancel/?$', tc_pls_order.cancel_order),
    # 福彩3D
    url(r'^order/fc3d/cancel/?$', fc3d_order.cancel_order),
    # 分分时时彩
    url(r'^order/ff_ssc/cancel/?$', ff_ssc_order.cancel_order),
    # 分分11选5
    url(r'^order/ff_11x5/cancel/?$', ff_11x5_order.cancel_order),
    # 分分快3
    url(r'^order/ff_ks/cancel/?$', ff_ks_order.cancel_order),
    # 北京pk10
    url(r'^order/ff_pk10/cancel/?$', ff_pk10_order.cancel_order),
    # 订单阅读状态
    url(r'^order/stats/?$', common.get_user_read_stats),
    # 预置数据
    url(r'^preset/lottery/?$', api.preset.view.get_avaliable_lottery_v2),
    url(r'^preset/?$', preset.get_preset),
    url(r'^preset/(?P<name>[^/]+)/?$', preset.get_part),

    # 第三方服务
    url(r'^third/qiniu/token/?$', api.third.qiniu.get_qiniu_token),
    url(r'^third/qiniu/remove/?$', api.third.qiniu.delete_data),
    url(r'^third/unionagency/submit/?$', api.third.unionagency.submit_from_third),
    url(r'^third/justpay/notify/?$', api.third.justpay.charge_callback),
    url(r'^third/unionagency/notify/?$', api.third.unionagency.charge_callback),
    url(r'^third/unionagency/withdraw/notify/?$', api.third.unionagency.withdraw_charge_callback),
    # 新union agency提现回调
    url(r'^withdraw/notify/unionagency/?$', withdraw_view.unionagency_withdraw_notify),
    # update
    url(r'^update/?$', update.get_update),
    url(r'^update_info/?$', update.get_update_info),
    # url(r'^download/?$',update.download_url),
    url(r'^patch/?$', update.get_patch),

    # coupon
    url(r'^my/fresh/coupons/?$', api.coupon.view.get_fresh_coupons),
    url(r'^my/coupons/?$', api.coupon.view.get_my_coupons),
    url(r'^coupons/recommend/?$', api.coupon.view.get_recommend_coupon),
    url(r'^coupons/avaliable/?$', api.coupon.view.get_available_coupons),
    # scrolling
    url(r'^scrolling/?$', api.scrolling.view.fetch_scrolling),

    # feedback
    url(r'^feedback/?$', api.feedback.view.feedback),

    # 晒单相关
    url(r'^user/show/(?P<show_id>\d+)/?$', api.show.view.SingleShow.as_view()),  # 个人新建，获取，更新晒单详情
    url(r'^my/shows/?$', api.show.view.get_my_shows),  # 获取我的晒单列表
    url(r'^show/timeline/?$', api.show.view.get_timeline),  # 所有用户的晒单分享

    # 第三方游戏平台
    url(r'^login/(?P<platform>[\w]+)/?$', api.platform.view.platform_login),
    url(r'^logout/(?P<platform>[\w]+)/?$', api.platform.view.platform_logout),

    # 获取客服系统h5页面url，主动调用
    url(r'cs/h5/?$', cs_view.get_h5_url),
    url(r'cs/h5/recharge_appeal/?$', cs_view.get_recharge_appeal_url),
    url(r'cs/h5/recharge_appeal_record/?$', cs_view.get_recharge_appeal_record_url),
    # 客服系统回调接口，被动调用
    url(r'cs/order/?$', cs_view.get_order),
    url(r'cs/appeal_order/?$', cs_view.get_appeal_order),
    url(r'cs/submit_appeal_order/?$', cs_view.submit_appeal_order),

    # justpay申诉回调
    url(r'appeal/notify/justpay/?$', appeal_view.appeal_notify_justpay),
    url(r'appeal/notify/miaofu/?$', appeal_view.appeal_notify_miaofu),
)
