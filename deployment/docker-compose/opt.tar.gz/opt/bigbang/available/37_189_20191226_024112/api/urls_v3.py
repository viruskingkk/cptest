# coding=utf-8

from django.conf.urls import patterns, url

import api.preset.view
import api.treasure.view

urlpatterns = patterns(
    '',
    url(r'^preset/lottery/?$', api.preset.view.get_available_lottery_v3),
    # 获得用户宝箱资料
    url(r'my/treasure/?', api.treasure.view.get_my_treasure_v3),
    # 开宝箱
    url(r'treasure/open/?$', api.treasure.view.open_treasure_v3),
)
