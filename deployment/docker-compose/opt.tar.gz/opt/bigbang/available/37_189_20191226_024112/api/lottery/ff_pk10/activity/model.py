# -*- coding: utf-8 -*-

from api import BaseModel


class TrendData(BaseModel):
    structure = {
        'term': str,   # 期数
        'number': str,  # 开奖结果
        'idx_0': list,  # 0位遗漏数据，表示0~9的遗漏数，如果命中当期，使用0
        'idx_1': list,  # 1位
        'idx_2': list,  # 2位
        'idx_3': list,  # 3位
        'idx_4': list,  # 4位
        'idx_5': list,  # 5位
        'idx_6': list,  # 6位
        'idx_7': list,  # 7位
        'idx_8': list,  # 8位
        'idx_9': list,
    }


class StatData(BaseModel):
    structure = {
        'max_seq': list,    # 最大连出
        'max_miss': list,   # 最大遗漏
        'avg_miss': list,   # 平均遗漏
        'hit': list         # 命中次数
    }

