#! -*- coding:utf-8 -*-

import logging
from django.core.management.base import BaseCommand

from common.cache import redis_cache
from common.timer.cyclical_handler import NEXT_TERM
from common.preset.db.lottery import set_preset_lottery_off

_LOGGER = logging.getLogger('worker')


class Command(BaseCommand):

    def handle(self, activity_type, status, **kwargs):
        activity_type = int(activity_type)
        status = int(status)
        if activity_type not in NEXT_TERM:
            print 'activity {} invalid!'.format(activity_type)
            return
        redis_cache.set_activity_switch(activity_type, status)
        set_preset_lottery_off(activity_type, status)
        print activity_type, status
