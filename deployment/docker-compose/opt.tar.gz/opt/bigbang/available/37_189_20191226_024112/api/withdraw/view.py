# -*- coding: utf-8 -*-
import logging
import json
from django.http import HttpResponse
from django.views.decorators.http import require_POST
from common.utils import exceptions as err
from common.utils.decorator import response_wrapper
from common.withdraw.group_withdraw_new import check_group_new_withdraw_notify_sign
from common.withdraw.just_withdraw import check_just_withdraw_notify
from common.withdraw import unionagency_withdraw

_LOGGER = logging.getLogger('alipay')


@require_POST
@response_wrapper
def group_new_withdraw_notify(req):
    try:
        check_group_new_withdraw_notify_sign(req)
        return HttpResponse('success', status=200)
    except err.ParamError as e:
        _LOGGER.warn('group_new_withdraw notify param error, %s', e)
        return HttpResponse('success', status=200)
    except Exception as e:
        _LOGGER.exception('group_new_withdraw notify exception.(%s)' % e)
        return HttpResponse('failed', status=200)


@require_POST
@response_wrapper
def just_withdraw_notify(req):
    try:
        check_just_withdraw_notify(req)
        return HttpResponse('success', status=200)
    except err.ParamError as e:
        _LOGGER.warn('just_withdraw notify param error, %s', e)
        return HttpResponse('success', status=200)
    except Exception as e:
        _LOGGER.exception('just_withdraw notify exception.(%s)' % e)
        return HttpResponse('failed', status=200)


@require_POST
def withdraw_charge_callback(request):
    try:
        unionagency_withdraw.check_notify_sign(request)
        return HttpResponse('success', status=200)
    except Exception as e:
        _LOGGER.exception('unionagency notify exception.(%s)' % e)
        return HttpResponse('failure', status=500)


@require_POST
@response_wrapper
def unionagency_withdraw_notify(req):
    param_dct = json.loads(req.body)
    unionagency_withdraw.new_check_sign(param_dct, req.get_full_path())
    unionagency_withdraw.withdraw_notify(param_dct)
