# -*- coding: utf-8 -*-

from api import BaseModel


class Banner(BaseModel):
    structure = {
        'id': long,
        'image': str,
        'cmd': str,
        'title': basestring
    }

class Shortcut(BaseModel):
    structure = {
        'id': long,
        'image': str,
        'cmd': str,
        'title': basestring
    }


class Loading(BaseModel):
    structure = {
        'id': long,
        'image': str,
        'stay': int,
        'cmd': str,
        'skip': bool,
        'start_ts': long,
        'end_ts': long
    }


class Recommend(BaseModel):
    structure = {
        'id': long,
        'activity_type': int,
        'title': basestring,
        'number': str,
        'cmd': str,
    }


class Reward(BaseModel):
    structure = {
        'id': long,
        'activity_type': int,
        'bet_type': int,
        'rate': int,
        'amount': int
    }


class FloatIcon(BaseModel):
    structure = {
        'id': long,
        'start_ts': int,
        'end_ts': int,
        'icon': basestring,
        'cmd': basestring
    }


PART_MODEL = {
    'banner': Banner,
    'loading': Loading,
    'recommend': Recommend,
    'float_icon': FloatIcon,
    'shotcut': Shortcut
}


class Lottery(BaseModel):
    structure = {
        'id': int,
        'image': basestring,
        'cmd': basestring,
        'title': basestring,
        'play_id': int,
        'tag': basestring
    }
