# -*- coding: utf-8 -*-

from api import BaseModel


class CouponLite(BaseModel):
    structure = {
        'id': int,
        'temp_id': int,
        'title': basestring,
        'desc': basestring,
        'price': int,
        'type': int,
        'status': int,
        'remark': basestring,
        'will_be_used': int,
        'source': basestring,
        'condition_price': int,
        'cmd': basestring,
        'bet_type': int,
        'activity_type': int,
        'start_date': basestring,
        'end_date': basestring,
        'expire_ts': int,
    }
