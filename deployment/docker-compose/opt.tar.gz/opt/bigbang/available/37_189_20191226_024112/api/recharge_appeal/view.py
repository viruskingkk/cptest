# -*- coding: utf-8 -*-
import json
import logging

from django.views.decorators.http import require_POST
from django.http.response import HttpResponse

from common.utils.decorator import response_wrapper
from common.utils.api import check_params

from api.recharge_appeal import handler as appeal_handler
from common.third.pay import justpay, mf_pay

_LOGGER = logging.getLogger('bigbang')


@require_POST
@response_wrapper
def appeal_notify_justpay(request):
    """
    充值申诉回调接口，justpay
    """
    params = json.loads(request.body)
    check_params(params, ['order_inquiry_no', 'status_id', 'status', 'reason_failure_id', 'reason_failure',
                          'updated_at', 'sign'])

    _LOGGER.info('justpay appeal_notify, params:%s' % json.dumps(params, ensure_ascii=False))

    justpay.check_sign_for_appeal_notify(params)
    success = appeal_handler.appeal_notify(params)

    if success:
        return HttpResponse('success', status=200)
    else:
        return HttpResponse('failed', status=500)


@require_POST
@response_wrapper
def appeal_notify_miaofu(request):
    """
    充值申诉回调接口，miaofu
    """
    params = json.loads(request.body)
    check_params(params, ['order_inquiry_no', 'status_id', 'status', 'updated_at', 'sign'])

    _LOGGER.info('miaofu pay appeal_notify, params:%s' % json.dumps(params, ensure_ascii=False))
    mf_pay.check_sign_for_appeal_notify(params)

    if 'reason_desc' in params:
        params.update(reason_failure=params.pop('reason_desc'))

    appeal_handler.appeal_notify(params)

    return {}
