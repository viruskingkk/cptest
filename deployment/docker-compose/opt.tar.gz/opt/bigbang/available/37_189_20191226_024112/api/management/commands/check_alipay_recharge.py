#! -*- coding:utf-8 -*-
import os
import json
import logging
from datetime import datetime

from common.recharge import handler

from django.core.management.base import BaseCommand


_LOGGER = logging.getLogger('alipay')


class Command(BaseCommand):

    def handle(self, **kwargs):
        handler.check_alipay_apply()
