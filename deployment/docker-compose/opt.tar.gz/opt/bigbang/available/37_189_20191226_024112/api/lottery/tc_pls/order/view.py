# -*- coding: utf-8 -*-
import logging
import json

from django.views.decorators.http import require_POST

from api.lottery.tc_pls.order import handler
from common.lottery.cyclical.tc_pls.db import order as db
from common.utils.api import token_required, check_params
from common.utils.decorator import response_wrapper
from common.utils.limit import frequency_limit

_TRACKER = logging.getLogger('tracker')


@require_POST
@response_wrapper
@token_required
def cancel_order(req):
    params = json.loads(req.body)
    check_params(params, ['order_ids'])
    db.cancel_orders(req.user_id, params['order_ids'])
    return {}
