# -*- coding: utf-8 -*-

from api import BaseModel
from common.lottery import LOTTERY_TYPE


class Activity(BaseModel):
    structure = {
        'id': int,
        'type': int,        # 活动类型，江苏快三固定为3
        'term': str,        # 期号
        'status': int,      # 1: 进行中， 2：等待爬取结果，3：已开奖
        'left_ts': int,     # 距离结束还剩多少秒
        'number': str,      # 如果已开奖，这里是开奖结果
        'announce_at': str  # 开奖时间
    }
    required_fields = ['id', 'term', 'status']
    default_fields = {
        'type': LOTTERY_TYPE.GX_KS,
        'left_ts': 0,
        'number': None
    }


class TrendData(BaseModel):
    structure = {
        'term': str,   # 期数
        'number': str,  # 开奖结果
        'idx_0': list,  # 百位遗漏数据，表示0~9的遗漏数，如果命中当期，使用0
        'idx_1': list,  # 十位
        'idx_2': list,  # 个位
    }


class StatData(BaseModel):
    structure = {
        'max_seq': list,    # 最大连出
        'max_miss': list,   # 最大遗漏
        'avg_miss': list,   # 平均遗漏
        'hit': list         # 命中次数
    }
