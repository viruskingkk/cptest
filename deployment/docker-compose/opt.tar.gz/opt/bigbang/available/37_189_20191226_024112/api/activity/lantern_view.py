# -*- coding: utf-8 -*-

from django.views.decorators.http import require_GET

from common.activity.lantern_db import get_task_status, get_winner_user_name_by_date, get_end_timing, \
    get_join_count, get_winners_list
from common.activity.utils import get_activity_time
from common.preset.model.preset import BANNER_TYPE
from common.utils.decorator import response_wrapper
from common.utils.tz import today_str


@require_GET
@response_wrapper
def get_home_info(request):
    user_id = request.user_id
    start_time, end_time = get_activity_time(BANNER_TYPE.get_key('lantern'))
    end_timing = get_end_timing()
    join_count = get_join_count(today_str())
    status = get_task_status(user_id, start_time, end_time, end_timing)
    return dict(status=status, start_time=start_time, end_time=end_time,  end_timing=end_timing,
                join_count=join_count)


@require_GET
@response_wrapper
def get_winners(request):
    return get_winners_list()
