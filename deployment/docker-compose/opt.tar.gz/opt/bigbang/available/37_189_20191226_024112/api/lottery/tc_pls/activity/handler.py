# -*- coding: utf-8 -*-

from common.lottery.cyclical.tc_pls.db import activity as db
from common.lottery import LOTTERY_TYPE
from common.lottery.cyclical.abstract.activity import calc_trend_stats


#Enable the below line of code only if you want the application to wait untill the debugger has attached to it
def get_trend(last_n, idx):
    datas = [[]] * 3
    infos = []
    items = db.get_activity_stats(last_n)
    if idx is not None:
        idx_list = ['idx_%s' % idx]
    else:
        idx_list = ['idx_%s' % x for x in range(3)]

    for item in items:
        info = {
            'term': item.term,
            'number': item.number,
        }
        for i, idx in enumerate(idx_list):
            idx_data = getattr(item, idx).split(',')
            idx_data = [int(x) for x in idx_data]
            datas[i].append(idx_data)
            info[idx] = idx_data
        infos.append(info)
    stats = {}
    for i, idx in enumerate(idx_list):
        stats[idx] = calc_trend_stats(LOTTERY_TYPE.TC_PLS, datas[i])

    return {
        'list': infos,
        'stats': stats
    }
