# -*- coding: utf-8 -*-
import json
import logging
import math
from datetime import datetime

import requests
from requests.exceptions import RequestException
from django.conf import settings

from common.account.db.account import get_user_name
from common.pay.model import PAY_TYPE
from common.recharge_appeal import db as appeal_db
from common.recharge_appeal.model import APPEAL_STATUS, JP_RECHARGE_NOTIFY_STATUS_MAP
from common.utils import exceptions as err
from common.utils import tz, currency
from common.notification import handler as notification_handler
from common.third.pay import mf_pay, justpay
from common.utils.decorator import retry


_LOGGER = logging.getLogger('bigbang')


def submit_appeal_order_to_miaofu(params):
    sign = mf_pay.generate_sign(params)
    params.update(sign=sign)
    url = '{}recharge/inquiry/create/'.format(settings.MF_API_HOST)
    _submit_appeal_order(url, params, 'miaofu')


def submit_appeal_order_to_justpay(params):
    sign = justpay.generate_sign(params, settings.JUSTPAY_API_KEY)
    params.update(sign=sign)
    url = '{}/pay/api/inquiry/create/'.format(settings.JUSTPAY_HOST)
    _submit_appeal_order(url, params, 'justpay')


@retry(RequestException)
def _submit_appeal_order(url, params, third_type):
    assert third_type in ('justpay', 'miaofu')
    appeal_id = params.get('order_inquiry_no')
    response = requests.post(url, data=params)
    _LOGGER.info('submit appeal order to %s, url:%s, params:%s, response:%s', third_type, response.url,
                 json.dumps(params, ensure_ascii=False),
                 response.text)

    res_dict = json.loads(response.text)
    if res_dict['status'] == 0:
        update_data = {'status': APPEAL_STATUS.SUBMIT,
                       'send_at': datetime.utcnow(),
                       'notified_status': res_dict.get('data', {}).get('status_id', 0)}
        appeal_db.update_appeal(appeal_id, update_data, True)
    else:
        # 记录失败原因
        update_data = {'extend': json.dumps(res_dict, ensure_ascii=False), 'notified_status': res_dict['status']}
        appeal_db.update_appeal(appeal_id, update_data, True)


def submit_appeal_order_to_third(appeal_id):
    appeal = appeal_db.get_appeal_order(appeal_id)
    if not appeal:
        raise err.ParamError(u'appeal id: %s 申诉订单不存在' % appeal_id)

    if appeal['status'] != APPEAL_STATUS.WAIT:
        _LOGGER.info('appeal id :%s not in wait status' % appeal_id)
        return

    user_id = appeal['user_id']
    user_name = appeal['name']

    data = {
        'order_inquiry_no': appeal_id,
        'out_trade_no': appeal['pay_id'],
        'user_id': user_id,
        'username': user_name,
        'receipt': appeal['receipt'],
    }

    if appeal['pay_type'] in [PAY_TYPE.UNIONAGENCY_V2_ALI, PAY_TYPE.UNIONAGENCY_V2_BANKCARD,
                              PAY_TYPE.UNIONAGENCY_V2_WX]:
        data.update({
            'mch_id': settings.MF_MERCHANT_ID,
            'amount': currency.convert_yuan_to_fen(appeal['pay_amount']),
            'user_pay_time': tz.utc_to_local_str(appeal['pay_at']),
            'user_remark': appeal['desc'],
            'notify_url': settings.APPEAL_NOTIFY_URL + 'miaofu/',
        })
        submit_appeal_order_to_miaofu(data)
    else:
        # 如果不是秒付，使用justpay
        data.update({
            'mch_id': settings.JUSTPAY_MCH_ID,
            'amount': appeal['pay_amount'],
            'transaction_time': tz.utc_to_local_str(appeal['pay_at']),
            'desc': appeal['desc'],
            'notify_url': settings.APPEAL_NOTIFY_URL + 'justpay/',
        })
        submit_appeal_order_to_justpay(data)


def appeal_notify(params):
    appeal = appeal_db.get_appeal_order(params.get('order_inquiry_no'))
    if not appeal:
        raise err.ParamError('appeal notify，订单 %s 不存在' % params.get('order_inquiry_no'))

    justpay_status = params['status_id']
    assert justpay_status in JP_RECHARGE_NOTIFY_STATUS_MAP
    update_params = {
        'status': JP_RECHARGE_NOTIFY_STATUS_MAP.get(justpay_status),
        'notified_status': justpay_status,
        'deal_at': tz.local_str_to_utc_str(params['updated_at']),
        'desc': params['desc'],
    }

    if params.get('reason_failure'):
        extend = json.loads(appeal['extend']) if appeal['extend'] else {}
        extend.update(reason_failure=params.get('reason_failure'))
        update_params.update({
            'extend': json.dumps(extend, ensure_ascii=False),
        })

        if params.get('reason_failure_id'):
            update_params.update({'failed_id': params.get('reason_failure_id')})

    appeal = appeal_db.update_appeal(appeal['id'], update_params)
    send_appeal_notification(appeal)
    if appeal['notified_status'] == params['status_id']:
        return True
    else:
        return False


def send_appeal_notification(appeal):
    extend = json.loads(appeal.get('extend') or '{}')
    try:
        if appeal['status'] == APPEAL_STATUS.SUCCESS:
            notification_handler.notify_recharge_appeal_success(appeal['user_id'], appeal['pay_id'],
                                                                appeal['pay_amount'])
        else:
            notification_handler.notify_recharge_appeal_fail(appeal['user_id'], appeal['pay_id'], appeal['pay_amount'],
                                                             extend.get('reason_failure'))
    except Exception as e:
        _LOGGER.info('recharge appeal send notification failed: %s' % e)
