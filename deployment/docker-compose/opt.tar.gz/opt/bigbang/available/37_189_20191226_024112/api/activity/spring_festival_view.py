# -*- coding: utf-8 -*-
import json
import logging

from django.views.decorators.http import require_GET, require_POST

from common.activity.spring_festival_db import get_tasks_with_status, receive_prize, get_act_status
from common.activity.utils import get_activity_time
from common.preset.model.preset import BANNER_TYPE
from common.utils import exceptions as err
from common.utils.api import token_required
from common.utils.decorator import response_wrapper
from common.utils.tz import now_ts
from common.notification.handler import notify_spring_part

_LOGGER = logging.getLogger(__name__)


@require_GET
@response_wrapper
def get_home_info(request):
    user_id = request.user_id
    start_time, end_time = get_activity_time(BANNER_TYPE.get_key('spring_festival'))
    status = get_act_status(user_id, start_time, end_time)
    tasks = get_tasks_with_status(user_id, status)

    return dict(status=status, tasks=tasks,
                time=dict(start_time=start_time, end_time=end_time))


@require_POST
@token_required
@response_wrapper
def open_prize(request):
    user_id = request.user_id
    try:
        params = json.loads(request.body)
        task_id = int(params['task_id'])
    except:
        raise err.ParamError(u'参数错误')
    start_time, end_time = get_activity_time(
        BANNER_TYPE.get_key('spring_festival'))
    if now_ts() > end_time:
        raise err.ParamError(u'活动已经结束')
    if now_ts() < start_time:
        raise err.ParamError(u'活动还未开始')
    prize = receive_prize(user_id, task_id)
    try:
        notify_spring_part(user_id, prize)
    except Exception as e:
        _LOGGER.error(e)
    return dict(prize=prize)