#! -*- coding:utf-8 -*-
import os
import json
import time
import logging
from datetime import datetime, timedelta

from common import orm
from common.game.model import *

from common.utils import tz

from django.core.management.base import BaseCommand


_LOGGER = logging.getLogger('worker')


def clear_lottery_part():
    MAX = 100000
    os = 0
    count = 0
    while os < MAX:
        items = LotteryPart.query.order_by(LotteryPart.id).limit(10000)
        for item in items:
            if item.updated_at > datetime.now() - timedelta(days=10):
                break
            item.delete(auto_commit=False)
            count += 1
        print 'to commit transaction offset {}'.format(os)
        orm.session.commit()
        print 'commited, rm %s lottery_part' % count
        os += 10000
        time.sleep(3)


def clear_bull_part():
    MAX = 100000
    os = 0
    count = 0
    while os < MAX:
        items = BullPart.query.order_by(BullPart.id).limit(10000)
        for item in items:
            if item.updated_at > datetime.now() - timedelta(days=10):
                break
            item.delete(auto_commit=False)
            count += 1
        print 'to commit transaction offset {}'.format(os)
        orm.session.commit()
        print 'commited, rm %s bull_part' % count
        os += 10000
        time.sleep(3)


class Command(BaseCommand):

    def handle(self, **kwargs):
        clear_lottery_part()
        clear_bull_part()
