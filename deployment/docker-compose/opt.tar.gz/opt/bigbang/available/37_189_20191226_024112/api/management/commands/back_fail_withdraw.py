#! -*- coding:utf-8 -*-
import fcntl
import logging

from django.core.management.base import BaseCommand

from common.transaction.model import Withdraw, WITHDRAW_STATUS
from common.transaction.db import withdraw_back

_LOGGER = logging.getLogger('worker')


class Command(BaseCommand):

    @staticmethod
    def back_fail_withdraw():
        items = Withdraw.query.filter(Withdraw.status == WITHDRAW_STATUS.FAIL).all()
        for item in items:
            withdraw_id = item.id
            print('ready to back withdraw {}'.format(withdraw_id))
            withdraw_back(0, withdraw_id, u'系统自动返款')
            print('withdraw {} back done'.format(withdraw_id))

    def handle(self, **kwargs):
        try:
            f = open('/tmp/flock_back_fail_withdraw', 'w')
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.back_fail_withdraw()
            fcntl.flock(f, fcntl.LOCK_UN)
        except Exception as e:
            _LOGGER.exception('trans error')
            raise e
