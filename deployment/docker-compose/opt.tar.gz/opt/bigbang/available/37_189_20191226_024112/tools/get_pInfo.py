# -*- coding: utf-8 -*-
import os
import sys

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.account.model.account import (Account, AccountToken)


def get_user_info_by_user_id(user_id):
    user = Account.query.filter(Account.id == user_id).first()
    info = AccountToken.query.filter(AccountToken.user_id == user_id).order_by(
        AccountToken.created_at.desc()).first()
    print 'P_INFO=%s|%s|%s|%s|%s|||%s|||' % info.token, info.user_id, user.phone, user.avatar, user.balance, user.user_name


def get_user_info_by_user_name(user_name):
    user = Account.query.filter(Account.user_name == user_name).first()
    info = AccountToken.query.filter(AccountToken.user_id == user.id).order_by(
        AccountToken.created_at.desc()).first()
    print info.token
    print info.user_id
    print user.phone
    phone = user.phone or ""
    print user.avatar
    avatar = user.avatar or ""
    print user.balance
    print user.user_name
    print 'P_INFO=%s|%s|%s|%s|%s|||%s|||' % (info.token, info.user_id, phone, avatar, user.balance, user.user_name)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print "input user info"
        exit(0)
    my_name = sys.argv[1]
    get_user_info_by_user_name(my_name)
