#! -*- coding:utf-8 -*-
"""
彩票退单脚本
"""
import os
import sys
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common import orm
from common.lottery.cyclical.abstract.order import manual_cancel_orders
from common.lottery.cyclical.model import ORDER_MODEL


def query_order_ids(activity_type, start_term, end_term):
    table = ORDER_MODEL.get(activity_type)
    query_order = orm.session.query(table).filter(table.term >= start_term, table.term <= end_term).all()
    order_list = []
    for query in query_order:
        order_list.append(query.id)
    return order_list


def refund_main(activity_type, start_term, end_term):
    order_ids = query_order_ids(activity_type, int(start_term), int(end_term))
    succ_list, fail_list = manual_cancel_orders(activity_type, order_ids)
    return succ_list, fail_list


if __name__ == "__main__":
    activity_type = int(sys.argv[1])
    start_term = sys.argv[2]
    end_term = sys.argv[3]
    print(u"start refund lottery activity_type:{} from term {} to "
          u"{}".format(activity_type, start_term, end_term))
    succ_list, fail_list = refund_main(activity_type, start_term, end_term)
    print(u'refund lottery_order successfully order_id:{}'.format(succ_list))
    print(u'refund lottery_order failed order_id:{}'.format(fail_list))