# -*- coding: utf-8 -*-
import os
import sys

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.lottery import KEYWORD_TYPE_DCT
from common.lottery.cyclical.abstract.activity import stop_term
from common.utils import tz
from common.lottery.db import get_unstopped_activity

if __name__ == '__main__':
    key = sys.argv[1]
    activity_type = KEYWORD_TYPE_DCT[key]
    query = get_unstopped_activity(activity_type)
    for activity in query:
        print('%s term <%s> not stopped' % (key, activity.term))
        if tz.now_ts() > activity.end_ts:
            print('stopping %s term <%s>' % (key, activity.term))
            stop_term(activity_type, activity.term)
