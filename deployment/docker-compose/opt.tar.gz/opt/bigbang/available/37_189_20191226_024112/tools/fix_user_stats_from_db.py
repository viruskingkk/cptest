# coding=utf-8
"""
2019年6月25号，这天服务器迁移，在解析日志文件track.json的时候，由于track.json包含一些历史遗留数据，以及 track id
两台service id 上设置的一样，导致数据出现问题，此文件为了修复相关的错误

本来想从交易流水表中，修复用户的相关数据，但是发现witch的交易流水表只保存了2019-01-20号以后的数据，因此无法从交易流水表中
修复用户的数据

用户的统计数据包括，
充值／提现数据
购彩数据
电玩城数据
Metis数据
红包数据
各个游戏（H5游戏、METIS游戏、HERA游戏）的数据
"""
import os
import sys
import datetime

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.stats import MG_BIGBANG_COLL
from common import orm
from common.pay.model import Pay, PAY_TYPE
from common.transaction.model import Withdraw
from common.utils.tz import get_utc_date
from common.account.db import account as account_db


def find_error_data_users():
    # 获取当天有统计的所有数据，由于2019-06-25 这天数据出错，所以这天的用户的数据都在可用有问题的名单中
    # start_date = datetime.datetime.strptime('2019-06-25 00:00:00', "%Y-%m-%d %H:%M:%S")
    # end_date = datetime.datetime.strptime('2019-06-26 00:00:00', "%Y-%m-%d %H:%M:%S")
    # items = MG_BIGBANG_COLL.daily_stats.find({'created_at': {'$gte': start_date, '$lt': end_date}}, {'user_id': 1})
    # user_ids = [item.get('user_id') for item in items]
    # print(user_ids)
    # return user_ids

    # 修复指定用户
    #return [91341, 2004481]

    date_range = [get_utc_date('2019-12-01'), get_utc_date('2019-12-30')]
    filters = [{
        '$match': {'updated_at': {
            '$gte': date_range[0],
            '$lt': date_range[1]
        }, '$or': [
            {'pay': {'$exists': 1}},
            {'kfc': {'$exists': 1}},
            {'lottery': {'$exists': 1}},
            {'bull': {'$exists': 1}},
            {'fruit': {'$exists': 1}},
            {'metis': {'$exists': 1}},
            {'recharge': {'$exists': 1}},
            {'withdraw': {'$exists': 1}}
        ]}},
        {'$group': {'_id': '$user_id'}},
    ]
    items = MG_BIGBANG_COLL.daily_stats.aggregate(filters)
    return [item['_id'] for item in items]


def fix_user_stats_from_db():
    user_ids = find_error_data_users()
    print(user_ids)
    fix_recharge_for_users(user_ids)
    fix_withdraw_data_for_users(user_ids)
    fix_total_gain(user_ids)


def clear_recharge_for_users(user_ids):
    MG_BIGBANG_COLL.user_stats.update({'_id': {'$in': user_ids}},
                                      {'$unset': {'recharge': 1}},
                                      multi=True)


def update_recharge_data(user_id, type_name, type_price, count):
    print(user_id, type_name, type_price, count)
    inc_data = {
        "recharge.total": float(type_price),
        "recharge.{}".format(type_name): float(type_price),
        "recharge.count": float(count)}

    MG_BIGBANG_COLL.user_stats.update({"_id": user_id}, {"$inc": inc_data})


def fix_recharge_for_users(user_ids):
    # 修复充值相关
    # 1.清除充值数据
    clear_recharge_for_users(user_ids)

    # 2.恢复用户各种充值信息
    union_recharges = orm.session.query(Pay.user_id, orm.func.sum(Pay.price), orm.func.count(Pay.price)) \
        .filter(Pay.user_id.in_(user_ids)) \
        .filter(Pay.status == 2, Pay.pay_type.in_([PAY_TYPE.UNIONAGENCY, PAY_TYPE.UNIONAGENCY_V2_ALI,
                                                   PAY_TYPE.UNIONAGENCY_V2_BANKCARD, PAY_TYPE.UNIONAGENCY_V2_WX])) \
        .group_by(Pay.user_id).all()

    for recharge in union_recharges:
        user_id, price, count = recharge[0], recharge[1], recharge[2]
        update_recharge_data(user_id, 'unionagency', price, count)

    wechat_recharges = orm.session.query(Pay.user_id, orm.func.sum(Pay.price), orm.func.count(Pay.price)) \
        .filter(Pay.user_id.in_(user_ids)) \
        .filter(Pay.status == 2, Pay.pay_type == PAY_TYPE.SELF_WECHAT) \
        .group_by(Pay.user_id).all()
    for recharge in wechat_recharges:
        user_id, price, count = recharge[0], recharge[1], recharge[2]
        update_recharge_data(user_id, 'agent_wechat', price, count)

    just_recharges = orm.session.query(Pay.user_id, orm.func.sum(Pay.price), orm.func.count(Pay.price)) \
        .filter(Pay.user_id.in_(user_ids)) \
        .filter(Pay.status == 2, ~Pay.pay_type.in_([PAY_TYPE.UNIONAGENCY, PAY_TYPE.UNIONAGENCY_V2_ALI,
                                                    PAY_TYPE.UNIONAGENCY_V2_BANKCARD, PAY_TYPE.UNIONAGENCY_V2_WX,
                                                    PAY_TYPE.SELF_WECHAT])) \
        .group_by(Pay.user_id).all()
    for recharge in just_recharges:
        user_id, price, count = recharge[0], recharge[1], recharge[2]
        update_recharge_data(user_id, 'justpay', price, count)


def fix_withdraw_data_for_users(user_ids):
    MG_BIGBANG_COLL.user_stats.update({'_id': {'$in': user_ids}},
                                      {'$unset': {'withdraw': 1}},
                                      multi=True)

    withdraws_wait = orm.session.query(Withdraw.user_id, orm.func.sum(Withdraw.price), orm.func.count(Withdraw.price)) \
        .filter(Withdraw.user_id.in_(user_ids)) \
        .filter((Withdraw.status != 32) &
                (Withdraw.status != 2) &
                (Withdraw.status != 16)) \
        .group_by(Withdraw.user_id).all()

    for withdraw_wait in withdraws_wait:
        user_id, price, count = withdraw_wait[0], withdraw_wait[1], withdraw_wait[2]
        print price

        MG_BIGBANG_COLL.user_stats.update({"_id": user_id}, {"$set": {"withdraw.total_wait": float(price),
                                                                      "withdraw.count_wait": float(count)}})

    withdraws_forbidden = orm.session.query(Withdraw.user_id, orm.func.sum(Withdraw.price),
                                            orm.func.count(Withdraw.price)) \
        .filter(Withdraw.user_id.in_(user_ids)) \
        .filter((Withdraw.status == 16)) \
        .group_by(Withdraw.user_id).all()
    for withdraw_forbidden in withdraws_forbidden:
        user_id, price, count = withdraw_forbidden[0], withdraw_forbidden[1], withdraw_forbidden[2]
        print price

        MG_BIGBANG_COLL.user_stats.update({"_id": user_id}, {"$set": {"withdraw.total_forbidden": float(price),
                                                                      "withdraw.count_forbidden": float(count)}})

    withdraws_done = orm.session.query(Withdraw.user_id, orm.func.sum(Withdraw.price), orm.func.count(Withdraw.price)) \
        .filter(Withdraw.user_id.in_(user_ids)) \
        .filter((Withdraw.status == 2)) \
        .group_by(Withdraw.user_id).all()
    for withdraw_done in withdraws_done:
        user_id, price, count = withdraw_done[0], withdraw_done[1], withdraw_done[2]
        print price

        MG_BIGBANG_COLL.user_stats.update({"_id": user_id}, {"$set": {"withdraw.total": float(price),
                                                                      "withdraw.count": float(count)}})


def fix_total_gain(user_ids):
    for user_id in user_ids:
        user_stats_info = MG_BIGBANG_COLL.user_stats.find_one({"_id": user_id})
        total_recharge = user_stats_info.get('recharge', {}).get('total', 0)
        withdraw_info = user_stats_info.get('withdraw', {})
        total_withdraw = withdraw_info.get('total_wait', 0) + withdraw_info.get('total_forbidden', 0) + \
            withdraw_info.get('total', 0)
        total_gain = total_withdraw - total_recharge
        print('total recharge:%s; total_withdraw:%s;total_gain:%s' % (total_recharge, total_withdraw, total_gain))

        MG_BIGBANG_COLL.user_stats.update({"_id": user_id}, {"$set": {"total_gain": float(total_gain)}})


def fix_new_user_daily_recharge():
    begin_date = get_utc_date('2019-12-11')
    end_data = get_utc_date('2019-12-12')

    recharge_users = orm.session.query(Pay.user_id).filter(Pay.status == 2).\
        filter(Pay.updated_at >= begin_date).filter(Pay.updated_at < end_data).group_by(Pay.user_id).all()
    user_ids = set()
    for user in recharge_users:
        user_ids.add(user[0])
    print(user_ids)

    accounts = account_db.get_account_in_ids(user_ids)
    new_recharge_users = {account.id for account in accounts if begin_date <= account.created_at < end_data}
    print(new_recharge_users)

    # 2.恢复用户各种充值信息
    union_recharges = orm.session.query(Pay.user_id, orm.func.sum(Pay.price), orm.func.count(Pay.price)) \
        .filter(Pay.user_id.in_(new_recharge_users)) \
        .filter(Pay.updated_at >= begin_date).filter(Pay.updated_at < end_data) \
        .filter(Pay.status == 2, Pay.pay_type.in_([PAY_TYPE.UNIONAGENCY, PAY_TYPE.UNIONAGENCY_V2_ALI,
                                                   PAY_TYPE.UNIONAGENCY_V2_BANKCARD, PAY_TYPE.UNIONAGENCY_V2_WX])) \
        .group_by(Pay.user_id).all()

    new_user_union_recharge_amount = 0
    new_union_users = set()
    for recharge in union_recharges:
        user_id, price, count = recharge[0], recharge[1], recharge[2]
        new_union_users.add(user_id)
        new_user_union_recharge_amount += price
    print('new_user_union_recharge_amount: %s' % new_user_union_recharge_amount)

    just_recharges = orm.session.query(Pay.user_id, orm.func.sum(Pay.price), orm.func.count(Pay.price)) \
        .filter(Pay.user_id.in_(new_recharge_users)) \
        .filter(Pay.updated_at >= begin_date).filter(Pay.updated_at < end_data) \
        .filter(Pay.status == 2, ~Pay.pay_type.in_([PAY_TYPE.UNIONAGENCY, PAY_TYPE.UNIONAGENCY_V2_ALI,
                                                    PAY_TYPE.UNIONAGENCY_V2_BANKCARD, PAY_TYPE.UNIONAGENCY_V2_WX,
                                                    PAY_TYPE.SELF_WECHAT])) \
        .group_by(Pay.user_id).all()

    new_user_jp_recharge_amount = 0
    new_jp_users = set()
    for recharge in just_recharges:
        user_id, price, count = recharge[0], recharge[1], recharge[2]
        new_jp_users.add(user_id)
        new_user_jp_recharge_amount += price
    print('new_user_jp_recharge_amount: %s' % new_user_jp_recharge_amount)

    # 修复当天报表
    daily_update_data = {
        'new_device': len(new_recharge_users),
        'active_register_user': len(new_recharge_users),
        'new_recharge_price': float(new_user_union_recharge_amount + new_user_jp_recharge_amount),
        'new_recharge_user': len(new_recharge_users),
        'new_agent_recharge_price': float(new_user_union_recharge_amount),
        'new_agent_recharge_user': len(new_union_users),
    }

    print(daily_update_data)

    error_data = MG_BIGBANG_COLL.daily_report.find_one({"_id": '2019-12-11'})
    for item in daily_update_data:
        print('%s: %s' % (item, error_data.get(item)))
    MG_BIGBANG_COLL.daily_report.update({"_id": '2019-12-11'}, {"$set": daily_update_data})

if __name__ == '__main__':
    fix_user_stats_from_db()
    #fix_new_user_daily_recharge()
