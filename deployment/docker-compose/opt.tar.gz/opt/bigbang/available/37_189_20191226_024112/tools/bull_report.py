#! -*- coding:utf-8 -*-
from datetime import timedelta
from common.stats import MG_BIGBANG_COLL as mg
from common.utils.tz import utc_to_local


def create_bull_report(day, new_user_id_list):
    """
    百人牛牛报表，分房间统计
    """
    end = day + timedelta(days=1)
    result = {'user_id_list': {}}
    # 总投注次数，开奖金额，投注金额
    group = {'_id': None, 'count': {'$sum': 1}}
    for k in ('bet_count', 'origin_award', 'award_amount', 'bet_amount',
              'extra_choushui', 'win_idx_1', 'win_idx_2', 'win_idx_4', 'win_idx_8'):
        group[k] = {'$sum': '$%s' % k}
    t = mg.bull.aggregate([
        {'$match': {'announced_at': {'$gte': day, '$lt': end}}},
        {'$group': group}
    ])
    t = t.next() if t.alive else {}
    t.pop('_id', None)
    result.update(t)
    # 系统坐庄
    t = mg.bull.aggregate([
        {'$match': {
            'announced_at': {'$gte': day, '$lt': end},
            'banker': {'$eq': 'sys'}
        }},
        {'$group': {
            '_id': None,
            'bet_amount': {'$sum': '$bet_amount'},
            'award_amount': {'$sum': '$award_amount'},
        }}
    ])
    t = t.next() if t.alive else {}
    result['sys_bet_amount'] = t.get('bet_amount', 0)
    result['sys_award_amount'] = t.get('award_amount', 0)

    # 非系统坐庄
    t = mg.bull.aggregate([
        {'$match': {
            'announced_at': {'$gte': day, '$lt': end},
            'banker': {'$ne': 'sys'}
        }},
        {'$group': {
            '_id': None,
            'bet_amount': {'$sum': '$bet_amount'},
            'award_amount': {'$sum': '$award_amount'},
        }}
    ])
    t = t.next() if t.alive else {}
    result['player_bet_amount'] = t.get('bet_amount', 0)
    result['player_award_amount'] = t.get('award_amount', 0)

    # 总参与人数
    updated_filter = {'$gte': day, '$lt': end}
    result['real_user_count'] = mg.daily_stats.count({
        'updated_at': updated_filter, 'bull': {'$exists': True}}) or 0

    # 总中奖次数，元宝数
    t = mg.daily_stats.aggregate([
        {'$match': {'updated_at': updated_filter, 'bull': {'$exists': True}}},
        {'$group': {'_id': None, 'count': {'$sum': '$bull.win_count'},
                    'win_amount': {'$sum': '$bull.win_amount'},
                    'user_id_list': {'$push': '$user_id'}
                    }
         }
    ])
    t = t.next() if t.alive else {}
    result['win_count'] = t.get('count', 0)
    result['win_amount'] = t.get('win_amount', 0)
    result['user_id_list']['bet_user_id'] = t.get('user_id_list', [])

    # 盈利用户数、元宝数
    t = mg.daily_stats.aggregate([
        {'$match': {'$and': [
            {'updated_at': updated_filter},
            {'bull.gain_amount': {'$gt': 0}}
        ]}},
        {'$group': {'_id': None, 'count': {'$sum': 1},
                    'amount': {'$sum': '$bull.gain_amount'},
                    'user_id_list': {'$push': '$user_id'}}}
    ])
    t = t.next() if t.alive else {}
    result['gain_count'] = t.get('count', 0)
    result['gain_amount'] = t.get('amount', 0)
    result['user_id_list']['gain_user_id'] = t.get('user_id_list', [])

    # 亏损用户数， 亏损金额
    t = mg.daily_stats.aggregate([
        {'$match': {'$and': [
            {'updated_at': updated_filter},
            {'bull.gain_amount': {'$lt': 0}}
        ]}},
        {'$group': {'_id': None, 'count': {'$sum': 1},
                    'amount': {'$sum': '$bull.gain_amount'},
                    'user_id_list': {'$push': '$user_id'}}}
    ])
    t = t.next() if t.alive else {}
    result['lose_count'] = t.get('count', 0)
    result['lose_amount'] = t.get('amount', 0)
    result['user_id_list']['lose_user_id'] = t.get('user_id_list', [])

    # 投注分布
    group = {'_id': None}
    for k in (2, 4, 8):
        for suffix in 'count', 'amount':
            field = 'index_%s_%s' % (k, suffix)
            group[field] = {'$sum': '$bull.%s' % field}
    for k in (0.1, 1, 10, 100, 500, 1000):
        field = 'amount_%s' % k
        if k == 0.1:
            field_key = 'amount_0'
        else:
            field_key = field
        group[field_key] = {'$sum': '$bull.%s' % field}
    t = mg.daily_stats.aggregate([
        {'$match': {'updated_at': updated_filter}},
        {'$group': group}
    ])
    t = t.next() if t.alive else {}
    t.pop('_id', None)
    result.update(t)

    # 抽水率
    if result.get('bet_amount'):
        result['profit_rate'] = (
            result['bet_amount'] - result['award_amount']) / float(
            result['bet_amount'])

    # 非系统坐庄次数
    t = mg.bull.aggregate([
        {'$match': {
            'announced_at': updated_filter,
            'banker': {'$ne': 'sys'}
        }},
        {'$group': {'_id': None, 'banker_count': {'$sum': 1}}}
    ])
    t = t.next() if t.alive else {}
    result['banker_count'] = t.get('banker_count', 0)

    t = mg.daily_stats.aggregate([
        {'$match': {'updated_at': updated_filter, 'bull.banker_count': {'$exists':1}}},
        {'$group': {'_id': None, 'banker_person': {'$sum': 1},
                    'user_id_list': {'$push': '$user_id'}}}
    ])
    t = t.next() if t.alive else {}
    result['banker_person'] = t.get('banker_person', 0)
    result['user_id_list']['banker_user_id'] = t.get('user_id_list', [])

    # 新用戶統計
    result['new_user'] = {
        'user_id_list': {}
    }
    # 新用戶非系统坐庄
    t = mg.bull.aggregate([
        {'$match': {
            'announced_at': {'$gte': day, '$lt': end},
            'banker': {'$in': new_user_id_list}
        }},
        {'$group': {
            '_id': None,
            'bet_amount': {'$sum': '$bet_amount'},
            'award_amount': {'$sum': '$award_amount'},
            'banker_count': {'$sum': 1}
        }}
    ])
    t = t.next() if t.alive else {}
    result['new_user']['player_bet_amount'] = t.get('bet_amount', 0)
    result['new_user']['player_award_amount'] = t.get('award_amount', 0)
    result['new_user']['banker_count'] = t.get('banker_count', 0)
    t = mg.daily_stats.aggregate([
        {'$match': {'updated_at': updated_filter,
                    'bull.banker_count': {'$exists': 1},
                    'user_id': {'$in': new_user_id_list},
                    }
         },
        {'$group': {'_id': None, 'banker_person': {'$sum': 1},
                    'user_id_list': {'$push': '$user_id'}}}
    ])
    t = t.next() if t.alive else {}
    result['new_user']['banker_person'] = t.get('banker_person', 0)
    result['new_user']['user_id_list']['banker_user_id'] = t.get('user_id_list', [])
    # 新用户盈利用户数、元宝数
    t = mg.daily_stats.aggregate([
        {'$match': {'$and': [
            {'updated_at': updated_filter},
            {'bull.gain_amount': {'$gt': 0}},
            {'user_id': {'$in': new_user_id_list}}
        ]}},
        {'$group': {'_id': None, 'count': {'$sum': 1},
                    'bet': {'$sum': '$bull.bet_amount'},
                    'win': {'$sum': {'$add': ["$bull.gain_amount", "$bull.bet_amount"]}},
                    'amount': {'$sum': '$bull.gain_amount'},
                    'user_id_list': {'$push': '$user_id'}}}
    ])
    t = t.next() if t.alive else {}
    gain_total_bet = t.get('bet', 0)
    gain_total_win = t.get('win', 0)
    result['new_user']['gain_count'] = t.get('count', 0)
    result['new_user']['gain_amount'] = t.get('amount', 0)
    result['new_user']['user_id_list']['gain_user_id'] = t.get('user_id_list', [])
    # 新用户亏损用户数， 亏损金额
    t = mg.daily_stats.aggregate([
        {'$match': {'$and': [
            {'updated_at': updated_filter},
            {'bull.gain_amount': {'$lt': 0}},
            {'user_id': {'$in': new_user_id_list}}
        ]}},
        {'$group': {'_id': None, 'count': {'$sum': 1},
                    'bet': {'$sum': '$bull.bet_amount'},
                    'win': {'$sum': {'$add': ["$bull.gain_amount", "$bull.bet_amount"]}},
                    'amount': {'$sum': '$bull.gain_amount'},
                    'user_id_list': {'$push': '$user_id'}}}
    ])
    t = t.next() if t.alive else {}
    lose_total_bet = t.get('bet', 0)
    lose_total_win = t.get('win', 0)
    result['new_user']['lose_count'] = t.get('count', 0)
    result['new_user']['lose_amount'] = t.get('amount', 0)
    result['new_user']['user_id_list']['lose_user_id'] = t.get('user_id_list', [])

    result['new_user']['bet_amount'] = gain_total_bet + lose_total_bet
    if gain_total_bet + lose_total_bet:
        result['new_user']['profit_rate'] = (((gain_total_bet + lose_total_bet) - (gain_total_win + lose_total_win)) /
                                             (gain_total_bet + lose_total_bet))
    else:
        result['new_user']['profit_rate'] = 0
    result['new_user']['real_user_count'] = result['new_user']['gain_count'] + result['new_user']['lose_count']
    result['new_user']['user_id_list']['bet_user_id'] = list(set(result['new_user']['user_id_list']['lose_user_id']
                                                                 + result['new_user']['user_id_list']['gain_user_id']))

    mg.bull_report.update_one(
        {'_id': utc_to_local(day).strftime('%Y-%m-%d')},
        {'$set': result}, upsert=True)
