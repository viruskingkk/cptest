# coding=utf-8
"""
手动退出第三方游戏
"""
import os
import sys
import logging

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

import argparse
from common.platform.common import base as base_handler
from common.platform.common.model import PLATFORM_TYPE
from common.platform.metis.handler import handler as metis_handler
from common.platform.ametis.handler import handler as ametis_handler
from common.platform.ares.handler import handler as ares_handler

_LOGGER = logging.getLogger(__name__)

HANDLERS = {
    PLATFORM_TYPE.METIS: metis_handler,
    PLATFORM_TYPE.ARES: ares_handler,
    PLATFORM_TYPE.AMETIS: ametis_handler
}


def logout_third_game(user_id, platform):
    need_logout, platform_str = base_handler.need_logout(user_id, platform)
    print('need_logout status:%s' % need_logout)
    if need_logout:
        handler = HANDLERS.get(platform)
    else:
        assert platform in [PLATFORM_TYPE.METIS, PLATFORM_TYPE.ARES, PLATFORM_TYPE.AMETIS]
        handler = HANDLERS.get(platform)
    balance, status = handler.query_balance_and_frozen_status(user_id)
    print(balance, status)
    if not status:
        res = handler.logout(user_id)
        print('logout third_game status is %s' % res)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Process some argument.')
    parser.add_argument('--user_id', dest='user_id')
    parser.add_argument('--platform', dest='platform')
    args = parser.parse_args()
    print(args)

    logout_third_game(int(args.user_id), int(args.platform))
    # 执行命令示例：python tools/logout_third_game.py --user_id=1955957 --platform=1