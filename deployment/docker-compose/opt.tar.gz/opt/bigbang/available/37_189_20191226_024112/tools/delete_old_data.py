# -*- coding: utf-8 -*-
"""
删除指定的表的一些历史数据，由于使用批量脚本需要根据 create_at 去判断，对于某些表，我们可以指定ID大小，去删除
"""
import os
import sys

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")
from common.utils.decorator import sql_wrapper
from common.transaction.model import Transaction


tables_info = {
    'transaction': {'table': Transaction, 'max_id': 5435027177372173728}
}


@sql_wrapper
def delete_table(table_name):
    if table_name in tables_info:
        table = tables_info[table_name]['table']
        max_id = tables_info[table_name]['max_id']

        item = table.query.filter(table.id == max_id).first()
        print item.as_dict()
        query = table.query.order_by(table.id).limit(5).all()
        for item in query:
            print(item.as_dict())


if __name__ == '__main__':
    delete_table('transaction')


