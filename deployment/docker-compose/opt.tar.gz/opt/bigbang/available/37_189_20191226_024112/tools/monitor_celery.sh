#!/bin/bash

now=$(date -u '+%Y-%m-%d %H:%M:%S')
if [ $(redis-cli llen async_common) -ge 20 ]; then
    echo $now' restart celery for queue size '$(redis-cli llen async_common) >> /var/log/bigbang/monitor.log
    sudo supervisorctl restart bigbang:celery
else
    echo 'celery healthy'
fi
