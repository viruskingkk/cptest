# coding=utf-8
import sys
import os

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.update import handler

from common.update import MG as mg

# witch测试包下载地址：http://czsqzs.com/witch_test

VERSION_NAME = '2.5.1'
VERSION_CODE = 35
VERSION_DESC = u'1. 修复了客服系统的异常问题。'

PKG_INFO = [
    ['com.wanhao.caipiao.lottery', 'http://czsqzs.com/witch_wh'],  # 万豪彩票
    ['com.wanhao.caipiao.assistant', 'http://czsqzs.com/witch_whzs'],  # 万豪彩票助手
    ['com.wanhao.lucky.lottery', 'http://czsqzs.com/witch_fc'],  # 万豪福彩
    ['com.wanhao.lucky.assistant', 'http://czsqzs.com/witch_fczs'],  # 万豪福彩助手
    ['com.allwin.caipiao.lottery', 'http://czsqzs.com/witch_qm'],    # 全民赢彩票
    ['com.allwin.lucky.lotteryzs', 'http://czsqzs.com/witch_qmzs'],    # 全民赢彩票助手
    ['com.allwin.lucky.lottery', 'http://czsqzs.com/witch_qmfc'],    # 全民赢福彩
    ['com.ssczx.wanhaocp.lottery', 'http://czsqzs.com/witch_ssc'],    # 时时彩
    ['com.xyssc.wanhao.lottery', 'http://czsqzs.com/witch_xy28'],    # 幸运28
    ['com.bjscssc.wanhao.lottery', 'http://czsqzs.com/witch_bjsc'],    # 北京赛车时时彩
    ['com.yongliqm.caipiao.lottery', 'http://czsqzs.com/wh_yl'],    # 永利彩票
    ['com.jincaiwh.caipiao.lottery', 'http://czsqzs.com/wh_jc'],    # 金彩彩票
    ['com.zhongyuyule.wanhao.lottery', 'http://czsqzs.com/witch_zyyl'],    # 众愉娱乐
    ['com.xingzuo.quanming.lottery', 'http://czsqzs.com/witch_xtd'],    # 星天斗
]


def update():
    # 先删除之前的配置，find_one
    mg.update_info.remove()

    for pkg_info in PKG_INFO:
        handler.add_item(pkg_info[0], VERSION_CODE, VERSION_NAME,
                         pkg_info[1],
                         VERSION_DESC,
                         [], [])


if __name__ == "__main__":
    update()
