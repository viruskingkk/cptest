# coding=utf-8
"""
读取解析track.json
"""
import json
import os
import sys
import time
import datetime

import arrow
from pymongo import MongoClient

# for test
# MG = MongoClient('127.0.0.1:27017').bigbang
# TRACK_FILE_NAME = os.path.join(os.path.dirname(__file__), 'test.json')


MG = MongoClient('103.230.243.167:27017').bigbang


def run():
    items = MG.daily_stats.find()
    for item in items:
        uid = item.get('user_id')
        us = MG.user_stats.find_one({'_id': uid})
        register_date = us.get('created_at')
        register_date = arrow.get(register_date).to('+08:00').format('YYYY-MM-DD')
        print 11111, register_date, arrow.now('+08:00').format('YYYY-MM-DD')
        if register_date == arrow.now('+08:00').format('YYYY-MM-DD'):
            x = MG.daily_stats.update({'_id': item['_id']}, {'$set':{'is_fresh': 1}})
