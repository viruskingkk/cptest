# coding=utf-8
"""
2019年6月25号，这天服务器迁移，在解析日志文件track.json的时候，由于track.json包含一些历史遗留数据，以及 track id
两台service id 上设置的一样，导致数据出现问题，此文件为了修复相关的错误，修复每日充值分段报表
"""
import os
import sys
import datetime
import argparse

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.stats import MG_BIGBANG_COLL
from common import orm
from common.pay.model import Pay, PAY_TYPE


def fix_daily_recharge_from_db(start_date):
    # start_hour = datetime.datetime(2019, 6, 25) - datetime.timedelta(hours=8)
    start_hour = start_date - datetime.timedelta(hours=8)
    end_day = start_hour + datetime.timedelta(hours=24)

    count = 0

    recharge_price = 0
    while start_hour < end_day:
        end_hour = start_hour + datetime.timedelta(hours=1)
        pay_list = orm.session.query(Pay.user_id, orm.func.sum(Pay.price), orm.func.count(Pay.price)) \
            .filter(Pay.updated_at >= start_hour, Pay.updated_at < end_hour) \
            .filter(Pay.status == 2) \
            .group_by(Pay.user_id).all()

        total = 0
        user_count = 0
        for item in pay_list:
            print(item)
            total += item[1]
            user_count = user_count + 1
        total = float(total)

        _id = '{}-{}'.format(start_date.strftime('%Y-%m-%d'), count)
        # item = MG_BIGBANG_COLL.daily_charge_report.find_one({'_id': _id})
        recharge_price = recharge_price + total

        v = {'recharge_price': recharge_price,
             'index': count,
             'recharge_user': user_count,
             'delta_price': total,
             'time_start': (start_hour + datetime.timedelta(hours=8)).strftime('%Y-%m-%d %H:%M'),
             'time_end': (start_hour + datetime.timedelta(hours=9)).strftime('%Y-%m-%d %H:%M'),
             'day': start_date.strftime('%Y-%m-%d')
             }

        print(_id, v)
        MG_BIGBANG_COLL.daily_charge_report.update_one({'_id': _id}, {'$set': v}, upsert=True)
        start_hour = end_hour
        count += 1

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Process some argument.')
    parser.add_argument('--start_day', dest='start_day')
    parser.add_argument('--end_day', dest='end_day')
    args = parser.parse_args()
    print(args)

    start_date = datetime.datetime.strptime(args.start_day, '%Y-%m-%d')

    fix_daily_recharge_from_db(start_date)
