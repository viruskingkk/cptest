from time import sleep

import datetime
import requests

url = "http://www.luckycp365.com/api/v1/auth/login"

payload = "{\n\t\"p\": \"[aid:51052e1b8c680330],[code:CN],[lan:zh],[svc:23],[svn:6.0],[cvn:1.4.0],[cvc:11],[chn:google]\",\n\t\"user_name\": \"arthas\",\n\t\"password\": \"333333\"\n}"
headers = {'content-type': 'application/json'}

filename = '/tmp/status.log'

while True:
    try:
        response = requests.request("POST", url, data=payload, headers=headers)
        with open(filename, 'a') as f:
            f.write(datetime.datetime.now().isoformat() + ' ' + str(response.status_code) + '\n')
    except Exception as e:
        with open(filename, 'a') as f:
            f.write(datetime.datetime.now().isoformat() + ' ' + str(e.message) + '\n')
    sleep(5)
