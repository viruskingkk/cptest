# coding=utf-8
'''
重庆时时彩加奖派奖BUG导致没有派奖, 修复脚本
'''
import json
import sys
import os

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.lottery.cyclical.model import ORDER_MODEL
from common.lottery.cyclical import ORDER_STATUS
from common.utils.decorator import sql_wrapper
from common.utils import currency
from common.transaction.model import TRANSACTION_TYPE, TRANSACTION_STATUS
from common.account.model.account import BALANCE_TYPE
from common import orm
from common.transaction.db import create_transaction
from common.lottery import LOTTERY_TYPE


@sql_wrapper
def main():
    order_table = ORDER_MODEL[activity_type]

    orders = orm.session.query(order_table).filter(order_table.bonus == 0).filter(
        order_table.term > start_term).filter(
        order_table.status.in_([ORDER_STATUS.WINNED, ORDER_STATUS.UNCHECK, ORDER_STATUS.SHOW])).all()
    for each in orders:
        print each.id
        order = order_table.query.with_for_update().filter(order_table.id == each.id).one()

        # hits = check_reward(self.activity_type, self.term, order.bet_type)
        # bonus, withdraw_bonus = WinOrderApplyer.calc_bonus(win_price, hits)

        bonus = order.win_price * 90 / 100
        extend = json.loads(order.extend)
        extend['withdraw_bonus'] = str(bonus)
        order.bonus = bonus
        order.extend = json.dumps(extend, ensure_ascii=False)
        order.save(auto_commit=False)

        # 创建交易，并更新用户余额
        create_transaction({
            'user_id': order.user_id,
            'type': TRANSACTION_TYPE.AWARD,
            'activity_type': activity_type,
            'title': u'{}加奖'.format(LOTTERY_TYPE.get_label(activity_type)),
            'price': currency.convert_yuan_to_hao(order.bonus),
            'balance_type': BALANCE_TYPE.WITHDRAW,
            'order_id': order.id,
            'status': TRANSACTION_STATUS.DONE,
        })

        orm.session.commit()
        logs.append((order.user_i, LOTTERY_TYPE.get_label(activity_type), bonus, order.term, order.id))

    write_log(logs)


def write_log(logs):
    with open('_'.join([str(activity_type), 'report.csv']), 'a') as f:
        f.write(u'用户id,彩种,追加加奖,期数,order_id \n')
        for log in logs:
            f.write('{},{},{},{},{}'.format(*log))
            print(log)


if __name__ == "__main__":
    activity_type = int(sys.argv[1])
    start_term = sys.argv[2]
    logs = []

    print(u"start fix {} {}".format(activity_type, start_term))
    main()
    print(u'end fix')
