#! -*- coding:utf-8 -*-
from datetime import timedelta
from common.stats import MG_BIGBANG_COLL as mg
from common.utils.tz import utc_to_local


def create_fruit_report(day, new_user_id_list):
    # 水果机相关
    end = day + timedelta(days=1)
    # 总投注次数，开奖金额，投注金额
    group = {'_id': None, 'count': {'$sum': 1}}
    for k in ('bet_count', 'origin_award', 'award_amount', 'bet_amount',):
        group[k] = {'$sum': '$%s' % k}
    t = mg.fruit.aggregate([
        {'$match': {'announced_at': {'$gte': day, '$lt': end}}},
        {'$group': group}
    ])
    t = t.next() if t.alive else {}
    t.pop('_id', None)
    result = t
    result['user_id_list'] = {}
    # 总参与人数
    updated_filter = {'$gte': day, '$lt': end}
    result['real_user_count'] = mg.daily_stats.count({
        'updated_at': updated_filter, 'fruit': {'$exists': True}}) or 0
    # 总中奖次数，元宝数
    t = mg.daily_stats.aggregate([
        {'$match': {'updated_at': updated_filter,
                    'fruit': {'$exists': True}}
         },
        {'$group': {'_id': None, 'count': {'$sum': '$fruit.win_count'},
                    'amount': {'$sum': '$fruit.win_amount'},
                    'user_id_list': {'$push': '$user_id'}}}
    ])
    t = t.next() if t.alive else {}
    result['win_count'] = t.get('count', 0)
    result['win_amount'] = t.get('amount', 0)
    result['user_id_list']['bet_user_id'] = t.get('user_id_list', [])
    # 盈利用户数、元宝数
    t = mg.daily_stats.aggregate([
        {'$match': {'$and': [
            {'updated_at': updated_filter},
            {'fruit.gain_amount': {'$gt': 0}}
        ]}},
        {'$group': {'_id': None, 'count': {'$sum': 1},
                    'amount': {'$sum': '$fruit.gain_amount'},
                    'user_id_list': {'$push': '$user_id'}}}
    ])
    t = t.next() if t.alive else {}
    result['gain_count'] = t.get('count', 0)
    result['gain_amount'] = t.get('amount', 0)
    result['user_id_list']['gain_user_id'] = t.get('user_id_list', [])
    # 亏损用户数， 亏损金额
    t = mg.daily_stats.aggregate([
        {'$match': {'$and': [
            {'updated_at': updated_filter},
            {'fruit.gain_amount': {'$lt': 0}}
        ]}},
        {'$group': {'_id': None, 'count': {'$sum': 1},
                    'amount': {'$sum': '$fruit.gain_amount'},
                    'user_id_list': {'$push': '$user_id'}}}
    ])
    t = t.next() if t.alive else {}
    result['lose_count'] = t.get('count', 0)
    result['lose_amount'] = t.get('amount', 0)
    result['user_id_list']['lose_user_id'] = t.get('user_id_list', [])
    # 投注分布
    group = {'_id': None}
    for k in range(6):
        for suffix in 'count', 'amount':
            field = 'index_%s_%s' % (k, suffix)
            group[field] = {'$sum': '$fruit.%s' % field}
    for k in (0.1, 1, 10, 100, 500, 1000):
        field = 'amount_%s' % k
        if k == 0.1:
            field_key = 'amount_0'
        else:
            field_key = field
        group[field_key] = {'$sum': '$fruit.%s' % field}
    t = mg.daily_stats.aggregate([
        {'$match': {'updated_at': updated_filter}},
        {'$group': group}
    ])
    t = t.next() if t.alive else {}
    t.pop('_id', None)
    result.update(t)
    # 开奖分布
    items = mg.fruit.aggregate([
        {'$match': {'announced_at': {'$gte': day, '$lt': end}}},
        {'$group': {'_id': '$win_index', 'count': {'$sum': 1}}}
    ])
    for item in items:
        result['win_index_%s' % int(item['_id'])] = item['count']
    if result.get('bet_amount'):
        result['profit_rate'] = (
            result['bet_amount'] - result['win_amount']) / float(
            result['bet_amount'])

    result['new_user'] = {'user_id_list': {}}
    # 新用户盈利用户数、元宝数
    t = mg.daily_stats.aggregate([
        {'$match': {'$and': [
            {'updated_at': updated_filter},
            {'fruit.gain_amount': {'$gt': 0}},
            {'user_id': {'$in': new_user_id_list}}
        ]}},
        {'$group': {'_id': None, 'count': {'$sum': 1},
                    'amount': {'$sum': '$fruit.gain_amount'},
                    'bet': {'$sum': '$fruit.bet_amount'},
                    'win': {'$sum': {'$add': ["$fruit.gain_amount", "$fruit.bet_amount"]}},
                    'user_id_list': {'$push': '$user_id'}}}
    ])
    t = t.next() if t.alive else {}

    gain_total_bet = t.get('bet', 0)
    gain_total_win = t.get('win', 0)
    result['new_user']['gain_count'] = t.get('count', 0)
    result['new_user']['gain_amount'] = t.get('amount', 0)
    result['new_user']['user_id_list']['gain_user_id'] = t.get('user_id_list', [])
    # 亏损用户数， 亏损金额
    t = mg.daily_stats.aggregate([
        {'$match': {'$and': [
            {'updated_at': updated_filter},
            {'fruit.gain_amount': {'$lt': 0}},
            {'user_id': {'$in': new_user_id_list}}
        ]}},
        {'$group': {'_id': None, 'count': {'$sum': 1},
                    'amount': {'$sum': '$fruit.gain_amount'},
                    'bet': {'$sum': '$fruit.bet_amount'},
                    'win': {'$sum': {'$add': ["$fruit.gain_amount", "$fruit.bet_amount"]}},
                    'user_id_list': {'$push': '$user_id'}}}
    ])
    t = t.next() if t.alive else {}
    result['lose_count'] = t.get('count', 0)
    result['lose_amount'] = t.get('amount', 0)
    lose_total_bet = t.get('bet', 0)
    lose_total_win = t.get('win', 0)
    result['new_user']['lose_count'] = t.get('count', 0)
    result['new_user']['lose_amount'] = t.get('amount', 0)
    result['new_user']['user_id_list']['lose_user_id'] = t.get('user_id_list', [])

    result['new_user']['bet_amount'] = gain_total_bet + lose_total_bet
    if gain_total_bet + lose_total_bet:
        result['new_user']['profit_rate'] = (((gain_total_bet + lose_total_bet) - (gain_total_win + lose_total_win)) /
                                             (gain_total_bet + lose_total_bet))
    else:
        result['new_user']['profit_rate'] = 0
    result['new_user']['real_user_count'] = result['new_user']['gain_count'] + result['new_user']['lose_count']
    result['new_user']['user_id_list']['bet_user_id'] = list(set(result['new_user']['user_id_list']['lose_user_id']
                                                                 + result['new_user']['user_id_list']['gain_user_id']))

    mg.fruit_report.update_one(
        {'_id': utc_to_local(day).strftime('%Y-%m-%d')},
        {'$set': result}, upsert=True)
