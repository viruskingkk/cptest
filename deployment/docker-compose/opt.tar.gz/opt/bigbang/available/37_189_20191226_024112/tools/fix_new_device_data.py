# coding=utf-8
import json
import sys
import os

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

# 按行读取track.json
# 如果是activie或register,读取aid和chn
# setOnInsert
from common.stats import MG_BIGBANG_COLL


def tt():
    f = file('/var/log/bigbang/track.json', 'r')
    for line in f.readlines():
        try:
            data = json.loads(line.strip())
        except:
            print line
            return
        if data['type'] in ('active', 'register'):
            aid = data['aid']
            chn = data['chn']
            if aid and chn:
                print MG_BIGBANG_COLL.device_stats.update({'aid': aid, "chn": None}, {"chn": chn})


if __name__ == "__main__":
    tt()
