# -*- coding: utf-8 -*-
import os
import sys

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.lottery.cyclical.abstract.order import manual_cancel_orders
from common.lottery.cyclical.model import ORDER_MODEL

activity_type = sys.argv[1]
term_list = sys.argv[2]

for term in term_list.split(','):
    activity_type = int(activity_type)
    order_table = ORDER_MODEL[activity_type]
    orders = order_table.query.with_for_update().filter(
        order_table.term == term).filter(
        order_table.status == 1).all()
    order_ids = []
    for order in orders:
        order_ids.append(order.id)
    print order_ids
    succ_list, fail_list = manual_cancel_orders(activity_type, order_ids)
    print succ_list, fail_list
