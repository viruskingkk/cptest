# coding=utf-8
import sys
import os

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.account.model.account import Account
from common.stats import MG as mg

def start(count=10000):
    fp = open('./agents', 'w')
    items = Account.query.filter(Account.avatar is not None).all()
    for item in items:
        fp.write('{}\t{}\n'.format(item.user_name, item.avatar))
    fp.close()


if __name__ == "__main__":
    start(10000)
