# -*- coding: utf-8 -*-
import sys

import requests

proxy_url = sys.argv[1]

destination_urls = [
    'http://caipiao.163.com',
    'http://kaijiang.500.com',
]

for url in destination_urls:
    response = requests.get(url, proxies={'http': proxy_url}, timeout=10)
    if response.status_code != 200:
        print('❌ connecting to %s failed' % url)
        print(response)
    else:
        print('✅ connecting to %s' % url)
