# coding=utf-8
"""
查询交易流水表中相邻两条数据balance相同的订单并找出标记第二条(最新的一条)
起因：同一时间进行多笔加减钱的操作，实际用户余额会错乱(大转盘情况比较严重)
"""
import json
import os
import sys
from datetime import timedelta, datetime
from urllib import quote_plus as urlquote

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common import orm as bigbang_orm
from common.utils import tz
from common.utils.orm import ArmoryOrm
from common.transaction.db import get_sharding_transaction_table
from common.transaction.model import (Transaction0, Transaction1, Transaction2,
                                      Transaction3, Transaction4, Transaction5, Transaction6, Transaction7,
                                      Transaction8, Transaction9, Transaction10, Transaction11, Transaction12,
                                      Transaction13, Transaction14, Transaction15, Transaction16, Transaction17,
                                      Transaction18, Transaction19)

MYSQL_CONF = {
    # 'db': 'mysql://root:123456@127.0.0.1:3306/sync_data_db?charset=utf8', # 测试环境
    'db': 'mysql://bigbang:n0ra@wang@103.230.243.141:3306/sync_data_db?charset=utf8',  # 线上slave库
    'DEBUG': False
}
orm = ArmoryOrm()
orm.init_conf(MYSQL_CONF)


class OperTransaction(orm.Model):
    __tablename__ = "o_transaction"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction0(orm.Model):
    __tablename__ = "o_transaction_0"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction1(orm.Model):
    __tablename__ = "o_transaction_1"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction2(orm.Model):
    __tablename__ = "o_transaction_2"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction3(orm.Model):
    __tablename__ = "o_transaction_3"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction4(orm.Model):
    __tablename__ = "o_transaction_4"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction5(orm.Model):
    __tablename__ = "o_transaction_5"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction6(orm.Model):
    __tablename__ = "o_transaction_6"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction7(orm.Model):
    __tablename__ = "o_transaction_7"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction8(orm.Model):
    __tablename__ = "o_transaction_8"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction9(orm.Model):
    __tablename__ = "o_transaction_9"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction10(orm.Model):
    __tablename__ = "o_transaction_10"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction11(orm.Model):
    __tablename__ = "o_transaction_11"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction12(orm.Model):
    __tablename__ = "o_transaction_12"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息

class OperTransaction13(orm.Model):
    __tablename__ = "o_transaction_13"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction14(orm.Model):
    __tablename__ = "o_transaction_14"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息

class OperTransaction15(orm.Model):
    __tablename__ = "o_transaction_15"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息

class OperTransaction16(orm.Model):
    __tablename__ = "o_transaction_16"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息

class OperTransaction17(orm.Model):
    __tablename__ = "o_transaction_17"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction18(orm.Model):
    __tablename__ = "o_transaction_18"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class OperTransaction19(orm.Model):
    __tablename__ = "o_transaction_19"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


table_dct = {Transaction0: OperTransaction0, Transaction1: OperTransaction1, Transaction2: OperTransaction2,
             Transaction3: OperTransaction3, Transaction4: OperTransaction4, Transaction5: OperTransaction5,
             Transaction6: OperTransaction6, Transaction7: OperTransaction7, Transaction8: OperTransaction8,
             Transaction9: OperTransaction9, Transaction10: OperTransaction10, Transaction11: OperTransaction11,
             Transaction12: OperTransaction12, Transaction13: OperTransaction13, Transaction14: OperTransaction14,
             Transaction15: OperTransaction15, Transaction16: OperTransaction16, Transaction17: OperTransaction17,
             Transaction18: OperTransaction18, Transaction19: OperTransaction19}

user_ids = [2717058,2679816,2640100,2658011,317189,2663618,925081,2713678,910398,2521988,
            2654185,2290320,2708324,939165,501233,1712179,2707614,1145041,1339569,2708887,
            2579321,1900919,2592739,2714132,1995229,72974,1105451,2715471,1656554,2703514,
            2305471,2548898,2116755,2725454,2736742,1781408,2503776,2117780,1624845,2709751,
            2716915,2008219,808062,2687773,1634370,158321,2645818,2181121,1185686,2458525,
            1905501,2165299,2051583,1483974,1829425,2665358,2662177,2535317,1465963,2683465,
            2357683,2635525,2666793,2561409,2666663,1987613,1004976,449535,2676742,2569061,
            2648247,2280072,2288088,2676896,2604723,2684585,2117301,708982,2722779,2643057,
            1979709,142396,2428901,2072134,536539,2484508,2721567,2657003,2704069,486022,
            2453384,814728,2682999,2729284,970755,2724626,2199266,2621402,2699020,2631162,
            2676719,23656,2677088,2736382,1135969,662340,2415256,2673729,2644422,2677107,
            290951,2310543,2713103,2637565,1000876,2662492,2647940,2671395,2698424,2727715,
            2732284,1747836,1344913,982207,2496591,2146409,4360,2602556,2722081,2677544,
            1189159,2715482,406249,1136043,2374583,2651826,701294,1022749,1772958,2647815,
            2644502,2706769,2385777,1789068,2683669,2574898,2667577,2516300,1797505,757750,
            2534589,2687455,568813,2732897,2487900,2692595,2432566,2637147,2496038,636114,
            1805908,27244,2709340,2013703,1811615,2686196,2229926,2678010,1910922,2720352,
            2484381,718281,2723046,715669,2041481,1461019,1245439,2530098,1553406,2226649,
            2455323,485940,1312958,2730165,2153082,2540199,2616731,2649891,2682255,2662294,
            1615818,1286627,1223201,2678077,2697823,550878,2729629,2679340,1511905,1241174,
            2381896,1891258,2688892,2652204,1905107,63786,2709717,702553,2736186,2678648,
            2500530,958068,2720432,11143,1249856,2625102,781089,1235638,2683929,1668457,
            684837,1026458,2695580,2648469,2563388,396470,2353043,433469,2655751,1278850,
            2653171,2724235,2736949,274504,775374,2230447,2736124,2671025,2672775,2664812,
            1065584,2160758,2736594,2529919,940411,2645854,2619764,2716271,2444588,2656798,
            2149424,2691146,1104831,1100951,1444307,2709886,2702255,67181,2706296,2691605,
            1418026,583955,36246,707493,1199462,2697772,2727480,1251832,2683764,2629189,
            2710748,925394,1028705,100709,1412011,2696218,2458043,2713127,2649087,2697591,
            2598171,1376019,844655,2617461,604462,1770935,2056347,2487762,2503866,184348,
            764289,2663750,2064401,1811387,681996,2727954,2619963,611424,507822,151020,
            2410900,2734821,2109292,2013871,2235356,1300752,2736907,1236976,334369,2681608,
            2632858,2244712,2726783,2230055,2534788,2704188,2486601,978587,531725,2721737,
            115072,2692737,1840306,2143209,465258,1973349,2706094,530311,2734054,850609,
            1463399,1948917,2484843,392920,2681806,2560859,633329,40282,91341,2505461,
            2617444,733862,2702669,841297,2687766,2736094,2670696,2652585,2244825,2721795,
            780359,2693347,2662841,2513738,2706386,1787213,2700015,1286673,2354190,2718697,
            2677064,2704377,1796506,2669708,2735098,2707062,695404,1031870,1624638,2643780,
            2047225,1070779,1328350,131547,1154724,216782,2633378,2180448,1600046,2730431,
            2680400,856023,2667210,990807,1632767,2440367,2697187,2509114,1033752,1768393,
            717697,2066153,1107992,2543725,613828,2631773,2703249,2656938,567558,27722,
            2735739,1824027,468616,2716878,1791602,1284625,1941169,2588037,2082915,1694003,
            1679866,1734344,2707096,2684974,2659854,1141611,184761]


def sync_trans_table():
    for uid in user_ids:
        trans_model = get_sharding_transaction_table(uid)

        def row_data_processor(s_trans):
            # d_trans = table_dct.get(trans_model)() 
            d_trans = OperTransaction()
            d_trans.id = s_trans.id
            d_trans.user_id = s_trans.user_id
            d_trans.type = s_trans.type
            d_trans.activity_type = s_trans.activity_type
            d_trans.pay_id = s_trans.pay_id
            d_trans.status = s_trans.status
            d_trans.title = s_trans.title
            d_trans.price = s_trans.price
            d_trans.balance = s_trans.balance
            d_trans.order_id = s_trans.order_id
            d_trans.extend = s_trans.extend
            d_trans.created_at = s_trans.created_at + timedelta(hours=8)
            d_trans.updated_at = s_trans.updated_at + timedelta(hours=8)
            return d_trans

        batch_template(uid, row_data_processor, trans_model, 'trans table')


def batch_template(user_id, row_data_processor, src_model, verbose):
    start_t = tz.now_ts()
    print 'start sync %s since %s at %s' % (verbose, user_id, start_t)
    batch_count = 0
    g_count = 0
    while True:
        print 'start the batch count: %s' % batch_count
        items = src_model.query.filter(src_model.user_id == user_id,
                                       src_model.created_at > '2019-03-31 16:00:00').order_by(src_model.id.asc())
        offset = batch_count * 2000
        batch_data = items.limit(2000).offset(offset).all()
        print 'get current batch data: %s' % batch_count
        batch_count += 1
        if not len(batch_data):
            break
        bulk = []
        for src_row in batch_data:
            last_item = src_model.query.filter(src_model.id < src_row.id).order_by(src_model.id.desc()).first()
            last_balance = last_item.balance if last_item else 0
            row_balance = src_row.balance or 0
            if last_item and row_balance == last_balance:
                print src_row.balance, last_balance
                g_count += 1
                des_data = row_data_processor(src_row)
                print des_data
                if des_data:
                    bulk.append(des_data)
        orm.session.bulk_save_objects(bulk)
        # orm.session.add_all(bulk)
        orm.session.commit()
    print 'finished sync %s count %s at %s cross %s seconds' % (verbose, g_count, tz.now_ts(), tz.now_ts() - start_t)
    orm.session.close()
    bigbang_orm.session.close()


if __name__ == "__main__":
    sync_trans_table()
