# coding=utf-8
"""
读取解析track.json
"""
import json
import os
import sys
import time
import datetime

import arrow
from pymongo import MongoClient

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from base.settings import MONGO_ADDR

# for test
# MG = MongoClient('127.0.0.1:27017').bigbang
# TRACK_FILE_NAME = os.path.join(os.path.dirname(__file__), 'test.json')

MG = MongoClient('192.168.11.4:27017').bigbang

TRACK_FILE_NAME = 'tools/track.json'
PREVIOUS_TRACK_FILE_NAME_1 = 'tools/track.json.2'
PREVIOUS_TRACK_FILE_NAME_2 = 'tools/track.json.3'


def get_now():
    return arrow.now('+08:00').format('YYYY-MM-DD hh:mm:ss')


def get_file_size():
    max_try = 5
    count = 0
    while count <= max_try:
        try:
            size = os.path.getsize(TRACK_FILE_NAME)
        except OSError as e:
            #print e
            count += 1
            time.sleep(0.5)
            continue
        else:
            return size


def save_user_stats(data):
    user_id = data['user_id']
    insert_data = {}
    insert_data['$set'] = data['set']
    insert_data['$inc'] = data['inc']
    insert_data['$setOnInsert'] = data.get('setOnInsert', {})
    insert_data['$setOnInsert'].update({"created_at": data['updated_at']})
    save_with_retry(MG.user_stats, user_id, insert_data)


def save_activity_stats(data):
    updated_at = data['updated_at']
    date_str = arrow.get(updated_at).to('+08:00').format('YYYY-MM-DD')
    activity_type = data['activity_type']
    key = '%s-%s' % (activity_type, date_str)
    insert_data = {}
    insert_data['$set'] = {'updated_at': updated_at, 'date': date_str, 'activity_type': activity_type}
    insert_data['$setOnInsert'] = {'created_at': updated_at}
    insert_data['$inc'] = data['activity']
    insert_data['$addToSet'] = data['push']
    save_with_retry(MG.activity_stats, key, insert_data)


def save_daily_stats(data):
    user_id = data['user_id']
    data['set']['user_id'] = user_id
    data['set'].pop('aid', None)
    updated_at = data['updated_at']
    date_str = arrow.get(updated_at).to('+08:00').format('YYYY-MM-DD')
    key = '%s-%s' % (user_id, date_str)
    insert_data = {}
    insert_data['$set'] = data['set']
    insert_data['$set'].update({
        "is_fresh": 0,
    })
    insert_data['$setOnInsert'] = {
        "created_at": data['updated_at']
    }
    try:
        user_stats = MG.user_stats.find_one({"_id": user_id})
    except Exception:
        pass
    else:
        chn = user_stats.get('chn')
        if chn:
            insert_data['$setOnInsert'].update({'chn': chn})
        aid = user_stats.get('aid')
        if aid:
            insert_data['$setOnInsert'].update({'aid': aid})
        register_date = user_stats.get('created_at')
        register_date = arrow.get(register_date).to('+08:00').format('YYYY-MM-DD')
        if register_date == arrow.now('+08:00').format('YYYY-MM-DD'):
            insert_data['$set'].update({'is_fresh': 1})
    insert_data['$inc'] = data['inc']
    save_with_retry(MG.daily_stats, key, insert_data)


def decode(line):
    data = json.loads(line)
    ts = arrow.get(data['@timestamp']).datetime
    activity_type = data.get('activity_type')
    bet_type = data.get('bet_type')
    user_id = data.get('user_id')
    type = data['type']
    to_save = {
        'user_id': user_id,
        'aid': data.get('aid', None),
        'type': type,
        'set': {"updated_at": ts},
        'setOnInsert': {},
        'inc': {},
        'updated_at': ts,
        'activity': {},
        'activity_type': activity_type
    }
    if type == 'register':
        to_save['set']['register_at'] = ts
        to_save['set']['aid'] = data['aid']
        to_save['set']['chn'] = data['chn'] or 'google'
    elif type == 'login' and data['logon'] == False:
        to_save['set']['first_login_at'] = ts
    elif type == 'win':
        win_price = float(data['price'])
        bonus = float(data.get('bonus', 0))
        if data.get('is_virtual'):
            bonus = float(data.get('is_virtual', 0))
        else:
            bonus = float(data.get('bonus', 0))
        to_save['inc']['win.total'] = win_price
        to_save['inc']['win.count'] = 1
        to_save['set']['win.last_at'] = ts
        to_save['inc']['bonus.total'] = bonus
        to_save['inc']['bonus.count'] = 1
        to_save['set']['bonus.last_at'] = ts
        to_save['inc']['win.%s' % activity_type] = win_price
        to_save['inc']['bonus.%s' % activity_type] = bonus
        to_save['inc']['%s.%s' % ('gain', activity_type)] = win_price + bonus
        to_save['inc']['gain.total'] = win_price + bonus
        # for activity_stats
        to_save['activity']['win.%s' % bet_type] = win_price
        to_save['activity']['win.total'] = win_price
        to_save['activity']['bonus.%s' % bet_type] = bonus
        to_save['activity']['bonus.total'] = bonus
        to_save['activity']['win.count'] = 1
        to_save['activity']['bonus.count'] = 1
        to_save['push'] = {'win.users': user_id}
    elif type == 'withdraw' and data['action'] == 'submit':
        to_save['inc']['%s.%s' % ('withdraw', data['withdraw_type'])] = float(data['cash_price'])
        to_save['inc']['withdraw.total'] = float(data['cash_price'])
        to_save['inc']['withdraw.count'] = 1
        to_save['set']['withdraw.last_at'] = ts
        to_save['inc']['total_gain'] = float(data['cash_price'])
    elif type == 'recharge':
        to_save['inc']['%s.%s' % ('recharge', data['channel'])] = float(data['price'])
        to_save['inc']['recharge.total'] = float(data['price'])
        to_save['inc']['total_gain'] = 0 - float(data['price'])
        to_save['set']['recharge.last_at'] = ts
        to_save['inc']['recharge.count'] = 1
    elif type == 'pay':
        to_save['inc']['pay.count'] = 1
        to_save['inc']['pay.total'] = float(data['price'])
        to_save['inc']['%s.%s' % ('pay', activity_type)] = float(data['price'])
        if data.get('coupon'):
            to_save['inc']['pay.coupon'] = float(data['price'])
            pay_money = float(data['price']) - float(data['coupon'])
            to_save['inc']['pay.money'] = pay_money
            to_save['inc']['%s.%s' % ('gain', activity_type)] = -pay_money
            to_save['inc']['gain.total'] = -pay_money
        else:
            to_save['inc']['pay.money'] = float(data['price'])
            to_save['inc']['%s.%s' % ('gain', activity_type)] = -float(data['price'])
            to_save['inc']['gain.total'] = -float(data['price'])
        # for activity_stats
        to_save['activity']['pay.%s' % bet_type] = float(data['price'])
        to_save['activity']['pay.total'] = float(data['price'])
        to_save['activity']['pay.count'] = 1
        to_save['push'] = {'pay.users': user_id}
    elif type == 'agent_return':
        #print(data)
        sender_id = data.get('sender')
        to_save['inc']['agent_return.count'] = 1
        to_save['inc']['agent_return.total'] = float(data['amount'])
        to_save['inc']['%s.%s' % ('agent_return', sender_id)] = float(data['amount'])
    elif type == 'active':
        to_save['set']['aid'] = data['aid']
        to_save['set']['cvc'] = data['cvc']
        to_save['set']['ip'] = data['ip']
        to_save['set']['ua'] = data['ua']
        to_save['set']['chn'] = data['chn']
    elif type == 'refund':
        to_save['inc']['refund.total'] = float(data['price'])
        to_save['inc']['%s.%s' % ('refund', activity_type)] = float(data['price'])
        to_save['inc']['%s.%s' % ('gain', data['refund_type'])] = float(data['price'])
        # for activity_stats
        to_save['activity']['refund.%s' % bet_type] = float(data['price'])
        to_save['activity']['refund.total'] = float(data['price'])
        to_save['activity']['refund.count'] = 1
        to_save['push'] = {'refund.users': user_id}
    elif type == 'coupon':
        action = data['action']
        to_save['inc']['coupon.%s' % action] = int(data['price'])
    return to_save


def track_device(data):
    aid = data['set']['aid']
    insert_data = {}
    insert_data['$set'] = data['set']
    insert_data['$setOnInsert'] = {"created_at": data['updated_at']}
    save_with_retry(MG.device_stats, aid, insert_data)


def save_with_retry(db, id, data):
    for k, v in data.items():
        if not v:
            data.pop(k)
    x = db.update({'_id': id}, data, upsert=True)
    #print get_now(), x


def handler_line(line):
    try:
        data = decode(line)
        #print data
        type = data['type']
        if type == 'login':
            save_user_stats(data)
        if type == 'active':
            track_device(data)
            if data['user_id'] != 1:
                data['set'].pop('chn', None)
                data['set'].pop('aid', None)
                save_user_stats(data)
                save_daily_stats(data)
        elif type == 'register':
            track_device(data)
            save_user_stats(data)
        elif type == 'pay':
            save_user_stats(data)
            save_daily_stats(data)
            save_activity_stats(data)
        elif type == 'agent_return':
            save_user_stats(data)
            save_daily_stats(data)
        elif type == 'win':
            save_user_stats(data)
            save_daily_stats(data)
            save_activity_stats(data)
        elif type == 'recharge':
            save_user_stats(data)
            save_daily_stats(data)
        elif type == 'withdraw':
            save_user_stats(data)
            save_daily_stats(data)
        elif type == 'refund':
            save_user_stats(data)
            save_daily_stats(data)
            save_activity_stats(data)
        elif type == 'coupon':
            save_user_stats(data)
            save_daily_stats(data)
    except Exception as e:
        #print 'handler line error %s' % e
        pass


class Tail(object):
    def __init__(self, file_name):
        self.fd = file(file_name, 'rb')
        self.fbytes = 0  # 上次读取到的位置

    def run(self, start_line = None, end_line = None):
        self.fbytes = 0
        count = 0
        if not start_line:
            start_line = 0
        while 1:
            self.fd.seek(self.fbytes, 0)
            line = self.fd.readline()
            if count < start_line:
                count = count + 1
                self.fbytes = self.fd.tell()
                continue
            if end_line and count > end_line:
                break
            if line:
                handler_line(line.strip())
                self.fbytes = self.fd.tell()
                print line
            else:
                time.sleep(1)
                break

from datetime import datetime as dt
from datetime import timedelta


def delete_daily_mongo_stats(f):
    MG.daily_stats.remove(f)
    MG.activity_stats.remove(f)
    MG.daily_stats.update({}, {'$unset': {'withdraw':1}}, multi=True)


def get_daily_track_interval(start_date):
    # binary search for track interval
    fd = file("/var/log/bigbang/admin-track.json", 'rb')
    f_lines = fd.readlines()
    n_lines = len(f_lines)
    start = 0
    end = n_lines - 1
    while 1:
        pivot = (start + end) / 2
        prev_content = json.loads(f_lines[pivot - 1])
        content = json.loads(f_lines[pivot])
        prev_timestamp = dt.strptime(prev_content['@timestamp'][:-7], "%Y-%m-%dT%H:%M:%S")
        timestamp = dt.strptime(content['@timestamp'][:-7], "%Y-%m-%dT%H:%M:%S")

        if (start_date == timestamp) and start_date > prev_timestamp:
            return pivot
        elif start_date > timestamp:
            start = pivot
        else:
            end = pivot


if __name__ == "__main__":
    start = dt.strptime('2018-02-12-16', "%Y-%m-%d-%H")
    end = dt.strptime('2018-02-13-16', "%Y-%m-%d-%H")# + timedelta(days=1)
    f = {'created_at': {'$gte': start, '$lt': end}}
    #print get_daily_track_interval(start)
    delete_daily_mongo_stats(f)
    #tail = Tail('var/log/bigbang/track.json.3')
    #tail.run(101717)
    #tail_1 = Tail('/var/log/bigbang/track.json.2')
    #tail_1.run(start_line = 74663)
    #tail_2 = Tail('var/log/bigbang/track.json.1')
    #tail_2.run(0)
    #tail_3 = Tail('var/log/bigbang/track.json')
    #tail_3.run(0)
