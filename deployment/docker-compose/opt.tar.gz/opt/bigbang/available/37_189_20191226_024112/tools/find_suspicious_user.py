#! -*- coding:utf-8 -*-
import os
import sys
from datetime import datetime

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.stats import MG_BIGBANG_COLL as mg

start_date = datetime(2018, 4, 1, 0, 0, 0)

for item in mg.user_stats.find({'updated_at': {'$gt': start_date}}):
    recharge = item.get('recharge', {}).get('total')
    pay = item.get('pay', {}).get('total')
    if not recharge or not pay:
        continue
    ratio = round(float(pay) / float(recharge), 2)
    if ratio > 10:
        print('user_id: %s, recharge: %s, bet: %s, bet/recharge: %s' % (item.get('_id'), recharge, pay, ratio))
