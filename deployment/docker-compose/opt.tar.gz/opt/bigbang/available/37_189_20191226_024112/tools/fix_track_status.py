# coding=utf-8
"""
修复track status

追号，可以提前购买还没有生成对应期数信息的彩种；
"""
import sys
import os

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.lottery.cyclical.model import ORDER_MODEL
from common.lottery.cyclical.abstract.order import try_stop_track_index
from common.lottery.model import TrackIndex
from common.utils import tz


def fix_track():
    items = TrackIndex.query.filter(TrackIndex.status == 1,
                                    TrackIndex.created_at >= tz.date_str_before(days=7),
                                    TrackIndex.created_at < tz.today_str()).all()
    for item in items:
        order_table = ORDER_MODEL[item.activity_type]
        try_stop_track_index(order_table, item.track_id)


if __name__ == "__main__":
    fix_track()
