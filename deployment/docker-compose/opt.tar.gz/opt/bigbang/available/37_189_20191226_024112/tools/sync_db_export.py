# coding=utf-8
"""
用户表
设备表
"""

import json
import os
import sys
from urllib import quote_plus as urlquote

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common import orm as bigbang_orm
from common.stats import MG_BIGBANG_COLL as mg
from common.account.model.account import Account
from common.utils import tz
from common.utils.orm import ArmoryOrm

MYSQL_CONF = {
    'db': 'mysql://user_name:%s@host_name:3306/database_name?charset=utf8' % urlquote('password'),
    'DEBUG': False
}
orm = ArmoryOrm()
orm.init_conf(MYSQL_CONF)


class WitchInformation(orm.Model):
    __tablename__ = "account"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.Integer, unique=True)
    channel = orm.Column(orm.VARCHAR)
    ip = orm.Column(orm.VARCHAR)
    aid = orm.Column(orm.VARCHAR)
    registered_at = orm.Column(orm.DATETIME)
    active_at = orm.Column(orm.DATETIME)


class WitchDeviceInformation(orm.Model):
    __tablename__ = "device"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    aid = orm.Column(orm.VARCHAR, unique=True)
    channel = orm.Column(orm.VARCHAR)
    ip = orm.Column(orm.VARCHAR)
    created_at = orm.Column(orm.DATETIME)
    active_at = orm.Column(orm.DATETIME)


batch_limit = 2000
OLDEST_DATE_TIME = tz.get_utc_date('2017-04-01')


def sync_account_table():
    def row_data_processor(s_account):
        d_account = WitchInformation()
        d_account.user_id = s_account.id
        d_account.channel = s_account.channel
        d_account.registered_at = s_account.created_at
        d_account.active_at = s_account.updated_at

        if s_account.extend:
            extend_field = json.loads(s_account.extend)
            d_account.ip = extend_field.get('ip')
            d_account.aid = extend_field.get('aid')

        return d_account

    last_cursor_id = orm.session.query(orm.func.max(WitchInformation.id)).scalar()
    if last_cursor_id is None:
        last_cursor_id = bigbang_orm.session.query(bigbang_orm.func.min(Account.id)).filter(
            Account.created_at >= OLDEST_DATE_TIME).scalar()

    batch_sql_template(last_cursor_id, row_data_processor, Account, 'account table')


def sync_device_table():
    device = mg.device_stats.find().sort('created_at', -1)
    count = device.count()
    print count
    min_id = orm.session.query(orm.func.min(WitchInformation.id)).scalar() or 1
    max_id = orm.session.query(orm.func.max(WitchInformation.id)).scalar() or 0
    skip_count = max_id - min_id + 1
    while skip_count < count:
        print 'start mongo export from %s' % skip_count
        device = device.limit(20).skip(skip_count)
        for item in device:
            d_device = WitchDeviceInformation()
            _id = item.get('aid')
            if not _id:
                continue
            _device = mg.device_stats.find_one({'_id': _id})
            d_device.aid = _device.get('aid')
            d_device.channel = _device.get('chn')
            d_device.ip = _device.get('ip')
            d_device.created_at = _device.get('created_at')
            d_device.active_at = _device.get('updated_at')
            d_device.save()
        skip_count += 20
        print 'end mongo export to %s ' % skip_count

    orm.session.commit()
    orm.session.close()
    bigbang_orm.session.close()


def batch_sql_template(last_cursor_id, row_data_processor, src_model, verbose):
    start_t = tz.now_ts()
    print 'start sync %s since %s at %s' % (verbose, last_cursor_id, start_t)
    if last_cursor_id is None:
        print 'ignore sync %s , because no new data' % (verbose,)
        return
    batch_count = 0
    g_count = 0
    while True:
        print 'start the batch count: %s' % batch_count
        query = src_model.query.filter(src_model.id > last_cursor_id).order_by(src_model.id.asc())
        batch_data = query.limit(batch_limit).all()
        print 'get current batch data: %s' % batch_count
        batch_count += 1
        if not batch_data:
            break
        bulk = []
        for src_row in batch_data:
            g_count += 1
            last_cursor_id = src_row.id
            des_data = row_data_processor(src_row)
            if des_data:
                bulk.append(des_data)
        orm.session.bulk_save_objects(bulk)
        orm.session.commit()
    print 'finished sync %s count %s at %s cross %s seconds' % (verbose, g_count, tz.now_ts(), tz.now_ts() - start_t)
    orm.session.close()
    bigbang_orm.session.close()


if __name__ == "__main__":
    tables = sys.argv[1]
    if 'account' in tables:
        sync_account_table()
    if 'device' in tables:
        sync_device_table()