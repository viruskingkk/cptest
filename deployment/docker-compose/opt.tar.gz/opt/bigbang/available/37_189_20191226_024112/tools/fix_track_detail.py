# coding=utf-8
"""
修正track_index表的track_detail
"""

import os
import sys
import datetime

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.lottery.model import TrackIndex
from common.lottery.db import generate_track_detail

for each in list(TrackIndex.query.filter(TrackIndex.detail == None).all()):
    generate_track_detail(each.track_id)
