#! -*- coding:utf-8 -*-
"""
将mongoDB的user_stats里没有created_at或created_at在12月21日及以后的集合新增或更新created_at
"""
from datetime import datetime
import logging

from common.stats import MG_BIGBANG_COLL as mg
from common.account.model.account import Account

_LOGGER = logging.getLogger(__name__)


def get_account_id():
    account_id_list = []
    start_time = datetime.strptime('2018-12-20 16:00:00', '%Y-%m-%d %H:%M:%S')
    items = mg.user_stats.find({'created_at': {'$exists': False}})
    query = mg.user_stats.find({'created_at': {'$gte': start_time}})
    for item in items:
        account_id_list.append(item['_id'])
    for item in query:
        account_id_list.append(item['_id'])
    account_id_list = list(set(account_id_list))
    return account_id_list


def get_account():
    account_list = []
    account_id_list = get_account_id()
    items = Account.query.filter(Account.id.in_(account_id_list))
    for item in items:
        account_list.append((item.id, item.created_at))
    return account_list


def update_created_at():
    account_list = get_account()
    _LOGGER.info('update accounts info:{}'.format(account_list))
    for account in account_list:
        mg.user_stats.update({'_id': account[0]}, {'$set': {'created_at': account[1], 'register_at': account[1]}})


if __name__ == "__main__":
    _LOGGER.info('start update_user_stats_created-at')
    try:
        update_created_at()
        _LOGGER.info('end update_user_stats_created-at successfully')
    except Exception as e:
        _LOGGER.error(e)