# -*- coding: utf-8 -*-

import os
import sys
import logging

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.recharge_appeal.db import get_appeal_orders
from api.recharge_appeal import handler

_LOGGER = logging.getLogger(__name__)


def check_appeal_status():
    items = get_appeal_orders(status=0)
    for item in items:
        try:
            _LOGGER.info('check_appeal_status, id:%s' % item['id'])
            print('check_appeal_status, id:%s' % item['id'])
            handler.submit_appeal_order_to_third(item['id'])
        except:
            _LOGGER.info('check_appeal_status error, id:%s' % item['id'])

if __name__ == "__main__":
    check_appeal_status()
