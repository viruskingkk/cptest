# -*- coding: utf-8 -*-
import os
import sys
from datetime import timedelta, datetime

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.utils.tz import utc_to_local
from common.preset.db.banner import get_banner_by_type
from common.preset.model.preset import BANNER_TYPE
from common.campaign.db.winner_ranking_award import award_winner_ranking
from common.campaign.model.winner_ranking import WinnerAwardRecord, WINNER_AWARD_TYPE
from common.campaign.winner_ranking_award import get_winner_ranking
from common.notification.handler import notify_winner_rank_daily, notify_winner_rank_weekly, notify_winner_rank_total


def award_yesterday():
    end = utc_to_local(datetime.now()).replace(hour=0, minute=0, second=0, microsecond=0)
    start = end - timedelta(days=1)
    award_daily(start, end)


def award_last_week():
    banner = get_banner_by_type(BANNER_TYPE.WINNER_RANKING)
    campaign_start = datetime.fromtimestamp(banner.campaign_start)
    now = datetime.now()
    delta_time = (now - campaign_start).days / 7 * 7
    weekly_start_date = campaign_start + timedelta(days=delta_time - 7)
    weekly_end_date = weekly_start_date + timedelta(days=7)
    if weekly_start_date < datetime.fromtimestamp(banner.campaign_start):
        print('not ready for awarding weekly')
        return
    award_weekly(weekly_start_date, weekly_end_date)


def award_new_year():
    banner = get_banner_by_type(BANNER_TYPE.WINNER_RANKING)
    start = datetime.fromtimestamp(banner.campaign_start)
    end = datetime.fromtimestamp(banner.campaign_end)
    now = datetime.now()
    if now < datetime.fromtimestamp(banner.campaign_end):
        print('not ready for awarding total')
        return
    award_total(start, end)


def award_daily(start, end):
    print '\n---> start daily award'
    award_record = WinnerAwardRecord.query. \
        filter(WinnerAwardRecord.type == WINNER_AWARD_TYPE.DAILY). \
        filter(WinnerAwardRecord.end > start). \
        first()
    if award_record:
        print('already awarded for %s - %s' % (start, end))
        return
    ranking = get_winner_ranking(start, end, WINNER_AWARD_TYPE.DAILY)
    for item in ranking:
        user_id = item.get('user_id')
        win_amount = item.get('amount')
        amount = item.get('estimated_award')
        rank = item.get('rank')
        if amount > 0:
            print 'awarding user <%s>, award_amount <%s>, win_amount: <%s>' % (user_id, amount, win_amount)
            award_winner_ranking(user_id, WINNER_AWARD_TYPE.DAILY, rank, amount, start, end)
            notify_winner_rank_daily(user_id, start.strftime("%m-%d"), rank, amount)


def award_weekly(start, end):
    print '\n---> start weekly award'
    award_record = WinnerAwardRecord.query. \
        filter(WinnerAwardRecord.type == WINNER_AWARD_TYPE.WEEKLY). \
        filter(WinnerAwardRecord.end > start). \
        first()
    if award_record:
        print('already awarded for %s - %s' % (start, end))
        return
    ranking = get_winner_ranking(start, end, WINNER_AWARD_TYPE.WEEKLY)
    for item in ranking:
        user_id = item.get('user_id')
        win_amount = item.get('amount')
        amount = item.get('estimated_award')
        rank = item.get('rank')
        if amount > 0:
            print 'awarding user <%s>, award_amount <%s>, win_amount: <%s>' % (user_id, amount, win_amount)
            # award_winner_ranking(user_id, WINNER_AWARD_TYPE.WEEKLY, rank, amount, start, end)
            # notify_winner_rank_weekly(user_id, rank, amount)


def award_total(start, end):
    print '\n---> start total award'
    award_record = WinnerAwardRecord.query. \
        filter(WinnerAwardRecord.type == WINNER_AWARD_TYPE.TOTAL). \
        filter(WinnerAwardRecord.end > start). \
        first()
    if award_record:
        print('already awarded for %s - %s' % (start, end))
        return
    ranking = get_winner_ranking(start, end, WINNER_AWARD_TYPE.TOTAL)
    for item in ranking:
        user_id = item.get('user_id')
        win_amount = item.get('amount')
        amount = item.get('estimated_award')
        rank = item.get('rank')
        if amount > 0:
            print 'awarding user <%s>, award_amount <%s>, win_amount: <%s>' % (user_id, amount, win_amount)
            # award_winner_ranking(user_id, WINNER_AWARD_TYPE.TOTAL, rank, amount, start, end)
            # notify_winner_rank_total(user_id, rank, amount)


if __name__ == '__main__':
    award_yesterday()
    award_last_week()
    award_new_year()
