# -*- coding: utf-8 -*-
import os
import sys

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common import orm
from common.transaction.model import Transaction
from common.transaction.db import get_sharding_transaction_table

while True:
    transaction_query = Transaction.query.order_by(Transaction.id.desc()).limit(100).all()

    for record in transaction_query:
        transaction_table = get_sharding_transaction_table(record.user_id)

        instance = transaction_table()
        instance.user_id = record.user_id
        instance.type = record.type
        instance.activity_type = record.activity_type
        instance.pay_id = record.pay_id
        instance.status = record.status
        instance.title = record.title
        instance.price = record.price
        instance.balance = record.balance
        instance.order_id = record.order_id
        instance.created_at = record.created_at
        instance.updated_at = record.updated_at
        instance.extend = record.extend
        instance.save(auto_commit=False)
        record.delete(auto_commit=False)

        orm.session.commit()

        print('transaction: %s, user_id: %s => %s' % (record.id, record.user_id, transaction_table.__tablename__))
