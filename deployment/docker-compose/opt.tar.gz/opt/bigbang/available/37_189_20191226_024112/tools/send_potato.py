#!/usr/bin/python
import sys
import json
import requests

# _SEND_TEXT_API = 'https://bot.potato.im:5423/8024864:haQAaBUKI0Mf4Frz3qsnzGP0/sendTextMessage'
_SEND_TEXT_API = 'https://api.potato.im:8443/8026170:CeywfHBsJqh1G1Gn6l07YXXc/sendTextMessage'
_SEND_TEXT_API_TELE = 'https://api.telegram.org/bot597397891:AAGExppImc2eYIv4yMJ-fOAoZTkKyIsg1Sk/sendMessage'

NOTIFY_UIDS = [8010041, 8001739, 8024785, 8008571, 8030363, 8036187, 8036377, 8039163, 8036197, 8059299, 8044897,
               20016358, 20024048]
NOTIFY_UIDS_TELE = [-276357059]


def send_text_msg(chat_type, chat_id, chat_text):
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    post_data = {
        "chat_type": chat_type,
        "chat_id": chat_id,
        "text": chat_text,
        "markdown": True,
    }
    response = requests.post(_SEND_TEXT_API, data=json.dumps(post_data, separators=(',', ':')), headers=headers,
                             timeout=5)
    print response.text


def send_text_msg_tele(chat_id, chat_text):
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    post_data = {
        "chat_id": chat_id,
        "text": chat_text,
        "parse_mode": "Markdown",
    }
    response = requests.post(_SEND_TEXT_API_TELE, data=json.dumps(post_data, separators=(',', ':')), headers=headers,
                             timeout=5)
    print response.text


if __name__ == "__main__":
    title = sys.argv[1].decode('utf-8')
    content = sys.argv[2].decode('utf-8')
    ext = sys.argv[3].decode('utf-8')
    for uid in NOTIFY_UIDS:
        send_text_msg(1, uid, u'**{}**\n**{}**\n**{}**'.format(title, content, ext))

    # only notify Telegram for CP-xx hosts
    if 'CP-' in title:
        for uid in NOTIFY_UIDS_TELE:
            send_text_msg_tele(uid, u'**{}**\n**{}**\n**{}**'.format(title, content, ext))
