# -*- coding: utf-8 -*-
import os
import sys
import json


base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.transaction.db import WITHDRAW_STATUS, WITHDRAW_TYPE, calc_withdraw_amount, CHECK_STATUS
from common.utils.export import gen_filename, redirect_to_file
from common.utils.tz import utc_to_local_str
from common.utils.decorator import sql_wrapper
from common.transaction.model import Withdraw
from common.admin.model import User
from sqlalchemy import and_


@sql_wrapper
def export_withdraw_records():
    items = Withdraw.query.filter(Withdraw.check_status != 0).\
        filter(and_(Withdraw.updated_at >= '2019-06-30 16:00:00', Withdraw.updated_at <= '2019-08-31 16:00:00')).all()

    users = User.query.all()
    user_map = {user.id: user.nickname for user in users}
    resp_items = []
    for item in items:
        withdraw_at = utc_to_local_str(item.created_at)
        updated_at = utc_to_local_str(item.updated_at)
        withdraw_info = json.loads(item.extend or '{}')
        if 'manual_check_info' not in withdraw_info:
            continue
        withdraw_status = WITHDRAW_STATUS.get_label(item.status)
        name = withdraw_info.get('name')
        phone = withdraw_info.get('phone')
        third_id = '-'
        pay_date = '-'
        withdraw_chn = '-'
        if 'auto_trans_info' in withdraw_info:
            third_id = withdraw_info['auto_trans_info'].get('order_id') or '-'
            pay_date = withdraw_info['auto_trans_info'].get('complete_pay_date')
            payer_no = withdraw_info['auto_trans_info'].get('payer_no')
            if payer_no == 'group_new_withdraw':
                withdraw_chn = u'万豪下分'
            else:
                withdraw_chn = u'官方下分'
        real_amount = item.real_price or calc_withdraw_amount(item.user_id, item.price)
        data_row = [item.id, item.user_id, item.price, real_amount,
                    WITHDRAW_TYPE.get_label(item.target_type), withdraw_chn, CHECK_STATUS.get_label(item.check_status),
                    withdraw_status, withdraw_at, updated_at]
        data_row += [third_id, pay_date]
        admin_id = withdraw_info.get('manual_check_info').get('admin_id')
        if admin_id:
            data_row += [user_map.get(admin_id)]
        else:
            data_row += ['']

        resp_items.append(data_row)
    return resp_items


filename = gen_filename('withdraw_records')
header = [
    u'提现单号', u'用户ID', u'提现金额', u'到账金额', u'提现方式',
    u'提现通道', u'审核状态', u'提现状态', u'提现时间', u'更新时间', u'第三方流水号', u'交易时间', u'审核人员']


items = export_withdraw_records()

# data = tablib.Dataset(*items, headers=header)

print(redirect_to_file(items, header, filename))
#
# with open('/tmp/' + filename, 'wb') as f:
#     f.write(data.xlsx)
