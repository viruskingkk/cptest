# coding=utf-8
import os
import sys
import datetime

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.stats import MG_BIGBANG_COLL
from common.pay.model import Pay, PAY_TYPE
from common.transaction.model import Withdraw
from common import orm


def main():
    MG_BIGBANG_COLL.user_stats.update({}, {'$unset': {'withdraw': 1, 'recharge': 1}}, multi=True)
    # 充值
    union_recharges = orm.session.query(Pay.user_id, orm.func.sum(Pay.price), orm.func.count(Pay.price))\
        .filter(Pay.status == 2, Pay.pay_type.in_([PAY_TYPE.UNIONAGENCY, PAY_TYPE.UNIONAGENCY_V2_ALI,
                                                   PAY_TYPE.UNIONAGENCY_V2_BANKCARD, PAY_TYPE.UNIONAGENCY_V2_WX])) \
        .group_by(Pay.user_id).all()
    for recharge in union_recharges:
        user_id, price, count = recharge[0], recharge[1], recharge[2]
        MG_BIGBANG_COLL.user_stats.update({"_id": user_id}, {"$inc": {
            "recharge.total": float(price),
            "recharge.unionagency": float(price),
            "recharge.count": float(count)}})

    wechat_recharges = orm.session.query(Pay.user_id, orm.func.sum(Pay.price), orm.func.count(Pay.price)) \
        .filter(Pay.status == 2, Pay.pay_type == PAY_TYPE.SELF_WECHAT) \
        .group_by(Pay.user_id).all()
    for recharge in wechat_recharges:
        user_id, price, count = recharge[0], recharge[1], recharge[2]

        MG_BIGBANG_COLL.user_stats.update({"_id": user_id}, {"$inc": {
            "recharge.total": float(price),
            "recharge.agent_wechat": float(price),
            "recharge.count": float(count)}})

    just_recharges = orm.session.query(Pay.user_id, orm.func.sum(Pay.price), orm.func.count(Pay.price))\
        .filter(Pay.status == 2, ~Pay.pay_type.in_([PAY_TYPE.UNIONAGENCY, PAY_TYPE.UNIONAGENCY_V2_ALI,
                                                   PAY_TYPE.UNIONAGENCY_V2_BANKCARD, PAY_TYPE.UNIONAGENCY_V2_WX,
                                                   PAY_TYPE.SELF_WECHAT])) \
        .group_by(Pay.user_id).all()
    for recharge in just_recharges:
        user_id, price, count = recharge[0], recharge[1], recharge[2]

        MG_BIGBANG_COLL.user_stats.update({"_id": user_id}, {"$inc": {
            "recharge.total": float(price),
            "recharge.justpay": float(price),
            "recharge.count": float(count)}})


    withdraws_wait = orm.session.query(Withdraw.user_id, orm.func.sum(Withdraw.price), orm.func.count(Withdraw.price)) \
        .filter((Withdraw.status != 32) &
                (Withdraw.status != 2) &
                (Withdraw.status != 16)) \
        .group_by(Withdraw.user_id).all()
    for withdraw_wait in withdraws_wait:
        user_id, price, count = withdraw_wait[0], withdraw_wait[1], withdraw_wait[2]
        print price

        MG_BIGBANG_COLL.user_stats.update({"_id": user_id}, {"$set": {"withdraw.total_wait": float(price),
                                                                      "withdraw.count_wait": float(count)}})


    withdraws_forbidden = orm.session.query(Withdraw.user_id, orm.func.sum(Withdraw.price), orm.func.count(Withdraw.price)) \
        .filter((Withdraw.status == 16)) \
        .group_by(Withdraw.user_id).all()
    for withdraw_forbidden in withdraws_forbidden:
        user_id, price, count = withdraw_forbidden[0], withdraw_forbidden[1], withdraw_forbidden[2]
        print price

        MG_BIGBANG_COLL.user_stats.update({"_id": user_id}, {"$set": {"withdraw.total_forbidden": float(price),
                                                                      "withdraw.count_forbidden": float(count)}})


    withdraws_done = orm.session.query(Withdraw.user_id, orm.func.sum(Withdraw.price), orm.func.count(Withdraw.price)) \
        .filter((Withdraw.status == 2)) \
        .group_by(Withdraw.user_id).all()
    for withdraw_done in withdraws_done:
        user_id, price, count = withdraw_done[0], withdraw_done[1], withdraw_done[2]
        print price

        MG_BIGBANG_COLL.user_stats.update({"_id": user_id}, {"$set": {"withdraw.total": float(price),
                                                                      "withdraw.count": float(count)}})



if __name__ == '__main__':
    main()
