# coding=utf-8

import os
import sys

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")
from common.activity.utils import ts_to_date_str_list, get_activity_time
from common.utils.tz import *
from common.preset.model.preset import BANNER_TYPE

from common.activity.ranking_db import open_prize
from common.utils import track_logging

_LOGGER = track_logging.getLogger(__name__)

if __name__ == '__main__':
    # 第二天开上一天的奖

    # todo 把获取活动的activity_days 提炼成一个函数

    yesterday_str = date_str_before(days=1)
    activity_start_time, activity_end_time = get_activity_time(BANNER_TYPE.get_key('ranking'))

    activity_days = ts_to_date_str_list(activity_start_time, activity_end_time)

    if yesterday_str not in activity_days:
        _LOGGER.info("open ranking activity winner not in activity_days {} {}".format(yesterday_str, activity_days))

    open_prize(yesterday_str)

    if yesterday_str == activity_days[-1]:
        open_prize(None, total=True)
