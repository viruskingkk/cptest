# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os
import sys

# add up one level dir into sys path
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(__file__))))
os.environ['DJANGO_SETTINGS_MODULE'] = 'base.settings'

from common.coupon.model import *
from common.utils.tz import now_ts
from common.utils.tracker import track_coupon

cmd = sys.argv[1]
if cmd == 'expire':
    coupons = AccountCoupon.query.filter(AccountCoupon.expire_ts <= now_ts()).filter(
        AccountCoupon.status == COUPON_STATUS.UNUSED).all()
    for coupon in coupons:
        coupon.status = COUPON_STATUS.EXPIRED
        coupon.save(auto_commit=False)
        log_data = coupon.as_dict()
        track_coupon(log_data, action='expire')
    orm.session.commit()
