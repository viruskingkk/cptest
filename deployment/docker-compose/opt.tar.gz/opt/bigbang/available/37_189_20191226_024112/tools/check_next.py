# coding=utf-8
"""
cron脚本，每分钟执行一次
检查是否有开启下一期活动，如果没有，就开启
"""
import os
import sys

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.lottery import LOTTERY_TYPE
from common.lottery.cyclical.abstract.activity import get_latest_term
from common.lottery.cyclical import ACTIVITY_STATUS
from common.timer.cyclical_handler import (ActivityNextHandler, SeqActivityNextHandler,
                                           NEXT_TERM, SEQ_NEXT_TERM)


def check_next_term():
    for activity_type in LOTTERY_TYPE.values():
        latest_activity = get_latest_term(activity_type)
        if latest_activity and latest_activity.status == ACTIVITY_STATUS.ANNOUNCED:
            if activity_type in NEXT_TERM:
                ActivityNextHandler(activity_type)
            if activity_type in SEQ_NEXT_TERM:
                SeqActivityNextHandler(activity_type)


if __name__ == "__main__":
    check_next_term()
