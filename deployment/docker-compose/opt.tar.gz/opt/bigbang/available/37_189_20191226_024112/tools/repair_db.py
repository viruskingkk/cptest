# coding=utf-8
"""
2019-10-23 迁移witch，数据库内容丢失
"""
import pymysql

old_db = {
    "host": "103.230.243.203",
    "user": "bigbang",
    "password": "n0ra@wang",
    "db": "bigbang",
}

new_db = {
    "host": "43.239.66.6",
    "user": "bigbang",
    "password": "n0ra@wang",
    "db": "bigbang",
}

tables = [
    # "sd_11x5","sd_11x5_order"
    # "ff_ks", "ff_ks_order", "ff_11x5", "ff_11x5_order", "ff_pk10", "ff_pk10_order", "xj_ssc", "xj_ssc_order",
    # "jx_11x5", "jx_11x5_order", "js_ks", "js_ks_order", "gd_11x5", "gd_11x5_order", "bj_pk10", "bj_pk10_order",
    # "withdraw", "account",
    "appeal",
]

# for i in range(0, 20):
#     tables.append('transaction_%s' % i)

LIMIT = 2000

def repair_data():
    old_conn = _get_conn(old_db)
    new_conn = _get_conn(new_db)

    old_cursor = old_conn.cursor()
    new_cursor = new_conn.cursor()

    for table in tables:
        last_cur = 0
        while True:
            old_cursor.execute("select id from {} where id > %s order by id asc limit %s".format(table), (last_cur, LIMIT))
            old_ids = old_cursor.fetchall()
            if not old_ids:
                break
            next_cur = old_ids[-1]["id"]
            new_cursor.execute("select id from {} where id > %s and id <= %s".format(table), (last_cur, next_cur))
            new_ids = new_cursor.fetchall()
            last_cur = next_cur
            diff_ids = set([i["id"] for i in old_ids]) - set([i["id"] for i in new_ids])
            if not diff_ids:
                continue
            print("=========> insert lost data: []", diff_ids)
            old_cursor.execute("select * from {} where id in %s".format(table), (diff_ids,))
            column_names = sorted([e[0] for e in old_cursor.description])
            columns_str = ",".join(column_names)
            placeholders = ",".join(["%s" for _ in range(len(column_names))])

            for row in old_cursor.fetchall():
                try:
                    print("insert into {}({}) values ({})".format(table, columns_str, placeholders), tuple([row[e] for e in column_names]))
                    new_cursor.execute("insert into {}({}) values ({})".format(table, columns_str, placeholders), tuple([row[e] for e in column_names]))
                    new_conn.commit()
                except pymysql.err.IntegrityError:
                    print("======> conflict: {}".format(row["id"]))
                    pass

    old_conn.close()
    new_conn.close()


def _get_conn(kwargs):
    return pymysql.connect(cursorclass=pymysql.cursors.DictCursor, **kwargs)


if __name__ == "__main__":
    repair_data()