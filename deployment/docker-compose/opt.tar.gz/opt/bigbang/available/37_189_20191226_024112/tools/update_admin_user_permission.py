# coding=utf-8
"""
修改用户的权限
2019-09-18给 高级用户运营/用户运营 添加站内信的权限（前端显示权限）
站内信前端代码为 143， 高级用户运营/用户运营 为7、8
"""
import os
import sys

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.admin.model import User
from common.utils.decorator import sql_wrapper


@sql_wrapper
def update_admin_user_permission():
    items = User.query.filter(User.duty.in_([7, 8])).all()
    for item in items:
        if '143' not in item.perm:
            item.perm = '143|' + item.perm
        item.save()


if __name__ == '__main__':
    update_admin_user_permission()