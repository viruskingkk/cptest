# -*- coding: utf-8 -*-
import sys

import os

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.pay.db import get_pay
from common.pay.model import PAY_STATUS

pay_id_list = sys.argv[1]

for pay_id in pay_id_list.split(','):
    pay = get_pay(pay_id)
    if pay.status == PAY_STATUS.FAIL:
        print 'processing %s' % pay_id
        pay.status = PAY_STATUS.SUBMIT
        pay.save()
