#! -*- coding:utf-8 -*-
import os
import sys
import random

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")
from common.pay.db import get_today_recharge, get_pay_over_user_ids
from common.activity.recharge_iphone_model import ACTIVITY_CONFIG, RechargeIphoneRecord, ACTIVITY_STATUS
from common.cache.redis_cache import get_recharge_iphone_activity_real_join_count, \
    set_recharge_iphone_activity_real_join_count
from common.timer import TIMER_EVENT_TYPE, TimerEvent, EventHandler
from common.utils.tz import now_ts, today_str


def main():
    old_count = get_recharge_iphone_activity_real_join_count(today_str())
    new_count = len(get_pay_over_user_ids(ACTIVITY_CONFIG['threshold'], today_str()))
    set_recharge_iphone_activity_real_join_count(today_str(), new_count)
    user_count = new_count - old_count
    times = random.randint(2, 4)
    next_ts = now_ts()
    TimerEvent.submit(TIMER_EVENT_TYPE.ADD_RECHARGE_IPHONE_JOIN_COUNT,
                      {'exec_ts': next_ts, 'count': user_count * times},
                      next_ts)


if __name__ == "__main__":
    main()
