# -*- coding: utf-8 -*-
import sys

import os

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.lottery.cyclical import ORDER_STATUS
from common.lottery.cyclical.js_ks.model.order import Order as js_ks_order
from common.lottery.cyclical.sd_11x5.model.order import Order as sd_11x5_order
from common.lottery.cyclical.gd_11x5.model.order import Order as gd_11x5_order
from common.lottery.cyclical.sh_11x5.model.order import Order as sh_11x5_order
from common.lottery.cyclical.jx_11x5.model.order import Order as jx_11x5_order

query = js_ks_order.query.filter(js_ks_order.created_at > '20180501'). \
    filter(js_ks_order.status == ORDER_STATUS.READY).all()

for item in query:
    term = item.term
    if len(term) != 11:
        item.term = term[:8] + '0' + term[-2:]
        item.save()
        print '%s -> %s' % (term, item.term)


query = sd_11x5_order.query.filter(sd_11x5_order.created_at > '20180501'). \
    filter(sd_11x5_order.status == ORDER_STATUS.READY).all()

for item in query:
    term = item.term
    if len(term) == 12:
        if term[-4:].startswith('00'):
            item.term = term[:8] + term[-2:]
            item.save()
            print '%s -> %s' % (term, item.term)
    if len(term) == 9:
        item.term = term[:8] + term[8:].zfill(2)
        item.save()
        print '%s -> %s' % (term, item.term)


query = sh_11x5_order.query.filter(sh_11x5_order.created_at > '20180501'). \
    filter(sh_11x5_order.status == ORDER_STATUS.READY).all()

for item in query:
    term = item.term
    if len(term) == 12:
        if term[-4:].startswith('00'):
            item.term = term[:8] + term[-2:]
            item.save()
            print '%s -> %s' % (term, item.term)
    if len(term) == 9:
        item.term = term[:8] + term[8:].zfill(2)
        item.save()
        print '%s -> %s' % (term, item.term)


query = gd_11x5_order.query.filter(gd_11x5_order.created_at > '20180501'). \
    filter(gd_11x5_order.status == ORDER_STATUS.READY).all()

for item in query:
    term = item.term
    if len(term) == 12:
        if term[-4:].startswith('00'):
            item.term = term[:8] + term[-2:]
            item.save()
            print '%s -> %s' % (term, item.term)
    if len(term) == 9:
        item.term = term[:8] + term[8:].zfill(2)
        item.save()
        print '%s -> %s' % (term, item.term)


query = jx_11x5_order.query.filter(jx_11x5_order.created_at > '20180501'). \
    filter(jx_11x5_order.status == ORDER_STATUS.READY).all()

for item in query:
    term = item.term
    if len(term) == 12:
        if term[-4:].startswith('00'):
            item.term = term[:8] + term[-2:]
            item.save()
            print '%s -> %s' % (term, item.term)
    if len(term) == 9:
        item.term = term[:8] + term[8:].zfill(2)
        item.save()
        print '%s -> %s' % (term, item.term)
