# coding=utf-8
"""
输出电销名单，输出的excel，在网页中的目录如一下格式
http://c.69whqi.com:9002/export_data/dianxiao_account_6d786c65-4d3c-48df-be0b-433d315dfd55.xlsx
"""
import os
import sys

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
print base_dir
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common import orm
from common.account.model.account import Account
from common.pay.model import Pay
from common.utils.decorator import sql_wrapper
from common.utils.export import gen_filename, redirect_to_file

USER_IDS = [2737316, 1812751, 2737320, 2269118, 2640018, 2737294, 245683, 2737318, 1624638, 2706952, 2737305, 2737299,
            2737325, 1540884, 1363354, 2659501, 2737330, 2359581, 792029, 880308, 2737303, 2289474, 2598846, 2659737,
            665421, 312643,
            ]


@sql_wrapper
def export_dianxiao_account():
    recharges = orm.session.query(Pay.user_id, orm.func.sum(Pay.price)) \
        .filter(Pay.user_id.in_(USER_IDS)) \
        .filter(Pay.status == 2) \
        .group_by(Pay.user_id).all()

    user_id_to_recharges = {}
    for recharge in recharges:
        user_id, price = recharge[0], recharge[1]
        user_id_to_recharges.update({user_id: price})

    ret_list = []
    for user_id in USER_IDS:
        account_info = Account.query.filter(Account.id == user_id).first()
        if account_info:
            item = [account_info.id, account_info.phone, account_info.user_name,
                    user_id_to_recharges.get(account_info.id)]
            ret_list.append(item)
    return ret_list


if __name__ == '__main__':
    filename = gen_filename('dianxiao_account')
    header = [u'用户id', u'电话', u'昵称', u'累充']
    items = export_dianxiao_account()
    print(redirect_to_file(items, header, filename))
