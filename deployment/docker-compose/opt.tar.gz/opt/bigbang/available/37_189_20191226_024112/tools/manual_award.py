# -*- coding: utf-8 -*-
import json
import os
import sys
from decimal import Decimal


base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "base.settings")

from common.account.db.account import add_campaign_award_in_transaction, get_account
from common.notification import db as notification_db
from common.notification.model import NOTIFY_TYPE

award_file = sys.argv[1]

with open(award_file) as f:
    for line in f:
        if line:
            user_id, amount = line.split(',')
            amount = round(float(amount), 2)
            extend = {
                'title': u'春节活动中奖',
                'award_amount': amount
            }

            account = get_account(user_id)
            if not account:
                continue
            add_campaign_award_in_transaction(user_id, Decimal(amount), extend)
            content = {
                'title': u'春节奖金',
                'body': u'恭喜您获得春节大奖赛奖金 %s 元，请在余额中查询金额。' % amount,
                'tag': u'活动派奖'
            }
            content = json.dumps(content, ensure_ascii=False)
            notification_db.create_user_notification(user_id, NOTIFY_TYPE.INSIDE, content)
            print 'user_id: %s, amount: %s' % (user_id, amount)
