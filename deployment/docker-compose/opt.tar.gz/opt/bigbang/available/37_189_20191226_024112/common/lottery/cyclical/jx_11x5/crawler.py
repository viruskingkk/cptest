# -*- coding: utf-8 -*-
import json
import logging
import os
import sys
import time
import traceback
from datetime import timedelta

import requests
from dateutil import parser
from lxml import etree

# add up one level dir into sys path
from common.lottery.handler import crawl_from_opencai

sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))))
os.environ['DJANGO_SETTINGS_MODULE'] = 'base.settings'

from common.lottery.cyclical.jx_11x5.db.activity import fullfill_result
from common.lottery import LOTTERY_TYPE, PROXY_URL, OPENCAI_LOTTERY_TYPES
from common.timer import TIMER_EVENT_TYPE, TimerEvent
from common.utils import tz

# 500彩票网
URL_500 = 'http://kaijiang.500.com/static/info/kaijiang/xml/dlc/%s.xml'

# 168开奖网
URL_168 = 'http://api.1680210.com/ElevenFive/getElevenFiveList.do?date=%s&lotCode=10015'


def _parse_and_fill_168(data, refer):
    if data['errorCode'] == 0:
        nodes = data['result']['data']
        for node in nodes:
            phase = node['preDrawIssue']
            number = node['preDrawCode']
            number = ','.join([str(int(each)) for each in number.split(',')])
            activity = fullfill_result(phase, number, refer)
            if activity:
                TimerEvent.submit(TIMER_EVENT_TYPE.CALC_STATS, {
                    'number': number, 'term': phase,
                    'activity_type': LOTTERY_TYPE.JX_11X5}, tz.now_ts())
                TimerEvent.submit(TIMER_EVENT_TYPE.ACTIVITY_ANNOUNCE, {
                    'number': number, 'term': phase,
                    'activity_type': LOTTERY_TYPE.JX_11X5}, tz.now_ts())


def _parse_and_fill(resp, refer):
    nodes = etree.fromstring(resp)
    for node in nodes:
        attrib = node.attrib
        phase = '20' + attrib['expect'].replace('-', '')
        number = attrib['opencode']
        number = ','.join([str(int(n)) for n in number.split(',')])
        activity = fullfill_result(phase, number, refer)
        if activity:
            TimerEvent.submit(TIMER_EVENT_TYPE.CALC_STATS, {
                'number': number, 'term': phase,
                'activity_type': LOTTERY_TYPE.JX_11X5}, tz.now_ts())
            TimerEvent.submit(TIMER_EVENT_TYPE.ACTIVITY_ANNOUNCE, {
                'number': number, 'term': phase,
                'activity_type': LOTTERY_TYPE.JX_11X5}, tz.now_ts())


def crawl_history_from_168(date):
    url = URL_168 % date.strftime('%Y-%m-%d')
    try:
        response = requests.get(url, proxies={'http': PROXY_URL}, timeout=10)
        resp_text = json.loads(response.text)
    except Exception as e:
        raise e
    if response.status_code != 200:
        raise RuntimeError('request error')
    _parse_and_fill_168(resp_text, url)


def crawl_history(date):
    url = URL_500 % date.strftime('%Y%m%d')
    try:
        response = requests.get(url, proxies={'http': PROXY_URL}, timeout=10)
    except Exception as e:
        raise e
    if response.status_code != 200:
        raise RuntimeError('request error')
    _parse_and_fill(response.content, url)


''' 在cron里面每天北京时间凌晨1点跑头一天
'''


def crawl_newest_from_168(now=None):
    now = now or tz.local_now()
    url = URL_168 % now.strftime('%Y-%m-%d')
    try:
        response = requests.get(url, proxies={'http': PROXY_URL}, timeout=10)
        resp_text = json.loads(response.text)
    except Exception as e:
        raise e
    if response.status_code != 200:
        return now
    _parse_and_fill_168(resp_text, url)
    return None


def crawl_newest(now=None):
    '''官网爬虫
    '''
    now = now or tz.local_now()
    refer = URL_500 % now.strftime('%Y%m%d')
    url = refer
    try:
        response = requests.get(url, timeout=5)
    except Exception:
        return now
    if response.status_code != 200:
        return now
    _parse_and_fill(response.content, refer)
    return None


def main(d):
    while True:
        try:
            crawl_from_opencai(LOTTERY_TYPE.JX_11X5)
        except Exception as e:
            logging.exception(u'%s error: %s' % (OPENCAI_LOTTERY_TYPES.get(LOTTERY_TYPE.JX_11X5), e))
        if d:
            break
        time.sleep(60)


if __name__ == '__main__':
    date = sys.argv[1] if len(sys.argv) > 1 else None
    main(date)
