# -*- coding: utf-8 -*-
import logging

from common.utils.decorator import sql_wrapper
from common.utils import db as utils
from common.preset.model.preset import Pay
from common import orm

_LOGGER = logging.getLogger(__name__)


@sql_wrapper
def get_pay_by_pay_type(pay_type):
    return Pay.query.filter(Pay.pay_type == pay_type).first()


@sql_wrapper
def get_pay(id):
    return utils.get(Pay, id)


@sql_wrapper
def upsert_pay(info, id=None):
    return utils.upsert(Pay, info, id)


@sql_wrapper
def list_pay(query_dct):
    return utils.list_object(query_dct, Pay)


@sql_wrapper
def delete_pay(id):
    utils.delete(Pay, id)


def get_pay_bonus_rate(type):
    pay = Pay.query.filter(Pay.pay_type == type).first()
    if pay:
        return pay.bonus_rate
    return 0


@sql_wrapper
def get_pay_preset_by_type(type):
    return Pay.query.filter(Pay.pay_type == type).first()


@sql_wrapper
def get_pay_type_to_title_map():
    preset_pays = orm.session.query(Pay.pay_type, Pay.title).all()
    return {item.pay_type: item.title for item in preset_pays}
