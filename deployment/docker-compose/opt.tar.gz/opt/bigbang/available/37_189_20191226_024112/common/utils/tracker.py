# coding=utf-8
import logging
from common.transaction.model import WITHDRAW_STATUS

_TRACKER = logging.getLogger('tracker')


def track_coupon(coupon, action):
    coupon.update({
        'type': 'coupon',
        'action': action
    })
    _TRACKER.info(coupon)


def track_recharge(user_id, price, channel):
    """
    充值
    :param user_id:
    :param price: float 金额
    :param channel: str 充值渠道
    :return:
    """
    _TRACKER.info({
        'type': 'recharge',
        'user_id': user_id,
        'price': price,
        'channel': channel
    })


def track_recharge_bonus(user_id, price):
    """
    充值奖金
    :param user_id:
    :param price: float 金额
    :param channel: str 充值渠道
    :return:
    """
    _TRACKER.info({
        'type': 'recharge_bonus',
        'user_id': user_id,
        'price': price,
    })


def track_withdraw(user_id, withdraw_type, price, status=WITHDRAW_STATUS.WAIT):
    """
    提现
    :param user_id: 
    :param withdraw_type: int 提现渠道 支付宝／银行 
    :param price: float 提现金额
    :param status: 提現狀態更新
    :return: 
    """
    _TRACKER.info({
        'type': 'withdraw',
        'user_id': user_id,
        'action': 'submit',
        'cash_price': price,
        'withdraw_type': withdraw_type,
        'status': status
    })


def track_active(user_id, cvc, aid, chn, ip=None, ua=None):
    _TRACKER.info({
        'type': 'active',
        'user_id': user_id,
        'cvc': cvc,
        'aid': aid,
        'chn': chn,
        'ip': ip,
        'ua': ua
    })


def track_win(user_id, activity_type, bet_type, price, bonus=0):
    """
    中奖
    :param user_id:  
    :param activity_type: 彩种 
    :param bet_type: 玩法
    :param price: 奖励金额
    :return: 
    """
    _TRACKER.info({
        'type': 'win',
        'user_id': user_id,
        'activity_type': activity_type,
        'bet_type': bet_type,
        'price': price,  # 奖励金额
        'bonus': bonus,  # 加奖金额
    })


def track_refund(user_id, activity_type, price, refund_type, bet_type):
    """
    退款，包括追号返款和撤单返款
    :param user_id: int 
    :param activity_type: int 彩种 
    :param price: float 退款金额
    :param refund_type: 1-追号返款， 2-撤单返款
    :return: 
    """
    _TRACKER.info({
        'type': 'refund',
        'user_id': user_id,
        'activity_type': activity_type,
        'price': price,
        'refund_type': refund_type,
        'bet_type': bet_type,
    })


def track_gain(activity_type, bet_price, win_price, bonus=0, user_id=None):
    """
    抽水统计，结算时记录
    :param activity_type: 彩种 
    :param bet_price: 投注金额
    :param win_price: 奖励金额
    :param bonus: 加奖
    :param user_id: 用户ID
    :return:
    """
    _TRACKER.info({
        'type': 'gain',
        'activity_type': activity_type,
        'bet_price': bet_price,  # 下注金额
        'win_price': win_price,  # 奖励金额
        'bonus': bonus,          # 加奖金额
        'user_id': user_id
    })


def track_black(user_id, reason):
    """
    拉黑用户
    :param user_id: int
    :param reason: str 拉黑原因
    :return: 
    """
    _TRACKER.info({
        'user_id': user_id,
        'type': 'black',
        'reason': reason
    })


def track_pay(user_id, activity_type, bet_type, price, is_virtual):
    """
    购买
    :param user_id:  
    :param activity_type: 彩种 
    :param bet_type: 玩法
    :param order_no: 订单号
    :param price: 奖励金额
    :return: 
    """
    _TRACKER.info({
        'type': 'pay',
        'user_id': user_id,
        'activity_type': activity_type,
        'bet_type': bet_type,
        'price': price,  # 奖励金额
    })


def track_register(user_id, aid, chn):
    _TRACKER.info({
        'type': 'register',
        'user_id': user_id,
        'aid': aid,
        'chn': chn
    })


def track_login(user_id, logon):
    _TRACKER.info({
        'type': 'login',
        'user_id': user_id,
        'logon': logon
    })


def track_system_recharge(user_id, amount):
    _TRACKER.info({
        'type': 'system_recharge',
        'user_id': user_id,
        'price': amount
    })


def track_metis(user_id, game_id, bet_amount, bet_result, invalid_amount, create_time,
                is_banker, bank_total_bet, bank_bet_result):
    lose_amount = 0
    if bet_result + bet_amount < 0:
        lose_amount = bet_result + bet_amount
    _TRACKER.info({
        'type': 'metis',
        'user_id': user_id,
        'game_id': game_id,
        'bet_amount': bet_amount,
        'bet_result': bet_result,
        'lose_amount': lose_amount,
        'invalid_amount': invalid_amount,
        'create_time': create_time,
        'is_bank': is_banker,
        'bank_total_bet': bank_total_bet,
        'bank_bet_result': bank_bet_result
    })


def track_imone(user_id, game_id, bet_amount, bet_result, create_time):
    _TRACKER.info({
        'type': 'imone',
        'user_id': user_id,
        'game_id': game_id,
        'bet_amount': bet_amount,
        'bet_result': bet_result,
        'create_time': create_time
    })


def track_imone_login(user_id, platform, login_balance, login_withdraw):
    _TRACKER.info({
        'type': 'imone_login',
        'user_id': user_id,
        'platform': platform,
        'login_balance': login_balance,
        'login_withdraw': login_withdraw
    })


def track_imone_logout(user_id, platform, logout_balance, logout_withdraw):
    _TRACKER.info({
        'type': 'imone_logout',
        'user_id': user_id,
        'platform': platform,
        'logout_balance': logout_balance,
        'logout_withdraw': logout_withdraw
    })
