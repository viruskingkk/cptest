# -*- coding: utf-8 -*-
# from decimal import *
#
# RATE = [
#     (5000, Decimal('0.015')),
#     (1000, Decimal('0.02')),
#     (100, Decimal('0.03'))
# ]
#
#
# def calc_withdraw_amount(user_id, cash_price):
#     cash_price = Decimal(cash_price)
#     if cash_price < 100:
#         return int(cash_price - 3)
#     else:
#         for money, rate in RATE:
#             if cash_price >= money:
#                 return int(cash_price * (1 - rate))
from common.transaction.model import Withdraw, WITHDRAW_STATUS
from common.utils.tz import get_utc_date


def _is_first_3_withdraw(user_id):
    today = get_utc_date()
    count = Withdraw.query.filter(Withdraw.user_id == user_id). \
        filter(Withdraw.status == WITHDRAW_STATUS.DONE). \
        filter(Withdraw.updated_at >= today).count()
    if count < 3:
        return True
    return False


def calc_withdraw_amount(user_id, cash_price):
    # 取消前3次免手续费的逻辑
    # if _is_first_3_withdraw(user_id):
    #     return int(cash_price)
    cash_price = int(cash_price)
    if cash_price < 100:
        return cash_price - 2
    return int(int(cash_price) * 0.98)
