# -*- coding: utf-8 -*-
from common.platform.common.model import PLATFORM_TYPE


def get_third_handler(platform):
    if platform == PLATFORM_TYPE.METIS:
        from common.platform.metis.handler import handler as metis_handler
        return metis_handler
    elif platform == PLATFORM_TYPE.AMETIS:
        from common.platform.ametis.handler import handler as ametis_handler
        return ametis_handler
    elif platform == PLATFORM_TYPE.ARES:
        from common.platform.ares.handler import handler as ares_handler
        return ares_handler
