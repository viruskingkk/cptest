# -*- coding: utf-8 -*-
import json
import time
import logging
from datetime import datetime, timedelta
from decimal import Decimal

from async import async_job
from common import orm, slave
from common.account.model.account import Account, BALANCE_TYPE
from common.coupon.model import AccountCoupon
from common.pay.model import PAY_STATUS, Pay, PAY_TYPE
from common.preset.db.pay import get_pay_bonus_rate
from common.transaction import calc_withdraw_amount
from common.transaction.model import (TRANSACTION_STATUS,
                                      TRANSACTION_TYPE, Withdraw,
                                      WITHDRAW_STATUS, WITHDRAW_TYPE, TITLE_MAPPER, TRANSACTION_SHARDING_CONFIG,
                                      TRANSACTION_SHARDING_COUNT, CHECK_STATUS, Transaction, RISK_STATUS)
from common.utils import exceptions as err
from common.utils import tracker
from common.utils import maestro_tracker
from common.utils.db import get_count
from common.utils.db import list_object
from common.utils.decorator import sql_wrapper, slave_wrapper
from common.utils.exceptions import DbError
from common.utils.helper import (
    get_orderby, parse_query_dct, paginate, generate_filter)
from common.utils.tz import local_now, utc_to_local_str, get_utc_date, date_str_before
from common.utils.api import check_params
from common.utils.currency import convert_yuan_to_hao, convert_hao_to_yuan
from common.cache.bull_cache import check_banker_lock, get_lock_amount, BULL_LOCK_RATIO
from sqlalchemy import func, or_
import copy
from common.prize.db import calc_first_award

_LOGGER = logging.getLogger(__name__)

_FRESH_AWARD_PRICE = 1.0

MAX_BONUS_RATE = 0.1
AVAILABLE_BONUS_PAY_TYPE = [
    PAY_TYPE.UNIONAGENCY,
    PAY_TYPE.UNIONAGENCY_V2_ALI,
    PAY_TYPE.UNIONAGENCY_V2_BANKCARD,
    PAY_TYPE.UNIONAGENCY_V2_WX,
]
MIN_BONUS_RATE_PAY_AMOUNT = 5


@sql_wrapper
def list_transaction(user_id, query_dct):
    return list_object(query_dct, get_sharding_transaction_table(user_id))


@sql_wrapper
def list_transaction(user_id, query_dct):
    table = get_sharding_transaction_table(user_id)
    query, total_count = list_object(query_dct, table, disable_paginate=True)
    total_income = query.with_entities(func.sum(table.price)).filter(table.price > 0).scalar()
    total_outcome = query.with_entities(func.sum(table.price)).filter(table.price < 0).scalar()
    query = paginate(query, query_dct)
    return query.all(), total_count, total_income, total_outcome


@slave_wrapper
def get_transactions(user_id, limit=0, offset=0, transaction_type=None, start_date=None):
    transaction_table = get_sharding_transaction_table(user_id)
    query = slave.session.query(transaction_table).filter(transaction_table.user_id == user_id).with_hint(transaction_table, 'USE INDEX (user_id)')

    if transaction_type is not None:
        if transaction_type == TRANSACTION_TYPE.IN:
            query = query.filter(transaction_table.type.in_([TRANSACTION_TYPE.IN]))
        elif transaction_type == TRANSACTION_TYPE.WITHDRAW:
            query = query.filter(
                transaction_table.type.in_([TRANSACTION_TYPE.WITHDRAW, TRANSACTION_TYPE.WITHDRAW_FAIL_REFUND]))
        elif transaction_type == TRANSACTION_TYPE.ACTIVITY:
            query = query.filter(
                transaction_table.type.in_([TRANSACTION_TYPE.SYSTEM_RECHARGE, TRANSACTION_TYPE.SYSTEM_CHASE,
                                            TRANSACTION_TYPE.PAY_BONUS, TRANSACTION_TYPE.RECHARGE_AWARD,
                                            TRANSACTION_TYPE.SPRING_FESTIVAL, TRANSACTION_TYPE.RANKING_AWARD,
                                            TRANSACTION_TYPE.LANTERN_AWARD]))
        elif transaction_type == TRANSACTION_TYPE.AWARD:
            query = query.filter(or_(transaction_table.type.op('&')(transaction_type),
                                     transaction_table.type == TRANSACTION_TYPE.THIRD_PLATFORM_UNFREEZE) > 0)

        else:
            query = query.filter(transaction_table.type.op('&')(transaction_type) > 0)
    if start_date is not None:
        query = query.filter(transaction_table.created_at >= start_date)
    query = query.order_by(transaction_table.updated_at.desc())
    if limit:
        query = query.limit(limit)
    if offset:
        query = query.offset(offset)
    return query.all()


@sql_wrapper
def add_pay_success_transaction(user_id, pay_id, pay_amount, extend):
    """
    充值成功
    """
    # update pay record status
    res = Pay.query.filter(Pay.id == pay_id).filter(
        Pay.status == PAY_STATUS.SUBMIT).update({
            'status': PAY_STATUS.DONE,
            'price': pay_amount,
            'updated_at': datetime.utcnow()
        })
    pay = Pay.query.filter(Pay.id == pay_id).first()
    bonus_rate = int(get_pay_bonus_rate(pay.pay_type)) * 0.01
    bonus_rate = validate_bonus_rate(pay.pay_type, bonus_rate, pay_amount)
    if res:
        award = calc_first_award(user_id, pay_amount)
        # if award create first_recharge award transaction
        if award:
            # 修改用户余额，并创建交易
            create_transaction({
                'user_id': user_id,
                'type': TRANSACTION_TYPE.RECHARGE_AWARD,
                'title': u'首充奖励',
                'extend': json.dumps({"amount": pay_amount}),
                'price': convert_yuan_to_hao(award),
                'balance_type': BALANCE_TYPE.BALANCE,
                'status': TRANSACTION_STATUS.DONE,
            })

            try:
                tracker.track_recharge_bonus(user_id, award)
            except:
                _LOGGER.exception('fail to track  first_recharge bouns')
            _LOGGER.info('user-{} took part in 188recharge_campaign'.format(user_id))

            try:
                maestro_tracker.track_maestro_platform_reward('first_recharge_' + str(pay.id), pay.user_id,
                                                              maestro_tracker.PLATFORM_REWARD_SUB_TYPE.CAMPAIGN,
                                                              maestro_tracker.PLATFORM_REWARD_THIRD_TYPE.FIRST_RECHARGE,
                                                              award,
                                                              int(datetime.strftime(datetime.now(), '%s')))
            except:
                _LOGGER.exception('user-{} pay_id-{} fail to track maestro first_recharge campaign'.format(user_id, pay.id))
        # if bonus_rate specified for type payment
        if bonus_rate:
            # 修改用户余额，并创建交易
            create_transaction({
                'user_id': user_id,
                'pay_id': pay_id,
                'type': TRANSACTION_TYPE.PAY_BONUS,
                'title': u'充值回馈',
                'extend': json.dumps(extend.get('ext'), ensure_ascii=False),
                'price': convert_yuan_to_hao(pay_amount * bonus_rate),
                'balance_type': BALANCE_TYPE.BALANCE,
                'status': TRANSACTION_STATUS.DONE,
            })

            tracker.track_recharge_bonus(user_id, pay_amount * bonus_rate)
            try:
                maestro_tracker.track_maestro_platform_reward('PayBonus' + str(pay.id), pay.user_id,
                                                              maestro_tracker.PLATFORM_REWARD_SUB_TYPE.PAY_BONUS,
                                                              maestro_tracker.PLATFORM_REWARD_THIRD_TYPE.PAY_BONUS,
                                                              pay_amount * bonus_rate,
                                                              int(datetime.strftime(datetime.now(), '%s')))
            except:
                _LOGGER.exception('user-{} fail to track maestro pay bonus'.format(user_id))

        # 修改用户余额，并创建交易
        create_transaction({
            'user_id': user_id,
            'pay_id': pay_id,
            'type': TRANSACTION_TYPE.IN,
            'title': u'充值',
            'extend': json.dumps(extend.get('ext'), ensure_ascii=False),
            'price': convert_yuan_to_hao(pay_amount),
            'balance_type': BALANCE_TYPE.BALANCE,
            'status': TRANSACTION_STATUS.DONE,
        })
        orm.session.commit()

        return True
    else:
        _LOGGER.warn(
            'add pay success transaction, concurrency occurred!, pay_id[%s]',
            pay_id)
    return False


@sql_wrapper
def add_pay_fail_transaction(user_id, pay_id, pay_amount, extend):
    """
    充值失败
    """
    # update pay record status
    res = Pay.query.filter(Pay.id == pay_id).filter(
        Pay.status == PAY_STATUS.SUBMIT).update({
            'status': PAY_STATUS.FAIL,
            'price': pay_amount,
            'updated_at': datetime.utcnow()
        })
    if res:
        account = Account.query.filter(Account.id == user_id).with_for_update().first()
        create_sharding_transaction(user_id, {'pay_id': pay_id,
                                              'type': TRANSACTION_TYPE.IN,
                                              'title': u'充值失败',
                                              'extend': json.dumps(extend.get('ext'), ensure_ascii=False),
                                              'price': 0 if not pay_amount else Decimal(pay_amount),
                                              'balance': account.balance,
                                              'status': TRANSACTION_STATUS.FAIL,
                                              })
        orm.session.commit()
        return True
    else:
        _LOGGER.warn(
            'add pay fail transaction, cocurrency occured!, pay_id[%s]',
            pay_id)
    return False


@sql_wrapper
def add_system_award_transaction(user_id, award_amount=_FRESH_AWARD_PRICE,
                                 title=u'派奖'):
    create_transaction({
        'user_id': user_id,
        'type': TRANSACTION_TYPE.AWARD,
        'title': title,
        'price': convert_yuan_to_hao(award_amount),
        'balance_type': BALANCE_TYPE.BALANCE,
        'status': TRANSACTION_STATUS.DONE,
    })
    orm.session.commit()
    _LOGGER.info('add system award, %s %s %s', user_id, award_amount, title)


@sql_wrapper
def get_consume(user_id):
    transaction_table = get_sharding_transaction_table(user_id)
    amount = orm.session.query(orm.func.sum(transaction_table.price)). \
        filter(transaction_table.user_id == user_id). \
        filter(transaction_table.status == TRANSACTION_STATUS.DONE). \
        filter(transaction_table.type == TRANSACTION_TYPE.BALANCE_BUY).first()[0]
    return amount


@sql_wrapper
def get_award(user_id):
    transaction_table = get_sharding_transaction_table(user_id)
    amount = orm.session.query(orm.func.sum(transaction_table.price)). \
        filter(transaction_table.user_id == user_id). \
        filter(transaction_table.status == TRANSACTION_STATUS.DONE). \
        filter(transaction_table.type == TRANSACTION_TYPE.AWARD).first()[0]
    return amount


@sql_wrapper
def create_withdraw(user_id, target_type, amount, target_info):
    account = Account.query.with_for_update().filter(Account.id == user_id).one()
    if account.balance < amount:
        raise err.ResourceInsufficient(u'余额不够')
    if account.withdraw < amount:
        raise err.ResourceInsufficient(u'可提现金额不够')

    trans, _ = create_transaction({
        'user_id': user_id,
        'type': TRANSACTION_TYPE.WITHDRAW,
        'title': u'提现',
        'price': -convert_yuan_to_hao(amount),
        'balance_type': BALANCE_TYPE.BALANCE,
        'status': TRANSACTION_STATUS.DONE,
    })

    withdraw = Withdraw()
    withdraw.trans_id = trans['id']
    withdraw.user_id = user_id
    withdraw.status = WITHDRAW_STATUS.WAIT
    withdraw.price = amount
    withdraw.target_type = target_type
    withdraw.after_cash = account.withdraw
    withdraw.extend = json.dumps({'info': target_info}, ensure_ascii=False)
    withdraw.balance = account.balance
    withdraw.save(auto_commit=False)

    orm.session.commit()
    try:
        maestro_tracker.track_maestro_withdraw_apply(
            withdraw_id=withdraw.id, user_id=withdraw.user_id, withdraw_type=withdraw.target_type,
            price=amount, real_price=calc_withdraw_amount(user_id, amount),
            _event_time=int(time.mktime(datetime.now().timetuple())))
    except Exception as e:
        _LOGGER.exception('track maestro withdraw apply fail, withdraw id: %s', withdraw.id)
    tracker.track_withdraw(user_id, target_type, calc_withdraw_amount(user_id, amount))
    return withdraw


def parse_query_title(query_dct):
    title_filter_dct = json.loads(query_dct['title'])
    join_filter = []
    if 'multiselect-all' in title_filter_dct['$in']:
        query_dct.pop('title', None)
    else:
        for title in title_filter_dct['$in'][:]:
            t = title.split(',')
            if len(t) == 2:
                filter = {"$and": [
                    {"title": {"$eq": t[0]}},
                    {"type": {"$eq": int(t[1])}}
                    ]}
                join_filter.append(filter)
                title_filter_dct['$in'].remove(title)
            elif title == u'红包抵扣':
                filter = {"$and": [
                    {"extend": {"$like": '%coupon_price%'}},
                    {"type": {"$eq": 4}}
                    ]}
                join_filter.append(filter)
                title_filter_dct['$in'].remove(title)
        if title_filter_dct['$in'] and join_filter:
            title_filter_dct = {"title": title_filter_dct}
            join_filter.append(title_filter_dct)
        if join_filter:
            query_dct['$or'] = json.dumps(join_filter)
            query_dct.pop('title', None)
        else:
            query_dct['title'] = json.dumps(title_filter_dct)
    return query_dct


def map_transaction_title(items):
    for item in items:
        if u'红包' in item.title:
            item.title = u'红包抵扣'
        elif item.title in TITLE_MAPPER:
            if type(TITLE_MAPPER[item.title]) is dict:
                item.title = TITLE_MAPPER[item.title][item.type]
            else:
                item.title = TITLE_MAPPER[item.title]
        # else:
        #    item.title = u'其他'
    return items


def get_user_withdraw(user_id, limit, offset, in_two_month=False):
    query = Withdraw.query.filter(Withdraw.user_id == user_id)
    if in_two_month:
        create_at = date_str_before(days=60)
        query = query.filter(Withdraw.created_at > create_at)

    query = query.order_by(Withdraw.id.desc())
    if limit:
        query = query.limit(limit)
    if offset:
        query = query.offset(offset)
    return query.all()


def list_withdraw(query_dct):
    return list_object(query_dct, Withdraw)


def done_withdraw(ids):
    Withdraw.query.filter(Withdraw.id.in_(ids)).update({
        'status': WITHDRAW_STATUS.DONE
    })
    orm.session.commit()


_ROAD_MAP = {
    WITHDRAW_STATUS.WAIT: [WITHDRAW_STATUS.BACK, WITHDRAW_STATUS.FORBIDDEN],
    WITHDRAW_STATUS.FAIL: [WITHDRAW_STATUS.BACK, WITHDRAW_STATUS.FORBIDDEN],
    WITHDRAW_STATUS.AUTO: [WITHDRAW_STATUS.BACK, WITHDRAW_STATUS.FORBIDDEN],
    WITHDRAW_STATUS.FORBIDDEN: [WITHDRAW_STATUS.BACK],
    WITHDRAW_STATUS.BACK: [],
    WITHDRAW_STATUS.DONE: [],
}

CAN_BE_BACK_STATUS = [WITHDRAW_STATUS.WAIT, WITHDRAW_STATUS.FAIL,
                      WITHDRAW_STATUS.FORBIDDEN, WITHDRAW_STATUS.AUTO]


@sql_wrapper
def check_withdraw(admin_id, withdraw_id, check_status, reason=None):
    update_info = {}
    update_info.update({
        'manual_check_info': {
            'admin_id': admin_id,
            'reason': reason,
            'check_date': local_now().strftime('%Y-%m-%d %H:%M:%S')
        }
    })
    record = Withdraw.query.with_for_update().filter(
        Withdraw.id == withdraw_id).first()
    record.check_status = check_status
    if record and record.status in (WITHDRAW_STATUS.WAIT,):
        updated_info = json.loads(record.extend)
        updated_info.update(update_info)
        if check_status == CHECK_STATUS.SUCC:
            record.status = WITHDRAW_STATUS.AUTO
        record.extend = json.dumps(updated_info, ensure_ascii=False)
    record.save()
    try:
        result = 'passed' if check_status == CHECK_STATUS.SUCC else 'rejection'
        maestro_tracker.track_maestro_withdraw_personal_check(
            record.id, record.user_id, record.target_type, record.price,
            record.real_price or calc_withdraw_amount(record.user_id, record.price),
            admin_id, result, int(datetime.strftime(record.created_at, '%s'))
        )
    except:
        _LOGGER.exception('track maestro withdraw_personal_check fail, withdraw id: %s', record.id)


@sql_wrapper
def batch_check_withdraws(admin_id, ids, check_status):
    if not ids:
        return
    update_info = {}
    update_info.update({
        'manual_check_info': {
            'admin_id': admin_id,
            'check_date': local_now().strftime('%Y-%m-%d %H:%M:%S')
        }
    })
    for id in ids:
        record = Withdraw.query.with_for_update().filter(
            Withdraw.id == id).first()
        record.check_status = check_status
        if record and record.status in (WITHDRAW_STATUS.WAIT,):
            updated_info = json.loads(record.extend)
            updated_info.update(update_info)
            if check_status == CHECK_STATUS.SUCC:
                record.status = WITHDRAW_STATUS.AUTO
            record.extend = json.dumps(updated_info, ensure_ascii=False)
        record.save()
        try:
            result = 'passed' if check_status == CHECK_STATUS.SUCC else 'rejection'
            maestro_tracker.track_maestro_withdraw_personal_check(
                record.id, record.user_id, record.target_type, record.price,
                record.real_price or calc_withdraw_amount(record.user_id, record.price),
                admin_id, result, int(datetime.strftime(record.created_at, '%s'))
            )
        except:
            _LOGGER.exception('track maestro withdraw_personal_check fail, withdraw id: %s', record.id)


def update_withdraw_status(admin_id, id, info):
    new_status = info['status']
    old_status = get_withdraw(id).status
    if _ROAD_MAP[old_status] == 'all' or new_status in _ROAD_MAP[old_status]:
        if new_status == WITHDRAW_STATUS.BACK:
            withdraw_back(admin_id, id, info['reason'])
            async_job.stats_withdraw.delay([id])
            return
        else:
            item = Withdraw.query.filter(Withdraw.id == id).with_lockmode('update').first()
            extend = json.loads(item.extend)
            if new_status == WITHDRAW_STATUS.AUTO:
                extend.update({
                    'manual_auto_trans_info': {
                        'admin_id': admin_id,
                        'pay_date': local_now().strftime('%Y-%m-%d %H:%M:%S'),
                    }
                })
            if new_status == WITHDRAW_STATUS.DONE:
                extend.update({
                    'manual_done_trans_info': {
                        'admin_id': admin_id,
                        'pay_date': local_now().strftime('%Y-%m-%d %H:%M:%S'),
                    }
                })
            if new_status == WITHDRAW_STATUS.FORBIDDEN:
                if item.check_status == CHECK_STATUS.WAITING:
                    item.check_status = CHECK_STATUS.FAIL
                extend.update({
                    'manual_forbidden_trans_info': {
                        'admin_id': admin_id,
                        'pay_date': local_now().strftime('%Y-%m-%d %H:%M:%S'),
                    }
                })

            item.status = new_status
            item.extend = json.dumps(extend, ensure_ascii=False)
            item.save()
            if new_status == WITHDRAW_STATUS.FORBIDDEN:
                tracker.track_withdraw(item.user_id, item.target_type, calc_withdraw_amount(item.user_id, item.price),
                                       status=WITHDRAW_STATUS.FORBIDDEN)
                tracker.track_withdraw(item.user_id, item.target_type, -calc_withdraw_amount(item.user_id, item.price))
    else:
        raise err.ParamError(u'无效操作，请检查订单状态!')


def get_last_info(user_id, target_type=None):
    query = Withdraw.query.filter(
        Withdraw.user_id == user_id).order_by(Withdraw.id.desc())
    if target_type is not None:
        query = query.filter(Withdraw.target_type == target_type)
    return query.first()


@sql_wrapper
def batch_update_withdraws(admin_id, ids, status):
    if not ids:
        return
    update_info = {}
    if status == WITHDRAW_STATUS.DONE:
        update_info.update({
            'manual_trans_info': {
                'admin_id': admin_id,
                'pay_date': local_now().strftime('%Y-%m-%d %H:%M:%S'),
            }
        })
    for id in ids:
        record = Withdraw.query.with_for_update().filter(
            Withdraw.id == id).first()
        if record:
            updated_info = json.loads(record.extend)
            updated_info.update(update_info)
            record.status = status
            record.extend = json.dumps(updated_info, ensure_ascii=False)
            record.save()


@sql_wrapper
def get_withdraw(withdraw_id):
    return Withdraw.query.filter(Withdraw.id == withdraw_id).first()


@sql_wrapper
def get_withdraw_count_amount(user_id, target_type=CHECK_STATUS.WAITING):
    query = Withdraw.query.filter(
        Withdraw.user_id == user_id, Withdraw.target_type == target_type)
    total_amount = 0
    if query:
        total_amount = query.with_entities(func.sum(Withdraw.price)).scalar() or 0
        total_count = get_count(query)
    return total_amount, total_count


@sql_wrapper
def get_cash_records(user_id, limit=0, offset=0):
    query = Withdraw.query.filter(Withdraw.user_id == user_id)
    query = query.order_by(Withdraw.created_at.desc())
    if limit > 0:
        query = query.limit(limit)
    if offset > 0:
        query = query.offset(offset)
    return query.all()


@sql_wrapper
def update_withdraw(admin_id, record_id, status):
    item = Withdraw.query.filter(Withdraw.id == record_id).with_lockmode('update').first()
    item.status = status
    updated_info = json.loads(item.extend or '{}')
    if status == WITHDRAW_STATUS.DONE:
        updated_info.update({
            'manual_trans_info': {
                'admin_id': admin_id,
                'pay_date': local_now().strftime('%Y-%m-%d %H:%M:%S'),
            }
        })
    item.withdraw_info = json.dumps(updated_info, ensure_ascii=False)
    item.save()


@sql_wrapper
def withdraw_back(admin_id, withdraw_id, reason):
    withdraw = Withdraw.query.with_for_update().filter(
        Withdraw.status.in_(CAN_BE_BACK_STATUS)).filter(
        Withdraw.id == withdraw_id).one()
    before_status = withdraw.status
    withdraw.status = WITHDRAW_STATUS.BACK

    # 提现失败返款
    _, account = create_transaction({
        'user_id': withdraw.user_id,
        'type': TRANSACTION_TYPE.WITHDRAW_FAIL_REFUND,
        'title': u'提现失败返款',
        'price': convert_yuan_to_hao(withdraw.price),
        'balance_type': BALANCE_TYPE.BALANCE,
        'status': TRANSACTION_STATUS.DONE,
    })

    extend = json.loads(withdraw.extend)

    if before_status != WITHDRAW_STATUS.FORBIDDEN:
        before_status = WITHDRAW_STATUS.WAIT
    if withdraw.check_status == CHECK_STATUS.WAITING:
        withdraw.check_status = CHECK_STATUS.FAIL
        if 'manual_check_info' not in extend:
            extend['manual_check_info'] = {
                'admin_id': admin_id,
                'reason': u'返款状态自动更新',
                'check_date': local_now().strftime('%Y-%m-%d %H:%M:%S')
            }
    extend['back_reason'] = reason
    extend['back_trans_info'] = {
        'admin_id': admin_id,
        'back_date': local_now().strftime('%Y-%m-%d %H:%M:%S'),
    }
    withdraw.extend = json.dumps(extend, ensure_ascii=False)
    withdraw.balance = account['balance']
    withdraw.save(auto_commit=False)
    orm.session.commit()
    tracker.track_withdraw(withdraw.user_id, withdraw.target_type,
                           -calc_withdraw_amount(withdraw.user_id, withdraw.price), before_status)
    try:
        maestro_tracker.track_maestro_withdraw_return(
            withdraw.id, withdraw.user_id, withdraw.target_type, withdraw.price, withdraw.real_price,
            reason, int(datetime.strftime(withdraw.updated_at, '%s')))
    except:
        _LOGGER.exception('track maestro withdraw fail, withdraw id: %s', withdraw_id)

    async_job.stats_withdraw.delay([withdraw_id])


def validate_bonus_rate(pay_type, bonus_rate, pay_amount):
    if bonus_rate > MAX_BONUS_RATE or bonus_rate < 0:
        _LOGGER.info('Invalid bonus rate, bonus rate is 0 now')
        return 0
    if pay_amount < MIN_BONUS_RATE_PAY_AMOUNT:
        _LOGGER.info('Pay amount too low, bonus rate is 0 now')
        return 0
    return bonus_rate


def create_sharding_transaction(user_id, attributes):
    transaction_table = get_sharding_transaction_table(user_id)
    instance = transaction_table()
    instance.user_id = user_id
    for k, v in attributes.iteritems():
        if hasattr(transaction_table, k) and k not in ('updated_at', 'created_at'):
            setattr(instance, k, v)
        else:
            raise DbError('illegal transaction attribute: %s' % k)
    instance.save(auto_commit=False)
    orm.session.flush()
    return instance


def get_sharding_transaction_table(user_id):
    table = TRANSACTION_SHARDING_CONFIG.get(int(user_id) % TRANSACTION_SHARDING_COUNT)
    if not table:
        raise DbError('transaction table not found. user_id: %s' % user_id)
    return table


def get_last_success_pay(user_id):
    return Pay.query.filter(Pay.user_id == user_id). \
        filter(Pay.status == PAY_STATUS.DONE). \
        order_by(Pay.updated_at.desc()).first()


def _decrease_from_out_to_in(amount_list, decr):
    # 从amount_list里每一项扣钱，规则是优先扣取前面的，当前不够时，再扣取后面项的
    first = amount_list[0]
    result = [first - decr]
    for each in amount_list[1:]:
        diff = first - each
        result.append(each if decr <= diff else (first - decr))
    return result


def _increase_balance(user_id, amount, balance_type=BALANCE_TYPE.BALANCE, balance_dct={}):
    """
    增加用户账号余额
    :param user_id:
    :param amount: 增加的钱，单位是毫
    :param balance_type: BALANCE_TYPE
    :return:
    """
    assert user_id > 0
    assert isinstance(amount, int)
    _LOGGER.info('user_id increase account amount: %s %s %s %s' %
                 (user_id, amount, balance_type, balance_dct))

    account = Account.query.with_for_update().populate_existing().filter(Account.id == user_id).first()

    if balance_type == BALANCE_TYPE.SPECIFIED:
        assert min(value for value in balance_dct) >= 0
    elif amount <= 0:
        _LOGGER.info('user_id increase less zero amount transaction: %s %s' % (user_id, amount))
        return account

    balance = convert_yuan_to_hao(account.balance)
    withdraw = convert_yuan_to_hao(account.withdraw)
    if balance_type != BALANCE_TYPE.SPECIFIED:
        balance += amount

    if balance_type == BALANCE_TYPE.AGENT:
        withdraw += amount
    elif balance_type == BALANCE_TYPE.WITHDRAW:
        withdraw += amount
    elif balance_type == BALANCE_TYPE.SPECIFIED:
        balance += balance_dct.get('balance', 0)
        withdraw += balance_dct.get('withdraw', 0)
    account.balance = convert_hao_to_yuan(balance)
    account.withdraw = convert_hao_to_yuan(withdraw)
    account.save(auto_commit=False)
    orm.session.flush()
    _LOGGER.info('the current account: %s %s' % (account.balance, account.withdraw))
    return account


def _decrease_balance(user_id, amount, balance_type=BALANCE_TYPE.BALANCE):
    """
    减少用户账号余额
    :param user_id:
    :param amount: 扣除的钱，单位是毫
    :param balance_type: BALANCE_TYPE
    :return: (decr_balance, decr_withdraw) 返回2个余额分别实际扣减的金额， 单位是分
    """
    assert user_id > 0
    assert isinstance(amount, int)
    assert balance_type in [BALANCE_TYPE.BALANCE, BALANCE_TYPE.WITHDRAW, BALANCE_TYPE.AGENT]
    _LOGGER.info('user_id decrease account amount: %s %s %s' % (user_id, amount, balance_type))
    if amount <= 0:
        _LOGGER.info('user_id decrease less zero amount transaction: %s %s' % (user_id, amount))
        return
    account = Account.query.with_for_update().populate_existing().filter(Account.id == user_id).first()
    balance = convert_yuan_to_hao(account.balance)
    withdraw = convert_yuan_to_hao(account.withdraw)

    if balance < withdraw:
        # 可提现余额比余额还多，属于异常情况，在这里记录异常情况，并修改可提现余额
        _LOGGER.error('user account balance data error: %s %s %s' % (user_id, balance, withdraw))
        withdraw = (int(balance / 100)) * 100

    if balance < amount:
        _LOGGER.info('user id : {},  balance {} < amount {}'.format(user_id, balance, amount))
        raise err.ResourceInsufficient(u'当前余额不足')
    if check_banker_lock(user_id):
        raise err.LockError('bull banker lock')
    if balance - amount < BULL_LOCK_RATIO * convert_yuan_to_hao(get_lock_amount(user_id)):
        raise err.BalanceInsufficient(u'账户余额不足')
    elif balance_type == BALANCE_TYPE.WITHDRAW:
        if withdraw < amount:
            raise err.ParamError(u'{}可提现余额不足:仅有{}'.format(user_id, account.withdraw))
        balance -= amount
        withdraw -= amount
    elif balance_type == BALANCE_TYPE.BALANCE:
        balance, withdraw = _decrease_from_out_to_in([balance, withdraw], amount)
    account.balance = convert_hao_to_yuan(balance)
    account.withdraw = convert_hao_to_yuan(withdraw)
    account.save(auto_commit=False)
    orm.session.flush()
    _LOGGER.info('the current account: %s %s' % (account.balance, account.withdraw))
    return account


def get_out_trans_id(out_trans_id):
    query = Transaction.query.filter(Transaction.out_trans_id == out_trans_id).first()
    if query:
        return False
    return True


def create_transaction(transaction_data):
    """
    创建交易，根据给定的参数创建交易表，并修改用户的🈷️余额、可提现余额
    :param transaction_data: 字典参数，其中包括用户ID、交易类型、交易名、交易金额（单位为毫）、余额类型
    根据不同的余额类型，做出不同的余额操作，见 BALANCE_TYPE
    :return: 返回此次交易之后的交易信息、用户信息
    """
    data = copy.deepcopy(transaction_data)
    check_params(data, ['user_id', 'type', 'title', 'price', 'balance_type'])
    assert data['balance_type'] in BALANCE_TYPE.to_dict()
    if data['balance_type'] == BALANCE_TYPE.SPECIFIED:
        check_params(data, ['balance_dct'])
        for key in data.get('balance_dct', {}):
            assert data['balance_dct'][key] >= 0
    # 去掉对交易金额为0的报错
    # else:
    #     assert data['price'] != 0

    if data.get('out_trans_id'):
        query = get_out_trans_id(data.get('out_trans_id'))
        if not query:
            raise err.ParamError(u'交易重复')

    # start transaction
    amount = data['price']
    if amount >= 0 or data['balance_type'] == BALANCE_TYPE.SPECIFIED:
        account = _increase_balance(data['user_id'], amount, data['balance_type'], data.get('balance_dct', {}))
    elif amount < 0:
        account = _decrease_balance(data['user_id'], -amount, data['balance_type'])
    data['price'], data['balance'] = convert_hao_to_yuan(amount), account.balance
    # insert transaction
    data.pop('balance_type')
    trans = create_sharding_transaction(data['user_id'], data)
    data['id'] = trans.id
    return trans.as_dict(), account.as_dict()


def check_trans_amount(uid, item):
    try:
        # 检查用户的3天内的交易流水表，查看交易流水表是否线性变化
        start_day = datetime.utcnow() - timedelta(days=3)
        trans = get_transactions_for_check(int(uid), start_day)
        pre_item = None
        total = 0
        for item in trans:
            if pre_item:
                dis = pre_item.balance + item.price - item.balance
                if abs(dis) > 0.001:
                    total = total + dis
            pre_item = item
        if total > 10:
            _LOGGER.error('user %s trans checkout error, amount %s' % (uid, total))
        return total
    except Exception as e:
        _LOGGER.exception(e)
        return 0


@slave_wrapper
def get_transactions_for_check(user_id, start_date=None):
    trans_table = get_sharding_transaction_table(user_id)
    query = trans_table.query.filter(trans_table.user_id == user_id)
    if start_date is not None:
        query = query.filter(trans_table.created_at >= start_date)
    query = query.order_by(trans_table.id.asc())
    return query.all()
