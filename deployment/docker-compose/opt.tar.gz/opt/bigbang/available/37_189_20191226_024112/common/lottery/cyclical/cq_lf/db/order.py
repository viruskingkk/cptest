# -*- coding: utf-8 -*-
from functools import partial

from common.lottery import LOTTERY_TYPE
from common.lottery.cyclical.abstract import order as base
from common.utils.decorator import sql_wrapper

get_order = sql_wrapper(
    partial(base.get_order, LOTTERY_TYPE.CQ_LF))

cancel_orders = sql_wrapper(
    partial(base.cancel_orders, LOTTERY_TYPE.CQ_LF))

OrderPayer = base.OrderPayer(LOTTERY_TYPE.CQ_LF)  # 是一个单例，而不是类，命名格式为了保持兼容
