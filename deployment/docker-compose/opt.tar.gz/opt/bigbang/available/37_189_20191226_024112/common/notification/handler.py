# coding=utf-8
import json

from common.notification.templates import (
    REWARD_CHECKING, REWARD_CHECKED, WITHDRAW_SUCCESS_TEMPLATE, REFUND_TEMPLATE, WITHDRAW_BACK_TEMPLATE,
    VERIFY_SUCCESSFULLY, AWARD_SUCCESSFULLY, RECHARGE_SUCCESSFULLY, WINNER_RANKING_AWARD_DAILY,
    WINNER_RANKING_AWARD_WEEKLY, WINNER_RANKING_AWARD_TOTAL, OFFLINE_RECHARGE_SUCCESSFULLY,
    OFFLINE_RECHARGE_FAIL, OFFLINE_RECHARGE_APPLY, REPLY_FEEDBACK, RECHARGE_IPHONE, SPRING_PART,
    SPRING_RANK, LANTERN_IPHONE, LANTERN_AMOUNT, LANTERN_RECHARGE_APPEAL_SUCCESS, LANTERN_RECHARGE_APPEAL_FAIL)
from common.notification.model import NOTIFY_TYPE
from common.notification import db as notification_db
from common.cache import redis_cache
from common.lottery.cyclical import ORDER_STATUS
from common.utils.exceptions import ServerError
from common.notification.model import CREATED_BY_TYPE


def notify_win(user_id, order_status, info):
    notify_type = NOTIFY_TYPE.AWARD
    if order_status == ORDER_STATUS.WINNED:
        template = REWARD_CHECKED
        redis_cache.increase_unread_notify_count(user_id, notify_type)
    else:
        template = REWARD_CHECKING
    generate_user_notification(user_id, notify_type, template, info)


def notify_withdraw_success(user_id, info):
    template = WITHDRAW_SUCCESS_TEMPLATE
    generate_user_notification(user_id, NOTIFY_TYPE.INSIDE, template, info)


def notify_award_success(user_id, campaign_name, game_type, price):
    template = AWARD_SUCCESSFULLY
    info = {
        'campaign': campaign_name,
        'type': game_type,
        'price': price
    }
    generate_user_notification(user_id, NOTIFY_TYPE.INSIDE, template, info)


def notify_offline_pay_apply(user_id, price):
    template = OFFLINE_RECHARGE_APPLY
    info = {
        'price': price,
    }
    generate_user_notification(user_id, NOTIFY_TYPE.INSIDE, template, info)


def notify_offline_pay_fail(user_id, price, reason='未知'):
    template = OFFLINE_RECHARGE_FAIL
    info = {
        'price': price,
        'reason': reason
    }
    generate_user_notification(user_id, NOTIFY_TYPE.INSIDE, template, info)


def notify_feedback(user_id, reply_content, feedback_content, created_at):
    template = REPLY_FEEDBACK
    info = {
        'reply_content': reply_content,
        'feedback_content': feedback_content,
        'created_at': created_at
    }
    return generate_user_notification(user_id, NOTIFY_TYPE.INSIDE, template, info, CREATED_BY_TYPE.CONSOLE)


def notify_offline_pay_success(user_id, price):
    template = OFFLINE_RECHARGE_SUCCESSFULLY
    info = {
        'price': price
    }
    generate_user_notification(user_id, NOTIFY_TYPE.INSIDE, template, info)


def notify_winner_rank_daily(user_id, date, rank, price):
    template = WINNER_RANKING_AWARD_DAILY
    info = {
        'date': date,
        'rank': rank,
        'price': price
    }
    generate_user_notification(user_id, NOTIFY_TYPE.INSIDE, template, info)


def notify_winner_rank_weekly(user_id, rank, price):
    template = WINNER_RANKING_AWARD_WEEKLY
    info = {
        'rank': rank,
        'price': price
    }
    generate_user_notification(user_id, NOTIFY_TYPE.INSIDE, template, info)


def notify_winner_rank_total(user_id, rank, price):
    template = WINNER_RANKING_AWARD_TOTAL
    info = {
        'rank': rank,
        'price': price
    }
    generate_user_notification(user_id, NOTIFY_TYPE.INSIDE, template, info)


def notify_recharge_success(user_id, campaign_name, price):
    template = RECHARGE_SUCCESSFULLY
    info = {
        'campaign': campaign_name,
        'price': price
    }
    generate_user_notification(user_id, NOTIFY_TYPE.INSIDE, template, info)


def notify_withdraw_back(user_id, info):
    template = WITHDRAW_BACK_TEMPLATE
    generate_user_notification(user_id, NOTIFY_TYPE.INSIDE, template, info)


def notify_refund(user_id, info):
    template = REFUND_TEMPLATE
    generate_user_notification(user_id, NOTIFY_TYPE.INSIDE, template, info)


def notify_verify_successfully(user_id, info):
    template = VERIFY_SUCCESSFULLY
    generate_user_notification(user_id, NOTIFY_TYPE.INSIDE, template, info)


def generate_user_notification(user_id, notify_type, template, info, create_by=None):
    if not user_id:
        raise ServerError('user_id is None')
    content = {'title': template['title'].format(**info),
               'body': template['body'].format(**info),
               'tag': template['tag']}
    content = json.dumps(content, ensure_ascii=False)
    return notification_db.create_user_notification(user_id, notify_type, content, create_by)


def notify_recharge_iphone_win(user_id):
    template = RECHARGE_IPHONE
    content = {}
    content['title'] = template['title']
    content['body'] = template['body']
    content['tag'] = template['tag']
    content = json.dumps(content, ensure_ascii=False)
    return notification_db.create_user_notification(user_id, NOTIFY_TYPE.INSIDE, content)


def notify_spring_part(user_id, price):
    template = SPRING_PART
    info = {'price': price}
    content = {
        'title': template['title'],
        'body': template['body'].format(**info),
        'tag': template['tag']
    }
    content = json.dumps(content, ensure_ascii=False)
    notification_db.create_user_notification(
        user_id, NOTIFY_TYPE.INSIDE, content)


def notify_spring_rank(user_id, price):
    template = SPRING_RANK
    info = {'price': price}
    content = {
        'title': template['title'],
        'body': template['body'].format(**info),
        'tag': template['tag']
    }
    content = json.dumps(content, ensure_ascii=False)
    notification_db.create_user_notification(
        user_id, NOTIFY_TYPE.INSIDE, content)


def notify_lantern_iphone_win(user_id):
    template = LANTERN_IPHONE
    content = {}
    content['title'] = template['title']
    content['body'] = template['body']
    content['tag'] = template['tag']
    content = json.dumps(content, ensure_ascii=False)
    return notification_db.create_user_notification(user_id, NOTIFY_TYPE.INSIDE, content)


def notify_lantern_amount_win(user_id, amount):
    template = LANTERN_AMOUNT
    content = {}
    award = {'amount': amount}
    content['title'] = template['title']
    content['body'] = template['body'].format(**award)
    content['tag'] = template['tag']
    content = json.dumps(content, ensure_ascii=False)
    return notification_db.create_user_notification(user_id, NOTIFY_TYPE.INSIDE, content)


def notify_recharge_appeal_success(user_id, order_id, amount):
    template = LANTERN_RECHARGE_APPEAL_SUCCESS
    content = {}
    params = {'order_id': order_id, 'amount': amount}
    content['title'] = template['title']
    content['body'] = template['body'].format(**params)
    content['tag'] = template['tag']
    content = json.dumps(content, ensure_ascii=False)
    return notification_db.create_user_notification(user_id, NOTIFY_TYPE.INSIDE, content)


def notify_recharge_appeal_fail(user_id, order_id, amount, reason_failure):
    template = LANTERN_RECHARGE_APPEAL_FAIL
    content = {}
    params = {'order_id': order_id, 'amount': amount, 'reason_failure': reason_failure}
    content['title'] = template['title']
    content['body'] = template['body'].format(**params)
    content['tag'] = template['tag']
    content = json.dumps(content, ensure_ascii=False)
    return notification_db.create_user_notification(user_id, NOTIFY_TYPE.INSIDE, content)
