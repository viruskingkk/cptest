# -*- coding: utf-8 -*-
from django.conf import settings
from common import orm
from common.utils.types import Enum

RECHARGE_STATUS = Enum({
    "ONGOING": (1L, u"处理中"),
    "SUCC": (2L, u"充值成功"),
    "FAIL": (4L, u"充值失败"),
})

RECHARGE_TYPE = Enum({
    "ALIPAY": (1L, u"agent_alipay"),
    "BANKCARD": (2L, u"agent_union"),
    "WECHATPAY": (3L, u"agent_wechat"),
})

RECHARGER_RULE = {
    1: {
        'alipay_order_id': str,
        'name': unicode,
        'uid': str,
    },
    2: {
        'name': unicode,
        'bank_no': str,
        'price': float,
        'time': str,
        'remark': unicode,
    },
    3: {
        'nickname': unicode,
        'wechat_no': str,
        'price': float,
        'time': str,
        'remark': unicode,
    }
}

RECHARGEE_INFO = {
    1: [{
        'alipay_no': 'wangkai0921@gmail.com',
        'name': u'成都游技网络有限公司',
        'qrcode': '',
        'qrlink': 'https://qr.alipay.com/FKX04142KPCB9FZAPZX4B6'
    }],
    2: [{
        'name': u'王',
        'bank_no': '6200 0000 0000 0000',
        'bank_addr': u'中国银行',
    }],
    3: [{
        'wechat_no': 'lovecat0926',  # ' '17070372050',
        'name': u'万豪～香草',
        'qrcode': settings.QINIU_BUCKETS['default'] + 'dailichongzhi.png?v=1.3'
    }]
}

EXTRA_AMOUNT = [(1000, 1999, 10), (2000, 2999, 20), (3000, 3999, 30),
                (4000, 4999, 40), (5000, 5999, 88), (6000, 6999, 98),
                (7000, 7999, 108), (8000, 8999, 118), (9000, 9999, 128),
                (10000, 1000000, 188)]


class RechargeApply(orm.Model):
    """
    自助充值记录
    CREATE TABLE `recharge_apply` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `user_id` int(11) NOT NULL,
      `recharge_type` tinyint(4) NOT NULL,
      `recharger_info` text COLLATE utf8mb4_unicode_ci NOT NULL,
      `rechargee_info` text COLLATE utf8mb4_unicode_ci NOT NULL,
      `status` tinyint(4) DEFAULT '1',
      `pay_id` bigint(20) DEFAULT NULL,
      `pay_amount` float DEFAULT NULL,
      `third_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
      `admin_id` int(11) DEFAULT NULL,
      `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
      PRIMARY KEY (`id`),
      UNIQUE KEY `third_id` (`third_id`),
      KEY `user_id` (`user_id`),
      KEY `recharge_type` (`recharge_type`,`status`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    """
    __tablename__ = "recharge_apply"
    id = orm.Column(orm.Integer, primary_key=True)
    user_id = orm.Column(orm.Integer)
    recharge_type = orm.Column(orm.Integer)
    recharger_info = orm.Column(orm.TEXT)  # 充值方信息. json
    rechargee_info = orm.Column(orm.TEXT)  # 被充值方信息. json
    status = orm.Column(orm.Integer)  # 1:处理中  2:充值成功 4:充值失败
    pay_id = orm.Column(orm.BigInteger)  # 充值关联的pay_id
    pay_amount = orm.Column(orm.FLOAT)
    third_id = orm.Column(orm.VARCHAR)  # 关联的第三方流水号
    admin_id = orm.Column(orm.Integer)  # 操作员id
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


ALIPAY_TRANS_KEY = 'j53918jhg5vfbjhgn4531u450'


class AlipayTrans(orm.Model):
    """
    支付宝转账收款记录
    CREATE TABLE `alipay_trans` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `third_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
      `remark_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
      `trans_amount` float NOT NULL,
      `status` tinyint(4) DEFAULT '0',
      PRIMARY KEY (`id`),
      UNIQUE KEY `third_id` (`third_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    """
    __tablename__ = "alipay_trans"
    id = orm.Column(orm.Integer, primary_key=True)
    third_id = orm.Column(orm.VARCHAR)  # 支付宝交易流水号
    remark_id = orm.Column(orm.VARCHAR)  # 转账备注填写的id, 默认为uid, 没有则为NULL
    pay_time = orm.Column(orm.VARCHAR)  # 转账时间
    trans_amount = orm.Column(orm.FLOAT)  # 转账金额
    status = orm.Column(orm.Integer)  # 0:未充值  1:已充值(关联pay_id)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
