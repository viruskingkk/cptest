# -*- coding: utf-8 -*-

import json

from common import orm
from common.account.db import account
from common.account.model.account import BALANCE_TYPE
from common.pay.db import get_today_recharge
from common.transaction.db import create_transaction
from common.transaction.model import TRANSACTION_STATUS, TRANSACTION_TYPE
from common.utils import exceptions as err
from common.utils.respcode import StatusCode
from common.utils.tz import today_str, to_ts, local_now
from common.utils import track_logging
from .spring_festival_model import SPRING_FESTIVAL_TASK, SPRING_FESTIVAL_TASK_TYPE, SPRING_FESTIVAL_TASK_JOIN_STATUS, \
    SpringFestivalRecord, SPRING_FESTIVAL_TASK_PRIZE
from common.utils.currency import convert_yuan_to_hao
from common.platform.common.db import get_user_today_game_effective_bet
from common.lottery.db import get_user_today_lottery_effective_bet
from common.account.db.account import get_account
from common.activity.utils import rand_pick

_LOGGING = track_logging.getLogger(__name__)


def get_task_status(user_id, task_id):
    if not user_id:
        return SPRING_FESTIVAL_TASK_JOIN_STATUS.TODO
    task = SPRING_FESTIVAL_TASK[task_id - 1]

    if had_open_prize(user_id, task_id):
        return SPRING_FESTIVAL_TASK_JOIN_STATUS.RECEIVED

    today_amount = 0
    if task['activity_type'] == SPRING_FESTIVAL_TASK_TYPE.RECHARGE:
        today_amount = get_today_recharge(user_id, [])
    elif task['activity_type'] == SPRING_FESTIVAL_TASK_TYPE.LOTTERY_JOIN:
        today_amount = get_user_today_lottery_effective_bet(user_id)
    elif task['activity_type'] == SPRING_FESTIVAL_TASK_TYPE.GAME_JOIN:
        today_amount = get_user_today_game_effective_bet(user_id)

    if today_amount and today_amount >= task['threshold']:
        return SPRING_FESTIVAL_TASK_JOIN_STATUS.DONE

    return SPRING_FESTIVAL_TASK_JOIN_STATUS.TODO


def had_open_prize(user_id, task_id):
    return orm.session.query(SpringFestivalRecord).filter(SpringFestivalRecord.user_id == user_id,
                                                          SpringFestivalRecord.task_id == task_id,
                                                          SpringFestivalRecord.date == today_str()).count()


def get_act_status(user_id, start_time, end_time):
    if not user_id:
        return SPRING_FESTIVAL_TASK_JOIN_STATUS.UNLOGIN
    now_ts = to_ts(local_now())
    if now_ts < start_time:
        return SPRING_FESTIVAL_TASK_JOIN_STATUS.UNSTART
    if now_ts > end_time:
        return SPRING_FESTIVAL_TASK_JOIN_STATUS.END
    return SPRING_FESTIVAL_TASK_JOIN_STATUS.ONGOING


def get_tasks_with_status(user_id, act_status):
    if not user_id:
        return SPRING_FESTIVAL_TASK

    result = []
    for task in SPRING_FESTIVAL_TASK:
        if act_status in [SPRING_FESTIVAL_TASK_JOIN_STATUS.END,
                          SPRING_FESTIVAL_TASK_JOIN_STATUS.UNSTART]:
            task['status'] = SPRING_FESTIVAL_TASK_JOIN_STATUS.TODO
        else:
            task['status'] = get_task_status(user_id, task['id'])
        result.append(task)

    return result


def add_receive_record(user_id, task_id, amount, auto_commit=False):
    user = account.get_account(user_id, use_cache=True)
    if not user:
        raise err.DataError(status=StatusCode.INVALID_USER)

    record = SpringFestivalRecord()
    record.user_id = user.id
    record.user_name = user.user_name
    record.amount = amount
    record.task_id = task_id
    record.date = today_str()
    record.save(auto_commit=auto_commit)


def receive_prize(user_id, task_id):
    task_id = int(task_id)
    if not task_id or not user_id:
        raise err.DataError(status=StatusCode.PARAM_REQUIRED)

    user = get_account(user_id, use_cache=True)
    if not user:
        raise err.DataError(status=StatusCode.INVALID_USER)

    if had_open_prize(user_id, task_id):
        raise err.DataError(u'已领取奖励')

    if get_task_status(user_id, task_id) != SPRING_FESTIVAL_TASK_JOIN_STATUS.DONE:
        raise err.DataError(u'未达到活动条件')

    award = rand_pick(*SPRING_FESTIVAL_TASK_PRIZE[SPRING_FESTIVAL_TASK[task_id - 1]['prize_conf']])
    _LOGGING.info("spring festival receive prize {} {} {}".format(user_id, task_id, award))

    add_receive_record(user_id, task_id, award)
    transaction_data = {
        'user_id': user.id,
        'type': TRANSACTION_TYPE.SPRING_FESTIVAL,
        'title': u'春节福利活动奖励',
        'extend': json.dumps({'task_id': task_id}, ensure_ascii=False),
        'price': convert_yuan_to_hao(award),
        'balance_type': BALANCE_TYPE.BALANCE,
        'status': TRANSACTION_STATUS.DONE,
    }
    create_transaction(transaction_data)
    orm.session.commit()

    return award