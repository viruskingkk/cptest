# -*- coding: utf-8 -*-
from common import orm
from common.lottery.cyclical import ACTIVITY_STATUS, STAT_TYPE
from common.lottery.cyclical.pls.model import TC_PLS_Activity, TC_PLS_Trend


class Activity(orm.Model, TC_PLS_Activity):
    __tablename__ = "tc_pls"


class Trend(orm.Model, TC_PLS_Trend):
    __tablename__ = "tc_pls_trend"
