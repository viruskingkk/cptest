# -*- coding: utf-8 -*-
from common import orm
from common.utils.types import Enum

TREASURE_AMOUNT = {
    1: [("2", 60), ("3", 19), ("4", 10), ("5", 6), ("6", 4), ("8", 1)],
    2: [("3", 60), ("4", 19), ("6", 10), ("8", 6), ("10", 4), ("18", 1)],
    3: [("18", 60), ("22", 19), ("28", 10), ("38", 6), ("48", 4), ("88", 1)],
    4: [("28", 60), ("48", 19), ("68", 10), ("88", 6), ("128", 4), ("188", 1)],
    5: [("188", 60), ("228", 19), ("288", 10), ("388", 6), ("488", 4), ("888", 1)],
    6: [("288", 60), ("488", 19), ("688", 10), ("888", 6), ("1288", 4), ("1888", 1)],
    7: [("488", 60), ("688", 19), ("888", 10), ("1288", 6), ("1888", 4), ("3888", 1)],
    8: [("888", 60), ("1288", 19), ("1888", 10), ("2888", 6), ("3888", 4), ("8888", 1)],
    9: [("2888", 60), ("4888", 19), ("5888", 10), ("6888", 6), ("8888", 4), ("18888", 1)],
}

# 累积金额对应档位
TREASURE_CONF = {
    200: 1,
    500: 2,
    2000: 3,
    5000: 4,
    20000: 5,
    50000: 6,
    100000: 7,
    200000: 8,
    500000: 9,
}

TREASURE_TYPE = Enum({
    "grade_1": (1L, "grade_1"),  # 档位50
    "grade_2": (2L, "grade_2"),  # 档位200
    "grade_3": (3L, "grade_3"),  # 档位500
    "grade_4": (4L, "grade_4"),  # 档位2000
    "grade_5": (5L, "grade_5"),  # 档位5000
    "grade_6": (6L, "grade_6"),  # 档位10000
    "grade_7": (7L, "grade_7"),  # 档位50000
    "grade_8": (8L, "grade_8"),  # 档位100000
    "grade_9": (9L, "grade_9"),  # 档位200000
})

TREASURE_STATUS = Enum({
    "UNOPEN": (0L, "unopen"),  # 宝箱未使用
    "OPENED": (1L, "opened"),  # 宝箱已使用
    # "EXPIRED": (2L, "expired"),  # 已过期
})

# 档位对应期望值
TREASURE_AVERAGE_VALUE = {
    1: 2.79,
    2: 4.22,
    3: 22.86,
    4: 45,
    5: 236.6,
    6: 458,
    7: 704,
    8: 1384,
    9: 4208,
}


class Treasure(orm.Model):
    __tablename__ = "treasure"
    id = orm.Column(orm.BigInteger, primary_key=True)
    user_id = orm.Column(orm.BigInteger)
    treasure_type = orm.Column(orm.Integer)  # 宝箱类型
    status = orm.Column(orm.Integer)  # 宝箱是否开启，默认为0
    transaction_id = orm.Column(orm.BigInteger)
    amount = orm.Column(orm.FLOAT)  # 金额
    date = orm.Column(orm.VARCHAR)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
