# -*- coding: utf-8 -*-
from functools import partial

from sqlalchemy.exc import IntegrityError

from common.lottery.cyclical.abstract import activity as base
from common.lottery.cyclical.cp11x5.activity import insert_stats as cp11x5_insert_stats
from common.utils.decorator import sql_wrapper
from common.lottery import LOTTERY_TYPE


insert_stats = partial(cp11x5_insert_stats, LOTTERY_TYPE.JX_11X5)

fullfill_result = sql_wrapper(
    partial(base.fullfill_result, LOTTERY_TYPE.JX_11X5))


get_latest_term = sql_wrapper(
    partial(base.get_latest_term, LOTTERY_TYPE.JX_11X5))


get_activity_by_term = sql_wrapper(
    partial(base.get_activity_by_term, LOTTERY_TYPE.JX_11X5))


stop_term = sql_wrapper(
    partial(base.stop_term, LOTTERY_TYPE.JX_11X5))


create_new_term = sql_wrapper(
    partial(base.create_new_term, LOTTERY_TYPE.JX_11X5))


get_stats_by_term = sql_wrapper(
    partial(base.get_stats_by_term, LOTTERY_TYPE.JX_11X5))


get_activity_stats = sql_wrapper(
    partial(base.get_activity_stats, LOTTERY_TYPE.JX_11X5))

