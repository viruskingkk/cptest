#! -*- coding:utf-8 -*-

import logging
import time
from datetime import datetime, timedelta

from requests.exceptions import RequestException

from common import orm
from common.platform.common.db import reverse_not_existed_fronzen, unfreeze_balance, \
    delete_withdraw_trans_log
from common.platform.common.model import M_TRANSACTION_TYPE, ThirdTransaction, ThirdWithdrawTransactionLog
from common.platform.integrate import get_third_handler
from common.utils.decorator import retry
from common.utils.thread import Thread

_LOGGER = logging.getLogger(__name__)

BATCH_COUNT = 200
IDLE_SLEEP_TIME = 120
CHECK_TIME_MINUTES_BEFORE_NOW = 5
ID_SEARCH_LIMIT = 100000


class ThirdTransactionCheck(Thread):
    MIN_UNCHECKED_ID = None

    def __init__(self, min_unchecked_id=None, *args, **kwargs):
        super(ThirdTransactionCheck, self).__init__(*args, **kwargs)
        if min_unchecked_id is not None:
            self.MIN_UNCHECKED_ID = min_unchecked_id

    def run(self):
        _LOGGER.info('starting auto check third transaction ...')
        if self.MIN_UNCHECKED_ID is None:
            self.MIN_UNCHECKED_ID = self.get_min_unchecked_transaction_id()
        continuous_fail_count = 0
        while not self.shutdown_flag.is_set():
            try:
                has_more = self.check_deposit_batch()
                has_more = self.check_withdraw_batch() or has_more
                if not has_more:
                    time.sleep(IDLE_SLEEP_TIME)
                continuous_fail_count = max(0, continuous_fail_count - 1)
            except:
                continuous_fail_count += 1
                if continuous_fail_count > 10:
                    _LOGGER.exception(
                        'auto check third transaction fail: MIN_UNCHECKED_ID: [%s]' % self.MIN_UNCHECKED_ID)
                    break
            finally:
                orm.session.close()

    @staticmethod
    def get_min_unchecked_transaction_id():
        """
        获取没有被检查的最小一条数据
        """
        query = ThirdTransaction.query.order_by(ThirdTransaction.id.desc()).first()
        min_id = query.id - ID_SEARCH_LIMIT
        date_before_5_minutes = (datetime.utcnow() - timedelta(minutes=CHECK_TIME_MINUTES_BEFORE_NOW))
        min_unchecked_trans = ThirdTransaction.query.filter(ThirdTransaction.checked == False).\
            filter(ThirdTransaction.created_at <= date_before_5_minutes).\
            filter(ThirdTransaction.id >= min_id).first()
        if min_unchecked_trans:
            # 如果存在没有检查的ID
            return min_unchecked_trans.id
        else:
            # 否则返回5分钟前最大的一条记录
            max_tran = ThirdTransaction.query.filter(ThirdTransaction.created_at <= date_before_5_minutes). \
                filter(ThirdTransaction.id >= min_id).order_by(ThirdTransaction.id.desc()).first()
            return max_tran.id if max_tran else 0

    def check_deposit_batch(self):
        """
        查找没有check的订单，check并移动游标；
        如果都check了，则移动游标到最近的一次
        :return:
        """
        _LOGGER.info('start batch deposit check, max trans id : %s' % self.MIN_UNCHECKED_ID)
        date_before_5_minutes = (datetime.utcnow() - timedelta(minutes=CHECK_TIME_MINUTES_BEFORE_NOW))
        query = ThirdTransaction.query.filter(ThirdTransaction.checked == False).\
            filter(ThirdTransaction.created_at <= date_before_5_minutes).\
            filter(ThirdTransaction.id >= self.MIN_UNCHECKED_ID).\
            order_by(ThirdTransaction.id.asc()).\
            limit(BATCH_COUNT)

        has_more = False
        for trans in query.all():
            if trans.checked:
                # 如果该订单已经checked，游标应该继续递增
                self.MIN_UNCHECKED_ID = trans.id
                continue
            self.check_deposit(trans)
            self.MIN_UNCHECKED_ID = trans.id
            has_more = True
        if not has_more:
            # 如果刚刚所查范围内的订单都check了，那就取刚刚范围内的最大订单，作为游标
            item = ThirdTransaction.query.\
                filter(ThirdTransaction.created_at <= date_before_5_minutes). \
                filter(ThirdTransaction.id >= self.MIN_UNCHECKED_ID). \
                order_by(ThirdTransaction.id.desc()). \
                first()
            if item:
                self.MIN_UNCHECKED_ID = item.id
        return has_more

    @retry(RequestException)
    def check_deposit(self, trans):
        if trans.type in [M_TRANSACTION_TYPE.FROZEN]:
            if not get_third_handler(trans.platform).check_trans_existed(trans.ref_id):
                _LOGGER.info('begin auto reverse user_id: %s, frozen_balance: %s, ref_id: %s' %
                             (trans.user_id, trans.balance / 100, trans.ref_id))
                reverse_status, reverse_trans = reverse_not_existed_fronzen(trans.user_id, trans.ref_id)
                if reverse_status:
                    _LOGGER.error('success finish auto reverse user_id %s, frozen_balance: %s, ref_id: %s' % (
                        trans.user_id, trans.balance / 100, trans.ref_id))
        trans.checked = True
        trans.save()

    def check_withdraw_batch(self):
        _LOGGER.info('start batch withdraw check')
        withdraw_trans_logs = ThirdWithdrawTransactionLog.query.filter(ThirdWithdrawTransactionLog.created_at <= (
                datetime.utcnow() - timedelta(minutes=CHECK_TIME_MINUTES_BEFORE_NOW))).limit(BATCH_COUNT).all()
        has_more = False
        for trans in withdraw_trans_logs:
            self.check_withdraw(trans)
            has_more = True
        return has_more

    @retry(RequestException)
    def check_withdraw(self, trans):
        if get_third_handler(trans.platform).check_trans_existed(trans.ref_id):
            _LOGGER.info('begin auto unfreeze_balance user_id: {}, amount: {}, ref_id: {}'.
                         format(trans.user_id, trans.amount / 100, trans.ref_id))
            unfreeze_balance(trans.user_id, trans.platform, trans.amount, trans.ref_id)
            _LOGGER.error('success auto unfreeze_balance user_id: {}, amount: {}, ref_id: {}'.
                          format(trans.user_id, trans.amount / 100, trans.ref_id))
        delete_withdraw_trans_log(trans.id)
