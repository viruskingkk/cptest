# -*- coding: utf-8 -*-

from common.platform.common.base import AbstractHandler
from common.platform.common.model import PLATFORM_TYPE
from common.platform.ametis import db as ametis_db
from common.platform.ametis import ametis_api
from common.utils import exceptions as err
from common.utils import track_logging

_LOGGER = track_logging.getLogger(__name__)


class AmetisHandler(AbstractHandler):
    def get_platform_code(self):
        return PLATFORM_TYPE.AMETIS

    def shutdown(self):
        return False

    def available(self, user_id, **kwargs):
        if ametis_db.is_pass_user(user_id):
            raise err.ServerError(u'游戏维护中，请稍后重试')
        if ametis_db.is_black_user(user_id):
            raise err.ServerError(u'游戏维护中，请稍后重试')
        return True

    def check_trans_existed(self, ref_id):
        status, _ = ametis_api.check_trans_status(ref_id)
        return status

    def query_balance_and_frozen_status(self, user_id):
        status, data = ametis_api.query_balance(user_id)
        if not status:
            return 0, True
        balance = data or 0
        if balance <= 0:
            return 0, True
        return balance, False

    def login_third(self, user_id, amount, ref_id, **params):
        game_id = params['game_id']
        is_vertical = ametis_db.check_is_vertical(game_id)
        status, data = ametis_api.enter_game(user_id, params['user_name'], game_id,
                                             ref_id, amount, is_vertical)
        if status:
            if str(data).startswith('{'):
                # 由于ametis此处返回状态码在python中识别处理混乱暂这样处理，后面可联调优化
                tip = data.get('tip')
                raise err.ServerError(u'您当前正在进行{}游戏，请先完成本局内容'.format(tip))
            datas = {'url': data}
            return datas
        else:
            raise err.ServerError(u'登入游戏失败，请稍候重试')

    def logout_third(self, user_id, amount, ref_id, *params):
        status, data = ametis_api.exit_game(user_id, ref_id)
        return status, data


handler = AmetisHandler()
