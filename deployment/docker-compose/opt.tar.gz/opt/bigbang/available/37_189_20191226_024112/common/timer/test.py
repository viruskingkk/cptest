# coding=utf-8
import time
import multiprocessing
from multiprocessing import Manager


def tt(*args, **kwargs):
    while 1:
        print args
        time.sleep(10)


def no_man():
    ps = []
    for arg in [123, 456]:
        p = multiprocessing.Process(target=tt, args=(arg,))
        p.start()
        ps.append(p)
    for p in ps:
        p.join()


def has_man():
    manager = Manager()
    value = manager.Value('b', True)
    ps = []
    for arg in [123, 456]:
        p = multiprocessing.Process(target=tt, args=(arg, value))
        p.start()
        ps.append(p)
    for p in ps:
        p.join()


if __name__ == "__main__":
    # no_man()
    has_man()
