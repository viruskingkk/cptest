# -*- coding: utf-8 -*-
from common import orm


class Order(orm.Model):
    __tablename__ = "jx_11x5_order"
    id = orm.Column(orm.BigInteger, primary_key=True)
    user_id = orm.Column(orm.BigInteger)
    track_id = orm.Column(orm.BigInteger)  # 每次追号会产生一个ID，普通的为null
    type = orm.Column(orm.SmallInteger)  # 订单类型
    term = orm.Column(orm.VARCHAR)  # 期号
    bet_type = orm.Column(orm.Integer)  # 押宝方式，见上面的枚举
    unit = orm.Column(orm.FLOAT, default=2)  # 用户自选的每注金额
    number = orm.Column(orm.VARCHAR)  # 用户购买数据，格式和bet_type有关
    price = orm.Column(orm.FLOAT)  # 总价
    status = orm.Column(orm.Integer)  # 订单状态
    track_status = orm.Column(orm.Integer)  # 追号状态
    times = orm.Column(orm.Integer, default=1)  # 倍数
    win_price = orm.Column(orm.FLOAT, default=0)  # 中奖金额
    bonus = orm.Column(orm.FLOAT, default=0)
    extend = orm.Column(orm.TEXT)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
