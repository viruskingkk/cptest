# -*- coding: utf-8 -*-
from common import orm
from common.utils.types import Enum

ACTIVITY_STATUS = Enum({
    "TODO": ('todo', u"未满足条件"),
    "DONE": ('done', u"满足条件，但未领取奖励"),
    "UNLOGIN": ('unlogin', u"未登录"),
    "UNSTART": ('unstart', u"未开始"),
    "UNREACH": ('unreach', u"未满足条件, 但未开奖"),
    "REACH": ('reach', u"满足条件, 但未开奖"),
    "END": ('end', u"已开奖"),
    "OVER": ('over', u"活动结束")
})

ACTIVITY_CONFIG = {
    "threshold": 100,
}

AWARD_TYPE = Enum({
    "REAL": ('real', u"实物"),
    "AMOUNT": ('amount', u"彩金"),

})

AWARD = [{
    "award_type": AWARD_TYPE.REAL,
    "thing": "iphoneXS",
    "real_user_probability": 0
},
    {
        "award_type": AWARD_TYPE.AMOUNT,
        "thing": "888",
        "real_user_probability": 1
    },
    {
        "award_type": AWARD_TYPE.AMOUNT,
        "thing": "688",
        "real_user_probability": 1
    },
    {
        "award_type": AWARD_TYPE.AMOUNT,
        "thing": "388",
        "real_user_probability": 1
    },
    {
        "award_type": AWARD_TYPE.AMOUNT,
        "thing": "188",
        "real_user_probability": 1
    }

]


class LanternRecord(orm.Model):
    '''
    元宵活动领取记录
    '''
    __tablename__ = "lantern_record"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    user_name = orm.Column(orm.VARCHAR)  # 用户名 (冗余，方便展示)
    rank = orm.Column(orm.Integer)
    date = orm.Column(orm.Date)  # 领取日期
    thing = orm.Column(orm.VARCHAR)  # 奖品
    created_at = orm.Column(orm.DATETIME)  # 下单时间
    updated_at = orm.Column(orm.DATETIME)
