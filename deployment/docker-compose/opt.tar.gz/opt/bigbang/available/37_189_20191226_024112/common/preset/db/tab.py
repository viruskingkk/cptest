# -*- coding: utf-8 -*-
import logging

from common.utils.decorator import sql_wrapper
from common.utils.db import list_object, get, upsert, delete
from common.preset.model.preset import Tab

_LOGGER = logging.getLogger(__name__)


@sql_wrapper
def get_tab(id):
    return get(Tab, id)


@sql_wrapper
def upsert_tab(info, id=None):
    return upsert(Tab, info, id)


@sql_wrapper
def list_tab(query_dct):
    return list_object(query_dct, Tab)


@sql_wrapper
def delete_tab(id):
    delete(Tab, id)


@sql_wrapper
def get_all_avaliable_tab(cvc=None):
    tabs = Tab.query.filter()
    if cvc:
        cvc = int(cvc)
        tabs = tabs.filter(Tab.min_version <= cvc, Tab.max_version >= cvc)
    return tabs.all()
