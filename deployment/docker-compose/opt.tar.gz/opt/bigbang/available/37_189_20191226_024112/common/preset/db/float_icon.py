# -*- coding: utf-8 -*-
import logging

from common.utils.decorator import sql_wrapper
from common.utils.db import list_object, get, upsert, delete
from common.preset.model.preset import FloatIcon

_LOGGER = logging.getLogger(__name__)


@sql_wrapper
def get_float_icon(id):
    return get(FloatIcon, id)


@sql_wrapper
def upsert_float_icon(info, id=None):
    return upsert(FloatIcon, info, id)


@sql_wrapper
def list_float_icon(query_dct):
    return list_object(query_dct, FloatIcon)


@sql_wrapper
def delete_float_icon(id):
    delete(FloatIcon, id)
