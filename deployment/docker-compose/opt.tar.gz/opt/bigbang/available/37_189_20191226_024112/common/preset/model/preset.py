# -*- coding: utf-8 -*-
from common import orm
from common.utils.types import Enum

DEVICE_TYPE = Enum({
    "ANDROID": (1, "android"),
    "IOS": (2, "ios"),
})

BANNER_TYPE = Enum({
    'ANNOUNCEMENT': ('announcement', 'announcement'),
    'DAILY_BET': ('daily_bet', 'daily_bet'),
    'DAILY_RECHARGE': ('daily_recharge', 'daily_recharge'),
    'DAILY_TREASURE': ('daily_treasure', 'daily_treasure'),
    'WINNER_RANKING': ('winner_ranking', 'winner_ranking'),
    'SPRING_FESTIVAL': ('spring_festival', 'spring_festival'),
    'RECHARGE_IPHONE': ('recharge_iphone', 'recharge_iphone'),
    'RANKING': ('ranking', 'ranking'),
    'LANTERN': ('lantern', 'lantern'),
})

# array of lottery id for lucky preset.
PRESET_LUCKY_IDs = [2]


class Preset(orm.Model):
    """
    一些杂项的预置
    目前content包括：
        彩种配置：打开或关闭某个彩种
        玩法配置：一个彩种可用的所有玩法
        加奖标示：每个玩法可能的加奖
        浮动图标：指向具体的url
        {
            "lottery":[{
                "type": 1,            # 彩种编号
                "enable": True,       # 是否开放
                "mark": str,          # 标示
                "bet_types":          # 具体玩法设置
                [   # key是彩种类型
                    {"type": "1", "mark": "", "enable": False}
                ]
            }],
            "float_icon": {       # 浮动图标
                "enable": true,
                "cmd": "xxxx"     # 点击后动作
            }
        }
    """
    __tablename__ = "preset"
    id = orm.Column(orm.BigInteger, primary_key=True)
    device_type = orm.Column(orm.Integer)
    title = orm.Column(orm.TEXT)
    max_version = orm.Column(orm.Integer)
    min_version = orm.Column(orm.Integer)
    chn = orm.Column(orm.TEXT)  # 指定渠道
    last_modified = orm.Column(orm.BigInteger)  # 同步版本号
    content = orm.Column(orm.TEXT)  # JSON
    remark = orm.Column(orm.TEXT)  # 备注
    webmode = orm.Column(orm.SmallInteger)  # 0-审核模式,1-发布模式
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class Loading(orm.Model):
    __tablename__ = "preset_loading"
    id = orm.Column(orm.BigInteger, primary_key=True)
    title = orm.Column(orm.TEXT)
    image = orm.Column(orm.TEXT)
    stay = orm.Column(orm.Integer)
    cmd = orm.Column(orm.TEXT)
    skip = orm.Column(orm.Boolean)
    start_ts = orm.Column(orm.BigInteger)
    end_ts = orm.Column(orm.BigInteger)
    abtest = orm.Column(orm.Integer)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class Banner(orm.Model):
    __tablename__ = "preset_banner"
    id = orm.Column(orm.BigInteger, primary_key=True)
    title = orm.Column(orm.TEXT)
    image = orm.Column(orm.TEXT)
    cmd = orm.Column(orm.TEXT)
    campaign_start = orm.Column(orm.BigInteger)
    campaign_end = orm.Column(orm.BigInteger)
    type = orm.Column(orm.VARCHAR)
    start_ts = orm.Column(orm.BigInteger)
    end_ts = orm.Column(orm.BigInteger)
    abtest = orm.Column(orm.Integer)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class Shortcut(orm.Model):
    __tablename__ = "preset_shortcut"
    id = orm.Column(orm.BigInteger, primary_key=True)
    title = orm.Column(orm.TEXT)
    image = orm.Column(orm.TEXT)
    cmd = orm.Column(orm.TEXT)
    abtest = orm.Column(orm.Integer)


class Discovery(orm.Model):
    __tablename__ = "preset_discovery"
    id = orm.Column(orm.BigInteger, primary_key=True)
    title = orm.Column(orm.TEXT)
    icon = orm.Column(orm.TEXT)
    start_ts = orm.Column(orm.BigInteger)
    end_ts = orm.Column(orm.BigInteger)
    desc = orm.Column(orm.TEXT)
    tag = orm.Column(orm.VARCHAR)
    cmd = orm.Column(orm.TEXT)
    abtest = orm.Column(orm.Integer)
    remark = orm.Column(orm.TEXT)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class Recommend(orm.Model):
    __tablename__ = "preset_recommend"
    id = orm.Column(orm.BigInteger, primary_key=True)
    title = orm.Column(orm.TEXT)
    activity_type = orm.Column(orm.SmallInteger)
    number = orm.Column(orm.TEXT)
    cmd = orm.Column(orm.TEXT)
    start_ts = orm.Column(orm.BigInteger)
    end_ts = orm.Column(orm.BigInteger)
    abtest = orm.Column(orm.Integer)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class Pay(orm.Model):
    __tablename__ = "preset_pay"
    id = orm.Column(orm.BigInteger, primary_key=True)
    title = orm.Column(orm.TEXT)
    category = orm.Column(orm.VARCHAR)
    icon = orm.Column(orm.TEXT)
    least_pay = orm.Column(orm.Integer)  # 最低支付限额
    max_pay = orm.Column(orm.Integer)  # 最高支付限额
    pay_type = orm.Column(orm.Integer)
    bonus_rate = orm.Column(orm.FLOAT)  # 充值回馈
    desc_short = orm.Column(orm.TEXT)  # 并排描述
    desc_long = orm.Column(orm.TEXT)  # 底部描述
    highlight = orm.Column(orm.Boolean, default=False)  # 高亮/推荐
    abtest = orm.Column(orm.Integer)
    extend = orm.Column(orm.TEXT)
    remark = orm.Column(orm.Integer)
    status = orm.Column(orm.Integer)  # 0: 可用 1: 不可用
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class Reward(orm.Model):
    """  加奖的设置较为复杂
         生效条件：1：起止时间；2：每日的时间段；3：每周的周几的时间段
         4：每月的几号的时间段；以上时间段可以换成期数段，所以格式为(value都是pair的list)：
         {
            "weekday": [], # 周几的限制
            "day": [],  # 几号的限制
            "ts": [[100000, 20000]],  # 起止时间戳
            "term": [[0,100],[105, 107]], # 起止期数，一个pair
            ""
         }
         约定：右侧为list；如果list里面是一个具体的值，表示列举，如果是一个list，表示范围，
         例如 weekday: [[0,5]]，表示每周一到周六；
         数据之间是or的关系，条件之间是and的关系。
    """
    __tablename__ = "preset_reward"
    id = orm.Column(orm.BigInteger, primary_key=True)
    title = orm.Column(orm.TEXT)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种, 0表示所有
    enable = orm.Column(orm.Boolean, default=True)  # 开关，当限额耗尽时会自动关闭
    bet_type = orm.Column(orm.Integer, default=0)  # 玩法, 0表示所有
    rate = orm.Column(orm.Integer, default=0)  # 加奖比例
    amount = orm.Column(orm.Integer, default=0)  # 加奖金额
    withdraw = orm.Column(orm.Boolean, default=True)
    limit = orm.Column(orm.BigInteger)  # 指向的limit限额
    condition = orm.Column(orm.TEXT)  # JSON，设计较为复杂
    remark = orm.Column(orm.TEXT)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class RewardLimit(orm.Model):
    """奖金池，限制加奖总额；多个加奖可指向同一个奖金池。
       当奖金池耗尽后，相关加奖会被自动关闭。
       该表已经废弃了
    """
    __tablename__ = "preset_reward_limit"
    id = orm.Column(orm.BigInteger, primary_key=True)
    title = orm.Column(orm.TEXT)  # 资金池名字
    total = orm.Column(orm.FLOAT)
    left = orm.Column(orm.FLOAT)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class FloatIcon(orm.Model):
    __tablename__ = "preset_float_icon"
    id = orm.Column(orm.BigInteger, primary_key=True)
    title = orm.Column(orm.TEXT)
    icon = orm.Column(orm.TEXT)
    start_ts = orm.Column(orm.BigInteger)
    end_ts = orm.Column(orm.BigInteger)
    cmd = orm.Column(orm.TEXT)
    abtest = orm.Column(orm.Integer)
    remark = orm.Column(orm.TEXT)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class Tab(orm.Model):
    __tablename__ = 'preset_tab'
    id = orm.Column(orm.Integer, primary_key=True)
    name = orm.Column(orm.VARCHAR)
    column_type = orm.Column(orm.Integer)
    sort_id = orm.Column(orm.Integer)
    max_version = orm.Column(orm.Integer)
    min_version = orm.Column(orm.Integer)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class Lottery(orm.Model):
    __tablename__ = 'preset_lottery'
    id = orm.Column(orm.Integer, primary_key=True)
    type = orm.Column(orm.Integer)
    bet_type = orm.Column(orm.Integer)
    cmd = orm.Column(orm.VARCHAR)
    tab = orm.Column(orm.Integer)
    sort_id = orm.Column(orm.Integer)
    image = orm.Column(orm.VARCHAR)
    platform = orm.Column(orm.Integer)
    is_vertical = orm.Column(orm.Integer)
    is_new_game = orm.Column(orm.Integer)
    is_hot_game = orm.Column(orm.Integer)
    start_ts = orm.Column(orm.Integer)
    end_ts = orm.Column(orm.Integer)
    desc = orm.Column(orm.VARCHAR)
    priority = orm.Column(orm.Integer)  # 优先级，同一彩种同一时段有多个记录满足条件，使用优先级高的
    device_type = orm.Column(orm.Integer)
    exclude_chn = orm.Column(orm.VARCHAR)
    pass_chn = orm.Column(orm.VARCHAR)
    min_cvc = orm.Column(orm.Integer)
    max_cvc = orm.Column(orm.Integer)
    remark = orm.Column(orm.VARCHAR)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    start_stop_lottery = orm.Column(orm.DATETIME)
    end_stop_lottery = orm.Column(orm.DATETIME)
    switch_off = orm.Column(orm.SmallInteger)  # 标识玩法开关状态: 1关闭,0开启


class ProfitRate(orm.Model):
    __tablename__ = 'preset_profit_rate'
    id = orm.Column(orm.Integer, primary_key=True)
    activity_type = orm.Column(orm.Integer)  # 彩种
    preset_amount = orm.Column(orm.Integer)  # 流水门槛
    preset_max_loss = orm.Column(orm.Integer)  # 保底盈亏金额
    preset_max_profit_rate = orm.Column(orm.FLOAT)  # 抽水门槛
    preset_min_profit_rate = orm.Column(orm.FLOAT)  # 放水门槛
    preset_win_rate = orm.Column(orm.FLOAT)  # 抽水概率
    preset_loss_rate = orm.Column(orm.FLOAT)  # 放水概率
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


PRESET_PARTS_TABLE = {
    "loading": Loading,
    "banner": Banner,
    "shortcut": Shortcut,
    "discovery": Discovery,
    "recommend": Recommend,
    "pay": Pay,
    "float_icon": FloatIcon,
    "reward": Reward,
    "qqgroup": None,
    'lottery': None,
}
