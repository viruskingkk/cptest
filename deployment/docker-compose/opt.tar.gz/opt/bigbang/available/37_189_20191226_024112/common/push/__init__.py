from common.utils.types import Enum


PUSH_COMMANDS = Enum({
    "TO_MAIN": (0L, "open main"),
    "TO_WIN_RECORD": (1L, "open win record"),
})
