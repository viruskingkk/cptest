# -*- coding: utf-8 -*-
'''
各类周期性彩票
'''

from common.lottery import LOTTERY_TYPE
from common.utils.types import Enum

CYCLICAL_TYPE = {  # 周期性彩票集合
    LOTTERY_TYPE.CQ_SSC,
    LOTTERY_TYPE.CQ_LF,
    LOTTERY_TYPE.JS_KS,
    LOTTERY_TYPE.SD_11X5,
    LOTTERY_TYPE.TJ_SSC,
    LOTTERY_TYPE.XJ_SSC,
    LOTTERY_TYPE.JX_11X5,
    LOTTERY_TYPE.GD_11X5,
    LOTTERY_TYPE.SH_11X5,
    LOTTERY_TYPE.GX_KS,
    LOTTERY_TYPE.BJ_PK10,
    LOTTERY_TYPE.TC_PLS,
    LOTTERY_TYPE.FC3D,
    LOTTERY_TYPE.FF_SSC,
    LOTTERY_TYPE.FF_11X5,
    LOTTERY_TYPE.FF_KS,
    LOTTERY_TYPE.FF_PK10,
}

STAT_TYPE = Enum({
    'MISS': (1, u'遗漏'),
    'APPEAR': (2, u'冷热'),
    'MAX': (4, u'最大'),
    'LAST': (8, u'上次'),
})

# 總球數
NUMBER_COUNT = {
    LOTTERY_TYPE.CQ_SSC: 10,
    LOTTERY_TYPE.CQ_LF: 20,
    LOTTERY_TYPE.JS_KS: 6,
    LOTTERY_TYPE.SD_11X5: 11,
    LOTTERY_TYPE.TJ_SSC: 10,
    LOTTERY_TYPE.XJ_SSC: 10,
    LOTTERY_TYPE.JX_11X5: 11,
    LOTTERY_TYPE.GD_11X5: 11,
    LOTTERY_TYPE.SH_11X5: 11,
    LOTTERY_TYPE.FF_11X5: 11,
    LOTTERY_TYPE.GX_KS: 6,
    LOTTERY_TYPE.BJ_PK10: 10,
    LOTTERY_TYPE.TC_PLS: 10,
    LOTTERY_TYPE.FC3D: 10,
    LOTTERY_TYPE.FF_SSC: 10,
    LOTTERY_TYPE.FF_KS: 6,
    LOTTERY_TYPE.FF_PK10: 10,
}

# 起始球號
START_NUM = {
    LOTTERY_TYPE.CQ_SSC: 0,
    LOTTERY_TYPE.CQ_LF: 1,
    LOTTERY_TYPE.JS_KS: 1,
    LOTTERY_TYPE.SD_11X5: 1,
    LOTTERY_TYPE.TJ_SSC: 0,
    LOTTERY_TYPE.XJ_SSC: 0,
    LOTTERY_TYPE.JX_11X5: 1,
    LOTTERY_TYPE.GD_11X5: 1,
    LOTTERY_TYPE.SH_11X5: 1,
    LOTTERY_TYPE.FF_11X5: 1,
    LOTTERY_TYPE.GX_KS: 1,
    LOTTERY_TYPE.BJ_PK10: 1,
    LOTTERY_TYPE.TC_PLS: 0,
    LOTTERY_TYPE.FC3D: 0,
    LOTTERY_TYPE.FF_SSC: 0,
    LOTTERY_TYPE.FF_KS: 1,
    LOTTERY_TYPE.FF_PK10: 1,
}

# 開獎球數
RESULT_LEN = {
    LOTTERY_TYPE.CQ_SSC: 5,
    LOTTERY_TYPE.CQ_LF: 8,
    LOTTERY_TYPE.JS_KS: 3,
    LOTTERY_TYPE.SD_11X5: 5,
    LOTTERY_TYPE.TJ_SSC: 5,
    LOTTERY_TYPE.XJ_SSC: 5,
    LOTTERY_TYPE.JX_11X5: 5,
    LOTTERY_TYPE.GD_11X5: 5,
    LOTTERY_TYPE.SH_11X5: 5,
    LOTTERY_TYPE.FF_11X5: 5,
    LOTTERY_TYPE.GX_KS: 3,
    LOTTERY_TYPE.BJ_PK10: 10,
    LOTTERY_TYPE.TC_PLS: 3,
    LOTTERY_TYPE.FC3D: 3,
    LOTTERY_TYPE.FF_SSC: 5,
    LOTTERY_TYPE.FF_KS: 3,
    LOTTERY_TYPE.FF_PK10: 10,
}

ACTIVITY_STATUS = Enum({
    "STARTED": (1L, u"进行中"),
    "STOPPED": (2L, u"已停止购买"),
    "ANNOUNCED": (3L, u"已开奖"),
})

ORDER_STATUS = Enum({
    "READY": (1L, u"预设状态"),
    "CANCEL": (2L, u"已取消"),
    "WINNED": (3L, u"已派奖"),
    "LOSE": (4L, u"未中奖"),  # 分开标记方便确认已处理过
    "UNCHECK": (5L, u"待审核"),  # 10万以上奖金需要审核
    "FAIL": (6L, u"审核未通过"),
    "SHOW": (7L, u"已晒带")
})

TRACK_STATUS = Enum({  # 追号状态
    "NOP": (0L, u"非追号订单"),
    "READY": (1L, u"追号中"),
    "TRACKED": (2L, u"已追号"),
    "WINNED": (3L, u"已中奖"),
    "STOPPED": (4L, u"中奖停追"),
    "CANCEL": (5L, u"已取消"),
})

ORDER_TYPE = Enum({
    "NORMAL": (1L, u"普通"),
    "PRE_ALL": (2L, u"预付"),
    "PRE_STOP_WIN": (4L, u"预付，中奖停追")
})
