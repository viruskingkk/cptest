# -*- coding: utf-8 -*-
from common import orm
from sqlalchemy.event import listens_for
from common.utils.types import Enum

ACCOUNT_STATUS = Enum({
    "NORMAL": (0L, u"预设状态"),
    "NAMED": (1L, u"已实名"),
    "TRADEABLE": (2L, u"已设置交易密码"),
    "BINDED": (4L, u"已绑定银行卡"),
    "PHONED": (8L, u"已绑定手机号"),
    "CHARGED": (16L, u"已充值過"),
    "BANNED": (1024L, u"黑名单"),
})


BALANCE_TYPE = Enum({
    'BALANCE': (1L, u'总余额'),
    'WITHDRAW': (2L, u'可提现余额'),
    'AGENT': (3L, u'代理可用余额'),
    'SPECIFIED': (4L, u'指定值写入')
})

ADMIN_SEARCHED_STATUS = Enum({
    'NORMAL': (0L, u'预设状态'),
    'TEST': (1L, u'测试用户'),
    'SALES': (2L, u'电销活动用户'),
    'OPERATION': (3L, u'运营活动用户'),
    'BLACK': (4L, u'黑名单用户'),

})

FinancialAccountType = Enum({
    "wechat": ('wechat', u"微信"),
    "alipay": ('alipay', u"支付宝"),
    "bank_card": ('bank_card', u"银行卡"),
})


class Account(orm.Model):
    __tablename__ = "account"
    id = orm.Column(orm.BigInteger, primary_key=True)
    citizen_id = orm.Column(orm.VARCHAR)  # 身份证号码
    avatar = orm.Column(orm.VARCHAR)
    user_name = orm.Column(orm.VARCHAR)  # 用户名
    name = orm.Column(orm.VARCHAR)  # 真实姓名
    channel = orm.Column(orm.VARCHAR)  # 用户注册渠道
    sign = orm.Column(orm.VARCHAR)  # 用户签名（欢迎语）
    phone = orm.Column(orm.VARCHAR)  # 非必须，不可重复
    password = orm.Column(orm.VARCHAR)  # 登录密码
    trade_pwd = orm.Column(orm.VARCHAR)  # 交易密码
    balance = orm.Column(orm.FLOAT, default=0.0)  # 账户余额
    withdraw = orm.Column(orm.FLOAT, default=0.0)  # 可用提现额度
    settings = orm.Column(orm.TEXT)  # 用户设置
    extend = orm.Column(orm.TEXT)
    status = orm.Column(orm.Integer, default=0)
    is_virtual = orm.Column(orm.Integer, default=0)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


@listens_for(Account, 'before_insert')
@listens_for(Account, 'before_update')
def change_withdraw(mapper, connection, target):
    if target.balance:
        target.withdraw = (int(target.balance / 100)) * 100


@listens_for(Account, 'load')
def account_load(target, context):
    if target.balance:
        target.withdraw = (int(target.balance / 100)) * 100


class AccountToken(orm.Model):
    __tablename__ = "account_token"
    user_id = orm.Column(orm.BigInteger, primary_key=True)
    token = orm.Column(orm.VARCHAR, primary_key=True)  # uuid
    chn = orm.Column(orm.VARCHAR)
    cvc = orm.Column(orm.VARCHAR)
    deleted = orm.Column(orm.SMALLINT)
    extend = orm.Column(orm.VARCHAR)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class FinancialAccount(orm.Model):
    __tablename__ = "financial_account"
    id = orm.Column(orm.BigInteger, primary_key=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.VARCHAR)
    account = orm.Column(orm.VARCHAR)
    real_name = orm.Column(orm.VARCHAR)
    bank = orm.Column(orm.VARCHAR)
    sub_bank = orm.Column(orm.VARCHAR)


BANK_LIST = {
    1: u"招商银行",
    2: u"工商银行",
    3: u"建设银行",
    4: u"农业银行",
    5: u"中国银行",
    6: u"交通银行",
    7: u"中信银行",
    8: u"兴业银行",
    9: u"光大银行",
    10: u"华夏银行",
    11: u"中国民生银行",
    12: u"广发银行",
    13: u"上海浦东发展银行",
    14: u"农村信用合作社",
    15: u"农村商业银行",
    16: u"平安银行",
    17: u"上海银行",
    18: u"北京银行",
    19: u"恒丰银行",
    20: u"渤海银行",
    21: u"广州银行",
    22: u"天津银行",
    23: u"浙商银行",
    24: u"宁波银行",
    25: u"温州银行",
    26: u"南京银行",
    27: u"常熟农村商业银行",
    28: u"徽商银行",
    29: u"重庆银行",
    30: u"哈尔滨银行",
    31: u"其他银行",
}
