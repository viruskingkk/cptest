# -*- coding: utf-8 -*-

import user_agents

def shorten_ua(ua_str):
    user_agent = user_agents.parse(ua_str)
    if user_agent.device.family == 'iOS-Device':
        device = 'iPhone'
    else:
        device = user_agent.device.family
    return device + '| ' +\
        user_agent.os.family + ' ' + user_agent.os.version_string


if __name__ == "__main__":
    print shorten_ua('HappyBuy/14 CFNetwork/808.3 Darwin/16.3.0')
