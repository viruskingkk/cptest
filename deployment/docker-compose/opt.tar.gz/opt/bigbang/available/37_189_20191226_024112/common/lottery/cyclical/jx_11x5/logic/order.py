# -*- coding: utf-8 -*-
from common.lottery.cyclical.sd_11x5.logic.order import *   # 同山东11选5完全一致
