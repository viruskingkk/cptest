# -*- coding: utf-8 -*-

import random
from common.preset.db import banner as banner_db
from common.utils import exceptions as err
from common.utils.tz import *

DAY_SECONDS = 24 * 3600


def rand_pick(seq, probabilities):
    x = random.uniform(0, 1)
    cumprob = 0.0
    for item, item_pro in zip(seq, probabilities):
        cumprob += item_pro
        if x < cumprob:
            break
    return item


def get_activity_time(banner_type):
    """
    :param banner_type:
    :return:
    """
    banner = banner_db.get_banner_by_type(banner_type)
    if not banner:
        raise err.DataError(u'活动尚未配置')

    return banner.campaign_start, banner.campaign_end


def ts_to_date_str_list(start_ts, end_ts):
    """
    :param start_ts:
    :param end_ts:
    :return:
    ["2019-09-01","2019-09-02","2019-09-03"]
    """
    result = []
    f = '%Y-%m-%d'
    while start_ts <= end_ts:
        today, today_start_ts = get_day_and_start_ts(start_ts, f=f)
        result.append(today)
        start_ts = today_start_ts
        start_ts += DAY_SECONDS

    return result


def hide_user_name(user_name):
    if not user_name:
        return user_name

    if len(user_name) > 9:
        return user_name[:5] + '***' + user_name[-4:]

    return user_name[:2] + '***' + user_name[-2:]