# -*- coding: utf-8 -*-
from common.utils.types import Enum
from common import orm
from common.account.model.account import FinancialAccountType


WITHDRAW_BLACK_STATUS = Enum({
    "ENABLE": (1, "启用"),
    "INVALID": (2, "失效")
})

WITHDRAW_BLACK_TYPE = Enum({
    "TEST_UID": ("test_uid", "测试id"),
    "BLACK_UID": ("black_uid", "恶意用户id"),
    "BLACK_ALIPAYNO": ("black_alipayno", "支付宝账号"),
    "BLACK_NAME": ("black_name", "真实姓名"),
    "BLACK_BANK": ("black_bank", "银行卡账号"),
    "BLACK_WECHAT": ("black_wechat", "微信账号"),
    "BLACK_PHONE": ("black_phone", "手机号"),
    "BLACK_SALES": ("black_sales", "电销黑名单"),
    "BLACK_OPERATIONS": ("black_operations", "运营活动黑名单"),
    "BAD_PHONE": ("bad_phone", "恶意手机号"),
    "BAD_BANK": ("bad_bank", "恶意银行卡"),
    "RECALL_UID": ("recall_uid", "召回活动黑名单"),
    "BLACK_EQUIPMENT": ("black_equipment", "恶意设备ID"),
    "BLACK_IP": ("black_ip", "恶意IP地址")
})

WITHDRAW_BLACK_GROUP = {
    'withdraw_black_list': [WITHDRAW_BLACK_TYPE.TEST_UID, WITHDRAW_BLACK_TYPE.BLACK_UID,
                            WITHDRAW_BLACK_TYPE.BLACK_SALES, WITHDRAW_BLACK_TYPE.BLACK_OPERATIONS],
    'withdraw_black_account_list': [WITHDRAW_BLACK_TYPE.BLACK_ALIPAYNO, WITHDRAW_BLACK_TYPE.BLACK_WECHAT,
                                    WITHDRAW_BLACK_TYPE.BLACK_BANK],
    'withdraw_black_account_info': [WITHDRAW_BLACK_TYPE.BLACK_PHONE, WITHDRAW_BLACK_TYPE.BAD_PHONE]
}

WITHDRAW_BLACK_ACCOUNT_MAP = {
    'black_alipayno': FinancialAccountType.alipay,
    'black_wechat': FinancialAccountType.wechat,
    'black_bank': FinancialAccountType.bank_card
}

WITHDRAW_BLACK_ACCOUNT_LIST = [
    WITHDRAW_BLACK_TYPE.BLACK_BANK,
    WITHDRAW_BLACK_TYPE.BLACK_WECHAT,
    WITHDRAW_BLACK_TYPE.BLACK_ALIPAYNO
]


class WithdrawBlack(orm.Model):
    __tablename__ = "withdraw_black"
    id = orm.Column(orm.BigInteger, primary_key=True)
    user_id = orm.Column(orm.BigInteger, default=0)  # user_id為0時，為系統的黑名單用戶庫
    type = orm.Column(orm.VARCHAR)
    type_account = orm.Column(orm.VARCHAR)
    money = orm.Column(orm.FLOAT, default=0.0)
    status = orm.Column(orm.SmallInteger)
    note = orm.Column(orm.VARCHAR)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class BlackModification(orm.Model):
    __tablename__ = "black_modification"
    id = orm.Column(orm.BigInteger, primary_key=True)
    user_id = orm.Column(orm.BigInteger)
    admin_id = orm.Column(orm.BigInteger)
    mod_type = orm.Column(orm.VARCHAR)
    type_account = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.SmallInteger)
    reason = orm.Column(orm.VARCHAR)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)

