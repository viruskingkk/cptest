# -*- coding: utf-8 -*-
from common import orm
from common.lottery.cyclical import ACTIVITY_STATUS, STAT_TYPE
from common.lottery.cyclical.lucky_farm.model import LFTrend, LFActivity


class Activity(orm.Model, LFActivity):
    __tablename__ = "cq_lf"


class Trend(orm.Model, LFTrend):
    __tablename__ = "cq_lf_trend"
