# -*- coding: utf-8 -*-
from common import orm


class BullTerm(orm.Model):
    __tablename__ = "bull_term"
    id = orm.Column(orm.Integer, primary_key=True)
    term_number = orm.Column(orm.Integer)
    status = orm.Column(orm.Integer)  # 1: 正在进行 2: 结算中 4: 已揭晓
    win_index = orm.Column(orm.Integer)  # 中奖序列号
    cards = orm.Column(orm.TEXT)  # cards ，JSON
    start_ts = orm.Column(orm.Integer)  # 本期开始时间戳
    announce_ts = orm.Column(orm.Integer)  # 本期开始结算时间戳
    end_ts = orm.Column(orm.Integer)  # 本期结束时间戳
    extend = orm.Column(orm.TEXT)  # 扩展字段，JSON
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    
class BullPart(orm.Model):
    __tablename__ = "bull_participate"
    id = orm.Column(orm.Integer, primary_key=True)
    term_number = orm.Column(orm.Integer)
    user_id = orm.Column(orm.Integer)  # user_id
    bet_index = orm.Column(orm.Integer)  # 押注序列号
    bet_amount = orm.Column(orm.Integer)  # 押注金额
    award_amount = orm.Column(orm.Integer, default=0)  # 中奖金额
    extend = orm.Column(orm.TEXT)  # 扩展字段，JSON
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class LotteryTerm(orm.Model):
    __tablename__ = "lottery_term"
    id = orm.Column(orm.Integer, primary_key=True)
    term_number = orm.Column(orm.Integer)
    status = orm.Column(orm.Integer)           # 1: 正在进行 2: 结算中 4: 已揭晓
    win_index = orm.Column(orm.Integer)        # 中奖序列号
    start_ts = orm.Column(orm.Integer)         # 本期开始时间戳
    announce_ts = orm.Column(orm.Integer)      # 本期开始结算时间戳
    end_ts = orm.Column(orm.Integer)           # 本期结束时间戳
    extend = orm.Column(orm.TEXT)              # 扩展字段，JSON
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class LotteryPart(orm.Model):
    __tablename__ = "lottery_participate"
    id = orm.Column(orm.Integer, primary_key=True)
    term_number = orm.Column(orm.Integer)
    user_id = orm.Column(orm.Integer)          # user_id
    bet_index = orm.Column(orm.Integer)        # 押注序列号
    bet_amount = orm.Column(orm.Integer)       # 押注金额
    award_amount = orm.Column(orm.Integer, default=0)     # 中奖金额
    extend = orm.Column(orm.TEXT)              # 扩展字段，JSON
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class GuessFruitTerm(orm.Model):
    __tablename__ = "guess_fruit_term"
    id = orm.Column(orm.Integer, primary_key=True)
    term_number = orm.Column(orm.Integer)
    status = orm.Column(orm.Integer)
    is_lucky = orm.Column(orm.Integer)
    win_index = orm.Column(orm.Integer)
    start_ts = orm.Column(orm.Integer)
    announce_ts = orm.Column(orm.Integer)
    end_ts = orm.Column(orm.Integer)
    extend = orm.Column(orm.TEXT)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class GuessFruitParticipate(orm.Model):
    __tablename__ = "guess_fruit_participate"
    id = orm.Column(orm.Integer, primary_key=True)
    term_number = orm.Column(orm.Integer)
    user_id = orm.Column(orm.Integer)
    bet_index = orm.Column(orm.Integer)
    bet_amount = orm.Column(orm.Integer)
    award_amount = orm.Column(orm.Integer)
    extend = orm.Column(orm.TEXT)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class KfcRecord(orm.Model):
    __tablename__ = "kfc_record"
    id = orm.Column(orm.Integer, primary_key=True)
    user_id = orm.Column(orm.Integer)
    bet_amount = orm.Column(orm.Integer)
    award_amount = orm.Column(orm.Integer)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)

