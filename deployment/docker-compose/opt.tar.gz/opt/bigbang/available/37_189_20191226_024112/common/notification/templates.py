# coding=utf-8

# 一些通知模版
# 派奖审核
REWARD_CHECKING = {
    'title': u'【派奖审核】彩种中奖{price}元，人工审核中',
    'body': u'恭喜亲，第{term}期 {activity_type} {bet_type}中奖{price}元。现已进入人工审核状态，会有专人联系您安全领奖，请保持手机畅通。（未绑定手机的用户请主动联系客服）',
    'tag': u'派奖审核'
}

# 审核通过及无须审核直接派奖
REWARD_CHECKED = {
    'title': u'【{activity_type}】派奖通知',
    'body': u'您参与的第【{term}】期【{activity_type}】【{bet_type}】中奖审核通过，奖金【{price}】元已直接派发至您的账户中。若有疑问，请联系在线客服，祝您继续好运！',
    'tag': u'派奖'
}

# 追号返款
REFUND_TEMPLATE = {
    'title': u'【追号返款】{activity_type}返款X元（{refund_type}）',
    'body': u'已返款{price}元到账户（{refund_type}）。{activity_type} {bet_type}，共{term_count}期（{terms}）。详情见账户明细。',
    'tag': u'追号返款'
}

# 提现通知
WITHDRAW_SUCCESS_TEMPLATE = {
    'title': u'【提现处理】提现{price}元到{target}，已处理',
    'body': u'您{date_str}的提现申请已通过审核，工作人员已打款，请注意查收。 若有疑问请联系客服。',
    'tag': u'提现处理'
}

# 提现失败退款
WITHDRAW_BACK_TEMPLATE = {
    'title': u'提现失败返款通知',
    'body': u'您在{date_str}提交的{price}元提现申请处理失败，原因：{reason}。提现金额已返还到您账户余额中，请查收。如有疑问，请联系在线客服处理，感谢您的支持和配合。',
    'tag': u'提现失败返款通知'
}

# 通过审核
VERIFY_SUCCESSFULLY = {
    'title': u'【红包到账】您的晒单已经通过审核。',
    'body': u'恭喜您，您的晒单已经通过了审核，系统赠送了您红包喔，祝您好运常来，再接再厉，赶快去使用吧。',
    'tag': u'红包到账'
}

# 流水闯关活动彩金
AWARD_SUCCESSFULLY = {
    'title': u'【彩金到账】活动派奖{price}元到账',
    'body': u'恭喜您，您在{campaign}中的{type}流水满足要求，彩金{price}元已到账，请注意查收',
    'tag': u'活动派奖'
}

# 元旦充值返现活动
RECHARGE_SUCCESSFULLY = {
    'title': u'【彩金到账】活动派奖{price}元到账',
    'body': u'恭喜您，您在{campaign}中的充值金额满足要求，彩金{price}元已到账，请注意查收',
    'tag': u'活动派奖'
}

# 线下充值失败
OFFLINE_RECHARGE_APPLY = {
    'title': u'【线下充值】{price}元充值已提交审核',
    'body': u'您的{price}元线下充值已提交审核，客服人员会第一时间处理，请留意您的到账和提醒信息。',
    'tag': u'线下自助充值'
}

# 线下充值失败
OFFLINE_RECHARGE_FAIL = {
    'title': u'【线下充值失败】{price}元充值审核未通过',
    'body': u'您好，您的线下充值审核未通过({reason})，{price}元未能成功到账，请重新提交申请，若有问题，请联系在线客服进行咨询。',
    'tag': u'线下自助充值'
}

# 线下充值到账
OFFLINE_RECHARGE_SUCCESSFULLY = {
    'title': u'【线下充值到账】{price}元充值成功到账',
    'body': u'恭喜您，您的线下充值已审核通过，{price}元已到账，请注意查收',
    'tag': u'线下自助充值'
}

# 抽宝箱
TREASURE_SUCCESSFULLY = {
    'title': u'【彩金到账】活动派奖{price}元到账',
    'body': u'恭喜您，您在{campaign}活动中抽奖获得的{price}元奖励已 经到账，请注意查收。',
    'tag': u'活动派奖'
}

# 春节活动
WINNER_RANKING_AWARD_DAILY = {
    'title': u'【彩金到账】活动派奖{price}元到账',
    'body': u'恭喜您在春节大奖赛{date}比赛中获得第{rank}名，获得奖金{price}元。更多奖金，更多惊喜，幸运中彩票伴您收获满满~',
    'tag': u'活动派奖'
}

WINNER_RANKING_AWARD_WEEKLY = {
    'title': u'【彩金到账】活动派奖{price}元到账',
    'body': u'恭喜您在春节七日奖池比赛中获得第{rank}名，获得奖金{price}元。春节大奖赛赢更多，奖更多，大奖就在眼前，预祝您再接再厉，旗开得胜~',
    'tag': u'活动派奖'
}

WINNER_RANKING_AWARD_TOTAL = {
    'title': u'【彩金到账】活动派奖{price}元到账',
    'body': u'恭喜您在春节“一炮三响”大奖赛中获得第{rank}名，获得奖金{price}元，感谢您的参与。“幸运中彩票”感恩一路有您，在2018新的一年中祝您大展宏图收获更多 ~',
    'tag': u'活动派奖'
}

# 回复用户反馈
REPLY_FEEDBACK = {
    'title': u'意见反馈回复',
    'body': u'您在【{created_at}】反馈的问题已得到回复。\n\n 反馈内容: \n {feedback_content} \n\n 客服回复:\n {reply_content}',
    'tag': u'用户反馈回复'
}

# 活动奖励统一通知
ACTIVITY_AWARD = {
    'title': u'活动奖励通知',
    'body': u'恭喜您参与【{activity_name}】成功，获得奖励【price】元，已发放到您的账户余额中，请查收！',
    'tag': u'活动奖励通知'
}

# 充值送iPhone活动通知
RECHARGE_IPHONE = {
    'title': u'春节活动奖励通知',
    'body': u'恭喜您在【春节活动】-【充值送iPhone】活动中，获得奖励【iPhoneXS】一部，请您在7个工作日内联系在线客服，便于我们尽快为您派发奖品，逾期将视为放弃领奖资格',
    'tag': u'活动派奖'
}

# 春节福利活动通知
SPRING_PART = {
    'title': u'春节活动奖励通知',
    'body': u'恭喜您在【春节活动】-【春节福利】活动中，获得奖励【彩金{price}元】，奖品已经派发到您的账户余额中，您可以在账户明细中进行查看。感谢您的参与。“幸运中彩票”感恩一路有您，在2019金猪好年财源滚滚到 ~',
    'tag': u'活动派奖'
}

# 春节财富排行榜活动通知
SPRING_RANK = {
    'title': u'春节活动奖励通知',
    'body': u'恭喜您在【春节活动】-【财富风云榜】活动中，获得奖励【彩金{price}元】，奖品已经派发到您的账户余额中，您可以在账户明细中进行查看。感谢您的参与。“幸运中彩票”感恩一路有您，在2019金猪好年财源滚滚到 ~',
    'tag': u'活动派奖'
}

# 元宵活动送iPhone通知
LANTERN_IPHONE = {
    'title': u'元宵节活动奖励通知',
    'body': u'恭喜您在【元宵节活动】活动中，获得奖励【iPhoneXS】，请您在7个工作日内联系在线客服，便于我们尽快为您派发奖品，逾期将视为放弃领奖资格',
    'tag': u'活动派奖'
}

# 元宵活动奖金通知
LANTERN_AMOUNT = {
    'title': u'元宵节活动奖励通知',
    'body': u'恭喜您在【元宵节活动】活动中，获得彩金{amount}元 ，奖品已经派发到您的账户余额中，您可以在账户明细中进行查看。若有任何疑问，请联系在线客服。',
    'tag': u'活动派奖'
}

# 充值申诉成功
LANTERN_RECHARGE_APPEAL_SUCCESS = {
    'title': u'充值申诉成功通知',
    'body': u'您提交的充值申诉（订单号：{order_id} ，金额：{amount}元)已受理成功，已为您成功充值，请您在“我的”界面查看账号余额变动。',
    'tag': u'充值申诉'
}

# 充值申诉失败
LANTERN_RECHARGE_APPEAL_FAIL = {
    'title': u'充值申诉失败通知',
    'body': u'您提交的充值申诉（订单号：{order_id} ，金额：{amount}元)被拒绝，原因为：【{reason_failure}】，请您再次确认提交的内容是否正确，感谢您的理解和支持！',
    'tag': u'充值申诉'
}