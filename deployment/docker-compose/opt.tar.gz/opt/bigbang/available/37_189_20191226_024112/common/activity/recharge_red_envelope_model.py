# -*- coding: utf-8 -*-
from common import orm
from common.utils.types import Enum

RED_ENVELOPE_TYPE = Enum({
    "CD1": (1L, u"彩蛋1"),
    "CD2": (2L, u"彩蛋2"),
    "CD3": (3L, u"彩蛋3"),
    "CD4": (4L, u"彩蛋4"),
    "CD5": (5L, u"彩蛋5"),
    "CD6": (6L, u"彩蛋6"),
})


class RedEnvelopeRecord(orm.Model):
    '''
    红包领取记录
    '''
    __tablename__ = "activity_red_envelop_record"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    user_name = orm.Column(orm.VARCHAR)  # 用户名 (冗余，方便展示)
    date = orm.Column(orm.Date)  # 领取日期
    amount = orm.Column(orm.FLOAT)  # 领取的金额，单位元
    red_envelope_type = orm.Column(orm.Integer)
    created_at = orm.Column(orm.DATETIME)  # 下单时间
    updated_at = orm.Column(orm.DATETIME)


# class ActivityRechargeCount(orm.Model):
#     '''
#     每天的充值统计，不包含vip充值(vip充值不参加活动)
#     '''
#     __tablename__ = "activity_recharge_count"
#     id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
#     user_id = orm.Column(orm.BigInteger)
#     date = orm.Column(orm.Date)  # 领取日期
#     amount_count = orm.Column(orm.FLOAT)  # 领取的金额，单位元
#     red_envelope_type = orm.Column(orm.Integer)
#     created_at = orm.Column(orm.DATETIME)  # 下单时间
#     updated_at = orm.Column(orm.DATETIME)
