# -*- coding: utf-8 -*-

from common import orm
from common.cache import redis_cache
from common.preset.model.preset import Lottery
from common.platform.ametis import ametis_api
from common.utils import track_logging, tz

_LOGGER = track_logging.getLogger(__name__)


def is_black_user(user_id):
    """判断是否为黑名单用户"""
    uids = redis_cache.get_platform_risk_uids('ametis', 'forbidden')
    if str(user_id) in uids:
        return True
    return False


def is_pass_user(user_id):
    """ metis白名单 """
    uids = redis_cache.get_platform_risk_uids('ametis', 'pass')
    if len(uids) != 0 and str(user_id) not in uids:
        return True
    return False


def check_is_vertical(game_id):
    """ 检查游戏是否为竖版 """
    game_id = int('88' + str(game_id))
    preset_item = orm.session.query(Lottery).filter(Lottery.type == game_id).first()
    if preset_item:
        is_vertical = preset_item.is_vertical
    else:
        is_vertical = False
    return is_vertical


def query_data_by_user(query_dct):
    """根据user_id和时间段获取用户总投注和总盈亏"""
    data = {}
    user_id = query_dct.get('user_id', '')
    today_start = tz.today_str() + ' 00:00:00'
    total_start = '2019-09-06 00:00:00'  # ametis游戏发布游戏时间
    today_status, today_list = ametis_api.query_data_by_user(user_id, today_start)
    total_status, total_list = ametis_api.query_data_by_user(user_id, total_start)
    if today_status:
        today_list = today_list.get('data_arr', [])
        if len(today_list):
            today_bet = int(today_list[0]['num_bet']) or 0
            today_win = int(today_list[0]['num_win']) or 0
            data['today_bet'] = today_bet / 100.0
            data['today_win'] = today_win / 100.0
    if total_status:
        total_list = total_list.get('data_arr', [])
        if len(total_list):
            all_bet = total_list[0]['num_bet'] or 0
            all_win = total_list[0]['num_win'] or 0
            data['all_bet'] = all_bet / 100.0
            data['all_win'] = all_win / 100.0
    return data
