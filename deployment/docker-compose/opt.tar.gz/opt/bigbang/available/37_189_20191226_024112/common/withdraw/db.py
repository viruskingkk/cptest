# -*- coding: utf-8 -*-
import json
import logging
from datetime import datetime

from common import orm
from common.account.model.account import Account
from common.transaction.model import Withdraw, WITHDRAW_STATUS, CHECK_STATUS, RISK_STATUS
from common.utils import tz
from common.utils import tracker
from common.utils import maestro_tracker
from common.utils import exceptions as err
from common.utils.db import get_count
from common.utils.decorator import sql_wrapper
from common.utils.helper import (
    get_orderby, parse_query_dct, paginate, generate_filter, limit_id_range)

_LOGGER = logging.getLogger('alipay')


@sql_wrapper
def withdraw_success_action(pay_id, amount, trade_no, payer_no='group_new_withdraw'):
    status = Withdraw.query.with_for_update().filter(Withdraw.id == pay_id).first().status
    if status == WITHDRAW_STATUS.DONE:
        return
    item = Withdraw.query.with_for_update().filter(Withdraw.id == pay_id).filter(
        Withdraw.status == WITHDRAW_STATUS.SUBMIT_TO_THIRD).first()
    if item is None:
        _LOGGER.info('Auto trans alipay, withdraw_success_action is none %s' % str(pay_id))
        raise err.DataError('withdraw_success_action query fail')

    item.status = WITHDRAW_STATUS.DONE
    item.real_price = float(amount)
    trans_info = {}
    trans_info.update({
        'payer_no': payer_no,
        'code': '10000',
        'amount': amount,
        'order_id': trade_no,
        'out_biz_no': pay_id,
        'complete_pay_date': tz.local_now().strftime('%Y-%m-%d %H:%M:%S'),
    })
    updated_info = json.loads(item.extend)
    updated_info.update({'auto_trans_info': trans_info})
    item.extend = json.dumps(updated_info, ensure_ascii=False)
    balance = Account.query.filter(Account.id == item.user_id).first().balance
    item.balance = balance
    item.save()
    tracker.track_withdraw(item.user_id, item.target_type, -float(amount))
    tracker.track_withdraw(item.user_id, item.target_type, float(amount), WITHDRAW_STATUS.DONE)
    try:
        maestro_tracker.track_maestro_withdraw(
            item.id, item.user_id, item.target_type, item.price, item.real_price,
            WITHDRAW_STATUS.DONE, updated_info.get('auto_risk', ''),
            int(datetime.strftime(item.updated_at, '%s')))
    except Exception as e:
        _LOGGER.exception('track maestro withdraw fail, withdraw id: %s', pay_id)
    try:
        maestro_tracker.track_maestro_withdraw_financial(
            item.id, item.user_id, item.target_type, item.price, item.real_price,
            'success', int(datetime.strftime(item.updated_at, '%s')))
    except Exception as e:
        _LOGGER.exception('track maestro withdraw_financial fail, withdraw id: %s', pay_id)
    return True


@sql_wrapper
def withdraw_failed_action(pay_id, amount, code, sub_code, sub_msg, out_biz_no,
                           payer_no='group_new_withdraw'):
    item = Withdraw.query.with_for_update().filter(Withdraw.id == pay_id).first()
    if item is None:
        _LOGGER.info('Auto trans alipay, withdraw_failed_action is none %s' % str(pay_id))
        raise err.DataError('withdraw_failed_action query fail')

    if item.status != WITHDRAW_STATUS.SUBMIT_TO_THIRD:
        # 该提现订单已经修改成其他状态
        return False

    item.status = WITHDRAW_STATUS.FAIL
    trans_info = {}
    trans_info.update({
        'payer_no': payer_no,
        'amount': amount,
        'code': code,
        'sub_code': sub_code,
        'sub_msg': sub_msg,
        'out_biz_no': out_biz_no,
        'complete_pay_date': tz.local_now().strftime('%Y-%m-%d %H:%M:%S'),
    })
    updated_info = json.loads(item.extend)
    updated_info.update({'auto_trans_info': trans_info})
    item.extend = json.dumps(updated_info, ensure_ascii=False)
    balance = Account.query.filter(Account.id == item.user_id).first().balance
    item.balance = balance
    item.save()
    try:
        maestro_tracker.track_maestro_withdraw_financial(
            item.id, item.user_id, item.target_type, item.price, item.real_price,
            'failure', int(datetime.strftime(item.updated_at, '%s')))
    except Exception as e:
        _LOGGER.exception('track maestro withdraw_financial fail, withdraw id: %s', pay_id)
    return True


@sql_wrapper
def get_withdraw_list_for_cs(user_id):
    start_date = tz.date_str_before(days=15)
    items = orm.session.query(Withdraw.id, Withdraw.created_at, Withdraw.price, Withdraw.target_type,
                              Withdraw.status, Withdraw.check_status). \
        filter(Withdraw.user_id == user_id). \
        filter(Withdraw.status != WITHDRAW_STATUS.DONE). \
        filter(Withdraw.created_at >= start_date).\
        order_by(Withdraw.id.desc()).all()
    return [{'id': item.id, 'created_at': item.created_at, 'price': item.price, 'target_type': item.target_type,
             'status': item.status, 'check_status': item.check_status} for item in items]


@sql_wrapper
def get_withdraw_records(query_dct, lsa=10000):
    """
    :param query_dct:
    :param lsa: limit search area, 限制搜索的ID范围
    :return:
    """
    min_id = None
    if lsa:
        max_item = Withdraw.query.order_by(Withdraw.id.desc()).first()
        if max_item:
            min_id = max_item.id - lsa

    query = Withdraw.query
    if 'user_id' in query_dct:
        query = query.filter(Withdraw.user_id == int(query_dct['user_id']))
    status = query_dct.get('status')
    if status:
        query = query.filter(Withdraw.status == int(status))
    created_at = query_dct.get('created_at')
    if created_at:
        created_at = json.loads(created_at)
        begin = created_at.get('$gte')
        end = created_at.get('$lte')
        if begin:
            query = query.filter(Withdraw.created_at >= begin)
        if end:
            query = query.filter(Withdraw.created_at <= end)
    if min_id:
        query = query.filter(Withdraw.id >= min_id)
    return query.all()


@sql_wrapper
def list_withdraw_records(query_dct, with_paginate=True):
    risk_type = 0
    if 'risk_type' in query_dct:
        risk_type = long(query_dct.pop('risk_type'))

    query = Withdraw.query.filter(generate_filter(
        parse_query_dct(query_dct, Withdraw), Withdraw))
    # auto_risk为true时，查询提现中含有风控信息的订单
    if query_dct.get('$auto_risk'):
        query = query.filter(Withdraw.check_status >= CHECK_STATUS.WAITING)

    if RISK_STATUS.get_label(risk_type):
        query = query.filter(Withdraw.extend.like(u'%%{}%%'.format(RISK_STATUS.get_label(risk_type))))

    user_id = query_dct.pop('user_id', None)
    if user_id:
        query = query.filter(Withdraw.user_id == user_id)

    # 限制范围
    query = limit_id_range(query, Withdraw)
    total_count = get_count(query)
    orderby = get_orderby(query_dct.get('$orderby'), Withdraw)
    if orderby is not None:
        query = query.order_by(orderby)
    if with_paginate:
        query = paginate(query, query_dct)
    return query.all(), total_count

@sql_wrapper
def get_withdraw(withdraw_id):
    return Withdraw.query.filter(Withdraw.id == withdraw_id).first()

@sql_wrapper
def withdraw_success_notify(withdraw_id, out_biz_no, payer_no='group_new_withdraw'):
    item = Withdraw.query.with_for_update().filter(Withdraw.id == withdraw_id).first()
    if not item:
        _LOGGER.error('withdraw id: %s not exist in db' % withdraw_id)
        raise err.ParamError('withdraw id: %s not exist in db' % withdraw_id)

    if item.status in [WITHDRAW_STATUS.DONE, WITHDRAW_STATUS.FAIL]:
        return False, item.as_dict()

    item.status = WITHDRAW_STATUS.DONE
    try:
        extend = json.loads(item.extend)
        trans_info = extend.get('auto_trans_info') if extend.get('auto_trans_info') else {}
    except ValueError:
        trans_info = {}
    trans_info.update({
        'complete_payer_no': payer_no,
        'complete_order_id': withdraw_id,
        'complete_out_biz_no': out_biz_no,
        'complete_pay_date': tz.local_now().strftime('%Y-%m-%d %H:%M:%S'),
    })
    updated_info = json.loads(item.extend)
    updated_info.update({'auto_trans_info': trans_info})
    item.extend = json.dumps(updated_info, ensure_ascii=False)
    balance = Account.query.filter(Account.id == item.user_id).first().balance
    item.balance = balance
    item.save()
    tracker.track_withdraw(item.user_id, item.target_type, -float(item.real_price))
    tracker.track_withdraw(item.user_id, item.target_type, float(item.real_price), WITHDRAW_STATUS.DONE)
    try:
        maestro_tracker.track_maestro_withdraw(
            item.id, item.user_id, item.target_type, item.price, item.real_price,
            WITHDRAW_STATUS.DONE, updated_info.get('auto_risk', ''),
            int(datetime.strftime(item.updated_at, '%s')))
    except Exception as e:
        _LOGGER.exception('track maestro withdraw fail, withdraw id: %s', withdraw_id)
    try:
        maestro_tracker.track_maestro_withdraw_financial(
            item.id, item.user_id, item.target_type, item.price, item.real_price,
            'success', int(datetime.strftime(item.updated_at, '%s')))
    except Exception as e:
        _LOGGER.exception('track maestro withdraw_financial fail, withdraw id: %s', withdraw_id)
    return True, item.as_dict()

@sql_wrapper
def withdraw_failed_notify(withdraw_id, out_biz_no, reason=None):
    item = Withdraw.query.with_for_update().filter(Withdraw.id == withdraw_id).first()
    if not item:
        _LOGGER.error('withdraw id: %s not exist in db' % withdraw_id)
        raise err.ParamError('withdraw id: %s not exist in db' % withdraw_id)

    if item.status == WITHDRAW_STATUS.FAIL:
        return

    if item.status == WITHDRAW_STATUS.DONE:
        # 如果该订单状态已经是成功了，但是UA又回调失败；表示该笔订单的转账之后被银行卡退回，转账不成功
        tracker.track_withdraw(item.user_id, item.target_type, -float(item.real_price),
                               status=WITHDRAW_STATUS.DONE)
        # 将该笔订单转变为待提现订单
        tracker.track_withdraw(item.user_id, item.target_type, float(item.real_price))

    item.status = WITHDRAW_STATUS.FAIL
    try:
        extend = json.loads(item.extend)
        trans_info = extend.get('auto_trans_info') if extend.get('auto_trans_info') else {}
    except ValueError:
        trans_info = {}
    trans_info.update({
        'complete_out_biz_no': out_biz_no,
        'complete_pay_date': tz.local_now().strftime('%Y-%m-%d %H:%M:%S'),
    })
    if reason:
        trans_info.update({'reason': reason})
    updated_info = json.loads(item.extend)
    updated_info.update({'auto_trans_info': trans_info})
    item.extend = json.dumps(updated_info, ensure_ascii=False)
    balance = Account.query.filter(Account.id == item.user_id).first().balance
    item.balance = balance
    item.save()
    try:
        maestro_tracker.track_maestro_withdraw_financial(
            item.id, item.user_id, item.target_type, item.price, item.real_price,
            'failure', int(datetime.strftime(item.updated_at, '%s')))
    except Exception as e:
        _LOGGER.exception('track maestro withdraw_financial fail, withdraw id: %s', withdraw_id)
