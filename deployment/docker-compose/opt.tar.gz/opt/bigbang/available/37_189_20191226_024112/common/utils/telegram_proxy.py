# -*- coding:utf-8 -*-
import requests

GROUP_DOMAIN_MONITOR = {'WITCH_BUG_FIX_BOT': -347162990}
ALARM_CHAT_IDS = [-1001460045325]
_API_SEND_TEXT_MESSAGE = 'https://api.telegram.org/bot742288847:AAHESXHhU8cfdfeNT5Nr5o7Lp4hlPLVLACs/sendMessage'


def send_text_message_to_group(text):
    for chat_id in GROUP_DOMAIN_MONITOR.values():
        send_text_message(chat_id, text)


def send_text_message(chat_id, text):
    params = dict(
        chat_id=chat_id,
        text=text,
    )
    response = requests.get(_API_SEND_TEXT_MESSAGE, params=params)
    if response.status_code != 200:
        return response.text


def send_alarm(text):
    for chat_id in ALARM_CHAT_IDS:
        send_text_message(chat_id, text)


if __name__ == '__main__':
    send_text_message_to_group('我是机器人')
