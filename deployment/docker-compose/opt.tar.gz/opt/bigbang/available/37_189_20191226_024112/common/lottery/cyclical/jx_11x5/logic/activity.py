# -*- coding: utf-8 -*-
'''考虑把term封装成类，用面向对象的方式实现以下函数
'''
from datetime import timedelta

from dateutil import parser

from common.utils import tz

TERM_INTERVAL = 20 * 60  # 单位秒

START_TIME = (9 * 60 + 10) * 60

END_TIME = (23 * 60 + 10) * 60

TOTAL_TERM = 42


def calc_term_by_ts(ts):
    '''通过绝对时间来计算期数（无偏移量）
    '''
    prefix, start_ts = tz.get_day_and_start_ts(ts)
    sub = ts - start_ts
    # 9点半开始第一期，23点过10结束，共84期
    if sub < START_TIME:  # 9:30
        term = 1
    # 11 * 60 * 60 = 82800
    elif sub < END_TIME:  # 23:00
        term = (sub - START_TIME) / TERM_INTERVAL + 1
    else:
        # first term in next day
        prefix = tz.get_next_day(ts)
        term = 1
    assert 1 <= term <= TOTAL_TERM
    return '%s%s' % (prefix, str(term).zfill(2))


def _plus_term(day, real_term, offset):
    day_offset = offset / TOTAL_TERM
    term_offset = offset % TOTAL_TERM
    day += timedelta(days=day_offset)
    real_term += term_offset
    if real_term > TOTAL_TERM:
        real_term -= TOTAL_TERM
        day += timedelta(days=1)
    elif real_term < 0:  # term_offset可能为负数
        real_term += TOTAL_TERM
        day -= timedelta(days=1)
    return day, real_term


def _format_term(day, real_term):
    return '%s%s' % (day.strftime('%Y%m%d'), str(real_term).zfill(2))


def plus_term(term, offset):
    '''计算期号，offset可以为负数
    '''
    if offset == 0:
        return term
    prefix, real_term = term[:8], int(term[8:])
    prefix, real_term = _plus_term(parser.parse(prefix), real_term, offset)
    return _format_term(prefix, real_term)


def xrange_term(term, count, step=1):
    '''生成器，根据plus term生成一个迭代器，类似xrange
    '''
    if step == 0:
        raise ValueError('step must be not 0')
    if count == 0:
        yield term
    cur_count = 0
    prefix, real_term = term[:8], int(term[8:])
    prefix = parser.parse(prefix)
    while abs(cur_count) < abs(count):
        cur_count += 1
        if cur_count == 1:
            yield term
        else:
            prefix, real_term = _plus_term(prefix, real_term, step)
            yield _format_term(prefix, real_term)


def calc_start_ts_by_term(term):
    '''通过期数计算开始时间，用来手动开启当前期数（无偏移量）
    '''
    prefix = term[:8]
    term = int(term[8:])
    start_ts = tz.to_ts(tz.local_to_utc(parser.parse(prefix)))
    return start_ts + START_TIME + (term - 1) * TERM_INTERVAL


def calc_stop_ts(start_ts):
    '''根据开始时间和当前的时间，来计算结束的时间，无偏移量
    '''
    term = calc_term_by_ts(start_ts)
    return calc_start_ts_by_term(term) + TERM_INTERVAL
