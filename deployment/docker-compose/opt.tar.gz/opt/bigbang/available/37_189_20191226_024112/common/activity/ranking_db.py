# -*- coding: utf-8 -*-

from datetime import timedelta, datetime

from common import orm
from common.account.db.account import get_account
from common.account.model.account import BALANCE_TYPE
from common.cache import redis_cache
from common.lottery.db import get_user_today_lottery_effective_bet
from common.platform.common.db import get_user_today_game_effective_bet
from common.preset.model.preset import BANNER_TYPE
from common.stats.report import get_total_join_order_list
from common.transaction.db import create_transaction
from common.transaction.model import TRANSACTION_TYPE, TRANSACTION_STATUS
from common.utils import track_logging
from common.utils.currency import convert_yuan_to_hao
from common.utils.tz import get_utc_date, ts_to_local_date_str
from utils import get_activity_time, ts_to_date_str_list, hide_user_name
from .ranking_model import RankingRecord, RECORD_TYPE, DAILY_AWARD, TOTAL_AWARD
from common.notification.handler import notify_spring_rank

_LOGGING = track_logging.getLogger(__name__)


def get_today_my_join(user_id):
    if not user_id:
        return user_id
    return get_user_today_lottery_effective_bet(user_id) + get_user_today_game_effective_bet(user_id)


def get_activity_rang_ranking(start_date, end_date):
    """
    根据时间获取排名
    :param start_date:
    :param end_date:
    :return:
    [{"user_id":123,'total_join':12313.123,'rank':1,user_name='XXX'}]
    """

    ranks = get_total_join_order_list(start_date, end_date)
    ranks = sorted(ranks, key=lambda k: k['total_join'], reverse=True)
    result = []
    for rank_info in ranks:
        if not rank_info['total_join']:
            ranks.remove(rank_info)
    for index, rank_info in enumerate(ranks):
        user = get_account(rank_info['_id'], use_cache=True)
        result.append(
            dict(user_id=rank_info['_id'], consumption=rank_info['total_join'], rank=index + 1,
                 user_name=user.user_name))

    return result


def get_ranks(activity_date, total):
    if had_open(activity_date, total):
        return [rank.as_dict() for rank in get_history_ranking_by_db(activity_date, total)]

    return get_history_ranking_by_mongo(activity_date, total)


def add_ranking_record(user_id, user_name, rank, activity_date, record_type, total_join, amount, auto_commit=False):
    r = RankingRecord()
    r.user_id = user_id
    r.user_name = user_name
    r.rank = rank
    r.date = activity_date
    r.record_type = record_type
    r.total_join = total_join
    r.amount = amount
    r.save(auto_commit=auto_commit)


def get_history_ranking_by_mongo(activity_date, total):
    activity_start_time, activity_end_time = get_activity_time(BANNER_TYPE.get_key('ranking'))

    if activity_date:
        activity_dates = ts_to_date_str_list(activity_start_time, activity_end_time)
        if activity_date not in activity_dates:
            _LOGGING.info("activity_date not in activity_dates {} {}".format(activity_date, activity_dates))
            return
        start_time = get_utc_date(activity_date)
        end_time = start_time + timedelta(days=1)

    if total:
        start_time = get_utc_date(ts_to_local_date_str(activity_start_time))
        end_time = get_utc_date(ts_to_local_date_str(activity_end_time))

    return get_activity_rang_ranking(start_time, end_time)


def get_history_ranks(days=[]):
    if not days:
        return []
    data_list = []
    award = get_award_list(RECORD_TYPE.DAILY)
    for day in days:
        day_dict = {}
        winners = []
        day_winners = orm.session.query(RankingRecord).\
            filter(RankingRecord.date == day,
                   RankingRecord.record_type == RECORD_TYPE.DAILY).\
            order_by(RankingRecord.rank).all()
        if day_winners:
            new_list = sorted(day_winners, key=lambda x: x.rank)
            for winner in new_list:
                if winner.total_join:
                    win_dict = {
                        'user_name': hide_user_name(winner.user_name),
                        'rank': winner.rank,
                        'consumption': int(float(winner.total_join)),
                        'prize': award[winner.rank - 1]
                    }
                    winners.append(win_dict)
        day_dict = {
            'date': day,
            'rank': winners
        }
        data_list.append(day_dict)
    return data_list


def get_today_ranks(day):
    award = get_award_list(RECORD_TYPE.DAILY)
    day_winners = orm.session.query(RankingRecord).\
        filter(RankingRecord.date == day,
               RankingRecord.record_type == RECORD_TYPE.DAILY).\
        order_by(RankingRecord.rank).all()
    if not day_winners:  # get from cache
        winners = []
        rank_list = redis_cache.get_today_ranks(day)
        for ranker in rank_list:
            if ranker.get('consumption'):
                win_dict = {
                    'user_name': hide_user_name(ranker['user_name']),
                    'rank': ranker['rank'],
                    'consumption': int(float(ranker['consumption'])),
                    'prize': award[ranker['rank'] - 1]
                }
                winners.append(win_dict)
        return {'date': day, 'rank': winners}
    winners = []
    for winner in day_winners:
        win_dict = {
            'user_name': hide_user_name(winner.user_name),
            'rank': winner.rank,
            'consumption': int(float(winner.total_join)),
            'prize': award[winner.rank - 1]
        }
        winners.append(win_dict)
    return {'date': day, 'rank': winners}


def get_total_ranks():
    award = get_award_list(RECORD_TYPE.TOTAL)
    total_winners = orm.session.query(RankingRecord).\
        filter(RankingRecord.record_type == RECORD_TYPE.TOTAL).\
        order_by(RankingRecord.rank).all()
    if not total_winners:
        winners = []
        rank_list = redis_cache.get_total_ranks()
        for ranker in rank_list:
            if ranker.get('consumption'):
                win_dict = {
                    'user_name': hide_user_name(ranker['user_name']),
                    'rank': ranker['rank'],
                    'consumption': int(float(ranker['consumption'])),
                    'prize': award[ranker['rank'] - 1]
                }
                winners.append(win_dict)
        return {'rank': winners}
    winners = []
    for winner in total_winners:
        win_dict = {
            'user_name': hide_user_name(winner.user_name),
            'rank': winner.rank,
            'consumption': int(float(winner.total_join)),
            'prize': award[winner.rank - 1]
        }
        winners.append(win_dict)
    return {'rank': winners}


def get_history_ranking_by_db(activity_date, total):
    if total:
        return orm.session.query(RankingRecord).filter(RankingRecord.record_type == RECORD_TYPE.TOTAL).order_by(
            RankingRecord.rank).all()
    return orm.session.query(RankingRecord).filter(RankingRecord.date == activity_date,
                                                   RankingRecord.record_type == RECORD_TYPE.DAILY).order_by(
        RankingRecord.rank).all()


def had_open(activity_date=None, total=None):
    assert activity_date or total
    if activity_date:
        return orm.session.query(RankingRecord).filter(RankingRecord.date == activity_date,
                                                       RankingRecord.record_type == RECORD_TYPE.DAILY).count()
    if total:
        return orm.session.query(RankingRecord).filter(RankingRecord.record_type == RECORD_TYPE.TOTAL).count()


def get_award_list(award_type):
    return TOTAL_AWARD if award_type == RECORD_TYPE.TOTAL else DAILY_AWARD


def open_prize(activity_date=None, total=None):
    assert activity_date or total

    if had_open(activity_date, total):
        return

    ranks = get_history_ranking_by_mongo(activity_date, total)

    record_type = RECORD_TYPE.TOTAL if total else RECORD_TYPE.DAILY

    award = get_award_list(record_type)

    notify_users = []
    for rank_info in ranks:
        user_id = rank_info['user_id']
        total_join = rank_info['consumption']
        rank = rank_info['rank']
        user_name = rank_info['user_name']

        user = get_account(user_id, use_cache=True)
        if not user:
            _LOGGING.info("ranking user_id not exists {}".format(user_id))
            continue

        amount = award[rank - 1]
        add_ranking_record(user_id, user_name, rank, activity_date, record_type, total_join, amount)

        data = {
            'user_id': user_id,
            'type': TRANSACTION_TYPE.RANKING_AWARD,
            'status': TRANSACTION_STATUS.DONE,
            'title': u'财富风云榜活动奖励',
            'price': convert_yuan_to_hao(amount),
            'balance_type': BALANCE_TYPE.WITHDRAW,
        }
        create_transaction(data)
        orm.session.commit()
        notify_users.append({'user_id': user_id, 'award': amount})
    if notify_users:
        for user in notify_users:
            notify_spring_rank(user['user_id'], user['award'])
