# -*- coding: utf-8 -*-
# 辅助计算的一些数学函数

import operator


def c(n, k):
    return r(n) / r(k) / r(n - k)


def fac(n):
    return reduce(operator.mul, range(1, n + 1))


def a(n, k):
    return reduce(operator.mul, range(n - k + 1, n + 1))


def r(x):
    """
    阶乘
    """
    if x in (1, 0):
        return 1
    else:
        return reduce(operator.mul, range(1, x + 1))


from decimal import Decimal

print r(Decimal(1))
