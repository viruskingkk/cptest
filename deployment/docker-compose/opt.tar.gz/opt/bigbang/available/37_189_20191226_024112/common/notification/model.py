# -*- coding: utf-8 -*-
from django.conf import settings
from common import orm
from common.utils.types import Enum

# context要做消息模版展示，do not change
NOTIFY_TYPE = Enum({
    "AWARD": (1L, u"中奖消息"),
    "CAMPAIGN": (2L, u"活动消息"),
    "SYSTEM": (3L, u"系统公告"),
    "INSIDE": (4L, u"站内消息")
})

# 与用户关联的非系统消息类型
USER_NOTIFY_TYPES = (NOTIFY_TYPE.AWARD, NOTIFY_TYPE.INSIDE)

# 与用户无关的系统消息类型
SYS_NOTIFY_TYPES = [NOTIFY_TYPE.CAMPAIGN, NOTIFY_TYPE.SYSTEM]

NOTIFY_ICONS = {
    NOTIFY_TYPE.AWARD: settings.QINIU_BUCKETS['default'] + 'ic_notification_zhongjiang.png',
    NOTIFY_TYPE.CAMPAIGN: settings.QINIU_BUCKETS['default'] + 'ic_notification_huodong.png',
    NOTIFY_TYPE.SYSTEM: settings.QINIU_BUCKETS['default'] + 'ic_notification_gonggao.png',
    NOTIFY_TYPE.INSIDE: settings.QINIU_BUCKETS['default'] + 'ic_notification_message.png',
}

NOTIFY_STATUS = Enum({
    "UNRELEASED": (0L, u"未发布"),
    "RELEASED": (1L, u"已发布")
})

CREATED_BY_TYPE = Enum({
    "SYSTEM": (0, "system"),
    "CONSOLE": (1, "console"),
})


class Notification(orm.Model):
    __tablename__ = "notification"
    id = orm.Column(orm.BigInteger, primary_key=True)
    user_id = orm.Column(orm.BigInteger)
    notify_type = orm.Column(orm.Integer)  # 通知类型, 消息分类, 1 2 3 4
    content = orm.Column(orm.TEXT)  # 通知内容. JSON, 包含title, content, tag
    extend = orm.Column(orm.TEXT)  # 存放系统消息的filters
    command = orm.Column(orm.TEXT)
    read = orm.Column(orm.Boolean, default=False)  # 已读／未读
    expire_ts = orm.Column(orm.Integer)  # 过期时间戳
    status = orm.Column(orm.SmallInteger, default=0)  # 状态，已／未发布
    created_by = orm.Column(orm.Integer, default=0)  # 0：系统 ，1：控制台
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


PUSH_DEVICE = Enum({
    'ALL': (0L, u'全部'),
    'ANDROID': (1L, u'安卓设备'),
    'IOS': (2L, u'IOS设备')
})

PUSH_STATUS = Enum({
    'READY': (0L, u'未处理'),
    'PUSHING': (1L, u'推送中'),
    'SUCCESS': (2L, u'推送完成'),
    'FAIL': (3L, u'推送失败'),
})


class XingeNotification(orm.Model):
    """
    信鸽推送消息
    """
    __tablename__ = 'xinge_notification'
    id = orm.Column(orm.BigInteger, primary_key=True)
    title = orm.Column(orm.TEXT)  # 通知标题
    content = orm.Column(orm.TEXT)  # 通知内容
    push_device = orm.Column(orm.Integer)  # 发送的设备
    status = orm.Column(orm.Integer)
    send_time = orm.Column(orm.TEXT)
    cmd = orm.Column(orm.TEXT)  # 跳转页面
    extend = orm.Column(orm.TEXT)  # 信鸽推送的到达数，点击数等
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class InAppAnnouncement(orm.Model):
    __tablename__ = 'in_app_announcement'
    id = orm.Column(orm.BigInteger, primary_key=True)
    title = orm.Column(orm.TEXT)
    content = orm.Column(orm.TEXT)
    start_ts = orm.Column(orm.BigInteger)
    end_ts = orm.Column(orm.BigInteger)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
