# -*- coding: utf-8 -*-
import time
from datetime import datetime, timedelta

from common import orm
from common.cache import redis_cache
from common.platform.common.base import AbstractHandler
from common.platform.common.model import PLATFORM_TYPE
from common.platform.ares import ares_api, db
from common.utils import track_logging, tracker, tz
from common.utils.currency import convert_fen_to_yuan, convert_yuan_to_fen
from common.utils import exceptions as err
from common.utils import id_generator
from analysis.games.es import emit_game_order

_LOGGER = track_logging.getLogger(__name__)

IMONE_WALLET_DCT = {10002: 2, 10003: 4, 1001: 201, 1002: 201}


def get_wallet_by_user(user_id):
    game_id = redis_cache.get_account_ares_gameId(user_id)
    if not game_id:
        return 0
    wallet = IMONE_WALLET_DCT[game_id]
    return wallet


def get_game_by_redis(user_id):
    game_id = redis_cache.get_account_ares_gameId(user_id)
    if not game_id:
        return 0
    return game_id


class AresHandler(AbstractHandler):
    def get_platform_code(self):
        return PLATFORM_TYPE.ARES

    def shutdown(self):
        return False

    def available(self, user_id, **kwargs):
        if db.is_pass_user(user_id):
            pass
        if db.is_black_user(user_id):
            raise err.ServerError(u'游戏维护中，请稍后重试')
        return True

    def check_trans_existed(self, ref_id):
        status, _ = ares_api.check_transfer_status_v2(ref_id)
        return status

    def query_balance_and_frozen_status(self, user_id):
        game_id = get_game_by_redis(user_id)
        status, data = ares_api.query_balance_v2(user_id, game_id)
        if not status:
            return 0, True
        balance = convert_yuan_to_fen(data['balance'])
        if balance < 0:
            return 0, True
        if int(game_id) == 100020:
            balance = int(balance / 100) * 100
        return balance, False

    def login_third(self, user_id, amount, ref_id, **params):
        game_id = int(params['game_id'])
        redis_cache.add_account_ares_gameId(user_id, game_id)
        amount = int(convert_fen_to_yuan(amount))
        status, data = ares_api.enter_game_v2(user_id, game_id, ref_id, amount, ip="127.0.0.1")
        if status:
            data['url'] = data['game_url']
            return data
        else:
            raise err.ServerError(u'登入游戏失败，请稍候重试')

    def logout_third(self, user_id, amount, ref_id, *params):
        game_id = get_game_by_redis(user_id)
        status, data = ares_api.exit_game_v2(user_id, ref_id, game_id)
        if not status:
            return False, 0
        return True, data['gold']


handler = AresHandler()


def add_bet_log_to_db(item):
    log = db.add_bet_logs(item)
    orm.session.commit()
    order_id = id_generator.generate_long_id(log['ref_id'])
    emit_game_order(log['user_id'], PLATFORM_TYPE.ARES, log['game_id'], order_id, log['bet_amount'],
                    log['bet_result'], datetime.strptime(log['create_time'], "%Y-%m-%d %H:%M:%S"))
    tracker.track_imone(log['user_id'], log['game_id'], float(item['gold_bet']),
                       float(item['gold_win']), log['create_time'])
