# -*- coding:utf-8 -*-
import json
import requests

from common.utils.types import Enum


_SEND_TEXT_API = 'https://api.potato.im:8443/8025178:EPl15VKEjL0FxOx0amOH3ga6/sendTextMessage'
_SEND_INLINE_API = 'https://bot.potato.im:5423/8025178:EPl15VKEjL0FxOx0amOH3ga6/sendInlineMarkupMessage'
_SEND_ACK_API = 'https://bot.potato.im:5423/8025178:EPl15VKEjL0FxOx0amOH3ga6/sendCallbackAnswer'


ADMIN = Enum({
    "ARNO": (8039825, u"arno"),
    "LORRY": (8040019, u"lorry"),
    "OWEN": (8039983, u"owen"),
    "MIKE": (8039163, u"mike"),
    "LISP": (8001199, u"lisp"),
    "JAMES": (8039279, u"james"),
    "KAEL": (8041455, u"kael"),
    "ALIN": (8040961, u"alin"),
    "AMY": (8040143, u"amy"),
    "GINA": (8040023, u"gina"),
})


def send_callback_ack(user_id, inline_message_id, show_alert='received'):
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    post_data = {
        "user_id": user_id,
        "inline_message_id": inline_message_id,
        "show_alert": show_alert,
    }
    response = requests.post(_SEND_ACK_API, data=json.dumps(post_data,separators=(',',':')), headers=headers, timeout=5)
    print response.text


def send_text_msg(chat_type, chat_id, chat_text):
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    post_data = {
        "chat_type": chat_type,
        "chat_id": chat_id,
        "text": chat_text,
        "markdown": True,
    }
    response = requests.post(_SEND_TEXT_API, data=json.dumps(post_data,separators=(',',':')), headers=headers, timeout=5)
    print response.text


def send_inline_markup_msg(chat_type, chat_id, chat_text, inline_markup):
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    post_data = {
        "chat_type": chat_type,
        "chat_id": chat_id,
        "text": chat_text,
        "markdown": True,
        "inline_markup": inline_markup
    }
    print json.dumps(post_data)
    response = requests.post(_SEND_INLINE_API, data=json.dumps(post_data,separators=(',',':')), headers=headers, timeout=5)
    print response.text


if __name__ == "__main__":
    inline_markup = [
        [{
            'type': 0,
            'text': 'Hello',
            'data': 'OnClick'
        }]
    ]
    send_inline_markup_msg(1, 8001739, u'start', inline_markup)
    #send_text_msg(1, 8001739, u'this is a plain text msg')
