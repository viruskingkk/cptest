# -*- coding: utf-8 -*-
import json
from common.withdraw.db import WITHDRAW_STATUS, list_withdraw_records
from common.admin import db as admin_db
from common.utils.tz import utc_to_local_str
from common.transaction import calc_withdraw_amount
from common.transaction.db import WITHDRAW_TYPE, CHECK_STATUS


def export_withdraw_records(query_dct):
    items, _ = list_withdraw_records(query_dct, with_paginate=False)
    admin_map = admin_db.get_user_id_to_name_map()
    resp_items = []
    for item in items:
        withdraw_at = utc_to_local_str(item.created_at)
        updated_at = utc_to_local_str(item.updated_at)
        withdraw_info = json.loads(item.extend or '{}')
        withdraw_status = WITHDRAW_STATUS.get_label(item.status)
        name = withdraw_info.get('name')
        phone = withdraw_info.get('phone')
        third_id = '-'
        pay_date = '-'
        withdraw_chn = '-'
        if 'auto_trans_info' in withdraw_info:
            third_id = withdraw_info['auto_trans_info'].get('order_id') or '-'
            pay_date = withdraw_info['auto_trans_info'].get('complete_pay_date')
            payer_no = withdraw_info['auto_trans_info'].get('payer_no')
            if payer_no == 'group_new_withdraw':
                withdraw_chn = u'万豪下分'
            else:
                withdraw_chn = u'官方下分'
        real_amount = item.real_price or calc_withdraw_amount(item.user_id, item.price)
        data_row = [item.id, item.user_id, item.price, real_amount,
                    WITHDRAW_TYPE.get_label(item.target_type), withdraw_chn, CHECK_STATUS.get_label(item.check_status),
                    withdraw_status, withdraw_at, updated_at]
        data_row += [third_id, pay_date]
        admin_id = withdraw_info.get('manual_check_info', {}).get('admin_id')
        if admin_id:
            data_row += [admin_map.get(admin_id)]
        else:
            data_row += ['']
        resp_items.append(data_row)
    return resp_items


def query_withdraw_items(query_dct):

    items, total_count = list_withdraw_records(query_dct)

    resp_items = []
    for item in items:
        data = item.as_dict()
        data['id'] = str(data['id'])
        data['real_cash_price'] = calc_withdraw_amount(data['user_id'], data['price'])
        data['created_at'] = utc_to_local_str(data['created_at'])
        data['updated_at'] = utc_to_local_str(data['updated_at'])
        data['withdraw_info'] = json.loads(data['extend'] or '{}')
        resp_items.append(data)

    return resp_items, total_count
