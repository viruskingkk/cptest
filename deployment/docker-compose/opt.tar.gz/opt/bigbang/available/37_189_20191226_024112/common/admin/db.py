# -*- coding: utf-8 -*-
from datetime import datetime

from future.utils import raise_with_traceback
from sqlalchemy.exc import SQLAlchemyError

from common.admin.model import (User, Permission,
                                UserToken, ROLE, Record)
from common.admin.model import orm
from common.account.db.account import encode_password
from common.utils import exceptions as err
from common.utils.respcode import StatusCode
from common.utils import id_generator
from common.utils.db import (get_orderby, parse_query_dct, list_object,
                             paginate, generate_filter, upsert, get_count)


def sql_wrapper(func):
    def _wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except SQLAlchemyError as e:
            orm.session.rollback()
            raise_with_traceback(err.DbError(e))
        except err.Error:
            orm.session.rollback()
            raise
        except Exception as e:
            orm.session.rollback()
            raise_with_traceback(err.Error(e))
        finally:
            orm.session.close()

    return _wrapper


@sql_wrapper
def create_user(email, password, nickname='',
                role=ROLE.FORBIDDEN):
    user = User()
    user.email = email
    user.password = encode_password(password)
    user.nickname = nickname
    user.role = role
    user.duty = 0
    user.created_at = user.updated_at = datetime.utcnow()

    user.save()


@sql_wrapper
def update_user(info, editor_info):
    user = User.query.with_for_update().filter(
        User.id == info['id']).first()
    if not user:
        raise_with_traceback(err.AuthenticateError(
            status=StatusCode.INVALID_USER))
    if info['id'] != editor_info.id and (
            'role' in info and editor_info.role <= int(info['role'])):
        raise_with_traceback(err.PermissionError())

    if 'perm' in info:
        perm_attrs = info['perm'].split('|')
        if '' in perm_attrs:
            perm_attrs.remove('')
        editor_info_attrs = (editor_info.perm).split('|')
        if not set(perm_attrs).issubset(set(editor_info_attrs)):
            raise_with_traceback(err.PermissionError())

    if 'password' in info:
        info['password'] = encode_password(info['password'])

    for k, v in info.iteritems():
        setattr(user, k, v)

    user.save()
    return user


@sql_wrapper
def list_users(query_dct, origin_role, disable_paginate):
    if origin_role < 2:
        return [], 0
    # user can only see lower level users
    query_dct = parse_query_dct(query_dct, User)
    email = query_dct.get('email')
    if 'role' in query_dct and origin_role < query_dct['role']:
        raise err.PermissionError()
    elif 'role' not in query_dct:
        query_dct['role'] = {"$lte": origin_role}
    if email:
        query_dct['email'] = {"$like": '%{}%'.format(email)}
    query = User.query.filter(generate_filter(query_dct, User))
    total_count = get_count(query)
    # orderby = get_orderby(query_dct.get('$orderby'), User)
    # if orderby is not None:
    #     query = query.order_by(orderby)
    # if not disable_paginate:
    #     query = paginate(query, query_dct)
    return query.all(), total_count


@sql_wrapper
def get_user(user_id):
    return User.query.filter(User.id == user_id).first()


@sql_wrapper
def login_user(email, password):
    user = User.query.filter(User.email == email).first()
    if not user:
        raise err.AuthenticateError(status=StatusCode.INVALID_USER)

    if user.password != encode_password(password):
        raise err.AuthenticateError(status=StatusCode.WRONG_USERNAME_PASSWORD)

    user_token = UserToken()
    user_token.token = id_generator.generate_uuid()
    user_token.deleted = 0
    user_token.user_id = user.id
    user_token.save()

    user_info = user.as_dict()
    user_info['token'] = user_token.token
    user_info.pop('password', '')
    return user_info


@sql_wrapper
def logout_device(user_id, token):
    UserToken.query.filter(
        UserToken.user_id == user_id).filter(UserToken.token == token).update(
        {'deleted': 1})

    orm.session.commit()


@sql_wrapper
def logout_user(user_id):
    UserToken.query.filter(
        UserToken.user_id == user_id).update({'deleted': 1})
    orm.session.commit()


@sql_wrapper
def get_online_info(user_id, token):
    return UserToken.query.filter(
        UserToken.user_id == user_id).filter(UserToken.token == token).first()


@sql_wrapper
def list_perm(query_dct):
    return list_object(query_dct, Permission)


@sql_wrapper
def create_perm(url, permission, min_role):
    perm = Permission()
    perm.url = url
    perm. permission = permission
    perm.min_role = min_role
    perm.created_at = perm.updated_at = datetime.utcnow()
    perm.save()
    return perm


@sql_wrapper
def get_perm(url=None, perm=None, id=None):
    if id:
        return Permission.query.filter(
            Permission.id == id).first()
    elif url and perm:
        return Permission.query.filter(
            Permission.url == url).filter(
            Permission.permission == perm).first()


@sql_wrapper
def update_perm(id, min_role, user_perm, desc, editor_info):
    if editor_info.role != ROLE.ADMIN:
        raise err.PermissionError('permission not allowd!')
    perm = Permission.query.filter(
        Permission.id == id).with_for_update().first()
    if perm:
        perm.min_role = min_role
        perm.desc = desc
        perm.user_perm = user_perm
        perm.save()


@sql_wrapper
def insert_record(info):
    return upsert(Record, info)


@sql_wrapper
def list_record(query_dct):
    email = query_dct.pop('email', None)
    query = orm.session.query(Record, User.email).join(
        User, Record.operator == User.id)
    if email is not None:
        query = query.filter(User.email.like('%%%s%%' % email))
    query_dct = parse_query_dct(query_dct, Record)
    query = query.filter(generate_filter(query_dct, Record))
    total_count = get_count(query)
    orderby = get_orderby(query_dct.get('$orderby'), Record)
    if orderby is not None:
        query = query.order_by(orderby)
    query = paginate(query, query_dct)
    return query.all(), total_count


@sql_wrapper
def get_nickname_by_id(user_id):
    query = User.query.filter(User.id == user_id).first()
    return query.nickname


def get_latest_active(user_id):
    query = UserToken.query.filter(UserToken.user_id == user_id).order_by(
        UserToken.updated_at.desc()).first()
    if not query:
        return
    return query.updated_at


@sql_wrapper
def get_user_id_to_name_map():
    users = User.query.all()
    return {user.id: user.nickname for user in users}
