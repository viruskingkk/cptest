# -*- coding: utf-8 -*-

import hashlib
import json
import time
from datetime import datetime
import requests

from django.conf import settings

from common.utils import track_logging

_LOGGER = track_logging.getLogger(__name__)

ARES_KEY = settings.ARES_KEY
ARES_URL = settings.ARES_URL
MERCHANT = "WITCH"
WEBSITE = "witch"
TIMESTAMP = int(time.time())


def generate_sign_v2(parameter, key):
    parameter['timestamp'] = int(time.time())
    s = ''
    for k in sorted(parameter.keys()):
        s += '%s=%s&' % (k, parameter[k])
    s += 'key=%s' % key
    print(s)
    m = hashlib.md5()
    m.update(s.encode('utf8'))
    sign = m.hexdigest().upper()
    return sign


def _base_request_v2(method, data, success_code=[0], timeout=10):
    url = ARES_URL + method
    key = ARES_KEY
    timestamp = int(time.time())
    headers = {'content-type': 'application/json'}
    data['M'] = MERCHANT
    data['L'] = WEBSITE
    data['timestamp'] = timestamp
    sign = generate_sign_v2(data, key)
    data['sign'] = sign
    _LOGGER.info('begin request imone_api {}, data: {}'.format(method, data))
    resp = requests.post(url, headers=headers, data=json.dumps(data, separators=(',', ':')), timeout=timeout)
    _LOGGER.info('finish request imone_api {}-{}, resp.content:{}'.format(method, data, resp.content))
    if resp.status_code != 200:
        return False, None
    else:
        resp_data = json.loads(resp.text)
        if resp_data['status'] in success_code:
            return True, resp_data.get('data')
        else:
            return False, None


def enter_game_v2(user_id, game_id, ref_id, gold, ip="127.0.0.1"):
    """
    进入imone游戏
    :return: (status, data) status: bool 标识是否成功
                            data: 成功后的数据，失败返回None
    """
    method = '/v2/enter_game/'
    data = {"user": user_id, "game_id": game_id, "refs": ref_id, "gold": gold, "ip_address": ip}
    return _base_request_v2(method, data)


def exit_game_v2(user_id, ref_id, game_id):
    method = '/v2/exit_game/'
    data = {"user": user_id, "refs": ref_id, "game_id": game_id}
    return _base_request_v2(method, data)


def query_balance_v2(user_id, game_id):
    """查询当前在游戏内的余额"""
    method = '/v2/get_balance/'
    data = {"user": user_id, "game_id": game_id}
    return _base_request_v2(method, data)


def check_transfer_status_v2(ref_id):
    """
    查询转账交易状态
    """
    method = '/v2/transfer/status/'
    data = {"refs": ref_id}
    return _base_request_v2(method, data)


def query_bet_logs_v2(start_date, end_date, page, size):
    """查询投注记录"""
    method = '/v2/bet_log/'
    start_str = datetime.strftime(start_date, '%Y-%m-%d %H:%M:%S')
    end_str = datetime.strftime(end_date, '%Y-%m-%d %H:%M:%S')
    data = {"start_time": start_str, "end_time": end_str, "page": page, "size": size}
    return _base_request_v2(method, data)


def check_IMplayer_id_v2(user_id):
    """根据平台用户ID查询IM玩家ID"""
    method = '/v2/imone_id/'
    data = {"user": user_id}
    return _base_request_v2(method, data)


def get_game_name(game_id):
    """根据游戏ID查询游戏name"""
    method = '/v2/get_game_name/'
    data = {"game_id": game_id}
    return _base_request_v2(method, data)
