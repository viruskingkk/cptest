# -*- coding: utf-8 -*-
import logging

from common.utils.decorator import sql_wrapper
from common.utils.db import list_object, get, upsert, delete
from common.preset.model.preset import Loading
from common.utils.tz import local_date_to_ts

_LOGGER = logging.getLogger(__name__)


@sql_wrapper
def get_loading(id):
    return get(Loading, id)


@sql_wrapper
def upsert_loading(info, id=None):
    info['start_ts'] = local_date_to_ts(info['start_ts'])
    info['end_ts'] = local_date_to_ts(info['end_ts'])
    return upsert(Loading, info, id)


@sql_wrapper
def list_loading(query_dct):
    return list_object(query_dct, Loading)


@sql_wrapper
def delete_loading(id):
    delete(Loading, id)
