# -*- coding: utf-8 -*-
import logging
import json
from datetime import datetime

from sqlalchemy import or_

from common import orm, slave
from common.utils.decorator import sql_wrapper, slave_wrapper
from common.utils.db import (delete, get_orderby,
                             parse_query_dct, paginate,
                             generate_filter, get_count)
from common.preset.model.preset import Preset
from common.utils import EnhencedEncoder

_LOGGER = logging.getLogger(__name__)


@slave_wrapper
def get_preset(id=None, app_version=None, device_type=None, chn=None):
    query = slave.session.query(Preset)
    if id:
        return query.filter(Preset.id == id).first()
    if app_version is not None:
        query = query.filter(
            # if not the default...
            Preset.min_version <= app_version).filter(
            or_(Preset.max_version >= app_version,
                Preset.max_version == None))
    if chn:
        s = '%,' + chn + ',%'
        q1 = query.filter(Preset.chn.like(s)).first()
        if q1:
            return q1
        else:
            query = query.filter(Preset.chn.in_((None, '')))
    if device_type is not None:
        query = query.filter(
            Preset.device_type.op('&')(device_type) > 0)
    inst = query.first()
    return inst


@sql_wrapper
def upsert_preset(info=None, id=None, base=None):
    if id is not None:
        preset = Preset.query.with_for_update().filter(
            Preset.id == id).first()
    else:
        if base is not None:
            preset = Preset()
            base_inst = Preset.query.filter(Preset.id == base).one().as_dict()
            for k in 'id', 'created_at', 'updated_at':
                base_inst.pop(k, None)
            base_inst['last_modified'] = 0
            preset = preset.from_dict(base_inst)
        else:
            preset = Preset()
            preset.min_version = 1
            preset.max_version = None
            preset.device_type = 0
            preset.content = json.dumps({
                'banner': [],
                'loading': [],
            })
            preset.last_modified = 0

        preset.created_at = preset.updated_at = datetime.utcnow()

    preset.last_modified += 1
    if info is not None:
        for k, v in info.iteritems():
            if hasattr(Preset, k) and k not in (
                    'last_modified', 'created_at', 'updated_at'):
                if k == 'content':
                    setattr(preset, k, json.dumps(
                        v, cls=EnhencedEncoder, ensure_ascii=False))
                else:
                    setattr(preset, k, v)
    if preset.content:
        ipay = json.loads(preset.content).get('ipay')
        if ipay:
            preset.webmode = ipay.get('webmode')
    preset.save()
    return preset


def list_preset(query_dct):
    version = query_dct.pop('version', None)
    device_type = query_dct.pop('device_type', None)
    webmode = query_dct.pop('webmode', None)

    if version:
        return [get_preset(app_version=int(version),
                           device_type=int(device_type))], 1

    query = Preset.query
    if device_type is not None:
        device_type = int(device_type)
        query = query.filter(Preset.device_type.op('&')(device_type) > 0)
    if webmode and int(webmode) >= 0:
        query = query.filter(Preset.webmode == int(webmode))
    query = query.filter(generate_filter(
        parse_query_dct(query_dct, Preset), Preset))
    total_count = get_count(query)
    orderby = get_orderby(query_dct.get('$orderby'), Preset)
    if orderby is not None:
        query = query.order_by(orderby)
    query = paginate(query, query_dct)
    return query.all(), total_count


@sql_wrapper
def delete_preset(id):
    delete(Preset, id)
