# -*- coding: utf-8 -*-
import re
from decimal import Decimal
from functools import wraps

from future.utils import raise_with_traceback
from django.views.decorators.csrf import csrf_exempt
from django.utils.encoding import smart_unicode
from geoip import geolite2
import geoip2.database

from common.utils.exceptions import AuthenticateError, ParamError
from common.utils.respcode import StatusCode

from django.conf import settings

DEFAULT_COUNTRY = "OTHER"
_DEFAULT_PAGE_SIZE = 10
_MAX_PAGE_SIZE = 30

city_reader = geoip2.database.Reader(settings.GEOLITE_CITY_DB)


def check_params(params, required_params,  # 必须值
                 default_param_dct=None,  # 默认值
                 param_type_dct=None,  # 参数类型，GET一般需要强制转换
                 param_validfunc_dct=None):  # 参数合法判定
    '''验证传入参数有效性，注意这里会对params做in-place修改
    '''
    for param in required_params:
        if param not in params:
            raise_with_traceback(ParamError('missing %s' % param))

    if default_param_dct:
        for param in default_param_dct:
            if param not in params:
                params[param] = default_param_dct[param]

    if param_type_dct:
        for field, t in param_type_dct.iteritems():
            if field in params:
                try:
                    if t is basestring:
                        t = smart_unicode
                    params[field] = t(params[field])
                except Exception:
                    raise_with_traceback(ParamError(
                        'param %s type wrong' % field))

    if param_validfunc_dct:
        for field, func in param_validfunc_dct.iteritems():
            if field in params:
                try:
                    assert func(params[field])
                except AssertionError:
                    raise_with_traceback(ParamError(
                        'param %s illegal' % field))


def check_auth(req):
    if not req.user_id:
        raise AuthenticateError(status=StatusCode.INVALID_TOKEN)


# for class based view, use `method_decorator`
def token_required(func):
    @csrf_exempt
    @wraps(func)
    def _wrapped(req, *args, **kwargs):
        check_auth(req)
        return func(req, *args, **kwargs)

    return _wrapped


def get_country(ip, locale=None):
    country = ""
    geo = geolite2.lookup(ip)
    if geo:
        country = geo.country
    if not country and locale:
        try:
            lang, cty = re.split(r'[-_]', locale)
            country = cty
        except:
            pass
    return country or DEFAULT_COUNTRY


def get_city(ip, lan='zh-CN'):
    try:
        city_obj = city_reader.city(ip)
        return city_obj.city.names.get(lan)
    except:
        return None


def get_client_ip(request):
    forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if forwarded_for:
        ip = forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    if not ip or ip == "unknown":
        real_ip = request.META.get('HTTP_X_REAL_IP')
        if real_ip:
            ip = real_ip.split(',')[0]
    return ip


def get_client_ua(request):
    return request.META.get('HTTP_USER_AGENT', '')


def page2offset(page, size,
                max_size=_MAX_PAGE_SIZE, default_size=_DEFAULT_PAGE_SIZE):
    '''return limit, offset
    '''
    limit = default_size if not size or size > max_size else size
    if not page or page < 1:
        page = 1
    offset = 0 if not page else (page - 1) * limit
    return limit, offset


class Struct:

    def __init__(self, **entries):
        self.__dict__.update(entries)


def dict2obj(dct):
    s = Struct(**dct)

    return s


_COM_P = re.compile(
    r'\[aid:(.*)\],\[code:(.*)\],\[lan:(.*)\],\[svc:(.*)\],\[svn:(.*)\],\[cvn:(.*)\],\[cvc:(.*)\],\[chn:(.*)\]')

_COM_P_MORE = re.compile(
    r'\[aid:(.*)\],\[model:(.*)\],\[code:(.*)\],\[lan:(.*)\],\[svc:(.*)\],\[svn:(.*)\],\[cvn:(.*)\],'
    r'\[cvc:(.*)\],\[chn:(.*)\],\[pkg:(.*)\]')


def parse_p(p):
    if not p:
        return {}
    # 如果客户端后期增加pkg参数，此处可以解析，解析不成功，可以使用老的方式
    g = _COM_P_MORE.match(p)
    if g:
        return {
            'aid': g.group(1),
            'model': g.group(2),
            'code': g.group(3),
            'lan': g.group(4),
            'svc': g.group(5),
            'svn': g.group(6),
            'cvn': g.group(7),
            'cvc': int(g.group(8)),  # app version
            'chn': g.group(9),  # channel: ios or android channel,
            'pkg': g.group(10)
        }

    g = _COM_P.match(p)
    if not g:
        return {}
    else:
        return {
            'aid': g.group(1),
            'code': g.group(2),
            'lan': g.group(3),
            'svc': g.group(4),
            'svn': g.group(5),
            'cvn': g.group(6),
            'cvc': int(g.group(7)),  # app version
            'chn': g.group(8)  # channel: ios or android channel
        }


def parse_common_params(query_dct):
    page = int(query_dct.get('page', 1))
    size = int(query_dct.get('size', 0))
    return page, size


def parse_unit(unit):
    unit = Decimal(unit)
    if unit not in (Decimal(2), Decimal('0.2'), Decimal('0.02')):
        raise ParamError('unit illigel')
    return unit


def mask_string(s):
    length = len(s)
    if length < 3:
        return '**'
    else:
        num = length / 3
        return s[:num] + '*' * (length - 2 * num) + s[-num:]


def mask_phone_username(phone):
    # 有些用户是直接采用手机号注册的，此时他的用户名为手机号，此时需要隐藏
    if re.match(r'\d{13}', phone) and phone.startswith('86'):
        return mask_string(phone)
    elif re.match(r'\d{11}', phone) and phone.startswith('1'):
        return mask_string(phone)

    return phone


# 获取请求操作系统
def get_operating_system(system_detail):
    system_start_index = system_detail.index('(')
    system_end_index = system_detail.index(')')
    operating_system = system_detail[system_start_index+1: system_end_index]
    device_start_index = operating_system.index(';')
    device = operating_system[device_start_index+1:]
    return device