# -*- coding: utf-8 -*-

from common.utils.decorator import sql_wrapper
from common.push.model import *


@sql_wrapper
def get_push_config(user_id):
    inst = PushConfig.query.filter(
        PushConfig.user_id == user_id).first()
    if inst:
        return inst.as_dict()
    else:
        return {}


@sql_wrapper
def update_push_config(user_id, config):
    saved = PushConfig.query.filter(
        PushConfig.user_id == user_id).first()
    if not saved:
        saved = PushConfig()
        saved.user_id = user_id
    for k, v in config.iteritems():
        if hasattr(PushConfig, k):
            setattr(saved, k, bool(v))

    saved.save()
