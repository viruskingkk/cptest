CREATE TABLE `metis_transaction` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `type` smallint(6) DEFAULT 0,
  `balance` bigint(20) DEFAULT 0,
  `withdraw` bigint(20) DEFAULT 0,
  `agent_balance` bigint(20) DEFAULT 0,
  `accu_balance` bigint(20) DEFAULT 0,
  `accu_withdraw` bigint(20) DEFAULT 0,
  `accu_agent_balance` bigint(20) DEFAULT 0,
  `curr_balance` bigint(20) DEFAULT 0,
  `curr_withdraw` bigint(20) DEFAULT 0,
  `curr_agent_balance` bigint(20) DEFAULT 0,
  `ref_id` varchar(128) NOT NULL,
  `checked` bool not null default 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ref_id` (`type`,`ref_id`),
  KEY `idx_user` (`user_id`)
);
-- add checked
alter table metis_transaction add column checked bool not null default 0;

CREATE TABLE `metis_withdraw_trans_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `amount` bigint(20) DEFAULT 0,
  `ref_id` varchar(128) NOT NULL,
  `checked` bool not null default 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ref_id` (`ref_id`),
  KEY `idx_user` (`user_id`)
);

CREATE TABLE `metis_bet_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `game_id` int(8) NOT NULL,
  `bet_type` tinyint(4) NOT NULL,
  `bet_amount` bigint(20) DEFAULT '0',
  `bet_result` bigint(20) DEFAULT '0',
  `round_id` varchar(128) NOT NULL,
  `play_type` varchar(16) NOT NULL,
  `extend` text NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ticket_id` (`ticket_id`),
  KEY `user_id` (`user_id`)
);

CREATE TABLE `metis_game_term` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `game_id` int(6) NOT NULL,
  `round_id` varchar(128) NOT NULL,
  `ticket_id` bigint(20) NOT NULL,
  `cards` text NOT NULL,
  `extend` text,
  `total_people` int(11) NOT NULL,
  `total_bet_amount` int(11) NOT NULL,
  `total_bet_result` int(11) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `round_id` (`round_id`)
);

CREATE TABLE `metis_game_participate` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `game_id` int(6) NOT NULL,
  `ticket_id` bigint(20) NOT NULL,
  `round_id` varchar(128) NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL,
  `bet_index` smallint(6) NOT NULL,
  `bet_amount` bigint(20) NOT NULL,
  `bet_result` bigint(20) NOT NULL,
  `extend` text,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `round_id` (`round_id`,`bet_index`,`user_id`)
);
