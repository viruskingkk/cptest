# -*- coding: utf-8 -*-
import logging

from common.utils.decorator import sql_wrapper
from common.utils import db as utils
from common.preset.model.preset import Recommend

_LOGGER = logging.getLogger(__name__)


@sql_wrapper
def get_recommend(id):
    return utils.get(Recommend, id)


@sql_wrapper
def upsert_recommend(info, id=None):
    return utils.upsert(Recommend, info, id)


@sql_wrapper
def list_recommend(query_dct):
    return utils.list_object(query_dct, Recommend)


@sql_wrapper
def delete_recommend(id):
    utils.delete(Recommend, id)
