# -*- coding: utf-8 -*-

import json
import random
from datetime import datetime

from common import orm
from common.account.db.account import get_account
from common.account.model.account import BALANCE_TYPE
from common.activity.utils import get_activity_time, hide_user_name
from common.activity.utils import ts_to_date_str_list
from common.cache.redis_cache import get_recharge_iphone_activity_join_count, incr_recharge_iphone_activity_join_count
from common.notification.handler import notify_lantern_iphone_win, notify_lantern_amount_win
from common.pay.db import get_today_recharge, get_pay_over_user_ids
from common.preset.model.preset import BANNER_TYPE
from common.transaction.db import create_transaction
from common.utils import track_logging
from common.utils.currency import convert_yuan_to_hao
from common.utils.tz import today_str, to_ts, now_ts, local_to_utc
from .lantern_model import ACTIVITY_CONFIG, LanternRecord, ACTIVITY_STATUS, AWARD, AWARD_TYPE
from common.transaction.model import TRANSACTION_STATUS, TRANSACTION_TYPE

_LOGGING = track_logging.getLogger(__name__)

ROBOT_USER_NAME = [u"开灵车发财", u"13023455357", u"2722781", u"2722782"]


def get_task_status(user_id, start_time, end_time, end_timing):
    now_t = now_ts()
    if now_t < start_time:
        return ACTIVITY_STATUS.UNSTART
    elif now_t > end_time:
        return ACTIVITY_STATUS.OVER

    # 比较当天的情况
    today_amount = get_today_recharge(user_id, [])
    if end_timing:
        if today_amount < ACTIVITY_CONFIG['threshold']:
            return ACTIVITY_STATUS.UNREACH
        else:
            return ACTIVITY_STATUS.REACH
    if not end_timing or not get_winner_user_name_by_date:
        return ACTIVITY_STATUS.END

    if not user_id:
        return ACTIVITY_STATUS.UNLOGIN


def get_winner_user_name_by_date(activity_date):
    winners = orm.session.query(LanternRecord).filter(LanternRecord.date == activity_date).order_by(
        LanternRecord.rank).all()
    if not winners:
        return None

    return [hide_user_name(winner.user_name) for winner in winners]


def get_end_timing():
    """
    获取开奖剩余时间
    :return:
    """
    open_local_time = local_to_utc(datetime.strptime(today_str() + ' 22:00:00', '%Y-%m-%d %H:%M:%S'))
    open_ts = to_ts(open_local_time)
    return max(open_ts - now_ts(), 0)


def get_join_count(activity_date):
    """
    :param activity_date:
    :return:
    """
    return get_recharge_iphone_activity_join_count(activity_date)


def get_winners_list():
    start_time, end_time = get_activity_time(BANNER_TYPE.get_key('lantern'))
    date_list = ts_to_date_str_list(start_time, end_time)
    winner_list = []
    for activity_date in date_list:
        winner_list.append(
            dict(date=activity_date, user_name=get_winner_user_name_by_date(activity_date)))
    return winner_list


def had_win(user_name):
    return orm.session.query(LanternRecord).filter(LanternRecord.user_name == user_name).count()


def had_open(activity_date):
    return orm.session.query(LanternRecord).filter(LanternRecord.date == activity_date).count()


def add_receive_record(user_id, user_name, activity_date, rank, thing, auto_commit=False):
    record = LanternRecord()
    record.user_id = user_id
    record.user_name = user_name
    record.date = activity_date
    record.rank = rank
    record.thing = thing
    record.save()


def random_winner(activity_date=None, real_user_probability=1):
    """
    随机 中奖用户，为机器人时，用户id 为空
    :return:
    user_id,user_name
    """
    if not activity_date:
        activity_date = today_str()

    if random.random() > real_user_probability:
        winner_id = None
        winner_name = random.choice(ROBOT_USER_NAME)
    else:
        user = get_pay_over_user_ids(ACTIVITY_CONFIG['threshold'], activity_date)
        winner_id = random.choice(user)[1]
        winner_name = get_account(winner_id).user_name

    _LOGGING.info(u'prepare winner_name is {}'.format(winner_name))
    if had_win(winner_name):
        return random_winner(activity_date, real_user_probability)

    return winner_id, winner_name


def add_join_count():
    incr_recharge_iphone_activity_join_count(today_str(), 1)


def open_prize(activity_date=None):
    """
    充值送iphone 开奖，机器人和真实用户2：1
    :return:
    """
    if not activity_date:
        activity_date = today_str()
    if had_open(activity_date):
        return

    start_time, end_time = get_activity_time(BANNER_TYPE.get_key('lantern'))

    if now_ts() < start_time or now_ts() > end_time:
        return

    for index, award in enumerate(AWARD):
        user_id, user_name = random_winner(activity_date, award['real_user_probability'])

        add_receive_record(user_id, user_name, activity_date, index + 1, award['thing'])
        if award['award_type'] == AWARD_TYPE.AMOUNT:
            transaction_data = {
                'user_id': user_id,
                'type': TRANSACTION_TYPE.LANTERN_AWARD,
                'title': u'元宵活动奖励',
                'price': convert_yuan_to_hao(int(award['thing'])),
                'balance_type': BALANCE_TYPE.BALANCE,
                'status': TRANSACTION_STATUS.DONE,
            }
            create_transaction(transaction_data)

        if user_id:
            if award['award_type'] == AWARD_TYPE.REAL:
                notify_lantern_iphone_win(user_id)
            else:
                notify_lantern_amount_win(user_id, int(award['thing']))

    orm.session.commit()