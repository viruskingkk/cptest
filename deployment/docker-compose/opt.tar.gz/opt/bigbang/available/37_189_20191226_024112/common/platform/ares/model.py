# -*- coding: utf-8 -*-

from common import orm
from common.utils.types import Enum

IMONE_GAME_ID_DCT = {
    102: u"真人AG", 120003: u"Ebet百家乐1", 120010: u"Ebet龙虎", 120014: u"Ebet骰宝", 40001: u"捕鱼天下",
    100020: u"千炮捕鱼", 240024: u"李逵劈鱼", 240025: u"金蟾捕鱼", 240029: u"猎鱼达人",1001: u"电竞牛牛", 2001: u"IM体育",
    # 以下为游戏大厅可跳转到的游戏类型
    120001: u'Ebet百家乐VVIP', 120002: u'Ebet百家乐VIP', 120004: u'Ebet百家乐6', 120005: u'Ebet百家乐8',
    120006: u'Ebet极速百家乐2', 120007: u'Ebet极速百家乐5', 120008: u'Ebet极速百家乐7', 120009: u'Ebet极速百家乐9',
    120012: u'Ebet轮盘1号桌', 120013: u'Ebet轮盘2号桌', 120015: u'Ebet百家乐3'
}

IMONE_STATUS = Enum({
    "WAITING": (0, u"交易中"),
    "SUCCESS": (1, u"交易成功"),
    "FAIL": (2, u"交易失败"),
})

GAME_ID_DCT = {'imfishingH510002': 10002, 'imfishing40001': 10003, 'imag1001': 10001, 'imsunbet1001': 1002}

# SUB_GAME_ID 是我们这边自己定义的，主要用来区别各个平台的字游戏（imone中包含真人、捕鱼，而真人中又包含有很多子游戏）
SUB_GAME_IMONE_ID_DICT = {
    'imag1002': [u'国际厅百家乐', 121002, u'AG-百家乐'],   # 原子游戏ID为 1002， 我在前面添加了一个 12
    'imag1003': [u'旗舰厅百家乐', 121003, u'AG-百家乐'],
    'imag1004': [u'国际厅龙虎', 121004, u'AG-龙虎'],
    'imag1005': [u'旗舰厅龙虎', 121005, u'AG-龙虎'],
    'imag1006': [u'旗舰厅轮盘', 121006, u'AG-轮盘'],
    'imag1007': [u'国际厅轮盘', 121007, u'AG-轮盘'],
    'imag1008': [u'旗舰厅骰宝', 121008, u'AG-骰宝'],
    'imag1009': [u'国际厅骰宝', 121009, u'AG-骰宝'],
    'imag1010': [u'竞咪厅百家乐', 121010, u'AG-百家乐'],
    'imag1011': [u'包桌厅百家乐', 121011, u'AG-百家乐'],
    'imag1012': [u'牛牛', 121012, u'AG-牛牛'],
    'imag1013': [u'炸金花', 121013, u'AG-炸金花'],
    'imag1014': [u'斗牛', 121014, u'AG-斗牛'],
    'imag1015': [u'欧洲厅百家乐', 121015, u'AG-百家乐'],
    'imag1016': [u'欧洲厅轮盘', 121016, u'AG-轮盘'],

    'imlive20003': [u'百家乐1', 220003, u'Ebet-百家乐'],  # 原子游戏ID为 20003， 我在前面添加了一个 2
    'imlive20004': [u'百家乐6', 220004, u'Ebet-百家乐'],
    'imlive20005': [u'百家乐8', 220005, u'Ebet-百家乐'],
    'imlive20015': [u'百家乐3', 220015, u'Ebet-百家乐'],
    'imlive20006': [u'极速百家乐2 ', 220006, u'Ebet-百家乐'],
    'imlive20007': [u'极速百家乐5 ', 220007, u'Ebet-百家乐'],
    'imlive20008': [u'极速百家乐7 ', 220008, u'Ebet-百家乐'],
    'imlive20009': [u'极速百家乐9 ', 220009, u'Ebet-百家乐'],
    'imlive20010': [u'龙虎1号桌 ', 220010, u'Ebet-龙虎'],
    'imlive20012': [u'轮盘1号桌 ', 220012, u'Ebet-轮盘'],
    'imlive20013': [u'轮盘2号桌 ', 220013, u'Ebet-轮盘'],
    'imlive20014': [u'骰宝1号桌 ', 220014, u'Ebet-骰宝'],
}

SUB_GAME_ID_INFO = {}

for key, value in SUB_GAME_IMONE_ID_DICT.items():
    SUB_GAME_ID_INFO.update({value[1]: [key, value[0], value[2]]})


class ImoneBetLogs(orm.Model):
    __tablename__ = "imone_bet_logs"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)  # 平台用户ID
    game_id = orm.Column(orm.VARCHAR)       # 游戏ID
    ref_id = orm.Column(orm.VARCHAR)  # 唯一订单号
    status = orm.Column(orm.SmallInteger)  # 注单状态,详见上IMONE_STATUS
    bet_amount = orm.Column(orm.BigInteger)   # 下注金额,单位:分
    bet_result = orm.Column(orm.BigInteger)   # 盈亏金额,单位:分
    create_time = orm.Column(orm.DATETIME)  # 下注时间
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class ImoneUserInfo(orm.Model):
    __tablename__ = "imone_user_info"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger, unique=True)  # 平台用户ID
    player_id = orm.Column(orm.VARCHAR, unique=True)  # 游戏方玩家ID
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
