# -*- coding: utf-8 -*-
import json
import logging
import time

from common.cache import ProxyAgent, prefix_key, bull_prefix_key, union_client
from common.lottery import DIY_LOTTERY
from common.utils.decorator import cache_wrapper
from common.utils.tz import left_seconds_today, now_ts, today_str, left_seconds_future_day

_LOGGER = logging.getLogger(__name__)
_LOCK_TIMEOUT = 10
_ACCOUNT_EXPIRE = 3600
_TREND_COUNT = 1200  # 最近1200期的趋势图数据
_RANKING_EXPIRE = 5 * 60


@cache_wrapper
def save_account(user_id, account_value):
    key = prefix_key('account:%s' % user_id)
    return ProxyAgent().setex(key, _ACCOUNT_EXPIRE, account_value)


@cache_wrapper
def get_account(user_id):
    """
    used for cache
    """
    key = prefix_key('account:%s' % user_id)
    return ProxyAgent().get(key)


@cache_wrapper
def submit_timer_event(event_type, cache_value, timestamp):
    """
    used for db
    """
    key = prefix_key('timerzset:%s' % event_type)
    return ProxyAgent().zadd(key, timestamp, cache_value)


@cache_wrapper
def event_exists(event_type):
    key = prefix_key('timerzset:%s' % event_type)
    return ProxyAgent().zcard(key)


@cache_wrapper
def range_expired_events(event_type, max_time):
    """
    used for db
    """
    key = prefix_key('timerzset:%s' % event_type)
    return ProxyAgent().zrangebyscore(key, 0, max_time)


@cache_wrapper
def remove_expired_event(event_type, event_value):
    """
    used for db
    """
    key = prefix_key('timerzset:%s' % event_type)
    return ProxyAgent().zrem(key, event_value)


@cache_wrapper
def timer_event_processed(event_id):
    """
    used for db
    """
    key = prefix_key('timerlock:%s' % event_id)
    return not ProxyAgent().setnx(key, int(time.time()))


@cache_wrapper
def get_user_stats(user_id):
    key = 'stats:user:%s' % user_id
    return ProxyAgent().hgetall(key)


@cache_wrapper
def add_unread_number(user_id):
    key = prefix_key('order:unread:%s' % user_id)
    ProxyAgent().incr(key, 1)


@cache_wrapper
def reset_unread_number(user_id):
    key = prefix_key('order:unread:%s' % user_id)
    ProxyAgent().delete(key)


@cache_wrapper
def get_unread_number(user_id):
    key = prefix_key('order:unread:%s' % user_id)
    return ProxyAgent().get(key) or 0


@cache_wrapper
def get_ios_qq_group_uin():
    key = prefix_key('qqgroup:ios_uin')
    return ProxyAgent().get(key)


@cache_wrapper
def get_ios_qq_group_key():
    key = prefix_key('qqgroup:ios_key')
    return ProxyAgent().get(key)


@cache_wrapper
def get_android_qq_group_key():
    '''XQ45d8jXYNdCEQbu0eYdW13AGYQmDAB8
    '''
    key = prefix_key('qqgroup:android_key')
    return ProxyAgent().get(key)


@cache_wrapper
def set_reward_config(activity_type, term, bet_type, config, expire=60):
    ''' 某一期的奖励设置，默认过期时间1分钟
    '''
    key = prefix_key('reward:%s:%s:%s' % (activity_type, term, bet_type))
    ProxyAgent().hmset(key, config)
    ProxyAgent().expire(key, expire)


@cache_wrapper
def get_reward_config(activity_type, term, bet_type):
    key = prefix_key('reward:%s:%s:%s' % (activity_type, term, bet_type))
    return ProxyAgent().hgetall(key)


@cache_wrapper
def set_reward_limit(id, limit):
    key = prefix_key('reward:limit:%s' % id)
    ProxyAgent().setnx(key, limit)


@cache_wrapper
def decr_reward_limit(id, amount):
    key = prefix_key('reward:limit:%s' % id)
    return ProxyAgent().incrby(key, -amount)


@cache_wrapper
def update_read_order_index(user_id, index_id):
    """应该序列化使用MySQL"""
    key = prefix_key('stats:order_index:%s' % user_id)
    ProxyAgent().set(key, index_id)


@cache_wrapper
def get_last_read_index(user_id):
    key = prefix_key('stats:order_index:%s' % user_id)
    t = ProxyAgent().get(key) or 0
    return int(t)


@cache_wrapper
def add_unread_win(user_id, activity_type, order_id):
    key = prefix_key('unread_win:%s' % user_id)
    ProxyAgent().sadd(key, "%s#%s" % (activity_type, order_id))


@cache_wrapper
def remove_unread_win(user_id, activity_type, order_id):
    key = prefix_key('unread_win:%s' % user_id)
    ProxyAgent().srem(key, "%s#%s" % (activity_type, order_id))


@cache_wrapper
def count_unread_win(user_id):
    key = prefix_key('unread_win:%s' % user_id)
    return ProxyAgent().scard(key)


@cache_wrapper
def add_ongoing_track(user_id, track_id):
    key = prefix_key('ongoing_track:%s' % user_id)
    ProxyAgent().sadd(key, track_id)


@cache_wrapper
def remove_ongoing_track(user_id, track_id):
    key = prefix_key('ongoing_track:%s' % user_id)
    ProxyAgent().srem(key, track_id)


@cache_wrapper
def count_ongoing_track(user_id):
    key = prefix_key('ongoing_track:%s' % user_id)
    return ProxyAgent().scard(key)


@cache_wrapper
def get_withdraw_status(payer_no):
    """
    used for db
    """
    key = prefix_key('withdrawstatus:{}'.format(payer_no))
    return ProxyAgent().get(key)


@cache_wrapper
def set_withdraw_status(payer_no, status):
    """
    used for db
    """
    key = prefix_key('withdrawstatus:{}'.format(payer_no))
    return ProxyAgent().set(key, status)


@cache_wrapper
def add_withdraw_daily_amount(amount):
    key = prefix_key('daily:withdraw')
    exists = ProxyAgent().exists(key)
    current_price = ProxyAgent().incrby(key, int(amount))
    if not exists:
        ttl = left_seconds_today()
        ProxyAgent().expire(key, ttl)
    return int(current_price)


@cache_wrapper
def get_withdraw_daily_amount():
    key = prefix_key('daily:withdraw')
    return int(ProxyAgent().get(key) or 0)


@cache_wrapper
def add_wheel_task(user_id, bit_index):
    key = 'lucky:wheel:%s' % user_id
    current_val = int(ProxyAgent().get(key) or 0)
    ret = ProxyAgent().set(key, current_val | bit_index)
    ttl = left_seconds_today()
    ProxyAgent().expire(key, ttl)


@cache_wrapper
def get_wheel_task(user_id):
    key = 'lucky:wheel:%s' % user_id
    return int(ProxyAgent().get(key) or 0)


@cache_wrapper
def get_wheel_double_bit(date_str):
    key = 'lucky:wheel:doublebit:%s' % date_str
    return int(ProxyAgent().get(key) or 0)


@cache_wrapper
def set_double_bit(date_str, rand_bit):
    key = 'lucky:wheel:doublebit:%s' % date_str
    ret = ProxyAgent().set(key, rand_bit)
    ttl = left_seconds_today() + 3600 * 24  # 保留到第二天
    ProxyAgent().expire(key, ttl)


@cache_wrapper
def add_new_fortune(user_id, award_index):
    """
    used for db
    """
    key = prefix_key('fortunewheel')
    cached_value = '%s:%s' % (user_id, award_index)
    ProxyAgent().zadd(key, int(time.time()), cached_value)
    return ProxyAgent().zremrangebyrank(key, 0, -21)


_HOT_KEYS_SIZE = 10


@cache_wrapper
def get_fortune_timeline():
    """
    used for db
    """
    key = prefix_key('fortunewheel')
    return ProxyAgent().zrevrangebyscore(key, '+inf', '-inf',
                                         start=0, num=_HOT_KEYS_SIZE)


_MAX_SCROLLING = 20


@cache_wrapper
def submit_scrolling(cache_value, timestamp, key='scrolling'):
    """
    used for db
    """
    key = prefix_key(key)
    return ProxyAgent().zadd(key, timestamp, cache_value)


@cache_wrapper
def range_scrolling(min_index=0, max_index=_MAX_SCROLLING - 1, key='scrolling'):
    """
    used for db
    """
    key = prefix_key(key)
    return ProxyAgent().zrevrange(key, min_index, max_index, withscores=True)


@cache_wrapper
def get_scrolling_count(key='scrolling'):
    key = prefix_key(key)
    return ProxyAgent().zcard(key)


@cache_wrapper
def trim_scrolling(key='scrolling'):
    key = prefix_key(key)
    return ProxyAgent().zremrangebyrank(key, 0, -_MAX_SCROLLING - 1)


@cache_wrapper
def set_unread_notify_count(user_id, notify_type, count):
    key = prefix_key('notify:%s:%s' % (user_id, notify_type))
    ProxyAgent().set(key, count)


@cache_wrapper
def get_unread_notify_count(user_id, notify_type):
    key = prefix_key('notify:%s:%s' % (user_id, notify_type))
    count = ProxyAgent().get(key) or 0
    count = int(count)
    if count <= 0:
        # fix sometime bug
        set_unread_notify_count(user_id, notify_type, 0)
        return 0
    return int(count)


@cache_wrapper
def increase_unread_notify_count(user_id, notify_type):
    key = prefix_key('notify:%s:%s' % (user_id, notify_type))
    ProxyAgent().incr(key)


@cache_wrapper
def decrease_unread_notify_count(user_id, notify_type):
    key = prefix_key('notify:%s:%s' % (user_id, notify_type))
    ProxyAgent().decr(key)


@cache_wrapper
def set_chn_links(platform, links):
    key = 'market:bigbang:%s' % platform
    union_client.delete(key)
    return union_client.hmset(key, links)


@cache_wrapper
def add_read_sys_notify(user_id, notify_id):
    key = prefix_key('sys_notify_read:%s' % user_id)
    ProxyAgent().sadd(key, notify_id)


@cache_wrapper
def has_read_sys_notify(user_id, notify_id):
    key = prefix_key('sys_notify_read:%s' % user_id)
    return ProxyAgent().sismember(key, notify_id)


@cache_wrapper
def get_chn_links(platform):
    key = 'market:bigbang:%s' % platform
    return union_client.hgetall(key)


@cache_wrapper
def get_self_recharge():
    key = prefix_key('self_recharge:on')
    return int(ProxyAgent().get(key) or 0)


@cache_wrapper
def set_self_recharge(status):
    key = prefix_key('self_recharge:on')
    return ProxyAgent().set(key, status)


@cache_wrapper
def get_activity_switch(activity_type):
    key = prefix_key('activity:{}:off'.format(activity_type))
    return int(ProxyAgent().get(key) or 0)


@cache_wrapper
def set_activity_switch(activity_type, status):
    key = prefix_key('activity:{}:off'.format(activity_type))
    return ProxyAgent().set(key, status)


@cache_wrapper
def add_withdraw_test_uids(*uids):
    """
    used for db
    """
    key = prefix_key('withdraw:uids:test')
    ProxyAgent().delete(key)
    return ProxyAgent().sadd(key, *uids)


@cache_wrapper
def get_withdraw_test_uids():
    """
    used for db
    """
    key = prefix_key('withdraw:uids:test')
    return ProxyAgent().smembers(key) or []


@cache_wrapper
def add_withdraw_black_uids(*uids):
    """
    used for db
    """
    key = prefix_key('withdraw:uids:black')
    ProxyAgent().delete(key)
    return ProxyAgent().sadd(key, *uids)


@cache_wrapper
def get_withdraw_black_uids():
    """
    used for db
    """
    key = prefix_key('withdraw:uids:black')
    return ProxyAgent().smembers(key) or []


@cache_wrapper
def add_withdraw_black_alipayno(*alipay_nos):
    """
    used for db
    提现黑名单
    """
    key = prefix_key('withdraw:alipayno:black')
    ProxyAgent().delete(key)
    return ProxyAgent().sadd(key, *alipay_nos)


@cache_wrapper
def get_withdraw_black_alipayno():
    """
    used for db
    提现黑名单
    """
    key = prefix_key('withdraw:alipayno:black')
    return ProxyAgent().smembers(key) or []


@cache_wrapper
def add_withdraw_black_name(*names):
    """
    used for db
    提现黑名单
    """
    key = prefix_key('withdraw:name:black')
    ProxyAgent().delete(key)
    return ProxyAgent().sadd(key, *names)


@cache_wrapper
def get_withdraw_black_name():
    """
    used for db
    提现黑名单
    """
    key = prefix_key('withdraw:name:black')
    return ProxyAgent().smembers(key) or []


@cache_wrapper
def create_track_info(track_id):
    """
    used for db
    追号记录汇总
    """
    key = prefix_key('track:%s' % track_id)
    ProxyAgent().hset(key, 'ts', now_ts())


@cache_wrapper
def increase_track_info(track_id, field, value):
    """
    used for db
    追号记录汇总
    """
    key = prefix_key('track:%s' % track_id)
    exists = ProxyAgent().exists(key)
    if exists:
        ProxyAgent().hincrbyfloat(key, field, float(value))
        ProxyAgent().expire(key, 3600 * 24)


@cache_wrapper
def get_track_info(track_id):
    key = prefix_key('track:%s' % track_id)
    return ProxyAgent().hgetall(key)


@cache_wrapper
def expire_track_info(track_id, ttl):
    key = prefix_key('track:%s' % track_id)
    return ProxyAgent().expire(key, ttl)


@cache_wrapper
def add_virtual_account(user_id):
    """
    used for db
    """
    key = prefix_key('virtual:account')
    return ProxyAgent().sadd(key, user_id)


@cache_wrapper
def get_limit_amount():
    """
    used for cache
    """
    key = prefix_key('withdraw:limitamount')
    return ProxyAgent().get(key) or 0


@cache_wrapper
def set_limit_amount(amount):
    """
    used for db
    """
    key = prefix_key('withdraw:limitamount')
    return ProxyAgent().set(key, amount)


@cache_wrapper
def add_treasure_amount(level, amount):
    key = prefix_key('campaign:treasure:stats')
    amount_field = 'level_%s_amount' % level
    count_field = 'level_%s_count' % level
    ProxyAgent().hincrby(key, amount_field, amount)
    ProxyAgent().hincrby(key, count_field, 1)
    ttl = left_seconds_today()
    ProxyAgent().expire(key, ttl)


@cache_wrapper
def get_treasure_stats(level):
    key = prefix_key('campaign:treasure:stats')
    amount_field = 'level_%s_amount' % level
    count_field = 'level_%s_count' % level
    return ProxyAgent().hget(key, amount_field) or 0, ProxyAgent().hget(key, count_field) or 0


@cache_wrapper
def set_award_ranking(value):
    key = prefix_key('award_ranking')
    return ProxyAgent().setex(key, _RANKING_EXPIRE, value)


@cache_wrapper
def get_award_ranking():
    key = prefix_key('award_ranking')
    return ProxyAgent().get(key)


@cache_wrapper
def set_user_award_ranking(user_id, value):
    key = prefix_key('user_award_ranking:%s' % user_id)
    return ProxyAgent().setex(key, _RANKING_EXPIRE, value)


@cache_wrapper
def get_user_award_ranking(user_id):
    key = prefix_key('user_award_ranking:%s' % user_id)
    return ProxyAgent().get(key)


@cache_wrapper
def add_total_bet(activity_type, amount):
    key = prefix_key('{}:total_bet:{}').format(DIY_LOTTERY.get(activity_type), today_str())
    ProxyAgent().incrbyfloat(key, float(amount))


@cache_wrapper
def get_total_bet(activity_type):
    key = prefix_key('{}:total_bet:{}').format(DIY_LOTTERY.get(activity_type), today_str())
    return float(ProxyAgent().get(key) or 0)


@cache_wrapper
def add_system_profit(activity_type, amount):
    key = prefix_key('{}:system_profit:{}').format(DIY_LOTTERY.get(activity_type), today_str())
    ProxyAgent().incrbyfloat(key, float(amount))


@cache_wrapper
def get_system_profit(activity_type):
    key = prefix_key('{}:system_profit:{}').format(DIY_LOTTERY.get(activity_type), today_str())
    return float(ProxyAgent().get(key) or 0)


@cache_wrapper
def set_available_pays(*pays):
    key = prefix_key('available_pays')
    ProxyAgent().delete(key)
    if pays:
        return ProxyAgent().sadd(key, *pays)
    else:
        return True


@cache_wrapper
def get_available_pays():
    key = prefix_key('available_pays')
    return ProxyAgent().smembers(key) or []


@cache_wrapper
def set_available_bank_types(bank_types):
    key = prefix_key('available_bank_types')
    return ProxyAgent().set(key, bank_types)


@cache_wrapper
def get_available_bank_types():
    key = prefix_key('available_bank_types')
    return ProxyAgent().get(key)


@cache_wrapper
def get_recharge_wechat():
    key = prefix_key('recharge:wechat')
    return ProxyAgent().smembers(key) or []


@cache_wrapper
def get_recharge_wechat_assign_count(count=1):
    key = prefix_key('recharge:wechat')
    return ProxyAgent().srandmember(key, count) or []


@cache_wrapper
def set_recharge_wechat(*wechat_infos):
    key = prefix_key('recharge:wechat')
    return ProxyAgent().sadd(key, *wechat_infos)


@cache_wrapper
def delete_recharge_wechat():
    key = prefix_key('recharge:wechat')
    ProxyAgent().delete(key)


@cache_wrapper
def set_allow_game_channels(*channels):
    key = prefix_key('allow_game_channels')
    ProxyAgent().delete(key)
    return ProxyAgent().sadd(key, *channels)


@cache_wrapper
def get_allow_game_channels():
    key = prefix_key('allow_game_channels')
    return ProxyAgent().smembers(key) or []


@cache_wrapper
def set_available_withdraw_channels(*channels):
    key = prefix_key('available_withdraw_channels')
    ProxyAgent().delete(key)
    return ProxyAgent().sadd(key, *channels)


@cache_wrapper
def get_available_withdraw_channels():
    key = prefix_key('available_withdraw_channels')
    return ProxyAgent().smembers(key) or []


# todo优化,根据pay_type存储quotas
@cache_wrapper
def set_alipay_quotas(*quotas):
    key = prefix_key('alipay_quotas')
    ProxyAgent().delete(key)
    return ProxyAgent().sadd(key, *quotas)


@cache_wrapper
def get_alipay_quotas():
    key = prefix_key('alipay_quotas')
    return list(ProxyAgent().smembers(key) or [])


@cache_wrapper
def set_wx_quotas(*quotas):
    key = prefix_key('wx_quotas')
    ProxyAgent().delete(key)
    return ProxyAgent().sadd(key, *quotas)


@cache_wrapper
def get_wx_quotas():
    key = prefix_key('wx_quotas')
    return list(ProxyAgent().smembers(key) or [])


@cache_wrapper
def set_game_strategy(game, key, value, ttl):
    if game == 'bull':
        if ttl <= -1:
            ProxyAgent().set(key, value)
        else:
            ProxyAgent().setex(key, ttl, value)


@cache_wrapper
def get_game_strategy(game, key):
    if game == 'bull':
        return ProxyAgent().get(key), ProxyAgent().ttl(key)


@cache_wrapper
def set_pool_award(amount):
    key = bull_prefix_key('bull:pool_award')
    ttl = left_seconds_today()
    return ProxyAgent().setex(key, ttl, amount)


@cache_wrapper
def get_pool_award():
    key = bull_prefix_key('bull:pool_award')
    return float(ProxyAgent().get(key) or 0), ProxyAgent().ttl(key)


@cache_wrapper
def clear_pool_award():
    key = bull_prefix_key('bull:pool_award')
    return ProxyAgent().delete(key)


@cache_wrapper
def set_daily_sum(amount):
    key = bull_prefix_key('bull:dailysum')
    ttl = left_seconds_today()
    return ProxyAgent().setex(key, ttl, amount)


@cache_wrapper
def get_daily_sum():
    key = bull_prefix_key('bull:dailysum')
    return float(ProxyAgent().get(key) or 0), ProxyAgent().ttl(key)


@cache_wrapper
def clear_daily_sum():
    key = bull_prefix_key('bull:dailysum')
    return ProxyAgent().delete(key)


@cache_wrapper
def get_daily_bet(platform):
    """获取平台单日投注限制金额
    """
    key = prefix_key('{}:dailybet').format(platform)
    return ProxyAgent().get(key) or 99999999  # 默认无上限


@cache_wrapper
def set_daily_bet(platform, amount):
    """设置平台单日投注限制金额
    """
    key = prefix_key('{}:dailybet').format(platform)
    return ProxyAgent().set(key, amount)


@cache_wrapper
def get_platform_risk_uids(platform, target):
    """获取平台禁止登入名单(forbidden)/赢家限制名单(winlist)/输家限制名单(loselist)/测试(pass)
    """
    key = prefix_key('{}:uids:{}').format(platform, target)
    return ProxyAgent().smembers(key) or []


@cache_wrapper
def add_platform_risk_uids(platform, target, *uids):
    """设置平台禁止登入名单(forbidden)/赢家限制名单(winlist)/输家限制名单(loselist)/测试(pass)
    """
    key = prefix_key('{}:uids:{}').format(platform, target)
    ProxyAgent().delete(key)
    return ProxyAgent().sadd(key, *uids)


@cache_wrapper
def add_daily_metis_value(game_id, value_type, amount, date_str):
    key = prefix_key('metis:daily:{}:{}:{}'.format(date_str, game_id, value_type))
    exists = ProxyAgent().exists(key)
    ProxyAgent().incrbyfloat(key, float(amount))
    if not exists:
        ttl = left_seconds_future_day(2)
        ProxyAgent().expire(key, ttl)


@cache_wrapper
def get_daily_metis_value(game_id, value_type, date_str):
    key = prefix_key('metis:daily:{}:{}:{}'.format(date_str, game_id, value_type))
    return float(ProxyAgent().get(key) or 0)


def set_pay_params(user_id, digest):
    """
    返回 True 表示设置成功，即不是重复提交
    :param user_id:
    :param digest:
    :return:
    """
    key = prefix_key('utils:duplicate:%s' % user_id)
    old_digest = ProxyAgent().get(key)
    ProxyAgent().set(key, digest)
    ProxyAgent().expire(key, 2)
    return not old_digest or old_digest != digest


@cache_wrapper
def get_recharge_iphone_activity_join_count(activity_date):
    return int(ProxyAgent().hget('recharge_iphone_activity', activity_date) or 0)


@cache_wrapper
def incr_recharge_iphone_activity_join_count(activity_date, count=1):
    return ProxyAgent().hincrby('recharge_iphone_activity', activity_date, count)


@cache_wrapper
def get_recharge_iphone_activity_real_join_count(activity_date):
    return int(ProxyAgent().hget('real_recharge_iphone_activity', activity_date) or 0)


@cache_wrapper
def set_recharge_iphone_activity_real_join_count(activity_date, count):
    return ProxyAgent().hset('real_recharge_iphone_activity', activity_date, count)


@cache_wrapper
def set_today_ranks(today, ranks=[]):
    key = prefix_key('date:%s:ranking' % today)
    content = json.dumps(ranks)
    return ProxyAgent().set(key, content)


@cache_wrapper
def get_today_ranks(today):
    key = prefix_key('date:%s:ranking' % today)
    content_str = ProxyAgent().get(key)
    if content_str:
        rank_list = json.loads(content_str)
        return sorted(rank_list, key=lambda x: x['rank'])
    else:
        return []


@cache_wrapper
def set_total_ranks(ranks=[]):
    key = prefix_key('total:ranking')
    content = json.dumps(ranks)
    return ProxyAgent().set(key, content)


@cache_wrapper
def get_total_ranks():
    key = prefix_key('total:ranking')
    content_str = ProxyAgent().get(key)
    if content_str:
        rank_list = json.loads(content_str)
        return sorted(rank_list, key=lambda x: x['rank'])
    else:
        return []


@cache_wrapper
def get_black_ip_aid():
    key = prefix_key('black_ip_aid')
    return ProxyAgent().smembers(key) or []


@cache_wrapper
def set_black_ip_aid(black_info):
    key = prefix_key('black_ip_aid')
    return ProxyAgent().sadd(key, black_info)


@cache_wrapper
def delete_black_ip_aid(black_info):
    key = prefix_key('black_ip_aid')
    return ProxyAgent().srem(key, black_info)


@cache_wrapper
def add_account_ares_gameId(user_id, game_id):
    """
    存入用户进入imone的游戏ID
    """
    key = prefix_key('ares_online_game:{}'.format(user_id))
    ProxyAgent().delete(key)
    return ProxyAgent().set(key, game_id)


@cache_wrapper
def get_account_ares_gameId(user_id):
    """
    查询用户当前在imone的游戏ID
    """
    key = prefix_key('ares_online_game:{}'.format(user_id))
    return int(ProxyAgent().get(key) or 0)


@cache_wrapper
def delete_account_ares_gameId(user_id):
    """
    退出游戏后删除用户在imone的游戏ID
    """
    key = prefix_key('ares_online_game:{}'.format(user_id))
    ProxyAgent().delete(key)


@cache_wrapper
def set_imone_last_update_time(wallet, timestamp):
    key = prefix_key('imone_last_update:{}'.format(wallet))
    return ProxyAgent().set(key, timestamp)


@cache_wrapper
def get_imone_last_update_time(wallet):
    key = prefix_key('imone_last_update:{}'.format(wallet))
    return int(ProxyAgent().get(key) or 0)


@cache_wrapper
def set_cs_user_token(user_id, token):
    key = prefix_key('cs_user_token_%s' % user_id)
    return ProxyAgent().setex(key, _ACCOUNT_EXPIRE, token)


@cache_wrapper
def get_cs_user_token(user_id):
    key = prefix_key('cs_user_token_%s' % user_id)
    return ProxyAgent().get(key)


@cache_wrapper
def get_kefu_type():
    key = prefix_key('kefu_type')
    return ProxyAgent().get(key) or 0


@cache_wrapper
def set_kefu_type(type_code):
    key = prefix_key('kefu_type')
    return ProxyAgent().set(key, type_code)


@cache_wrapper
def add_track_response_uids(*uids):
    key = prefix_key('track_response_uids')
    ProxyAgent().delete(key)
    return ProxyAgent().sadd(key, *uids)


@cache_wrapper
def get_track_response_uids():
    key = prefix_key('track_response_uids')
    return ProxyAgent().smembers(key) or []


@cache_wrapper
def save_user_p(user_id, p_str):
    key = prefix_key('user_%s_p_str' % user_id)
    return ProxyAgent().set(key, p_str)


@cache_wrapper
def get_user_p(user_id):
    key = prefix_key('user_%s_p_str' % user_id)
    return ProxyAgent().get(key)
