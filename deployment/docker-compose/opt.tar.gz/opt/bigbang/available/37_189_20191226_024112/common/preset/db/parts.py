# -*- coding: utf-8 -*-
import logging

from common.utils.decorator import sql_wrapper
from common.utils import db as utils

_LOGGER = logging.getLogger(__name__)


@sql_wrapper
def get(table, id):
    return utils.get(table, id)


@sql_wrapper
def upsert(table, info, id=None):
    return utils.upsert(table, info, id)


@sql_wrapper
def list(table, query_dct):
    return utils.list_object(query_dct, table)


@sql_wrapper
def delete(table, id):
    utils.delete(table, id)
