# -*- coding: utf-8 -*-

import random
from datetime import datetime

from common import orm
from common.account.db.account import get_account
from common.activity.utils import get_activity_time, hide_user_name
from common.activity.utils import ts_to_date_str_list
from common.cache.redis_cache import get_recharge_iphone_activity_join_count, \
    incr_recharge_iphone_activity_join_count
from common.notification.handler import notify_recharge_iphone_win
from common.pay.db import get_today_recharge, get_pay_over_user_ids
from common.preset.model.preset import BANNER_TYPE
from common.utils import track_logging
from common.utils.tz import today_str, to_ts, now_ts, local_to_utc
from .recharge_iphone_model import ACTIVITY_CONFIG, RechargeIphoneRecord, ACTIVITY_STATUS

_LOGGING = track_logging.getLogger(__name__)

ROBOT_USER_NAME = [u'我们都一样', u'就是要中奖', u'15170362508', u'13656376607',
                   u'2722781', u'2722782', u'djkg948', u'Zcbiod2017']


def get_task_status(user_id, start_time, end_time, end_timing):
    if not user_id:
        return ACTIVITY_STATUS.UNLOGIN
    if now_ts() < start_time:
        return ACTIVITY_STATUS.UNSTART
    if now_ts() > end_time:
        return ACTIVITY_STATUS.OVER

    # 比较当天的情况
    today_amount = get_today_recharge(user_id, [])

    if end_timing:
        if today_amount < ACTIVITY_CONFIG['threshold']:
            return ACTIVITY_STATUS.UNREACH
        else:
            return ACTIVITY_STATUS.REACH
    else:
        return ACTIVITY_STATUS.END


def get_winner_user_name_by_date(activity_date):
    winner = orm.session.query(RechargeIphoneRecord).filter(RechargeIphoneRecord.date == activity_date).first()
    if not winner:
        return None
    return hide_user_name(winner.user_name)


def get_end_timing():
    """
    获取开奖剩余时间
    :return:
    """
    open_local_time = local_to_utc(datetime.strptime(today_str() + ' 22:00:00', '%Y-%m-%d %H:%M:%S'))
    open_ts = to_ts(open_local_time)
    return max(open_ts - now_ts(), 0)


def get_join_count(activity_date):
    """
    :param activity_date:
    :return:
    """
    return get_recharge_iphone_activity_join_count(activity_date)


def get_winners_list():
    start_time, end_time = get_activity_time(BANNER_TYPE.get_key('recharge_iphone'))
    date_list = ts_to_date_str_list(start_time, end_time)
    winner_list = []
    for activity_date in date_list:
        winner_list.append(
            dict(date=activity_date, user_name=hide_user_name(get_winner_user_name_by_date(activity_date))))
    return winner_list


def had_win(user_name):
    return orm.session.query(RechargeIphoneRecord).filter(RechargeIphoneRecord.user_name == user_name).count()


def had_open(activity_date):
    return orm.session.query(RechargeIphoneRecord).filter(RechargeIphoneRecord.date == activity_date).count()


def add_receive_record(user_id, user_name, activity_date, auto_commit=False):
    record = RechargeIphoneRecord()
    record.user_id = user_id
    record.user_name = user_name
    record.date = activity_date
    record.save()


def random_winner(activity_date=None):
    """
    随机 中奖用户，为机器人时，用户id 为空
    :return:
    user_id,user_name
    """
    if not activity_date:
        activity_date = today_str()

    if random.random() >= .0:
        winner_id = None
        winner_name = random.choice(ROBOT_USER_NAME)
    else:
        user = get_pay_over_user_ids(ACTIVITY_CONFIG['threshold'], activity_date)
        winner_id = random.choice(user)[1]
        winner_name = get_account(winner_id).user_name

    if had_win(winner_name):
        return random_winner(activity_date)

    return winner_id, winner_name


def add_join_count():
    incr_recharge_iphone_activity_join_count(today_str(), 1)


def open_prize(activity_date=None):
    """
    充值送iphone 开奖，机器人和真实用户2：1
    :return:
    """
    if not activity_date:
        activity_date = today_str()

    if had_open(activity_date):
        return

    start_time, end_time = get_activity_time(BANNER_TYPE.get_key('recharge_iphone'))

    if now_ts() < start_time or now_ts() > end_time:
        return

    user_id, user_name = random_winner(activity_date)

    add_receive_record(user_id, user_name, activity_date)

    if user_id:
        notify_recharge_iphone_win(user_id)
