# -*- coding: utf-8 -*-
import random

from common.utils.types import Enum

PROXY_URL = random.choice([
    'http://54.179.186.218:3128',
    'http://54.169.207.42:3128',
    # 'http://47.97.121.48:3128/',
    # 'http://47.97.121.105:3128/',
])

# OPENCAI_API_URL = 'http://e.apiplus.net/daily.do?token=t58970be7491e0817k&code=%s&format=json&date=%s'
OPENCAI_API_URL = 'http://wd.apiplus.net/daily.do?token=t68dfedde5a39d058k&code=%s&format=json&date=%s'

LOTTERY_TYPE = Enum({
    "CQ_SSC": (1L, u"重庆时时彩"),
    "JS_KS": (3L, u"江苏快3"),
    "SD_11X5": (4L, u"山东11选5"),
    "TJ_SSC": (6L, u"天津时时彩"),
    "XJ_SSC": (7L, u"新疆时时彩"),
    "JX_11X5": (8L, u"江西11选5"),
    "GD_11X5": (9L, u"广东11选5"),
    "SH_11X5": (10L, u"上海11选5"),
    "GX_KS": (11L, u"广西快3"),
    "BJ_PK10": (12L, u"北京PK10"),
    "CQ_LF": (13L, u"重庆幸运农场"),
    "TC_PLS": (14L, u"体彩排列3"),
    "FC3D": (15L, u"福彩3D"),
    "FF_SSC": (17L, u"极速分分彩"),
    "FF_11X5": (18L, u"极速11选5"),
    "FF_KS": (19L, u"极速快3"),
    "FF_PK10": (20L, u"极速PK10"),
    # "BJ_28": (21L, u"北京28"),
    # "EGG_28": (22L, u"蛋蛋28"),
    # "MARK_6": (23L, u"六合彩"),
})

DIY_LOTTERY = {
    LOTTERY_TYPE.FF_SSC: 'ff_ssc',
    LOTTERY_TYPE.FF_11X5: 'ff_11x5',
    LOTTERY_TYPE.FF_KS: 'ff_ks',
    LOTTERY_TYPE.FF_PK10: 'ff_pk10',
}

LF_LOTTERY_TYPES = (
    LOTTERY_TYPE.CQ_LF,
)

GAME_TYPE = Enum({
    "BULL": (101L, u"百人牛牛"),
    "CHICKEN": (102L, u"捉金鸡"),
    "FRUIT": (103L, u"水果机"),
    "WHEEL": (104L, u"大转盘"),
})

METIS_GAME_TYPE = Enum({
    "HALL": (5000, u"大厅"),
    "SUPER_BULL": (5500, u"超级牛牛"),
    "FLOWER": (5501, u"欢乐炸金花"),
    "SUPER_SIX": (5502, u"百家乐"),
    "DRAGON_TIGER": (5503, u"龙虎斗"),
    "GOLD_SHARK": (5504, u"金鲨银鲨"),
    "FOREST_BALL": (5505, u"森林舞会"),
    "DICE": (5506, u"骰宝"),
    "RED_BLACK": (5507, u"红黑大战"),
    "FUNK_MONKEY": (5600, u"放克猴子"),
    "EXPLORE": (5603, u"秘境探险"),
    "SUPER_BULL_1": (55001, u"超级牛牛-4倍场"),
    "SUPER_BULL_2": (55002, u"超级牛牛-10倍场"),
    "ROB_BULL_1": (59001, u"抢庄牛牛-初级场"),
    "ROB_BULL_2": (59002, u"抢庄牛牛-中级场"),
    "ROB_BULL_3": (59003, u"抢庄牛牛-高级场"),
    "ROB_BULL_4": (59004, u"抢庄牛牛-顶级场"),
    "SUOHA_1": (60011, u"梭哈-初级场"),
    "SUOHA_2": (60012, u"梭哈-进阶场"),
    "SUOHA_3": (60013, u"梭哈-高级场"),
    "SUOHA_4": (60014, u"梭哈-贵宾场"),
    "FLOWER_DUIZHAN_1": (60021, u"炸金花-体验房"),
    "FLOWER_DUIZHAN_2": (60022, u"炸金花-初级房"),
    "FLOWER_DUIZHAN_3": (60023, u"炸金花-中级房"),
    "FLOWER_DUIZHAN_4": (60024, u"炸金花-高级房"),
})

IMONE_GAME_TYPE = Enum({
    "IMAG": (102, u"真人AG"),
    "BACCARAT_EBET": (120003, u"百家乐Ebet"),
    "LONGHU_EBET": (120010, u"龙虎Ebet"),
    "DICE_EBET": (120014, u"骰宝Ebet"),
    "FISH_SKY_2": (40001, u"捕鱼天下"),
    "QPAO_FISH_H5": (100020, u"千炮捕鱼"),
    "LIKUI_FISH": (240024, u"李逵劈鱼"),
    "JINCHAN_FISH": (240025, u"金蟾捕鱼"),
    "FISH_3D": (240029, u'猎鱼达人'),
    "ESPORTS_BULL": (1001, u"电竞牛牛"),
    "PE_IM": (2001, u"IM体育"),
})

METIS_GAME_WITH_BANKER = [
    METIS_GAME_TYPE.SUPER_BULL,
    METIS_GAME_TYPE.DRAGON_TIGER,
    METIS_GAME_TYPE.FLOWER
]

KS_LOTTERY_TYPES = (
    LOTTERY_TYPE.JS_KS,
    LOTTERY_TYPE.GX_KS,
)

FF_KS_LOTTERY_TYPES = (
    LOTTERY_TYPE.FF_KS,
)

SSC_LOTTERY_TYPES = (
    LOTTERY_TYPE.CQ_SSC,
    LOTTERY_TYPE.XJ_SSC,
    LOTTERY_TYPE.TJ_SSC,
)

FF_SSC_LOTTERY_TYPES = (
    LOTTERY_TYPE.FF_SSC,
)

PK10_LOTTERY_TYPES = (
    LOTTERY_TYPE.BJ_PK10,
)

FF_PK10_LOTTERY_TYPES = (
    LOTTERY_TYPE.FF_PK10,
)

CP11X5_LOTTERY_TYPES = (
    LOTTERY_TYPE.GD_11X5,
    LOTTERY_TYPE.SD_11X5,
    LOTTERY_TYPE.JX_11X5,
    LOTTERY_TYPE.SH_11X5,
)

FF11X5_LOTTERY_TYPES = (
    LOTTERY_TYPE.FF_11X5,
)

TC_LOTTERY_TYPES = (
    LOTTERY_TYPE.TC_PLS,
)

FC_LOTTERY_TYPES = (
    LOTTERY_TYPE.FC3D,
)

KEYWORD_TYPE_DCT = {
    'cq_ssc': LOTTERY_TYPE.CQ_SSC,
    'js_ks': LOTTERY_TYPE.JS_KS,
    'sd_11x5': LOTTERY_TYPE.SD_11X5,
    'tj_ssc': LOTTERY_TYPE.TJ_SSC,
    'xj_ssc': LOTTERY_TYPE.XJ_SSC,
    'jx_11x5': LOTTERY_TYPE.JX_11X5,
    'gd_11x5': LOTTERY_TYPE.GD_11X5,
    'sh_11x5': LOTTERY_TYPE.SH_11X5,
    'gx_ks': LOTTERY_TYPE.GX_KS,
    'bj_pk10': LOTTERY_TYPE.BJ_PK10,
    'cq_lf': LOTTERY_TYPE.CQ_LF,
    'tc_pls': LOTTERY_TYPE.TC_PLS,
    'fc3d': LOTTERY_TYPE.FC3D,
    'ff_ssc': LOTTERY_TYPE.FF_SSC,
    'ff_11x5': LOTTERY_TYPE.FF_11X5,
    'ff_ks': LOTTERY_TYPE.FF_KS,
    'ff_pk10': LOTTERY_TYPE.FF_PK10,
}

OPENCAI_LOTTERY_TYPES = {
    LOTTERY_TYPE.CQ_SSC: 'cqssc',
    LOTTERY_TYPE.JS_KS: 'jsk3',
    LOTTERY_TYPE.SD_11X5: 'sd11x5',
    LOTTERY_TYPE.TJ_SSC: 'tjssc',
    LOTTERY_TYPE.XJ_SSC: 'xjssc',
    LOTTERY_TYPE.JX_11X5: 'jx11x5',
    LOTTERY_TYPE.GD_11X5: 'gd11x5',
    LOTTERY_TYPE.SH_11X5: 'sh11x5',
    LOTTERY_TYPE.GX_KS: 'gxk3',
    LOTTERY_TYPE.BJ_PK10: 'bjpk10',
    LOTTERY_TYPE.CQ_LF: 'cqklsf',
    # LOTTERY_TYPE.TC_PLS: 'pl3',
    # LOTTERY_TYPE.FC3D: 'fc3d',
}
