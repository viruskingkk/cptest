# -*- coding: utf-8 -*-
import json
import logging
from datetime import datetime

from common import orm
from common.lottery.cyclical.model import ACTIVITY_MODEL, ORDER_MODEL
from common.utils.decorator import sql_wrapper
from common.utils.db import list_object, get, upsert, delete

_LOGGER = logging.getLogger('bigbang')


@sql_wrapper
def list_activity(activity_type, query_dct):
    activity_table = ACTIVITY_MODEL[activity_type]
    if 'activity_type' in query_dct:
        del query_dct['activity_type']
    return list_object(query_dct, activity_table)


@sql_wrapper
def get_activity(activity_type, id):
    activity_table = ACTIVITY_MODEL[activity_type]
    return get(activity_table, id)


@sql_wrapper
def list_order(activity_type, query_dct):
    order_table = ORDER_MODEL[activity_type]
    if 'activity_type' in query_dct:
        del query_dct['activity_type']
    return list_object(query_dct, order_table)


@sql_wrapper
def get_order(activity_type, id):
    order_table = ORDER_MODEL[activity_type]
    return get(order_table, id)
