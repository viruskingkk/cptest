# coding=utf-8
import logging
import time
from datetime import datetime
from common.utils.types import Enum

_MAESTRO = logging.getLogger('maestro')


def track_maestro_create_recharge(pay_id, user_id, recharge_type, recharge_price, _event_time):
    _MAESTRO.info({
        '_id': str(pay_id),
        '_event_id': 'recharge_apply',
        'user_id': user_id,
        'recharge_type': recharge_type,
        '_event_time': _event_time,
        'out_trans_id': str(pay_id),
        'price': recharge_price
    })


def track_maestro_recharge(pay_id, user_id, recharge_type, status, price, third_time, _event_time):
    """
    :param pay_id: 支付id
    :param user_id: 用戶id
    :param recharge_type: 提現類型 ‘justpay' or 'unionagency' or 'wechat'
    :param status: 提現成功:2、提現失敗:4固化後結果
    :param price: 提現金額
    :param third_time: 送上第三方時間，timestamp
    :param _event_time: 完成事件時間
    :return:
    """
    _MAESTRO.info({
        '_id': str(pay_id),
        '_event_id': 'recharge',
        'user_id': user_id,
        'recharge_type': recharge_type,
        'status': status,
        'price': float(price),
        'third_time': third_time,
        '_event_time': _event_time
    })


def track_maestro_withdraw_apply(withdraw_id, user_id, withdraw_type, price, real_price, _event_time):
    _MAESTRO.info({
        '_id': str(withdraw_id),
        '_event_id': 'withdraw_apply',
        'user_id': user_id,
        'sub_type': withdraw_type,
        'out_trans_id': str(withdraw_id),
        'price': float(price),
        'real_price': float(real_price),
        '_event_time': _event_time
    })


def track_maestro_withdraw_risk_check(withdraw_id, user_id, withdraw_type, price, real_price, result,
                                      reason, _event_time):
    _MAESTRO.info({
        '_id': str(withdraw_id),
        '_event_id': 'withdraw_risk_check',
        'user_id': user_id,
        'sub_type': withdraw_type,
        'out_trans_id': str(withdraw_id),
        'price': float(price),
        'real_price': float(real_price),
        'result': result,
        'reason': reason,
        '_event_time': _event_time
    })


def track_maestro_withdraw_personal_check(withdraw_id, user_id, withdraw_type, price, real_price,
                                          auth_user, result, _event_time):
    _MAESTRO.info({
        '_id': str(withdraw_id),
        '_event_id': 'withdraw_personal_check',
        'user_id': user_id,
        'sub_type': withdraw_type,
        'out_trans_id': str(withdraw_id),
        'price': float(price),
        'real_price': float(real_price),
        'auth_user': auth_user,
        'result': result,
        '_event_time': _event_time
    })


def track_maestro_withdraw_financial(withdraw_id, user_id, withdraw_type, price, real_price, result, _event_time):
    _MAESTRO.info({
        '_id': str(withdraw_id),
        '_event_id': 'withdraw_financial',
        'user_id': user_id,
        'sub_type': withdraw_type,
        'out_trans_id': str(withdraw_id),
        'price': float(price),
        'real_price': float(real_price),
        'result': result,
        '_event_time': _event_time
    })


def track_maestro_withdraw_return(withdraw_id, user_id, withdraw_type, price, real_price, return_reason, _event_time):
    _MAESTRO.info({
        '_id': str(withdraw_id),
        '_event_id': 'withdraw_return',
        'user_id': user_id,
        'sub_type': withdraw_type,
        'out_trans_id': str(withdraw_id),
        'price': float(price),
        'real_price': float(real_price or price),
        'return_reason': return_reason,
        '_event_time': _event_time
    })


def track_maestro_withdraw(withdraw_id, user_id, withdraw_type, price, real_price, status, risk_reason, _event_time):
    """
    :param withdraw_id: 提現id
    :param user_id: 用戶id
    :param withdraw_type: 提現類型，'justpay' or 'unionagency'
    :param price: 提現金額
    :param real_price: 實際提現金額
    :param status: 提現成功：2、提現失敗: `4
    :param risk_reason: 風控原因
    :param _event_time: 完成事件時間
    :return:
    """
    _MAESTRO.info({
        '_id': str(withdraw_id),
        '_event_id': 'withdraw',
        'user_id': user_id,
        'sub_type': withdraw_type,
        'status': status,
        'price': float(price),
        'real_price': float(real_price),
        'risk_reason': risk_reason,
        '_event_time': _event_time
    })


def track_maestro_cp_lottery(user_id, sub_type, third_type, out_trans_id, price,
                             win, bonus, refund, profit, _event_time, seq_no, bet_target):
    _MAESTRO.info({
        '_id': '-'.join([str(sub_type), str(out_trans_id)]),
        '_event_id': 'cp_lottery',
        'seq_no': seq_no,
        'user_id': user_id,
        'sub_type': sub_type,
        'third_type': third_type,
        'out_trans_id': out_trans_id,
        'price': float(price),
        'win': float(win),
        'bonus': float(bonus),
        'refund': float(refund),
        'bet_target': bet_target,
        'profit': float(profit),
        '_event_time': _event_time
    })


def track_maestro_metis(user_id, third_type, out_trans_id, price, bet_target, profit, _event_time, seq_no):
    _MAESTRO.info({
        '_id': str(out_trans_id),
        '_event_id': 'cp_game',
        'seq_no': str(seq_no),
        'user_id': user_id,
        'sub_type': 'metis',
        'third_type': third_type,
        'out_trans_id': out_trans_id,
        'price': float(price),
        'win': float(profit) + float(price),
        'bet_target': bet_target,
        'profit': float(profit),
        '_event_time': _event_time
    })


def track_maestro_active(user_id, cvc, aid, chn, ip=None):
    _MAESTRO.info({
        '_id': '-'.join([str(user_id), str(aid or ''), str(int(time.mktime(datetime.now().timetuple())))]),
        '_event_id': 'active',
        'user_id': user_id,
        'cvc': cvc,
        'aid': aid,
        'chn': chn,
        'ip': ip,
        '_event_time': int(time.mktime(datetime.now().timetuple()))
    })


def track_bind_phone(user_id, phone):
    _MAESTRO.info({
        '_id': '_'.join([str(user_id), str(int(time.mktime(datetime.now().timetuple())))]),
        '_event_id': 'bind_phone',
        'user_id': user_id,
        'phone': phone,
        '_event_time': int(time.mktime(datetime.now().timetuple()))
    })


def track_maestro_register(user_id, cvc, aid, chn, ip=None, event_time=None):
    data = {
        '_id': str(user_id),
        '_event_id': 'register',
        'user_id': user_id,
        'cvc': cvc,
        'aid': aid,
        'chn': chn,
        'ip': ip,
        '_event_time': int(time.mktime(datetime.now().timetuple()))
    }
    if event_time:
        data['_event_time'] = int(time.mktime(event_time.timetuple()))
    _MAESTRO.info(data)


def track_coupon_birth(coupon_id, user_id, coupon_type, coupon_amount, _event_time):
    _MAESTRO.info({
        '_id': str(coupon_id),
        '_event_id': 'coupon_birth',
        'user_id': user_id,
        'type': coupon_type,
        'amount': float(coupon_amount),
        '_event_time': _event_time
    })


def track_coupon_used(coupon_id, user_id, coupon_type, coupon_amount, activity_type, lottery_price, _event_time):
    _MAESTRO.info({
        '_id': str(coupon_id),
        '_event_id': 'coupon_used',
        'user_id': user_id,
        'type': coupon_type,
        'amount': float(coupon_amount),
        'for': activity_type,
        'real_amount': lottery_price,
        '_event_time': _event_time
    })


PLATFORM_REWARD_SUB_TYPE = Enum({
    "SYSTEM_RECHARGE": ('system_recharge', u'系统上分'),
    "COUPON": ('coupon', u'红包'),
    "CAMPAIGN": ('campaign', u'活动奖励'),
    "PAY_BONUS": ('pay_bonus', u'充送'),
})

PLATFORM_REWARD_THIRD_TYPE = Enum({
    "COUPON_SEND": ('coupon_send', u'红包发放'),
    "SYSTEM_RECHARGE": ('system_recharge', u'系统上分'),
    "PAY_BONUS": ('pay_bonus', u'充送'),
    "FIRST_RECHARGE": ('first_recharge', u'新首充送活动'),
    "RED_ENVELOPE": ('recharge_red_envelope', u'双旦活动'),
    "WHEEL": ('wheel', u'大转盘活动')
})


def track_maestro_platform_reward(platform_reward_id, user_id, sub_type, third_type, reward_amount, _event_time):
    _MAESTRO.info({
        '_id': str(platform_reward_id),
        '_event_id': 'platform_reward',
        'user_id': user_id,
        'sub_type': sub_type,
        'third_type': third_type,
        'reward_amount': float(reward_amount),
        '_event_time': _event_time
    })
