# -*- coding: utf-8 -*-
from common.cache import ProxyAgent, strategy_client
from common.utils.decorator import cache_wrapper

_REDIS_KEY_PREFIX = 'lucky'
_BLACK_LIST = 'super:kfc:black:uids'
_WHITE_LIST = 'super:kfc:white:uids'
_SBLACK = 'super:kfc:black'
_SWHITE = 'super:kfc:white'

BULL_LOCK_RATIO = 5

def prefix_key(key):
    return '%s:%s' % (_REDIS_KEY_PREFIX, key)

def prefix_sblack_key(uid):
    """
    hash table, 存储黑名单用户参数，{"rate": 0.5, "count": 10}
    """
    return '%s:%s' % (_SBLACK, uid)

def prefix_swhite_key(uid):
    """
    hash table, 存储白名单用户参数，{"rate": 0.5, "count": 10}
    """
    return '%s:%s' % (_SWHITE, uid)


@cache_wrapper
def add_lock_amount(user_id, amount, ts):
    key = prefix_key('bull:userlock:%s' % user_id)
    ProxyAgent().incrbyfloat(key, amount)
    ProxyAgent().expire(key, ts)


@cache_wrapper
def get_lock_amount(user_id, ):
    key = prefix_key('bull:userlock:%s' % user_id)
    return float(ProxyAgent().get(key) or 0)


@cache_wrapper
def check_banker_lock(user_id):
    key = prefix_key('bull:bankerlock:%s' % user_id)
    return ProxyAgent().exists(key)


@cache_wrapper
def set_super_black_uid(uid, times, ratio, ttl):
    key = prefix_sblack_key(uid)
    s_key = _BLACK_LIST
    strategy_client.hmset(key, {
        'count': times,
        'rate': ratio
    })
    strategy_client.expire(key, ttl)
    strategy_client.sadd(s_key, uid)

@cache_wrapper
def remove_super_black_uid(uid):
    key = prefix_sblack_key(uid)
    s_key = _BLACK_LIST
    strategy_client.delete(key)
    strategy_client.srem(s_key, uid)

@cache_wrapper
def get_super_black_uids():
    s_key = _BLACK_LIST
    u_list = []
    uids = strategy_client.smembers(s_key) or []
    for uid in uids:
        u_key = prefix_sblack_key(uid)
        u_data = strategy_client.hgetall(u_key)
        if not u_data:
            strategy_client.srem(s_key, uid)
        else:
            ttl = strategy_client.ttl(u_key)
            u_list.append({
                'uid': int(uid),
                'times': u_data.get('count'),
                'ratio': u_data.get('rate', 1.0),
                'ttl': int(ttl)
            })
    return u_list

@cache_wrapper
def set_super_white_uid(uid, times, ratio, ttl):
    key = prefix_swhite_key(uid)
    s_key = _WHITE_LIST
    strategy_client.hmset(key, {
        'count': times,
        'rate': ratio
    })
    strategy_client.expire(key, ttl)
    strategy_client.sadd(s_key, uid)

@cache_wrapper
def remove_super_white_uid(uid):
    key = prefix_swhite_key(uid)
    s_key = _WHITE_LIST
    strategy_client.delete(key)
    strategy_client.srem(s_key, uid)

@cache_wrapper
def get_super_white_uids():
    s_key = _WHITE_LIST
    u_list = []
    uids = strategy_client.smembers(s_key) or []
    for uid in uids:
        u_key = prefix_swhite_key(uid)
        u_data = strategy_client.hgetall(u_key)
        if not u_data:
            strategy_client.srem(s_key, uid)
        else:
            ttl = strategy_client.ttl(u_key)
            u_list.append({
                'uid': int(uid),
                'times': u_data.get('count'),
                'ratio': u_data.get('rate', 1.0),
                'ttl': int(ttl)
            })
    return u_list
