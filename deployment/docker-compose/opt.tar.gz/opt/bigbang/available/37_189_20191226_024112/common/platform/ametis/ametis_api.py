# -*- coding: utf-8 -*-

import hashlib
import json
import time
import requests
from django.conf import settings

from common.utils import track_logging, tz
from common.utils.api import mask_phone_username

_LOGGER = track_logging.getLogger(__name__)

AMETIS_KEY = settings.AMETIS_KEY
AMETIS_URL = settings.AMETIS_URL
AMETIS_DATA_URL = settings.AMETIS_DATA_URL
MERCHANT = "WITCH"
WEBSITE = "witch"
TIMESTAMP = int(time.time())


def generate_sign(data):
    is_vertical = data.get('is_vertical')
    if is_vertical:
        data.pop('is_vertical')
    s = '{}{}{}&{}{}'.format(WEBSITE, TIMESTAMP, AMETIS_KEY, json.dumps(data), MERCHANT)
    _LOGGER.info('ametis_api-{}'.format(s))
    m = hashlib.md5()
    m.update(s)
    sign = m.hexdigest()
    return sign, is_vertical


def _base_request(method, data, success_code=[0], timeout=10):
    sign, is_vertical = generate_sign(data)
    url = AMETIS_URL + "?M={}&L={}&time={}&sign={}".format(MERCHANT, WEBSITE, TIMESTAMP, sign)
    if is_vertical:
        url += "&V=1"
    headers = {'content-type': 'application/json'}
    data = json.dumps(data)
    _LOGGER.info('begin request ametis_api {}-{}, data: {}'.format(method, url, data))
    resp = requests.post(url, headers=headers, data=data, timeout=timeout)
    _LOGGER.info('finish request ametis_api {}-{}, resp.content:{}'.format(method, data, resp.content))
    if resp.status_code != 200:
        return False, None
    else:
        resp_data = json.loads(resp.text)
        if resp_data['code'] in success_code:
            return True, resp_data.get('data')
        else:
            return False, None


def enter_game(user_id, user_name, game_id, ref_id, amount, is_vertical):
    """
    进入ametis游戏
    :return: (status, data) status: bool 标识是否成功
                            data: 成功后的数据，失败返回None
    """
    method = "trade_bank"
    data = {"func": method, "game": game_id, "refs": ref_id, "user": user_id, "gold": amount,
            "nick": mask_phone_username(user_name), "is_vertical": is_vertical}
    return _base_request(method, data, [0, 1])


def check_trans_status(ref_id):
    """
    查询转账交易状态
    """
    method = "trade_find"
    data = {"func": method, "refs": ref_id}
    return _base_request(method, data)


def exit_game(user_id, ref_id):
    method = "trade_draw"
    data = {"func": method, "user": user_id, "refs": ref_id}
    return _base_request(method, data)


def query_balance(user_id):
    method = "query_gold"
    data = {"func": method, "user": user_id}
    return _base_request(method, data)


def query_orders(user_id, page, size, start_time,
                 end_time=None, game_id=""):
    if not end_time:
        end_time = tz.local_now().strftime('%Y-%m-%d %H:%M:%S')
    method = "users_bets"
    data = {"func": "users_bets", "acc": user_id, "gid": game_id, "tm1": start_time,
            "tm2": end_time, "idx": page-1, "num": size}
    return _base_request(method, data)


def _base_ametis_request(data, timeout=10):
    data = json.dumps(data)
    m = hashlib.md5()
    s = WEBSITE + ':__M&ar@es!__F:' + data
    m.update(s)
    sign = m.hexdigest()
    url = AMETIS_DATA_URL
    headers = {'content-type': 'application/json'}
    payload = {"rand": WEBSITE, "sign": sign}
    _LOGGER.info('begin request ametis_api {}, data: {}, sign: {}'.format(url, data, sign))
    resp = requests.post(url, params=payload, headers=headers, data=data, timeout=timeout)
    _LOGGER.info('finish request ametis_api {}, resp.content:{}'.format(data, resp.content))
    if resp.status_code != 200:
        return False, None
    else:
        resp_data = json.loads(resp.text)
        return True, resp_data


def query_data_by_user(user_id, start_time, end_time=None, game_id=''):
    if not end_time:
        end_time = tz.local_now().strftime('%Y-%m-%d %H:%M:%S')
    method = "get_stat_win"
    data = {"code": method, "acc": user_id, "tm1": start_time, "tm2": end_time, "gid": game_id,
            "idx": 0, "M": MERCHANT, "sel_m": "", "order_by": ""}
    return _base_ametis_request(data)
