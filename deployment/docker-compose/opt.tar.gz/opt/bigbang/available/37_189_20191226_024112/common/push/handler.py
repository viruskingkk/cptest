# -*- coding: utf-8 -*-
import json
import logging


from common.third.push_notification import (
    push_to_android, push_to_ios, push_to_ipad)
from common.push.model import *

_LOGGER = logging.getLogger(__name__)


def push(user_id, title, body, payload):
    push_to_android(user_id, title, body, payload)
    push_to_ios(user_id, title, body, payload)
    # push_to_ipad(user_id, title, body, payload)


def push_notification(user_id, content):
    try:
        data = json.loads(content)
        title = data['title'].encode('utf-8')
        body = data['content'].encode('utf-8')
        payload = {
            'title': title,
            'content': body
        }
        if data['command']:
            command = data['command'].encode('utf-8')
            payload['command'] = command
        push(user_id, title, body, payload)
    except Exception as e:
        _LOGGER.exception('push_notification exception, %s', e)


def push_msg(user_id, data):
    try:
        push(user_id, data.get('title', ''), data.get('content', ''), data)
    except Exception as e:
        _LOGGER.exception(e)