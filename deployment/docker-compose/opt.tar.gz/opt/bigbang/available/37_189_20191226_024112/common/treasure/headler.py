# -*- coding: utf-8 -*-

from common.treasure.db import get_treasures
from api import BaseModel
from common.treasure.model import TREASURE_CONF, TREASURE_AMOUNT


class CycleTreasure(BaseModel):
    structure = {
        'id': long,
        'user_id': int,
        'treasure_type': int,
        'status': int,
        'date': str,
        'amount': int,
    }
    required_fields = ['id', 'user_id', 'treasure_type', 'date']
    default_fields = {
        'status': 0,
        'amount': 0,
    }


def get_treasure_list(user_id):
    items = get_treasures(user_id)
    resp_items = []
    for item in items:
        data = CycleTreasure(item.as_dict())
        resp_items.append(data)
    return {'treasures': sorted(resp_items, key=lambda k: k['treasure_type'])}


def get_treasure_config():
    config = []
    for amount in TREASURE_CONF:
        min_award = int(TREASURE_AMOUNT.get(TREASURE_CONF[amount])[0][0])
        max_award = int(TREASURE_AMOUNT.get(TREASURE_CONF[amount])[-1][0])
        award_range = '%s~%s' % (min_award, max_award)
        config.append({
            'amount': amount,
            'award_range': award_range
        })
    return sorted(config, key=lambda k: k.get('amount'))

