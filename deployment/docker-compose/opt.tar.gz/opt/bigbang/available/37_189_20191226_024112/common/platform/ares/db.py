# -*- coding: utf-8 -*-

from common import orm
from common.cache import redis_cache
from common.platform.ares import ares_api
from common.platform.ares.model import ImoneBetLogs, ImoneUserInfo
from common.utils import track_logging, decorator
from common.utils.currency import convert_yuan_to_fen
from common.utils.tz import local_str_to_utc_str

_LOGGER = track_logging.getLogger(__name__)


def is_black_user(user_id):
    """判断是否为黑名单用户"""
    uids = redis_cache.get_platform_risk_uids('ares', 'forbidden')
    if str(user_id) in uids:
        return True
    return False


def is_pass_user(user_id):
    """ 判断是否为白名单用户 """
    uids = redis_cache.get_platform_risk_uids('ares', 'pass')
    if len(uids) != 0 and str(user_id) not in uids:
        return True
    return False


def calculate_accumulated_win_amount(balance, freeze_balance):
    """
    计算时间段用户的派奖总
    """
    amount = balance + freeze_balance
    if amount > 0:
        return amount
    return 0


def get_lastest_time_betlogs():
    """获取最近的记录更新时间"""
    query = ImoneBetLogs.query.order_by(ImoneBetLogs.create_time.desc()).first()
    return query.create_time if query else None


def get_imPlayer_id(user_id):
    """根据平台用户ID查询IM玩家ID"""
    status, data = ares_api.check_IMplayer_id_v2(user_id)
    if status:
        # player_id = data['userId']
        player_id = data['imone_user_id']
    else:
        player_id = get_imone_player_id(user_id)
    return player_id


@decorator.sql_wrapper
def add_bet_logs(data):
    """添加imone游戏记录进数据库"""
    log = ImoneBetLogs()
    log.user_id = data['user_id']
    log.game_id = data['game_id']
    log.ref_id = str(data['refs_id'])
    log.status = data['status']
    log.bet_amount = convert_yuan_to_fen(data['gold_bet'])
    log.bet_result = convert_yuan_to_fen(data['gold_win'])
    log.create_time = local_str_to_utc_str(data['time_at'])
    log.save(auto_commit=False)
    orm.session.flush()
    return log.as_dict()


@decorator.sql_wrapper
def get_bet_log_by_ticket_id_and_game_id(ticket_id, game_id):
    # ticket_id 和 game_id 组合起来是唯一
    bet_log = ImoneBetLogs.query.filter(ImoneBetLogs.ticket_id == ticket_id).\
        filter(ImoneBetLogs.game_id == game_id).first()
    return bet_log.as_dict() if bet_log else None


@decorator.sql_wrapper
def add_imone_user_info(user_id, player_id):
    user_info = ImoneUserInfo.query.filter(ImoneUserInfo.user_id == user_id).first()
    if user_info:
        return user_info.as_dict()

    user_info = ImoneUserInfo()
    user_info.user_id = user_id
    user_info.player_id = player_id
    user_info.save()
    return user_info.as_dict()


@decorator.sql_wrapper
def get_imone_user_info_by_player_id(player_id):
    user_info = ImoneUserInfo.query.filter(ImoneUserInfo.player_id == player_id).first()
    return user_info.as_dict() if user_info else None


@decorator.sql_wrapper
def get_imone_player_id(user_id):
    user_info = ImoneUserInfo.query.filter(ImoneUserInfo.user_id == user_id).first()
    return user_info.player_id if user_info else None
