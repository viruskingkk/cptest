# -*- coding: utf-8 -*-
import json
import time
import hashlib
import requests
import logging
import copy

from django.conf import settings
from common.utils import exceptions as err
from common.transaction.model import WITHDRAW_STATUS, BANK_CODE_MAP
from common.account.db.account import get_user_bankcard
from common.withdraw import check_daily_risk
from common.withdraw.db import withdraw_success_action, withdraw_failed_action, withdraw_success_notify, \
    withdraw_failed_notify
from common.utils import tz, currency
from common.utils.types import Enum
from async import async_job

from common.utils import track_logging

_LOGGER = track_logging.getLogger(__name__)

"""
自建银行卡代理下分
"""

MCH_ID = settings.UNIONAGENCY_MCH_ID
API_KEY = settings.UNIONAGENCY_API_KEY
CHARGE_URL = settings.UNIONAGENCY_WITHDRAW_CHARGE_URL
QUERY_URL = settings.UNIONAGENCY_WITHDRAW_QUERY_URL
NOTIFY_URL = settings.UNIONAGENCY_WITHDRAW_NOTIFY_URL

WITHDRAW_ORDER_STATUS = Enum({
    "WAIT": (0L, "待下分"),
    "LOCKED": (1L, "已锁定"),
    "DONE": (2L, "已下分"),
    "REJECTED": (3L, "拒绝下分"),
})


def generate_sign(parameter, key):
    s = ''
    for k in sorted(parameter.keys()):
        s += '%s=%s&' % (k, parameter[k])
    s += 'key=%s' % key
    m = hashlib.md5()
    m.update(s.encode('utf8'))
    sign = m.hexdigest().upper()
    return sign


def new_generate_sign(parameter, key, add_timestamp=True):
    if add_timestamp and 'timestamp' not in parameter:
        parameter['timestamp'] = int(time.time())
    s = ''
    for k in sorted(parameter.keys()):
        if parameter[k] is not None:
            s += '%s=%s&' % (k, parameter[k])
    s += 'key=%s' % key
    m = hashlib.md5()
    m.update(s.encode('utf8'))
    sign = m.hexdigest().upper()
    return sign


def create_charge(user_id, withdraw):
    bankcard = get_user_bankcard(user_id)
    updated_info = json.loads(withdraw.extend)
    detail = updated_info.get('info', {})
    ip, city, sdk_version = detail.get('ip'), detail.get('city'), detail.get('sdk_version')
    real_price = withdraw.real_price
    trans_info = {}
    if ip and city and sdk_version:
        if bankcard:
            bank_no = bankcard.account
            bank_name = bankcard.bank
            sub_bank = bankcard.sub_bank
            real_name = bankcard.real_name
        else:
            bank_no = detail.get('no')
            bank_name = detail.get('bankname')
            real_name = detail.get('name')
            sub_bank = detail.get('bankname')
        parameter_dict = {
            'sdk_version': sdk_version,
            'mch_id': MCH_ID,
            'user_id': user_id,
            'out_trade_no': withdraw.id,
            'body': u'提现',
            'pay_type': u'bankcard',
            'pay_account_num': bank_no,
            'pay_account_username': real_name,
            'pay_account_bank': bank_name,
            'pay_account_bank_subbranch': sub_bank,
            'amount': real_price,
            'notify_url': NOTIFY_URL,
            'region': city,
            'client_ip': ip,
        }
        parameter_dict['sign'] = generate_sign(parameter_dict, API_KEY)
        _LOGGER.info('withdraw params to unionagency: %s', parameter_dict)
        res = requests.post(CHARGE_URL, data=parameter_dict, timeout=60).text
        _LOGGER.info(u'unionagency withdraw {} response data: {}'.format(withdraw.id, res))
        try:
            res = json.loads(res)
        except ValueError:
            raise err.DataError(u'第三方通道异常')
        if res['status'] == 2 and res['msg'] == 'out_trade_no exists':
            withdraw.status = WITHDRAW_STATUS.SUBMIT_TO_THIRD
            trans_info.update({
                'payer_no': 'union_bank_withdraw',
                'code': 'submit',
                'amount': real_price,
                'out_biz_no': withdraw.id,
                'order_id': 'miss',
                'pay_date': tz.local_now().strftime('%Y-%m-%d %H:%M:%S'),
            })
        else:
            res_dict = res.get('data', {})
            order_status = int(res_dict.get('order_status'))
            trans_info.update({
                'payer_no': 'union_bank_withdraw',
                'code': 'submit',
                'amount': real_price,
                'out_biz_no': withdraw.id,
                'order_id': res_dict.get('order_id'),
                'pay_date': tz.local_now().strftime('%Y-%m-%d %H:%M:%S'),
            })
            if order_status == 0:
                withdraw.status = WITHDRAW_STATUS.SUBMIT_TO_THIRD
            elif order_status == 3:
                withdraw.status = WITHDRAW_STATUS.FAIL
                fail_reason = res_dict.get('reason', '')
                trans_info.update({
                    'sub_msg': fail_reason,
                })
            else:
                pass
        updated_info.update({'auto_trans_info': trans_info})
        withdraw.extend = json.dumps(updated_info, ensure_ascii=False)
        withdraw.save()
        return res


def create_withdraw(user_id, withdraw):
    bankcard = get_user_bankcard(user_id)
    real_price = int(withdraw.real_price)
    updated_info = json.loads(withdraw.extend)
    detail = updated_info.get('info', {})
    trans_info = {}
    if bankcard:
        withdraw_name = bankcard.real_name
        withdraw_account = bankcard.account
        bank_name = bankcard.bank
    else:
        # 对于一些老版本的用户，他们没有绑定银行卡的功能，只会在提现的时候填写银行卡信息，因此需要兼容
        withdraw_name = detail.get('name')
        withdraw_account = detail.get('no')
        bank_name = detail.get('bankname')

    if withdraw_name and withdraw_account and bank_name:
        ip = detail.get('ip')
        device_id = detail.get('device_id', '')
        sdk_version = detail.get('sdk_version')
        device_type = 'android'
        if 'ios' in sdk_version:
            device_type = 'ios'
        parameter_dict = {
            'mch_id': settings.NEW_UNIONAGENCY_MCH_ID,
            'mch_withdraw_no': withdraw.id,
            'amount': currency.convert_yuan_to_fen(real_price),
            'withdraw_type': 'bankcard',
            'withdraw_name': withdraw_name,
            'withdraw_account': withdraw_account,
            'withdraw_bank_code': BANK_CODE_MAP.get(bank_name, 'OTHERS'),
            'user_id': str(user_id),
            'remark': '',
            'device_type': device_type,
            'device_id': device_id,
            'device_ip': ip
        }
        parameter_dict['sign'] = new_generate_sign(parameter_dict, settings.NEW_UNIONAGENCY_API_KEY)
        _LOGGER.info(u'unionagency withdraw submit params : %s' % parameter_dict)
        res = requests.post(settings.NEW_UNIONAGENCY_WITHDRAW_URL, data=parameter_dict).text
        _LOGGER.info(u'unionagency withdraw response data: %s' % res)
        try:
            res_dict = json.loads(res)
        except ValueError:
            raise err.DataError(u'第三方通道异常')
        if res_dict.get('status') != 0:
            _LOGGER.error(u'unionagency withdraw response data error, data: %s' % res)
            return False
        response_data = res_dict.get('data')
        if response_data.get('status') in ('new', 'success'):
            withdraw.status = WITHDRAW_STATUS.SUBMIT_TO_THIRD
            trans_info.update({
                'payer_no': 'union_bank_withdraw',
                'code': 'submit',
                'amount': real_price,
                'out_biz_no': withdraw.id,
                'order_id': res_dict.get('order_id'),
                'pay_date': tz.local_now().strftime('%Y-%m-%d %H:%M:%S'),
            })
        else:
            withdraw.status = WITHDRAW_STATUS.FAIL
            trans_info.update({
                'payer_no': 'union_bank_withdraw',
                'code': 'submit',
                'amount': real_price,
                'out_biz_no': withdraw.id,
                'order_id': res_dict.get('order_id'),
                'pay_date': tz.local_now().strftime('%Y-%m-%d %H:%M:%S'),
                'complete_pay_date': tz.local_now().strftime('%Y-%m-%d %H:%M:%S'),
            })
        updated_info.update({'auto_trans_info': trans_info})
        withdraw.extend = json.dumps(updated_info, ensure_ascii=False)
        withdraw.save()
        return res
    else:
        _LOGGER.error(u'unionagency withdraw info error,  id, %s' % withdraw.id)


def query(out_trade_no):
    parameter_dict = {
        'mch_id': MCH_ID,
        'out_trade_no': out_trade_no,
        'random_num': 4444,
    }
    parameter_dict['sign'] = generate_sign(parameter_dict, API_KEY)
    res = requests.post(QUERY_URL, data=parameter_dict, timeout=5).text
    return res


def new_check_sign(params, desc=''):
    copy_params = copy.deepcopy(params)
    sign = copy_params.pop('sign')
    calculated_sign = new_generate_sign(copy_params, settings.NEW_UNIONAGENCY_API_KEY, False)
    if sign != calculated_sign:
        _LOGGER.info("unionagency sign: %s, calculated sign: %", sign, calculated_sign)
        raise err.ParamError('%s sign not pass, data: %s' % (desc, params))


def withdraw_notify(params):
    # 我们属于UA平台的商户，获取withdraw_id
    withdraw_id = int(params['mch_withdraw_no'])
    if not withdraw_id:
        _LOGGER.error("fatal error, out_trade_no not exists, data: %s" % params)
        raise err.ParamError('unionagency event does not contain pay ID')
    trade_status = params['status']
    trade_no = params['order_id']
    if trade_status == 'success':
        success, item = withdraw_success_notify(withdraw_id, trade_no, payer_no='bankcard')
        if success:
            _LOGGER.info('Auto trans bankcard, check_bankcard_withdraw_notify_sign succ')
            check_daily_risk(float(item.get('real_price')))
    elif trade_status == 'fail':
        withdraw_failed_notify(withdraw_id, trade_no)


def check_notify_sign(request):
    data = request.POST.dict()
    sign = data.pop('sign')
    calculated_sign = generate_sign(data, API_KEY)
    if sign != calculated_sign:
        _LOGGER.info("unionagency sign: %s, calculated sign: %", sign, calculated_sign)
        raise err.ParamError(u'sign not pass, data: %s' % data)
    withdraw_id = int(data['trade_no'])
    if not withdraw_id:
        _LOGGER.error(u"fatal error, out_trade_no not exists, data: %s" % data)
        raise err.ParamError('unionagency event does not contain pay ID')
    trade_status = int(data['pay_result'])
    amount = float(data['total_fee'])
    trade_no = int(data['trade_no'])
    _LOGGER.info(u'unionagency check_notify, data %s', data)
    if trade_status == WITHDRAW_ORDER_STATUS.DONE:
        succ = withdraw_success_action(withdraw_id, amount, trade_no, payer_no='union_bank_withdraw')
        if succ:
            _LOGGER.info('Auto trans bankcard, check_bankcard_withdraw_notify_sign succ')
            check_daily_risk(float(amount))
            async_job.stats_withdraw.delay([withdraw_id])
    elif trade_status == WITHDRAW_ORDER_STATUS.REJECTED:
        reason = data.get('reason', '')
        succ = withdraw_failed_action(withdraw_id, amount, trade_status,
                                      trade_status, reason, trade_no, payer_no='union_bank_withdraw')
    else:
        raise err.ParamError(u'Wrong trade status: %s, data: %s' % (trade_status, data))
