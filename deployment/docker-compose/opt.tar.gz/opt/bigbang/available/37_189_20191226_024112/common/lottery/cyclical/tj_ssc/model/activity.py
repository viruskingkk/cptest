# -*- coding: utf-8 -*-
from common import orm
from common.lottery.cyclical import ACTIVITY_STATUS
from common.lottery.cyclical.ssc.model import SSCTrend, SSCActivity


class Activity(orm.Model, SSCActivity):
    __tablename__ = "tj_ssc"


class Trend(orm.Model, SSCTrend):
    __tablename__ = "tj_ssc_trend"
