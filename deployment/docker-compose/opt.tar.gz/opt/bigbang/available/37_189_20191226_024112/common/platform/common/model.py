#! -*- coding:utf-8 -*-
from django.conf import settings

from common import orm, ArmoryOrm
from common.utils.types import Enum

metis_orm = ArmoryOrm()
metis_orm.init_conf(settings.METIS_MYSQL_CONF)

M_TRANSACTION_TYPE = Enum({
    "FROZEN": (1L, u"out"),
    "FROZEN_REVERSE": (2L, u"reverse out"),
    "UNFREEZE": (3L, u"in")
})

PLATFORM_TYPE = Enum({
    "WITCH": (0L, u"witch"),
    "METIS": (1L, u"metis"),
    "ARES": (3L, u"ares"),
    "AMETIS": (4L, u"ametis"),
})


class ThirdTransaction(orm.Model):
    __tablename__ = "metis_transaction"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    platform = orm.Column(orm.Integer)  # 平台 PLATFORM_TYPE
    type = orm.Column(orm.Integer)  # 转入/转出
    balance = orm.Column(orm.BigInteger)  # 账户余额-累计
    withdraw = orm.Column(orm.BigInteger)  # 可用提现额度-累计
    accu_balance = orm.Column(orm.BigInteger)  # 累計余额
    accu_withdraw = orm.Column(orm.BigInteger)  # 累計提現
    curr_balance = orm.Column(orm.BigInteger)  # 当前余额
    curr_withdraw = orm.Column(orm.BigInteger)  # 当前可提现
    ref_id = orm.Column(orm.VARCHAR)  # 唯一订单号
    checked = orm.Column(orm.Boolean, default=False)  # 是否已和metis对账
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class ThirdWithdrawTransactionLog(orm.Model):
    __tablename__ = "metis_withdraw_trans_log"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    platform = orm.Column(orm.Integer)  # 平台 PLATFORM_TYPE
    amount = orm.Column(orm.BigInteger)
    ref_id = orm.Column(orm.VARCHAR)
    checked = orm.Column(orm.Boolean, default=False)  # 是否已和metis对账
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class MetisPlatformUser(metis_orm.Model):
    __tablename__ = "users"
    id = orm.Column(orm.BigInteger, primary_key=True)
    subsidiary_user_id = orm.Column(orm.VARCHAR)


class MetisPlatformLogBet(metis_orm.Model):
    __tablename__ = "log_bet"
    id = orm.Column(orm.BigInteger, primary_key=True)
    user_id = orm.Column(orm.BigInteger)
    bet_amount = orm.Column(orm.FLOAT)  # 押注金额
    bet_result = orm.Column(orm.FLOAT)  # 返还金额
    status = orm.Column(orm.Integer)  # 1 为有效投注
    bet_type = orm.Column(orm.Integer)  # 1 为有效投注
    created_at = orm.Column(orm.DATETIME)


# V2.4.8版本游戏platform改名,ares和imone游戏type在此dict兼容查询
ARES_IMONE_GAME_TYPE = {
    102: u"真人AG", 120003: u"视讯百家乐", 120010: u"视讯龙虎斗", 120014: u"视讯骰宝", 40001: u"捕鱼天下",
    100020: u"千炮捕鱼", 240024: u"李逵劈鱼", 240025: u"金蟾捕鱼", 240029: u"猎鱼达人",1001: u"电竞牛牛", 2001: u"IM体育",
    # 以下为IMone真人游戏大厅可跳转到的游戏类型
    120001: u'Ebet百家乐VVIP', 120002: u'Ebet百家乐VIP', 120004: u'Ebet百家乐6', 120005: u'Ebet百家乐8',
    120006: u'Ebet极速百家乐2', 120007: u'Ebet极速百家乐5', 120008: u'Ebet极速百家乐7', 120009: u'Ebet极速百家乐9',
    120012: u'Ebet轮盘1号桌', 120013: u'Ebet轮盘2号桌', 120015: u'Ebet百家乐3',
    # 以上为imone游戏,以下为ametis游戏
    885500: u"超级牛牛", 885501: u"欢乐炸金花",885502: u"百家乐", 885503: u"龙虎斗", 885504: u"金鲨银鲨",
    885505: u"森林舞会", 885506: u"骰宝", 885507: u"红黑大战", 885600: u"放克猴子", 885603: u"秘境探险",
    885900: u"抢庄牛牛", 886001: u"梭哈", 886002: u"炸金花"
}
