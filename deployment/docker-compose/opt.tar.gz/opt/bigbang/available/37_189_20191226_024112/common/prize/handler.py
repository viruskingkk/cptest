# coding: utf-8

from common.account.db.account import get_user_bankcard, get_account
from common.prize.db import get_fresh_award


def check_bind(user_id, bind_type='phone'):
    if get_fresh_award(user_id):
        return False
    if bind_type == 'phone':
        user = get_account(user_id)
        if user and user.phone and len(user.phone) == 13:
            return True
        return False
    if bind_type == 'bankcard':
        bankcard = get_user_bankcard(user_id)
        return True if bankcard else False
    return False
