# -*- coding: utf-8 -*-

from common import orm
from common.utils.types import Enum

MSG_TYPE = Enum({
    "WIN": (1L, u'用户中奖')
})


class PushConfig(orm.Model):
    '''用户的各类push开关
    '''
    __tablename__ = "push_config"
    id = orm.Column(orm.BigInteger, primary_key=True)
    user_id = orm.Column(orm.BigInteger)
    win = orm.Column(orm.Boolean, default=True)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
