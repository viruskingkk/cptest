# coding=utf-8
import logging

from common.timer import EventHandler
from common.coupon.db import expire_coupon

_LOGGER = logging.getLogger('worker')


class CouponExpiredHandler(EventHandler):
    def process(self, event_msg):
        _LOGGER.info('start processing Coupon Expired Event[%s]' % event_msg)
        try:
            coupon_id = event_msg['coupon_id']
            expire_coupon(coupon_id)
        except Exception as e:
            _LOGGER.exception('CouponExpiredHandler process error.(%s)' % e)
        return True
