# -*- coding: utf-8 -*-

from common import orm


class MetisBetLogs(orm.Model):
    __tablename__ = "metis_bet_logs"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    ticket_id = orm.Column(orm.BigInteger)  # 游标，注单编号
    user_id = orm.Column(orm.BigInteger)
    status = orm.Column(orm.Boolean, default=False)  # 判断是否已回滚
    game_id = orm.Column(orm.Integer)  # 游戏type
    bet_type = orm.Column(orm.Integer)  # 投注类型: 1.非莊家, 2.莊家, 4.機器人, 5 = 1(非莊家)+4(機器人)
    play_type = orm.Column(orm.Integer)  # 用户投注类型：ex.天/地/玄/黄
    bet_amount = orm.Column(orm.BigInteger)  # 用户投注额
    bet_result = orm.Column(orm.BigInteger)  # 用户盈亏
    round_id = orm.Column(orm.VARCHAR)  # 游戏局号
    both_press = orm.Column(orm.Boolean, default=False)  # 是否对压
    extend = orm.Column(orm.TEXT)  # 详细下注信息
    create_time = orm.Column(orm.DATETIME)  # 下注时间
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class MetisGameTerm(orm.Model):
    __tablename__ = "metis_game_term"
    id = orm.Column(orm.BigInteger, primary_key=True)
    game_id = orm.Column(orm.Integer)
    ticket_id = orm.Column(orm.BigInteger)  # 游标
    round_id = orm.Column(orm.VARCHAR)
    cards = orm.Column(orm.TEXT)  # cards ，JSON
    total_people = orm.Column(orm.Integer)  # 总人数
    total_bet_amount = orm.Column(orm.Integer)  # 总下注额
    total_bet_result = orm.Column(orm.Integer)  # 总盈亏
    extend = orm.Column(orm.TEXT)  # 扩展字段，JSON
    create_time = orm.Column(orm.DATETIME)  # 本期开始时间戳
    flag = orm.Column(orm.SmallInteger)  # 策略flag,0=未執行 1=未生效 2=生效
    original_rate = orm.Column(orm.FLOAT)  # 原始抽水率
    original_cards = orm.Column(orm.TEXT)  # 原始开牌
    rate = orm.Column(orm.FLOAT)  # 调整后抽水率
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class MetisGamePart(orm.Model):
    __tablename__ = "metis_game_participate"
    id = orm.Column(orm.BigInteger, primary_key=True)
    game_id = orm.Column(orm.Integer)
    ticket_id = orm.Column(orm.BigInteger)  # 游标
    round_id = orm.Column(orm.VARCHAR)
    user_id = orm.Column(orm.Integer)  # user_id
    bet_index = orm.Column(orm.Integer)  # 押注序列号
    bet_amount = orm.Column(orm.BigInteger)  # 押注金额
    bet_result = orm.Column(orm.BigInteger, default=0)  # 返还金额
    extend = orm.Column(orm.TEXT)  # 扩展字段，JSON
    create_time = orm.Column(orm.DATETIME)  # 本期开始时间戳
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class MetisPool(orm.Model):
    __tablename__ = "metis_pool"
    id = orm.Column(orm.BigInteger, primary_key=True)
    game_id = orm.Column(orm.Integer)
    water_rate = orm.Column(orm.FLOAT)  # 抽水率
    water_pool = orm.Column(orm.FLOAT)  # 水池
    control_rate = orm.Column(orm.FLOAT)  # 控制抽水率
    control_pool = orm.Column(orm.FLOAT)  # 欲增减抽水池量
    now_rate = orm.Column(orm.FLOAT)  # 调整后抽水率
    now_pool = orm.Column(orm.FLOAT)  # 调整后人工水池
    date = orm.Column(orm.VARCHAR)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class MetisPumping(orm.Model):
    __tablename__ = "metis_pumping"
    id = orm.Column(orm.BigInteger, primary_key=True)
    game_id = orm.Column(orm.Integer)
    control_value = orm.Column(orm.Integer)  # 初始投注门槛值
    upper_value = orm.Column(orm.FLOAT)  # 抽水率上限(0-1)
    upper_rate = orm.Column(orm.FLOAT)  # 抽水概率(0-100)
    lower_value = orm.Column(orm.FLOAT)  # 抽水率下限(0-1)
    lower_rate = orm.Column(orm.FLOAT)  # 放水概率(0-100)
    pool_lower_limit = orm.Column(orm.FLOAT)  # 保底盈亏金额，正数则为盈，负数则为亏
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)