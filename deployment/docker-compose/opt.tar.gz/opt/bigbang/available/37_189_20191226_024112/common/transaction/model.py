# -*- coding: utf-8 -*-
from common import orm
from common.utils.types import Enum

# todo 待优化，这里应该细分每个TRANSACTION_TYPE
TRANSACTION_TYPE = Enum({
    "IN": (1L, u"充值"),
    "AWARD": (2L, u"派奖"),
    "BALANCE_BUY": (4L, u"购彩"),
    "REFUND": (8L, u"退款"),
    "WITHDRAW": (16L, u"提现"),
    "PAY_OFF": (32L, u"赔付"),
    "AGENT_RETURN": (64L, u"代理返点"),
    "AGENT_BONUS": (128L, u"代理分红"),
    "AGENT_TRANSFER": (256L, u"代理转账"),
    "PLATFORM_TRANSFER": (512L, u"平台转账"),
    "SYSTEM_RECHARGE": (8193, u"系统奖励"),
    "SYSTEM_CHASE": (8194, u"系统追分"),
    "ACTIVITY": (10001, u"活动"),
    "PAY_BONUS": (10002, u"充值回馈"),
    "WITHDRAW_FAIL_REFUND": (20002, u"提现失败返款"),
    "RECAPTURE": (10003, u"款项追回"),
    "RECHARGE_AWARD": (10004, u"188充值活动"),
    "SPRING_FESTIVAL": (10005L, u"春节福利活动"),
    "RANKING_AWARD": (10006L, u"春节流水排名活动"),
    "LANTERN_AWARD": (10008, u"元宵活动"),
    "THIRD_PLATFORM_FROZEN": (10020, u"第三方冻结"),
    # "THIRD_PLATFORM_REVERSE": (10022, u"第三方回滚"),
    "THIRD_PLATFORM_UNFREEZE": (10024, u"第三方解冻"),
})


TRANSACTION_STATUS = Enum({
    "WAIT": (0L, "wait"),
    "DONE": (1L, "finished"),
    "FAIL": (2L, "fail")
})

WITHDRAW_STATUS = Enum({
    "WAIT": (1L, u"未提现"),
    "DONE": (2L, u"已提现"),
    "FAIL": (4L, u"提现失败"),
    "AUTO": (8L, u"自动提现中"),
    "FORBIDDEN": (16L, u'禁止提现'),
    "BACK": (32L, u"提现失败，返回余额"),
    "SUBMIT_TO_THIRD": (64L, u"已提交第三方提现中")
})

# 遗留BUG,客户端的状态和服务端不一致
FIX_WITHDRAW_STATUS = {
    WITHDRAW_STATUS.WAIT: 0,
    WITHDRAW_STATUS.DONE: 1,
    WITHDRAW_STATUS.FAIL: 2,
    WITHDRAW_STATUS.AUTO: 0,
    WITHDRAW_STATUS.FORBIDDEN: 2,
    WITHDRAW_STATUS.BACK: 2,
    WITHDRAW_STATUS.SUBMIT_TO_THIRD: 0
}

WITHDRAW_TYPE = Enum({
    "BANKCARD": (0L, u"银行卡"),
    "ALIPAY": (1L, u"支付宝"),
    'QQPAY': (12, u'qq钱包'),
    'WECHATPAY': (13L, u'微信')
})

WITHDRAW_CHANNELS = Enum({
    'JUSTPAY_ALIPAY': ('justpay_alipay', u'justpay 支付宝'),
    'GROUP_ALIPAY': ('group_alipay', u'集团支付宝'),
    'UNIONAGENCY_BANKCARD': ('unionagency_bankcard', u'unionagency 银行卡')
})

TITLE_MAPPER = {
    u'充值': u'充值',
    u'提现': u'提现',
    u'派奖': u'购彩中奖',
    u'加奖': u'购彩加奖',
    u'红包抵扣': u'红包抵扣',
    u'大转盘': {2: u'转盘奖励', 4: u'参与转盘'},
    u'牛牛': {2: u'牛牛奖励', 4: u'参与牛牛'},
    u'捉金鸡': {2: u'slots奖励', 4: u'参与slots'},
    u'幸运星': {2: u'slots奖励', 4: u'参与slots'},
    u'水果机': {2: u'水果机奖励', 4: u'参与水果机'},
    u'提现失败返款': u'提现退款',
    u'追号返款': u'购彩退款',
    u'购彩': u'购彩'
}

RISK_STATUS = Enum({
    "NONE": (0L, None),
    "ALL": (1L << 0, u"auto_risk"),
    "TEST": (1L << 1, u"测试用户"),
    "BLACK_USER": (1L << 2, u"黑名单用户"),
    "BLACK_ACCOUNT": (1L << 3, u"黑名单收款账户"),
    "BLACK_NAME": (1L << 4, u'黑名单收款姓名'),
    "ILLEGAL": (1L << 5, u"非法用户"),
    "NO_USER_STATS": (1L << 6, u"不存在累积数据"),
    "NO_RECHARGE": (1L << 7, u"没有充值"),
    "WITHDRAW_MORE": (1L << 8, u"累积提现%/累积充值%>="),
    "RECHARGE_APP_PAY": (1L << 9, u"apple pay用户"),
    "WIN_MORE": (1L << 10, u"盈利总额%/累积充值%>="),
    "TRUE_PROFIT": (1L << 11, u"累计提现%-累积充值%-余额%>="),
    "PRODUCT_WIN_MORE": (1L << 12, u"累计产品%玩法用户盈利%超过"),
    "NO_DAILY_STATS": (1L << 13, u"不存在今日数据"),
    "NO_Today_GAIN": (1L << 14, u"今日盈利数据缺失"),
    "TODAY_GAIN_LIMIT": (1L << 15, u"今日盈利%超过限额"),
    "TODAY_WITHDRAW_LIMIT": (1L << 16, u"当前提现金额%超限"),
    "TODAY_PRODUCT_WIN_MORE_RECHARGE": (1L << 17, u"当日产品%玩法用户盈利超过充值金额"),
    "TODAY_PRODUCT_WIN_LIMIT": (1L << 18, u"今日提现%-今日玩法用户盈利%"),
    "WITHDRAW_LIMIT": (1L << 19, u"当前提现金额%超限"),
    "TODAY_WITHDRAW_AMOUNT_LIMIT": (1L << 20, u"收款账号今日提现%超过"),
    "TODAY_PRODUCT_WIN_MORE": (1L << 21, u"当日产品%玩法用户盈利%超过"),
    "TELEMARKETING": (1L << 22, u"电销黑名单"),
    "OPERATION": (1L << 23, u"运营黑名单")
})


BANK_CODE_MAP = {u"汇丰银行": "HSBC",
                 u"浙江稠州商业银行": "CZCB",
                 u"长沙银行": "CSCB",
                 u"上海农商银行": "SRCB",
                 u"江苏银行": "JSBANK",
                 u"甘肃银行": "GSBANK",
                 u"江西省农村信用社": "JXRCU",
                 u"汉口银行": "HKB",
                 u"湖北银行": "HBC",
                 u"云南红塔银行": "YXCCB",
                 u"衡水市商业银行": "HSBK",
                 u"沧州银行": "BOCZ",
                 u"宁波通商银行": "NBCBANK",
                 u"梅县客家村镇银行": "KJCZYH",
                 u"威海市商业银行": "WHCCB",
                 u"天津滨海农村商业银行": "TJBHB",
                 u"遂宁银行": "SNCCB",
                 u"上饶银行": "SRBANK",
                 u"曲靖市商业银行": "QJCCB",
                 u"河北省农村信用社": "HBRCU",
                 u"鄞州银行": "NBYZ",
                 u"东营银行": "DYCCB",
                 u"东莞农村商业银行": "DRCBCL",
                 u"江苏长江商业银行": "CJCCB",
                 u"中原银行": "ZYB",
                 u"成都农村商业银行": "CDRCB",
                 u"南京银行": "NJCB",
                 u"南海农商银行": "NHB",
                 u"福建海峡银行": "FJHXBC",
                 u"张家口银行": "ZJKCCB",
                 u"韩亚银行": "HANABANK",
                 u"深圳农村商业银行": "SZRCB",
                 u"盘锦银行": "PJCCB",
                 u"葫芦岛银行": "HLDB",
                 u"吉林省农村信用社": "JLRCU",
                 u"厦门银行": "XMBANK",
                 u"陕西省农村信用社": "SXRCCU",
                 u"营口沿海银行": "YKYHCCB",
                 u"广东华兴银行": "GHB",
                 u"大连农村商业银行": "DLRCB",
                 u"盛京银行": "SJBANK",
                 u"浙江泰隆商业银行": "ZJTLCB",
                 u"中国邮政储蓄银行": "PSBC",
                 u"邮政储蓄银行": "PSBC",
                 u"邮政银行": "PSBC",
                 u"三门峡银行": "SCCB",
                 u"邢台银行": "XTB",
                 u"广州银行": "GCB",
                 u"唐山银行": "TSCCB",
                 u"海南省农村信用社": "BOHN",
                 u"郑州银行": "ZZBANK",
                 u"吴江农村商业银行": "WJRCB",
                 u"昆山农商银行": "KSRB",
                 u"银座村镇银行": "YZBANK",
                 u"北京银行": "BJBANK",
                 u"承德银行": "BOCD",
                 u"宁波东海银行": "NDHB",
                 u"昆仑银行": "KLB",
                 u"广东省农村信用社联合社": "GDRCC",
                 u"晋城银行": "JINCHB",
                 u"成都银行": "CDCB",
                 u"天津武清村镇银行": "TJWQCZ",
                 u"营口银行": "BOYK",
                 u"晋商银行": "JSB",
                 u"绵阳市商业银行": "MYBANK",
                 u"联合村镇银行": "URB",
                 u"顺德农商银行": "SDEB",
                 u"外换银行": "KEB",
                 u"贵州省农村信用社联合社": "GZRCU",
                 u"济宁银行": "JNBANK",
                 u"广东南粤银行": "NYBANK",
                 u"富滇银行": "FDB",
                 u"东莞银行": "BOD",
                 u"东营莱商村镇银行": "DYLSCZ",
                 u"烟台银行": "YTBANK",
                 u"河北银行": "BHB",
                 u"广西壮族自治区农村信用社联合社": "GXRCU",
                 u"锦州银行": "BOJZ",
                 u"新韩银行": "BOSH",
                 u"湖南农村信用社": "HNRCC",
                 u"华融湘江银行": "HRXJB",
                 u"恒丰银行": "EGBANK",
                 u"厦门国际银行": "XIB",
                 u"山东农村信用社": "SDRCU",
                 u"赣州银行": "GZB",
                 u"齐商银行": "ZBCB",
                 u"石嘴山银行": "SZSBK",
                 u"其它银行": "OTHERS",
                 u"山西省农村信用社": "SXRCU",
                 u"浙江省农村信用社联合社": "ZJNX",
                 u"晋中银行": "JZBANK",
                 u"哈尔滨银行": "HRBB",
                 u"中信银行": "CNCB",
                 u"阜新银行": "FXCB",
                 u"北京农商银行": "BJRCB",
                 u"中国光大银行": "CEB",
                 u"光大银行": "CEB",
                 u"平顶山银行": "BOP",
                 u"辽宁农村信用社": "LNRCC",
                 u"农村商业银行": "RCB",
                 u"四川天府银行": "CGNB",
                 u"河南省农村信用社": "HNRCU",
                 u"辽阳银行": "LYCB",
                 u"秦皇岛银行": "BOQHD",
                 u"齐鲁银行": "QLBANK",
                 u"交通银行": "BCM",
                 u"西安银行": "XABANK",
                 u"云南省农村农信社": "YNRCC",
                 u"洛阳银行": "BOL",
                 u"宁夏银行": "NXBANK",
                 u"四川省农村信用社": "SCRCU",
                 u"无锡农村商业银行": "WRCB",
                 u"中国工商银行": "ICBC",
                 u"工商银行": "ICBC",
                 u"内蒙古银行": "H3CB",
                 u"浙江民泰商业银行": "MTBANK",
                 u"长春朝阳和润村镇银行": "CCHRCZYH",
                 u"九江银行": "JJBANK",
                 u"莱商银行": "LSBANK",
                 u"德阳银行": "BODY",
                 u"廊坊银行": "LANGFB",
                 u"青海银行": "BOQH",
                 u"苏州银行": "BOSZ",
                 u"枣庄银行": "ZZYH",
                 u"东亚银行": "HKBEA",
                 u"柳州银行": "LZCCB",
                 u"乌海银行": "WHBANK",
                 u"中银富登村镇银行": "BOCFCB",
                 u"上海银行": "SHBANK",
                 u"贵阳银行": "GYCB",
                 u"焦作中旅银行": "JZCBANK",
                 u"嘉兴银行": "JXBANK",
                 u"中国民生银行": "CMBC",
                 u"浙商银行": "CZB",
                 u"铁岭银行": "TLBANK",
                 u"渤海银行": "BOHAIB",
                 u"中国银行": "BOC",
                 u"澳门商业银行": "BCMBANK",
                 u"长城华西银行": "DYCB",
                 u"华夏银行": "HXB",
                 u"福建省农村信用社联合社": "FJNX",
                 u"江苏太仓农村商业银行": "TCRCB",
                 u"桂林银行": "GLBANK",
                 u"金华银行": "JHBANK",
                 u"江苏省农村信用社联合社": "JSRCU",
                 u"招商银行": "CMB",
                 u"张家港农商银行": "ZRCBANK",
                 u"青海省农村信用社": "QHRC",
                 u"龙江银行": "DAQINGB",
                 u"湖商村镇银行": "HSCZB",
                 u"中国建设银行": "CCB",
                 u"建设银行": "CCB",
                 u"潍坊银行": "BANKWF",
                 u"黄河农村商业银行": "YRRCB",
                 u"广西北部湾银行": "BGB",
                 u"鑫汇村镇银行": "XHDLCZ",
                 u"南阳市商业银行": "BNY",
                 u"重庆农村商业银行": "CRCBANK",
                 u"徽商银行": "HSBANK",
                 u"江南农村商业银行": "CZRCB",
                 u"漯河银行": "LHBANK",
                 u"广西农村信用社": "GXNX",
                 u"湖州银行": "HZCCB",
                 u"安徽省农村信用社": "ARCU",
                 u"富邦华一银行": "FBBANK",
                 u"长春经开融丰村镇银行": "JKRFCZYH",
                 u"邯郸银行": "HDBANK",
                 u"海口联合农商银行": "UBCHN",
                 u"江西银行": "NCB",
                 u"日照银行": "RZB",
                 u"保定银行": "BDCBANK",
                 u"宜宾市商业银行": "YBCCB",
                 u"新疆农村信用社": "XJRCU",
                 u"友利银行": "WOORI",
                 u"尧都农商银行村镇银行": "YDNSCZYH",
                 u"江阴农商银行": "JYRCB",
                 u"贵州银行": "ZYCBANK",
                 u"杭州银行": "HZCB",
                 u"包商银行": "BSB",
                 u"天津农商银行": "TRCB",
                 u"重庆银行": "CQBANK",
                 u"黑龙江农信": "HLJRCU",
                 u"平安银行": "PAB",
                 u"德州银行": "DZBANK",
                 u"内蒙古农村信用社": "NMGNXS",
                 u"榆次融信村镇银行": "RXCB",
                 u"临商银行": "LSBC",
                 u"珠海华润银行": "RBOZ",
                 u"兴业银行": "CIB",
                 u"湖北省农村信用社": "HURCB",
                 u"台州银行": "TZCB",
                 u"微众银行": "WEBANK",
                 u"乐山银行": "LSCCB",
                 u"江苏江阴农村商业银行": "JRCB",
                 u"鄂尔多斯银行": "ORBANK",
                 u"宁夏黄河农村商业银行": "NXRCU",
                 u"网商银行": "ANTBANK",
                 u"中国农业银行": "ABC",
                 u"农业银行": "ABC",
                 u"攀枝花市商业银行": "PZHCCB",
                 u"广州农村商业银行": "GRCB",
                 u"温州银行": "WZCB",
                 u"长安银行": "CABANK",
                 u"自贡银行": "ZGCCB",
                 u"重庆三峡银行": "CCQTGB",
                 u"天津银行": "TCCB",
                 u"泰安市商业银行": "TACCB",
                 u"新疆汇合银行": "BOHH",
                 u"鞍山银行": "ASCB",
                 u"韩国企业银行": "QYBANK",
                 u"武汉农村商业银行": "WHRCB",
                 u"常熟农商银行": "CSRCB",
                 u"兰州银行": "LZYH",
                 u"广发银行": "CGB",
                 u"乌鲁木齐银行": "URMQCCB",
                 u"青岛银行": "QDCCB",
                 u"泉州银行": "BOQZ",
                 u"绍兴银行": "SXCB",
                 u"长春绿园融泰村镇银行": "LYRTCZYH",
                 u"泸州市商业银行": "LUZBANK",
                 u"大连银行": "DLB",
                 u"甘肃省农村信用社": "GSRCU",
                 u"吉林银行": "JLBANK",
                 u"抚顺银行": "BOFS",
                 u"宁波银行": "NBBANK",
                 u"浦发银行": "SPDB",
                 u"上海浦东发展银行": "SPDB",
                 }


WITHDRAW_BASE = 10


class Transaction(orm.Model):
    __tablename__ = "transaction"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


CHECK_STATUS = Enum({
    "NULL": (0L, u"无需审核"),
    "WAITING": (1L, u"待审核"),
    "SUCC": (2L, u"审核通过"),
    "FAIL": (4L, u"审核未通过"),
})


class Withdraw(orm.Model):
    __tablename__ = 'withdraw'
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    trans_id = orm.Column(orm.BigInteger)  # 每笔提现对应一笔交易记录
    target_type = orm.Column(orm.SmallInteger)  # 提现方式
    user_id = orm.Column(orm.BigInteger)
    status = orm.Column(orm.Integer)  # 提现状态
    check_status = orm.Column(orm.Integer, default=0)  # 提现状态
    price = orm.Column(orm.FLOAT)  # 用户提现金额
    real_price = orm.Column(orm.FLOAT)  # 用户实际提现金额
    after_cash = orm.Column(orm.FLOAT)  # 用户提现后剩余可提现金额
    extend = orm.Column(orm.TEXT)  # 用户使用具体信息
    balance = orm.Column(orm.FLOAT)  # 用户余额
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)


class Transaction0(orm.Model):
    __tablename__ = "transaction_0"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction1(orm.Model):
    __tablename__ = "transaction_1"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction2(orm.Model):
    __tablename__ = "transaction_2"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction3(orm.Model):
    __tablename__ = "transaction_3"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction4(orm.Model):
    __tablename__ = "transaction_4"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction5(orm.Model):
    __tablename__ = "transaction_5"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction6(orm.Model):
    __tablename__ = "transaction_6"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction7(orm.Model):
    __tablename__ = "transaction_7"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction8(orm.Model):
    __tablename__ = "transaction_8"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction9(orm.Model):
    __tablename__ = "transaction_9"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction10(orm.Model):
    __tablename__ = "transaction_10"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction11(orm.Model):
    __tablename__ = "transaction_11"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction12(orm.Model):
    __tablename__ = "transaction_12"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction13(orm.Model):
    __tablename__ = "transaction_13"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction14(orm.Model):
    __tablename__ = "transaction_14"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction15(orm.Model):
    __tablename__ = "transaction_15"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction16(orm.Model):
    __tablename__ = "transaction_16"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction17(orm.Model):
    __tablename__ = "transaction_17"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction18(orm.Model):
    __tablename__ = "transaction_18"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


class Transaction19(orm.Model):
    __tablename__ = "transaction_19"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    type = orm.Column(orm.Integer)
    activity_type = orm.Column(orm.Integer, default=0)  # 彩种，默认为0表示充值
    # 关联的支付编号，refer Pay::id  type==1或2时，为None
    pay_id = orm.Column(orm.VARCHAR)
    status = orm.Column(orm.Integer, default=0)  # 交易是否完成
    title = orm.Column(orm.VARCHAR)
    price = orm.Column(orm.FLOAT)  # 交易的金额
    balance = orm.Column(orm.FLOAT)  # 交易后的账户余额
    order_id = orm.Column(orm.BigInteger)  # 对应type==2，关联的订单编号
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)
    extend = orm.Column(orm.TEXT)  # JSON，关联购买信息


TRANSACTION_SHARDING_COUNT = 20

TRANSACTION_SHARDING_CONFIG = {
    0: Transaction0,
    1: Transaction1,
    2: Transaction2,
    3: Transaction3,
    4: Transaction4,
    5: Transaction5,
    6: Transaction6,
    7: Transaction7,
    8: Transaction8,
    9: Transaction9,
    10: Transaction10,
    11: Transaction11,
    12: Transaction12,
    13: Transaction13,
    14: Transaction14,
    15: Transaction15,
    16: Transaction16,
    17: Transaction17,
    18: Transaction18,
    19: Transaction19,
}
