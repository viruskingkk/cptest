#! -*- coding:utf-8 -*-
from datetime import datetime
from sqlalchemy import func

from common import orm
from common.account.model.account import Account, BALANCE_TYPE
from common.utils.db import list_object, generate_filter, parse_query_dct, get_count, paginate
from common.platform.common.model import M_TRANSACTION_TYPE, ThirdTransaction, ThirdWithdrawTransactionLog
from common.platform.common.model import PLATFORM_TYPE
from common.transaction.model import TRANSACTION_TYPE, TRANSACTION_STATUS
from common.transaction.db import create_transaction
from common.platform.integrate import get_third_handler
from common.stats import MG_BIGBANG_COLL
from common.utils import track_logging, decorator, tracker
from common.utils.currency import convert_yuan_to_fen, convert_fen_to_yuan, convert_fen_to_hao
from common.utils.tz import today_str, get_utc_date

_LOGGER = track_logging.getLogger(__name__)


def frozen_balance(user_id, platform, amount, ref_id):
    """
    冻结资金到第三方游戏平台

    :param user_id:
    :param platform:
    :param amount: 单位是分
    :param ref_id: 交易唯一订单号
    :return:
    """
    _LOGGER.info(
        'begin frozen_balance: uid: {}, platform: {}, amount: {}, ref_id: {}'.format(user_id, platform, amount, ref_id))
    assert user_id > 0
    assert platform in PLATFORM_TYPE.values()

    try:
        if amount <= 0:
            return
        trans = get_transaction_by_ref_id(M_TRANSACTION_TYPE.FROZEN, ref_id)
        if trans:
            return trans

        # 添加第三方交易信息
        trans = add_transaction(user_id, platform, ref_id, M_TRANSACTION_TYPE.FROZEN, amount, amount)

        # 在交易总表中创建交易，并减少用户余额
        _, account = create_transaction({
            'user_id': user_id,
            'type': TRANSACTION_TYPE.THIRD_PLATFORM_FROZEN,
            'title': u'{}游戏登录'.format(PLATFORM_TYPE.get_label(platform)),
            'price': -convert_fen_to_hao(amount),
            'balance_type': BALANCE_TYPE.BALANCE,
            'order_id': trans.id,
            'status': TRANSACTION_STATUS.DONE,
        })

        # 在第三方交易中，记录当前用户的余额
        trans.curr_balance = convert_yuan_to_fen(account['balance'])
        trans.curr_withdraw = convert_yuan_to_fen(account['withdraw'])

        orm.session.commit()
        _LOGGER.info('finish frozen_balance: {} {} {} {}'.format(user_id, platform, amount, ref_id))
        return trans
    except:
        orm.session.rollback()
        raise
    finally:
        orm.session.close()


def reverse_not_existed_fronzen(user_id, ref_id):
    """
    回滚 冻结资金到第三方游戏平台 操作.

    :param user_id:
    :param ref_id:
    :return: (boolean: 是否本次成功, reverse_trans: 冲正trans)
    """
    try:
        _LOGGER.info('begin reverse frozen_balance : {} {}'.format(user_id, ref_id))
        deposit_trans = get_transaction_by_ref_id(M_TRANSACTION_TYPE.FROZEN, ref_id)
        if not deposit_trans:
            return
        reverse_trans = get_transaction_by_ref_id(M_TRANSACTION_TYPE.FROZEN_REVERSE, ref_id)
        if reverse_trans:
            return False, reverse_trans

        reverse_trans = add_transaction(user_id, deposit_trans.platform, ref_id, M_TRANSACTION_TYPE.FROZEN_REVERSE,
                                        -deposit_trans.balance, -deposit_trans.withdraw)

        # 创建交易，并增加用户余额
        _, account = create_transaction({
            'user_id': user_id,
            'type': TRANSACTION_TYPE.THIRD_PLATFORM_UNFREEZE,
            'title': u'{}游戏退出'.format(PLATFORM_TYPE.get_label(reverse_trans.platform)),
            'price': convert_fen_to_hao(reverse_trans.balance),
            'balance_type': BALANCE_TYPE.BALANCE,
            'order_id': reverse_trans.id,
            'status': TRANSACTION_STATUS.DONE,
        })

        # 在第三方交易中，记录当前用户的余额
        reverse_trans.curr_balance = convert_yuan_to_fen(account['balance'])
        reverse_trans.curr_withdraw = convert_yuan_to_fen(account['withdraw'])

        orm.session.commit()
        _LOGGER.info('finish reverse frozen_balance: {} {}'.format(user_id, ref_id))
        return True, reverse_trans
    except:
        orm.session.rollback()
        raise
    finally:
        orm.session.close()


def unfreeze_balance(user_id, platform, amount, ref_id):
    """
    从第三方平台提现钱到witch

    :param user_id:
    :param platform:
    :param amount: 单位是分
    :param ref_id: 交易唯一订单号
    :return:
    """
    assert user_id > 0
    _LOGGER.info(
        'begin unfreeze_balance: uid: {}, platform: {}, amount: {}, ref_id: {}'.format(user_id, platform, amount,
                                                                                       ref_id))
    try:
        if amount < 0:
            return

        trans = get_transaction_by_ref_id(M_TRANSACTION_TYPE.UNFREEZE, ref_id)
        if trans:
            return trans
        trans = add_transaction(user_id, platform, ref_id, M_TRANSACTION_TYPE.UNFREEZE, amount, 0)
        # 创建交易，并增加用户余额
        _, account = create_transaction({
            'user_id': user_id,
            'type': TRANSACTION_TYPE.THIRD_PLATFORM_UNFREEZE,
            'title': u'{}游戏退出'.format(PLATFORM_TYPE.get_label(platform)),
            'price': convert_fen_to_hao(amount),
            'balance_type': BALANCE_TYPE.BALANCE,
            'order_id': trans.id,
            'status': TRANSACTION_STATUS.DONE,
        })

        # 在第三方交易中，记录当前用户的余额
        trans.curr_balance = convert_yuan_to_fen(account['balance'])
        trans.curr_withdraw = convert_yuan_to_fen(account['withdraw'])

        orm.session.commit()
        _LOGGER.info('finish unfreeze_balance from {}: {} {} {} {}'.format(platform, user_id,
                                                                           trans.balance, trans.withdraw, ref_id))
        return trans
    except:
        orm.session.rollback()
        raise
    finally:
        orm.session.close()


def add_transaction(user_id, platform, ref_id, trans_type, balance, withdraw):
    assert user_id > 0
    assert platform in PLATFORM_TYPE.values()
    assert ref_id
    assert trans_type in M_TRANSACTION_TYPE.values()
    assert balance > 0
    assert withdraw >= 0
    assert balance or withdraw
    trans = ThirdTransaction()
    trans.platform = platform
    trans.user_id = user_id
    trans.ref_id = ref_id
    trans.type = trans_type

    last_trans = get_latest_trans(user_id, platform)
    if trans_type == M_TRANSACTION_TYPE.FROZEN:
        assert balance >= withdraw
        balance = -balance
        withdraw = -withdraw
    elif trans_type == M_TRANSACTION_TYPE.FROZEN_REVERSE:
        pass
    elif trans_type == M_TRANSACTION_TYPE.UNFREEZE:
        last_frozen_trans = get_latest_trans(user_id, platform, trans_type=M_TRANSACTION_TYPE.FROZEN)
        assert last_frozen_trans

        if platform == PLATFORM_TYPE.METIS:
            accu_win_amount = get_third_handler(platform).calculate_accumulated_win_amount(user_id,
                                        last_frozen_trans.created_at, datetime.utcnow())
        else:
            # 对于IMone和ametis，没有办法直接使用他们的数据库，快速去获取获利金额
            accu_win_amount = balance + last_frozen_trans.balance
            accu_win_amount = accu_win_amount if accu_win_amount > 0 else 0
        withdraw = min(accu_win_amount + -last_frozen_trans.withdraw, balance)
    else:
        raise Exception('trans type error')

    trans.balance = balance
    trans.withdraw = withdraw

    trans.accu_balance = (last_trans.accu_balance if last_trans else 0) + balance

    trans.save(auto_commit=False)
    orm.session.flush()
    return trans


def get_transaction_by_id(trans_id):
    assert trans_id > 0
    metis_trans = ThirdTransaction.query.filter_by(id=trans_id).order_by(ThirdTransaction.id.desc()).first()
    return metis_trans


def get_transaction_by_ref_id(trans_type, ref_id):
    assert trans_type in M_TRANSACTION_TYPE.values()
    assert ref_id
    metis_trans = ThirdTransaction.query.filter_by(type=trans_type, ref_id=ref_id).order_by(
        ThirdTransaction.id.desc()).first()
    return metis_trans


def add_withdraw_trans_log(user_id, platform, amount, ref_id):
    if amount <= 0:
        return
    try:
        withdraw_trans_log = ThirdWithdrawTransactionLog(user_id=user_id, platform=platform,
                                                         amount=amount, ref_id=ref_id)
        withdraw_trans_log.save()
        return withdraw_trans_log.id
    finally:
        orm.session.close()


def delete_withdraw_trans_log(w_id):
    try:
        withdraw_trans_log = ThirdWithdrawTransactionLog.query.filter_by(id=w_id)
        withdraw_trans_log.delete()
        orm.session.commit()
    finally:
        orm.session.close()


def set_withdraw_trans_checked(w_id):
    withdraw_trans = ThirdWithdrawTransactionLog.query.filter_by(id=w_id).first()
    if withdraw_trans:
        withdraw_trans.checked = True
    withdraw_trans.save()
    orm.session.commit()
    orm.session.close()


def _calc_current_amount(account, trans):
    trans.curr_balance = convert_yuan_to_fen(account.balance)
    trans.curr_withdraw = convert_yuan_to_fen(account.withdraw)
    return trans


def get_user_today_game_effective_bet(user_id):
    """
    获取用户当天电玩城的有效投注
    :param user_id:
    :return:
    """
    user_data = MG_BIGBANG_COLL.daily_stats.find_one({'_id': '%s-%s' % (user_id, today_str())})
    if not user_data:
        return 0

    user_metis_data = user_data.get('metis', {})

    mties_total_bet = user_metis_data.get('total_bet', 0)
    mties_invalid_amount = user_metis_data.get('invalid_amount', 0)

    lottery = user_data.get('lottery', {}).get('bet_amount', 0)
    kfc = user_data.get('kfc', {}).get('bet_amount', 0)
    fruit = user_data.get('fruit', {}).get('bet_amount', 0)
    bull = user_data.get('bull', {}).get('bet_amount', 0)

    return mties_total_bet + lottery + kfc + fruit + bull - mties_invalid_amount


def get_latest_trans(user_id, platform=None, trans_type=None):
    query = ThirdTransaction.query.filter(
        ThirdTransaction.user_id == user_id).order_by(
        ThirdTransaction.id.desc())
    if platform is not None:
        query = query.filter_by(platform=platform)
    if trans_type:
        query = query.filter_by(type=trans_type)
    return query.first()


@decorator.sql_wrapper
def set_transaction_checked(trans_type, ref_id):
    trans = get_transaction_by_ref_id(trans_type, ref_id)
    if trans:
        trans.checked = True
        trans.save()


logout_type = (M_TRANSACTION_TYPE.UNFREEZE, M_TRANSACTION_TYPE.FROZEN_REVERSE)


@decorator.sql_wrapper
def query_game_trans(query_dct):
    page = query_dct.pop('$page')
    size = query_dct.pop('$size')
    query, total_count = list_object(query_dct, ThirdTransaction, disable_paginate=True)
    total_login = query.with_entities(func.sum(ThirdTransaction.balance)).filter(
        ThirdTransaction.type == M_TRANSACTION_TYPE.FROZEN).scalar() or 0
    total_logout = query.with_entities(func.sum(ThirdTransaction.balance)).filter(
        ThirdTransaction.type.in_(logout_type)).scalar() or 0
    query = query.order_by(ThirdTransaction.id.desc())

    page_query_dct = {'$page': page, '$size': size}
    query = query.filter(generate_filter(parse_query_dct(page_query_dct, ThirdTransaction), ThirdTransaction))
    query = paginate(query, page_query_dct)
    return query.all(), total_count, total_login, total_logout


@decorator.sql_wrapper
def get_today_profit(user_id, platform):
    today_utc_date = get_utc_date()
    item = ThirdTransaction.query.filter(ThirdTransaction.user_id == user_id).\
        filter(ThirdTransaction.updated_at >= today_utc_date). \
        filter(ThirdTransaction.platform == platform).first()
    if not item:
        return 0
    profit = ThirdTransaction.query.filter(ThirdTransaction.user_id == user_id).\
        filter(ThirdTransaction.id >= item.id). \
        filter(ThirdTransaction.platform == platform).\
        with_entities(func.sum(ThirdTransaction.balance)).scalar()
    return convert_fen_to_yuan(profit)
