# -*- coding: utf-8 -*-
from common import orm
from common.utils.types import Enum

# SPRING_FESTIVAL_TASK_TYPE = Enum({
#     "TASK1": (1L, u"充值任意金额"),
#     "TASK2": (2L, u"购买任意彩票"),
#     "TASK3": (3L, u"参与电玩城任意游戏"),
#     "TASK4": (4L, u"充值累计达100元"),
#     "TASK5": (5L, u"购买彩票累计达100元"),
#     "TASK6": (6L, u"参与电玩城累计达100元"),
# })


SPRING_FESTIVAL_TASK_TYPE = Enum({
    "RECHARGE": ('recharge', u"充值活动"),
    "LOTTERY_JOIN": ('lottery_join', u"购买彩票活动"),
    "GAME_JOIN": ('game_join', u"参与电玩城活动"),
})

SPRING_FESTIVAL_TASK_JOIN_STATUS = Enum({
    "UNLOGIN": ('unlogin', u"未登录"),
    "UNSTART": ('unstart', u"未开始"),
    "ONGOING": ('ongoing', u"进行中"),
    "END": ('end', u"已结束"),
    "TODO": ('todo', u"未满足条件"),
    "DONE": ('done', u"满足条件，但未领取奖励"),
    "RECEIVED": ('received', u"已领取奖励"),
})

SPRING_FESTIVAL_TASK_PRIZE = [
    ([.1, .2, .3, .4, .5], [.2, .2, .2, .2, .2]),
    ([1, 2, 3, 4, 5], [.2, .2, .2, .2, .2])
]

SPRING_FESTIVAL_TASK = [
    {
        "id": 1,
        "name": u"充值任意金额",
        "activity_type": SPRING_FESTIVAL_TASK_TYPE.RECHARGE,
        "min_bonus": 0.1,
        "max_bonus": 1,
        "status": SPRING_FESTIVAL_TASK_JOIN_STATUS.TODO,
        "threshold": 0,
        "prize_conf": 0
    },
    {
        "id": 2,
        "name": u"购买任意彩票",
        "activity_type": SPRING_FESTIVAL_TASK_TYPE.LOTTERY_JOIN,
        "min_bonus": 0.1,
        "max_bonus": 1,
        "status": SPRING_FESTIVAL_TASK_JOIN_STATUS.TODO,
        "threshold": 0,
        "prize_conf": 0

    },
    {
        "id": 3,
        "name": u"参与电玩城任意游戏",
        "activity_type": SPRING_FESTIVAL_TASK_TYPE.GAME_JOIN,
        "min_bonus": 0.1,
        "max_bonus": 1,
        "status": SPRING_FESTIVAL_TASK_JOIN_STATUS.TODO,
        "threshold": 0,
        "prize_conf": 0
    },

    {
        "id": 4,
        "name": u"充值累计达100元",
        "activity_type": SPRING_FESTIVAL_TASK_TYPE.RECHARGE,
        "min_bonus": 1,
        "max_bonus": 10,
        "status": SPRING_FESTIVAL_TASK_JOIN_STATUS.TODO,
        "threshold": 100,
        "prize_conf": 1
    },
    {
        "id": 5,
        "name": u"购买彩票累计达100元",
        "activity_type": SPRING_FESTIVAL_TASK_TYPE.LOTTERY_JOIN,
        "min_bonus": 1,
        "max_bonus": 10,
        "status": SPRING_FESTIVAL_TASK_JOIN_STATUS.TODO,
        "threshold": 100,
        "prize_conf": 1
    },
    {
        "id": 6,
        "name": u"参与电玩城累计达100元",
        "activity_type": SPRING_FESTIVAL_TASK_TYPE.GAME_JOIN,
        "min_bonus": 1,
        "max_bonus": 10,
        "status": SPRING_FESTIVAL_TASK_JOIN_STATUS.TODO,
        "threshold": 100,
        "prize_conf": 1
    },

]


class SpringFestivalRecord(orm.Model):
    '''
    春节福利领取记录
    '''
    __tablename__ = "activity_spring_festival"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    user_name = orm.Column(orm.VARCHAR)  # 用户名 (冗余，方便展示)
    date = orm.Column(orm.Date)  # 领取日期
    amount = orm.Column(orm.FLOAT)  # 领取的金额，单位元
    task_id = orm.Column(orm.Integer)
    created_at = orm.Column(orm.DATETIME)  # 下单时间
    updated_at = orm.Column(orm.DATETIME)
