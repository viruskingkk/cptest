# -*- coding: utf-8 -*-
from common import orm
from common.lottery.cyclical import ACTIVITY_STATUS
from common.lottery.cyclical.cp11x5.model import Trend as Trend_11x5
from common.lottery.cyclical.cp11x5.model import Activity as Activity_11x5


class Activity(orm.Model, Activity_11x5):
    __tablename__ = "jx_11x5"


class Trend(orm.Model, Trend_11x5):
    __tablename__ = "jx_11x5_trend"
