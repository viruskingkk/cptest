# -*- coding: utf-8 -*-
from common import orm
from common.utils.types import Enum

DAILY_AWARD = [1888, 988, 688, 588, 488, 388, 288, 188, 88, 68]
TOTAL_AWARD = [8888, 6666, 3888, 2998, 1998, 1688, 998, 888, 688, 328]

RECORD_TYPE = Enum({
    "DAILY": (0L, u"每日榜"),
    "TOTAL": (1L, u"总榜"),
})

RANK_ACTIVITY_STATUS = Enum({
    "NOT_START": (0, u"还未开始"),
    "ON_GOING": (1, u"进行中"),
    "END": (2, u"结束")
})


class RankingRecord(orm.Model):
    '''
    财富风云榜
    '''
    __tablename__ = "ranking_activity_record"
    id = orm.Column(orm.BigInteger, primary_key=True, autoincrement=True)
    user_id = orm.Column(orm.BigInteger)
    user_name = orm.Column(orm.VARCHAR)  # 用户名 (冗余，方便展示)
    total_join = orm.Column(orm.FLOAT, default=0.0)    # 累计参与金额
    amount = orm.Column(orm.FLOAT, default=0.0)  # 奖励金额
    date = orm.Column(orm.Date)
    rank = orm.Column(orm.Integer)
    record_type = orm.Column(orm.Integer, default=0)
    created_at = orm.Column(orm.DATETIME)
    updated_at = orm.Column(orm.DATETIME)