from django.conf import settings
from datetime import datetime
from django.conf import settings
from functools import wraps
from django.db import connection


def dummy_send_auth_code(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not settings.IS_PRODUCTION_ENV:
            return save_dummy_auth_code(args[0], args[1])
        return func(*args, **kwargs)

    return wrapper


def save_dummy_auth_code(phone, code=None):
    mobiles = phone if type(phone) == list else [phone, ]

    message = str(code)

    tables = connection.introspection.table_names()
    if 'sms_dummy' not in tables:
        create_sql = "CREATE TABLE sms_dummy (created_at varchar(255), phone varchar(255), message varchar(255));"
        connection.cursor().execute(create_sql)

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for mobile in mobiles:
        insert_sql = "INSERT INTO sms_dummy VALUES('" + now + "','" + str(mobile) + "','" + message + "')"
        connection.cursor().execute(insert_sql)
    return True
